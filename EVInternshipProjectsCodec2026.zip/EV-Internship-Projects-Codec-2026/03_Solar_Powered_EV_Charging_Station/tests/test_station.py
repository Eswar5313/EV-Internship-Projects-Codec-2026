"""pytest suite - run `pytest -q` from the project folder."""
import json
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.config import BATTERY, RESULTS_DIR, SEARCH  # noqa: E402
from src.dispatch import simulate  # noqa: E402
from src.economics import crf, evaluate  # noqa: E402
from src.load_profile import build_load  # noqa: E402
from src.sizing import choose_design, run_grid  # noqa: E402
from src.solar import load_nasa_power, poa_irradiance, pv_ac_per_kwp  # noqa: E402


@pytest.fixture(scope="module")
def weather():
    return load_nasa_power()


@pytest.fixture(scope="module")
def ac_per_kwp(weather):
    return pv_ac_per_kwp(weather)


@pytest.fixture(scope="module")
def load():
    return build_load()[0]


@pytest.fixture(scope="module")
def result(ac_per_kwp, load):
    return simulate(ac_per_kwp * 70, load, 125.0)


def test_nasa_file_complete(weather):
    assert len(weather) == 8760
    assert weather.ghi_wm2.min() >= 0
    assert 1400 < weather.ghi_wm2.sum() / 1000 < 2100   # plausible for NCR India


def test_poa_and_yield_plausible(weather, ac_per_kwp):
    poa = poa_irradiance(weather)
    assert poa.min() >= 0 and poa.max() < 1300
    assert (poa[weather.ghi_wm2 == 0] == 0).all()
    assert 1200 < ac_per_kwp.sum() < 1800                 # kWh/kWp/yr
    assert ac_per_kwp.max() <= 1 / 1.15 + 1e-9            # inverter clipping respected


def test_load_reproducible_and_positive(load):
    load2 = build_load()[0]
    assert np.allclose(load, load2)
    assert load.sum() > 0 and load.min() >= 0
    assert load.max() <= 2 * 7.4 + 30 + 1e-9              # never exceeds installed charger power


def test_hourly_energy_balance_closes(result):
    assert result.energy_balance_error() < 1e-9
    served = result.pv_to_load + result.batt_discharge
    assert np.allclose(served + result.unmet, result.load_kwh)


def test_battery_energy_balance_closes(result):
    eta = np.sqrt(BATTERY.round_trip_eff)
    assert result.battery_balance_error(eta, eta, BATTERY.soc_initial) < 1e-6


def test_soc_within_bounds(result):
    assert result.soc.min() >= BATTERY.soc_min - 1e-9
    assert result.soc.max() <= BATTERY.soc_max + 1e-9


def test_c_rate_limits(result):
    assert result.batt_charge.max() <= BATTERY.c_rate_charge * 125 + 1e-9
    assert result.batt_discharge.max() <= BATTERY.c_rate_discharge * 125 * np.sqrt(BATTERY.round_trip_eff) + 1e-9


def test_no_battery_means_more_unmet(ac_per_kwp, load):
    a = simulate(ac_per_kwp * 70, load, 0.0)
    b = simulate(ac_per_kwp * 70, load, 125.0)
    assert a.lpsp > b.lpsp


def test_chosen_design_meets_lpsp(ac_per_kwp, load):
    grid = run_grid(ac_per_kwp, load)
    chosen = choose_design(grid)
    assert chosen.lpsp <= SEARCH.lpsp_target
    assert grid.feasible.sum() > 0
    # the chosen design must be the cheapest feasible one
    assert chosen.npc_inr == grid[grid.feasible].npc_inr.min()


def test_economics_positive_and_consistent():
    ec = evaluate(70, 125, 53_000, 55_000)
    assert ec["lcoe_inr_per_kwh"] > 0
    assert ec["npc_inr"] > ec["total_capex_inr"]
    assert abs(crf(0.08, 20) - 0.10185) < 1e-4
    assert ec["grid_alternative_lcoe_inr_per_kwh"] > 0


def test_summary_json_exists_and_consistent():
    p = RESULTS_DIR / "summary.json"
    if not p.exists():
        pytest.skip("run main.py first")
    s = json.loads(p.read_text())
    d = s["dispatch_annual"]
    assert abs(d["served_kwh"] + d["unmet_kwh"] - d["load_kwh"]) < 1e-3
    assert d["lpsp"] <= SEARCH.lpsp_target
    assert s["economics"]["lcoe_inr_per_kwh"] > 0
