"""
Stochastic EV charging demand model (DECLARED SYNTHETIC - no measured station data).

For every day of the year:
  * number of sessions per vehicle class ~ Poisson(mean * weekend factor)
  * arrival time ~ Gaussian mixture (morning / midday / evening peaks)
  * energy per session ~ Uniform(kwh_min, kwh_max)
  * charging power = min(vehicle limit, charger rating)
A first-come-first-served port queue (2 x AC, 1 x DC) assigns a start time; a
customer who would wait more than `max_wait_min` leaves (counted as "lost", not
as unmet load).  Each session's energy is then spread over the hourly bins it
occupies, giving an 8760-h load profile in kWh.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .config import CHARGERS, LOAD_SEED, VEHICLES, ChargerParams, VehicleClass


@dataclass
class Session:
    day: int
    vclass: str
    charger: str
    arrival_h: float
    start_h: float
    end_h: float
    kwh: float
    power_kw: float
    served: bool


def _sample_arrival(rng: np.random.Generator, peaks) -> float:
    w = np.array([p[2] for p in peaks], dtype=float)
    idx = rng.choice(len(peaks), p=w / w.sum())
    mean, sd, _ = peaks[idx]
    return float(np.clip(rng.normal(mean, sd), 6.0, 22.5))  # station open 06:00-23:00


def generate_sessions(year_days: int = 365, seed: int = LOAD_SEED,
                      vehicles=VEHICLES, chargers: ChargerParams = CHARGERS,
                      weekday_of_day0: int = 2) -> list[Session]:
    """weekday_of_day0=2 -> 1 Jan 2025 is a Wednesday."""
    rng = np.random.default_rng(seed)
    sessions: list[Session] = []
    for d in range(year_days):
        weekend = ((weekday_of_day0 + d) % 7) >= 5
        day_sessions = []
        for v in vehicles:
            mean = v.sessions_per_weekday * (v.weekend_factor if weekend else 1.0)
            n = rng.poisson(mean)
            for _ in range(n):
                arr = _sample_arrival(rng, v.arrival_peaks)
                kwh = float(rng.uniform(v.kwh_min, v.kwh_max))
                rating = chargers.ac_kw if v.charger == "ac" else chargers.dc_kw
                p = min(v.power_kw, rating)
                day_sessions.append((arr, v, kwh, p))
        day_sessions.sort(key=lambda s: s[0])
        # FCFS port queue: free-time per port
        free = {"ac": [0.0] * chargers.n_ac, "dc": [0.0] * chargers.n_dc}
        for arr, v, kwh, p in day_sessions:
            ports = free[v.charger]
            i = int(np.argmin(ports))
            start = max(arr, ports[i])
            wait_min = (start - arr) * 60.0
            dur = kwh / p
            if wait_min > chargers.max_wait_min:
                sessions.append(Session(d, v.name, v.charger, arr, np.nan, np.nan, kwh, p, False))
                continue
            end = start + dur
            ports[i] = end
            sessions.append(Session(d, v.name, v.charger, arr, start, end, kwh, p, True))
    return sessions


def sessions_to_hourly(sessions: list[Session], year_days: int = 365) -> np.ndarray:
    """Spread each served session's energy over hourly bins (kWh per hour)."""
    load = np.zeros(year_days * 24)
    for s in sessions:
        if not s.served:
            continue
        t0, t1 = s.start_h, s.end_h
        h = int(np.floor(t0))
        while t0 < t1 and h < 24:
            seg = min(t1, h + 1.0) - t0
            if seg > 0:
                load[s.day * 24 + h] += seg * s.power_kw
            t0 = h + 1.0
            h += 1
        # any charging that spills past midnight is dropped (rare, session ends by ~23:30)
    return load


def build_load(seed: int = LOAD_SEED):
    sessions = generate_sessions(seed=seed)
    load = sessions_to_hourly(sessions)
    df = pd.DataFrame([s.__dict__ for s in sessions])
    return load, df


def load_summary(load: np.ndarray, sessions_df: pd.DataFrame) -> dict:
    served = sessions_df[sessions_df.served]
    return {
        "annual_load_kwh": float(load.sum()),
        "mean_daily_load_kwh": float(load.sum() / 365),
        "peak_hourly_load_kw": float(load.max()),
        "sessions_total": int(len(sessions_df)),
        "sessions_served": int(served.shape[0]),
        "sessions_lost_queue": int((~sessions_df.served).sum()),
        "kwh_by_class": served.groupby("vclass")["kwh"].sum().round(1).to_dict(),
        "sessions_by_class": served.groupby("vclass").size().to_dict(),
    }
