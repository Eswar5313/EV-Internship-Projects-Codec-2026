"""
Central configuration for the off-grid solar EV charging station model.

Every number here is either
  (a) taken from a cited source  -> see `SOURCES` at the bottom and README §Sources, or
  (b) an engineering ASSUMPTION  -> flagged with "ASSUMPTION" in the comment.
The same list is written to the "Assumptions_Sources" sheet of the Excel workbook
so the spreadsheet is self-documenting.
"""
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
NASA_FILE = DATA_DIR / "nasa_power_hourly_2025.csv"

# --------------------------------------------------------------------------- site
@dataclass(frozen=True)
class Site:
    name: str = "Ghaziabad, Uttar Pradesh, India"
    latitude: float = 28.67          # deg N  (NASA POWER query point)
    longitude: float = 77.42         # deg E
    tilt_deg: float = 28.0           # ASSUMPTION: tilt ~ latitude for annual-optimal fixed array
    azimuth_deg: float = 180.0       # facing due south (northern hemisphere)
    albedo: float = 0.20             # ASSUMPTION: typical ground albedo (Duffie & Beckman)
    year: int = 2025                 # NASA POWER data year


# ----------------------------------------------------------------------------- PV
@dataclass(frozen=True)
class PVParams:
    noct_c: float = 45.0             # ASSUMPTION: typical mono-PERC module NOCT (datasheets 42-46 C)
    temp_coeff_per_c: float = -0.0035  # ASSUMPTION: -0.35 %/C Pmax, typical mono-PERC datasheet
    soiling: float = 0.96            # ASSUMPTION: NCR India dust; 4 % annual average soiling loss
    wiring_mismatch: float = 0.97    # ASSUMPTION: DC wiring + mismatch
    inverter_eff: float = 0.96       # ASSUMPTION: Euro-efficiency of a modern string inverter
    dc_ac_ratio: float = 1.15        # ASSUMPTION: inverter AC rating = kWp / 1.15 (clipping modelled)
    availability: float = 0.98       # ASSUMPTION: downtime


# ------------------------------------------------------------------------ battery
@dataclass(frozen=True)
class BatteryParams:
    chemistry: str = "LiFePO4"
    soc_min: float = 0.10            # 80 % depth of discharge window (10 %..90 %) - ASSUMPTION per LFP practice
    soc_max: float = 0.90
    round_trip_eff: float = 0.92     # ASSUMPTION: LFP + PCS round-trip 90-93 %
    c_rate_charge: float = 0.5       # ASSUMPTION: 0.5C max charge (kW per kWh)
    c_rate_discharge: float = 0.5    # ASSUMPTION: 0.5C max discharge
    soc_initial: float = 0.50
    cycle_life: int = 6000           # ASSUMPTION: LFP datasheet 6000 cycles @ 80 % DoD
    calendar_life_yr: int = 10       # ASSUMPTION: replacement at year 10


# -------------------------------------------------------------------- chargers
@dataclass(frozen=True)
class ChargerParams:
    n_ac: int = 2
    ac_kw: float = 7.4               # Type-2 AC single-phase 32 A (brief)
    n_dc: int = 1
    dc_kw: float = 30.0              # DC fast charger (brief)
    max_wait_min: float = 60.0       # ASSUMPTION: customer leaves if no port free within 60 min


# --------------------------------------------------------------------- EV demand
@dataclass(frozen=True)
class VehicleClass:
    name: str
    charger: str                     # "ac" or "dc"
    sessions_per_weekday: float      # ASSUMPTION - Poisson mean
    weekend_factor: float            # ASSUMPTION
    kwh_min: float                   # ASSUMPTION - uniform energy per session
    kwh_max: float
    power_kw: float                  # vehicle-side charging limit (onboard charger / DC acceptance)
    arrival_peaks: tuple = ((10.0, 2.0, 0.5), (17.5, 2.0, 0.5))  # (mean hour, sd, weight) mixture


VEHICLES = (
    # Electric 2-wheelers: ~3-4 kWh packs (Ather 450X 3.7 kWh, Ola S1 Pro 4 kWh), ~1 kW onboard charger
    VehicleClass("2W scooter (AC)", "ac", sessions_per_weekday=8, weekend_factor=0.8,
                 kwh_min=1.5, kwh_max=3.0, power_kw=1.0,
                 arrival_peaks=((9.5, 1.5, 0.45), (13.0, 2.0, 0.2), (18.0, 1.5, 0.35))),
    # Compact EV car on AC: Tata Nexon EV 30.2 kWh, 7.2 kW onboard AC charger
    VehicleClass("Car AC 7.2 kW", "ac", sessions_per_weekday=3, weekend_factor=0.9,
                 kwh_min=8.0, kwh_max=20.0, power_kw=7.2,
                 arrival_peaks=((10.0, 1.5, 0.5), (16.5, 2.0, 0.5))),
    # Car on DC 30 kW fast charger
    VehicleClass("Car DC 30 kW", "dc", sessions_per_weekday=6, weekend_factor=1.1,
                 kwh_min=10.0, kwh_max=25.0, power_kw=30.0,
                 arrival_peaks=((11.0, 2.5, 0.5), (18.5, 2.0, 0.5))),
)
LOAD_SEED = 2026


# ------------------------------------------------------------------- economics
@dataclass(frozen=True)
class Economics:
    currency: str = "INR"
    project_life_yr: int = 20        # ASSUMPTION
    discount_rate: float = 0.08      # ASSUMPTION: 8 % real discount rate
    pv_capex_per_kwp: float = 48_000 # MNRE benchmark cost, 10-100 kW rooftop, FY2019-20 (Rs 48/W) [S3]
    pv_om_per_kwp_yr: float = 1_000  # ASSUMPTION: ~2 % of capex per year
    inverter_repl_per_kwp: float = 6_000  # ASSUMPTION: inverter replacement at year 10
    batt_capex_per_kwh: float = 20_000    # ASSUMPTION: small C&I LFP incl. PCS/BMS/enclosure;
                                          # utility-scale India ~USD 120-125/kWh (~Rs 10,500) [S4], x~2 for <1 MWh systems
    batt_om_per_kwh_yr: float = 200       # ASSUMPTION: 1 % of capex per year
    batt_repl_cost_factor: float = 0.70   # ASSUMPTION: replacement battery at 70 % of today's price
    ac_charger_cost: float = 70_000       # ASSUMPTION: 7.4 kW Type-2 AC charger installed
    dc_charger_cost: float = 600_000      # ASSUMPTION: 30 kW DC charger installed
    civil_land_misc: float = 500_000      # ASSUMPTION: civil works, canopy, metering, cabling
    grid_tariff_per_kwh: float = 7.46     # UPERC Tariff Order FY2024-25, LMV-11 EV charging ABR [S5]
    grid_tariff_escalation: float = 0.03  # ASSUMPTION: 3 %/yr nominal escalation of grid tariff
    charging_price_per_kwh: float = 15.0  # ASSUMPTION: retail price charged to EV users (public chargers Rs 12-20/kWh)
    usd_inr: float = 84.0                 # ASSUMPTION: FX for converting cited USD costs


# ------------------------------------------------------------------- sizing search
@dataclass(frozen=True)
class SizingSearch:
    pv_kwp_grid: tuple = tuple(range(30, 151, 10))        # 30..150 kWp
    batt_kwh_grid: tuple = tuple(range(50, 501, 25))      # 50..500 kWh
    lpsp_target: float = 0.05                             # >=95 % of load served (brief)


SITE = Site()
PV = PVParams()
BATTERY = BatteryParams()
CHARGERS = ChargerParams()
ECON = Economics()
SEARCH = SizingSearch()

# ------------------------------------------------------------------- sources list
SOURCES = [
    ("S1", "NASA POWER hourly API (ALLSKY_SFC_SW_DWN, T2M), 2025, 28.67N 77.42E - REAL DATA downloaded to data/",
     "https://power.larc.nasa.gov/api/temporal/hourly/point?parameters=ALLSKY_SFC_SW_DWN,T2M&community=RE&longitude=77.42&latitude=28.67&start=20250101&end=20251231&format=CSV"),
    ("S2", "Duffie & Beckman, Solar Engineering of Thermal Processes (isotropic sky transposition, Erbs diffuse fraction)",
     "https://onlinelibrary.wiley.com/doi/book/10.1002/9781118671603"),
    ("S3", "MNRE rooftop solar benchmark cost FY2019-20: Rs 48/W for 10-100 kW (reported by Saur Energy, 19 Jul 2019)",
     "https://www.saurenergy.com/solar-energy-news/mnre-benchmark-costs-rooftop-solar-installations"),
    ("S4", "Ember / RESI India (Dec 2025): utility-scale BESS capex ~USD 125/kWh outside China & US; India auctions imply ~USD 120/kWh",
     "https://www.resiindia.org/post/battery-storage-costs-plummet-utility-scale-projects-now-at-125-kwh-lcos-hits-65-mwh"),
    ("S5", "UPERC Tariff Order FY2024-25 (10 Oct 2024): LMV-11 Electric Vehicle charging average billing rate Rs 7.46/kWh",
     "https://dvvnl.org/UploadFiles/tariffPlan/UPPCL%20Tariff%20Order%202024-25%20dt%2010.10.2024.pdf"),
    ("S6", "ICCT (Bieker 2021) Table A.8: Tata Nexon EV 30.2 kWh battery; Indian EV real-world consumption",
     "https://theicct.org/sites/default/files/publications/Global-LCA-passenger-cars-jul2021_0.pdf"),
    ("S7", "HOMER Pro methodology (dispatch, NPC, LCOE definitions replicated here in Python)",
     "https://homerenergy.com/products/pro/docs/latest/index.html"),
    ("S8", "Erbs, Klein & Duffie (1982) diffuse fraction correlation, Solar Energy 28(4)",
     "https://doi.org/10.1016/0038-092X(82)90302-4"),
]

ASSUMPTIONS = [
    ("Array tilt 28 deg, south facing, albedo 0.20", "Tilt = latitude rule of thumb"),
    ("PV losses: soiling 4 %, wiring/mismatch 3 %, inverter 96 %, availability 98 %, NOCT 45 C, -0.35 %/C", "Typical datasheet / PVsyst default-style values"),
    ("DC/AC ratio 1.15 with inverter clipping", "Common design practice"),
    ("LiFePO4: SOC window 10-90 % (80 % DoD), round-trip 92 %, 0.5C limits, 6000 cycles, 10-yr replacement", "LFP datasheet-typical values"),
    ("EV arrivals: Poisson daily counts, Gaussian-mixture arrival hours, uniform kWh per session, seeded RNG", "No measured station data available - declared synthetic"),
    ("Scooter 1.5-3.0 kWh/session at 1 kW; car AC 8-20 kWh at 7.2 kW; car DC 10-25 kWh at 30 kW", "Based on ~3.7 kWh scooters and 30 kWh cars"),
    ("Customers leave if no port is free within 60 min (lost sessions tracked separately from LPSP)", "Queue model simplification"),
    ("Economics: 20-yr life, 8 % real discount, PV Rs 48,000/kWp, battery Rs 20,000/kWh, chargers Rs 0.7 L (AC) / Rs 6 L (DC), civil Rs 5 L", "See SOURCES S3-S5 for anchors; rest are assumptions"),
    ("O&M: PV Rs 1,000/kWp/yr, battery Rs 200/kWh/yr; inverter replaced yr 10 @ Rs 6,000/kWp; battery replaced yr 10 @ 70 % of capex", "Assumption"),
    ("Grid comparison: LMV-11 tariff Rs 7.46/kWh escalating 3 %/yr; retail charging price Rs 15/kWh", "Tariff cited (S5); escalation and retail price are assumptions"),
    ("Single weather year (2025) repeated for all 20 years; no degradation of PV (could add 0.5 %/yr)", "Simplification"),
]
