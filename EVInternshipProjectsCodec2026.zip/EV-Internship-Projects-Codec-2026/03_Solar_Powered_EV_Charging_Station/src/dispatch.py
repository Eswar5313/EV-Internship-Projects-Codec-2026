"""
Hourly energy dispatch (HOMER-style "load following" for an off-grid PV + battery system).

Priority each hour:  PV -> load  ->  surplus charges battery  ->  rest curtailed
                     deficit from battery (within SOC & C-rate limits) -> rest is UNMET.
All quantities in kWh per 1-h step.  Battery losses are split sqrt(RTE) on each leg.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .config import BATTERY, BatteryParams


@dataclass
class DispatchResult:
    pv_kwh: np.ndarray
    load_kwh: np.ndarray
    pv_to_load: np.ndarray
    batt_charge: np.ndarray      # kWh into battery terminals (before charge loss)
    batt_discharge: np.ndarray   # kWh delivered to load from battery (after discharge loss)
    curtailed: np.ndarray
    unmet: np.ndarray
    soc: np.ndarray              # state of charge (fraction) at END of each hour
    batt_kwh: float

    @property
    def lpsp(self) -> float:
        return float(self.unmet.sum() / self.load_kwh.sum())

    @property
    def served(self) -> np.ndarray:
        return self.pv_to_load + self.batt_discharge

    def energy_balance_error(self) -> float:
        """PV - load_served - charge - curtail should be 0 every hour; returns max abs."""
        resid = self.pv_kwh - self.pv_to_load - self.batt_charge - self.curtailed
        return float(np.abs(resid).max())

    def battery_balance_error(self, eta_c: float, eta_d: float, soc0: float) -> float:
        stored_in = (self.batt_charge * eta_c).sum()
        taken_out = (self.batt_discharge / eta_d).sum()
        delta = (self.soc[-1] - soc0) * self.batt_kwh
        return float(abs(stored_in - taken_out - delta))

    def annual_summary(self) -> dict:
        eq_cycles = self.batt_discharge.sum() / self.batt_kwh if self.batt_kwh > 0 else 0.0
        return {
            "pv_generation_kwh": float(self.pv_kwh.sum()),
            "load_kwh": float(self.load_kwh.sum()),
            "served_kwh": float(self.served.sum()),
            "unmet_kwh": float(self.unmet.sum()),
            "lpsp": self.lpsp,
            "pv_direct_to_load_kwh": float(self.pv_to_load.sum()),
            "battery_discharge_kwh": float(self.batt_discharge.sum()),
            "battery_charge_kwh": float(self.batt_charge.sum()),
            "curtailed_kwh": float(self.curtailed.sum()),
            "curtailment_fraction": float(self.curtailed.sum() / max(self.pv_kwh.sum(), 1e-9)),
            "battery_equivalent_full_cycles_per_year": float(eq_cycles),
            "renewable_fraction": 1.0,
        }


def simulate(pv_kwh: np.ndarray, load_kwh: np.ndarray, batt_kwh: float,
             bp: BatteryParams = BATTERY) -> DispatchResult:
    n = len(pv_kwh)
    eta = np.sqrt(bp.round_trip_eff)
    e_min, e_max = bp.soc_min * batt_kwh, bp.soc_max * batt_kwh
    p_ch = bp.c_rate_charge * batt_kwh       # kWh per hour at terminals
    p_dis = bp.c_rate_discharge * batt_kwh
    e = bp.soc_initial * batt_kwh

    pv_to_load = np.empty(n); ch = np.empty(n); dis = np.empty(n)
    cur = np.empty(n); unmet = np.empty(n); soc = np.empty(n)
    for t in range(n):
        pv, ld = pv_kwh[t], load_kwh[t]
        direct = pv if pv < ld else ld
        surplus = pv - direct
        deficit = ld - direct
        # charge
        room = (e_max - e) / eta                 # terminal energy that fits
        c = min(surplus, room, p_ch)
        c = c if c > 0 else 0.0
        e += c * eta
        # discharge
        avail = (e - e_min) * eta                # deliverable energy
        d = min(deficit, avail, p_dis * eta)
        d = d if d > 0 else 0.0
        e -= d / eta
        pv_to_load[t] = direct; ch[t] = c; dis[t] = d
        cur[t] = surplus - c; unmet[t] = deficit - d
        soc[t] = e / batt_kwh if batt_kwh > 0 else 0.0
    return DispatchResult(pv_kwh, load_kwh, pv_to_load, ch, dis, cur, unmet, soc, batt_kwh)
