"""All matplotlib figures written to results/."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import RESULTS_DIR
from .dispatch import DispatchResult

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
C_PV, C_LOAD, C_BATT, C_UNMET, C_CURT = "#E8A317", "#2A6F97", "#3FA34D", "#C8102E", "#9E9E9E"


def plot_daily_solar(monthly: pd.DataFrame, path=RESULTS_DIR / "daily_solar_input.png"):
    fig, ax = plt.subplots(figsize=(9, 4.5))
    x = np.arange(12)
    ax.bar(x - 0.2, monthly.ghi_kwh_m2_day, 0.4, label="GHI (horizontal) kWh/m²/day", color="#F5C46B")
    ax.bar(x + 0.2, monthly.poa_kwh_m2_day, 0.4, label="POA (28° tilt) kWh/m²/day", color=C_PV)
    ax2 = ax.twinx()
    ax2.plot(x, monthly.yield_kwh_per_kwp_day, "o-", color=C_LOAD, label="AC yield kWh/kWp/day")
    ax2.set_ylabel("Specific yield (kWh/kWp/day)", color=C_LOAD)
    ax.set_xticks(x); ax.set_xticklabels(MONTHS)
    ax.set_ylabel("Irradiation (kWh/m²/day)")
    ax.set_title("Daily solar input by month - Ghaziabad (NASA POWER 2025, real data)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper right", fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_load_profile(load: np.ndarray, sessions: pd.DataFrame, path=RESULTS_DIR / "ev_demand_profile.png"):
    hourly = load.reshape(365, 24)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    ax = axes[0]
    ax.plot(range(24), hourly.mean(axis=0), color=C_LOAD, lw=2, label="mean")
    ax.fill_between(range(24), np.percentile(hourly, 10, axis=0), np.percentile(hourly, 90, axis=0),
                    color=C_LOAD, alpha=0.2, label="10-90 percentile")
    ax.set_xlabel("Hour of day"); ax.set_ylabel("Charging load (kW)")
    ax.set_title("Average daily EV charging profile (synthetic, seeded)")
    ax.legend(); ax.grid(alpha=0.3); ax.set_xticks(range(0, 24, 2))
    ax = axes[1]
    served = sessions[sessions.served]
    by = served.groupby(["vclass", served.arrival_h.astype(int)])["kwh"].sum().unstack(0).fillna(0) / 365
    by.plot(kind="bar", stacked=True, ax=ax, width=0.85, color=["#3FA34D", "#2A6F97", "#E8A317"])
    ax.set_xlabel("Arrival hour"); ax.set_ylabel("kWh/day (by arrival hour)")
    ax.set_title("Energy demand by vehicle class"); ax.grid(axis="y", alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_week_dispatch(res: DispatchResult, start_day: int, title: str, path):
    s, e = start_day * 24, (start_day + 7) * 24
    t = np.arange(s, e) / 24.0
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(12, 7), sharex=True, gridspec_kw={"height_ratios": [3, 1.3]})
    ax.fill_between(t, 0, res.pv_kwh[s:e], color=C_PV, alpha=0.35, label="PV generation")
    ax.plot(t, res.load_kwh[s:e], color=C_LOAD, lw=1.5, label="EV load")
    ax.plot(t, res.batt_discharge[s:e], color=C_BATT, lw=1.2, label="battery -> load")
    ax.plot(t, -res.batt_charge[s:e], color=C_BATT, lw=1.2, ls="--", label="PV -> battery (neg.)")
    ax.fill_between(t, 0, res.unmet[s:e], color=C_UNMET, alpha=0.6, label="unmet load")
    ax.fill_between(t, 0, -res.curtailed[s:e], color=C_CURT, alpha=0.4, label="curtailed (neg.)")
    ax.axhline(0, color="k", lw=0.5); ax.set_ylabel("kW (hourly kWh)")
    ax.set_title(title); ax.legend(ncol=3, fontsize=8, loc="upper left"); ax.grid(alpha=0.3)
    ax2.plot(t, res.soc[s:e] * 100, color=C_BATT, lw=1.5)
    ax2.axhline(10, color="grey", ls=":"); ax2.axhline(90, color="grey", ls=":")
    ax2.set_ylabel("Battery SOC (%)"); ax2.set_ylim(0, 100); ax2.set_xlabel("Day of year")
    ax2.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_sizing_heatmap(grid: pd.DataFrame, chosen: pd.Series, lpsp_target: float,
                        path=RESULTS_DIR / "sizing_heatmap.png"):
    lp = grid.pivot(index="batt_kwh", columns="pv_kwp", values="lpsp") * 100
    npc = grid.pivot(index="batt_kwh", columns="pv_kwp", values="npc_inr") / 1e6
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2))
    for ax, data, title, cmap, vmax in [
        (axes[0], lp, "Loss of power supply probability, LPSP (%)", "RdYlGn_r", 30),
        (axes[1], npc, "Net present cost (₹ million, 20 yr)", "viridis", None)]:
        im = ax.imshow(data.values, origin="lower", aspect="auto", cmap=cmap, vmax=vmax,
                       extent=[data.columns.min() - 5, data.columns.max() + 5,
                               data.index.min() - 12.5, data.index.max() + 12.5])
        fig.colorbar(im, ax=ax)
        cs = ax.contour(data.columns, data.index, lp.values, levels=[lpsp_target * 100], colors="k", linewidths=1.5)
        ax.clabel(cs, fmt=f"LPSP={lpsp_target*100:.0f}%%", fontsize=8)
        ax.plot(chosen.pv_kwp, chosen.batt_kwh, "w*", ms=16, mec="k", label="chosen (min NPC, LPSP≤5%)")
        ax.set_xlabel("PV array (kWp)"); ax.set_ylabel("Battery (kWh)"); ax.set_title(title)
        ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_monthly_balance(res: DispatchResult, months: np.ndarray, path=RESULTS_DIR / "monthly_energy_balance.png"):
    df = pd.DataFrame({"month": months, "PV": res.pv_kwh, "load": res.load_kwh,
                       "PV direct": res.pv_to_load, "battery": res.batt_discharge,
                       "unmet": res.unmet, "curtailed": res.curtailed}).groupby("month").sum() / 1000
    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(12)
    ax.bar(x, df["PV direct"], color=C_PV, label="PV -> load")
    ax.bar(x, df["battery"], bottom=df["PV direct"], color=C_BATT, label="battery -> load")
    ax.bar(x, df["unmet"], bottom=df["PV direct"] + df["battery"], color=C_UNMET, label="unmet")
    ax.bar(x, -df["curtailed"], color=C_CURT, alpha=0.5, label="curtailed PV (neg.)")
    ax.plot(x, df["PV"], "o-", color="#8B5A00", label="PV generation")
    ax.axhline(0, color="k", lw=0.6)
    ax.set_xticks(x); ax.set_xticklabels(MONTHS); ax.set_ylabel("MWh per month")
    ax.set_title("Monthly energy balance - chosen design"); ax.legend(ncol=3, fontsize=8); ax.grid(axis="y", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
    return df
