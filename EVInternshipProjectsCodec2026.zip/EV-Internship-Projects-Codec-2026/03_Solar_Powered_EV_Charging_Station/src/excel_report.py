"""
Build results/solar_ev_station.xlsx with openpyxl.  The Economics sheet is made of
LIVE formulas that reference the Inputs sheet, so a reviewer can change any price,
discount rate or tariff and see NPC / LCOE / payback update in Excel or LibreOffice.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .config import ASSUMPTIONS, BATTERY, CHARGERS, ECON, PV, SEARCH, SITE, SOURCES

HDR = Font(bold=True, color="FFFFFF")
HFILL = PatternFill("solid", fgColor="2A6F97")
INFILL = PatternFill("solid", fgColor="FFF2CC")
FORMFILL = PatternFill("solid", fgColor="E2EFDA")


def _header(ws, row, cols):
    for j, c in enumerate(cols, 1):
        cell = ws.cell(row=row, column=j, value=c)
        cell.font = HDR; cell.fill = HFILL; cell.alignment = Alignment(horizontal="center", wrap_text=True)


def _autowidth(ws, widths=None):
    for j, col in enumerate(ws.columns, 1):
        w = (widths or {}).get(j)
        if w is None:
            w = min(60, max(10, max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2))
        ws.column_dimensions[get_column_letter(j)].width = w


def build_workbook(path, monthly: pd.DataFrame, load: np.ndarray, load_sum: dict,
                   grid: pd.DataFrame, chosen: pd.Series, dispatch_sum: dict, econ: dict):
    wb = Workbook()

    # ------------------------------------------------------------------ Inputs
    ws = wb.active; ws.title = "Inputs"
    _header(ws, 1, ["Parameter", "Value", "Unit", "Source / note"])
    inputs = [
        ("PV array size", float(chosen.pv_kwp), "kWp", "Chosen by sizing search (min NPC, LPSP<=target)"),
        ("Battery bank size", float(chosen.batt_kwh), "kWh", "Chosen by sizing search"),
        ("PV capex", ECON.pv_capex_per_kwp, "INR/kWp", "S3 MNRE benchmark FY2019-20 (10-100 kW)"),
        ("Battery capex", ECON.batt_capex_per_kwh, "INR/kWh", "ASSUMPTION anchored on S4"),
        ("AC charger cost (each)", ECON.ac_charger_cost, "INR", "ASSUMPTION"),
        ("Number of AC chargers", CHARGERS.n_ac, "-", "Brief"),
        ("DC charger cost (each)", ECON.dc_charger_cost, "INR", "ASSUMPTION"),
        ("Number of DC chargers", CHARGERS.n_dc, "-", "Brief"),
        ("Civil / misc", ECON.civil_land_misc, "INR", "ASSUMPTION"),
        ("PV O&M", ECON.pv_om_per_kwp_yr, "INR/kWp/yr", "ASSUMPTION"),
        ("Battery O&M", ECON.batt_om_per_kwh_yr, "INR/kWh/yr", "ASSUMPTION"),
        ("Inverter replacement (yr 10)", ECON.inverter_repl_per_kwp, "INR/kWp", "ASSUMPTION"),
        ("Battery replacement cost factor (yr 10)", ECON.batt_repl_cost_factor, "fraction", "ASSUMPTION"),
        ("Replacement year", 10, "yr", "ASSUMPTION (battery calendar life)"),
        ("Discount rate (real)", ECON.discount_rate, "fraction", "ASSUMPTION"),
        ("Project life", ECON.project_life_yr, "yr", "ASSUMPTION"),
        ("Grid tariff (LMV-11 EV)", ECON.grid_tariff_per_kwh, "INR/kWh", "S5 UPERC FY2024-25"),
        ("Grid tariff escalation", ECON.grid_tariff_escalation, "fraction/yr", "ASSUMPTION"),
        ("Grid connection cost (alternative)", 300_000, "INR", "ASSUMPTION"),
        ("Retail charging price", ECON.charging_price_per_kwh, "INR/kWh", "ASSUMPTION"),
        ("Annual EV load (simulated)", load_sum["annual_load_kwh"], "kWh/yr", "Synthetic load model, seeded"),
        ("Annual served energy (chosen design)", dispatch_sum["served_kwh"], "kWh/yr", "Dispatch simulation"),
        ("LPSP target", SEARCH.lpsp_target, "fraction", "Brief (>=95 % served)"),
        ("Specific PV yield", float(monthly.yield_kwh_per_kwp_month.sum()), "kWh/kWp/yr", "NASA POWER 2025 + PV model"),
        ("Battery round-trip efficiency", BATTERY.round_trip_eff, "fraction", "ASSUMPTION"),
        ("Battery DoD window", BATTERY.soc_max - BATTERY.soc_min, "fraction", "ASSUMPTION"),
        ("Site latitude", SITE.latitude, "deg", "NASA POWER"),
        ("Site longitude", SITE.longitude, "deg", "NASA POWER"),
        ("Array tilt", SITE.tilt_deg, "deg", "ASSUMPTION"),
    ]
    ref = {}
    for i, (name, val, unit, note) in enumerate(inputs, 2):
        ws.cell(row=i, column=1, value=name)
        c = ws.cell(row=i, column=2, value=val); c.fill = INFILL
        ws.cell(row=i, column=3, value=unit); ws.cell(row=i, column=4, value=note)
        ref[name] = f"Inputs!$B${i}"
    _autowidth(ws, {1: 40, 2: 14, 3: 12, 4: 55})

    # ----------------------------------------------------------- Solar_Monthly
    ws = wb.create_sheet("Solar_Monthly")
    _header(ws, 1, ["Month", "Days", "GHI kWh/m2/day", "POA kWh/m2/day", "Yield kWh/kWp/day",
                    "Yield kWh/kWp/month", "Array output kWh/month (formula)", "Array output kWh/day (formula)", "T_amb mean C"])
    for i, (m, r) in enumerate(monthly.iterrows(), 2):
        ws.cell(row=i, column=1, value=int(m)); ws.cell(row=i, column=2, value=int(r.days))
        ws.cell(row=i, column=3, value=round(r.ghi_kwh_m2_day, 3)); ws.cell(row=i, column=4, value=round(r.poa_kwh_m2_day, 3))
        ws.cell(row=i, column=5, value=round(r.yield_kwh_per_kwp_day, 3)); ws.cell(row=i, column=6, value=round(r.yield_kwh_per_kwp_month, 2))
        ws.cell(row=i, column=7, value=f"=F{i}*{ref['PV array size']}").fill = FORMFILL
        ws.cell(row=i, column=8, value=f"=G{i}/B{i}").fill = FORMFILL
        ws.cell(row=i, column=9, value=round(r.t_amb_mean_c, 2))
    ws.cell(row=14, column=1, value="Annual").font = Font(bold=True)
    for col in "BFG":
        ws[f"{col}14"] = f"=SUM({col}2:{col}13)"; ws[f"{col}14"].fill = FORMFILL
    ws["C14"] = "=SUMPRODUCT(C2:C13,B2:B13)"; ws["C14"].fill = FORMFILL
    ws["D14"] = "=SUMPRODUCT(D2:D13,B2:B13)"; ws["D14"].fill = FORMFILL
    ws["A16"] = "Source: NASA POWER hourly ALLSKY_SFC_SW_DWN + T2M, 2025, 28.67N 77.42E (real data, data/nasa_power_hourly_2025.csv)"
    ch = BarChart(); ch.title = "Daily solar input (kWh/m2/day)"; ch.y_axis.title = "kWh/m2/day"
    ch.add_data(Reference(ws, min_col=3, max_col=4, min_row=1, max_row=13), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=13)); ch.height, ch.width = 7, 16
    ws.add_chart(ch, "K2")
    _autowidth(ws)

    # ------------------------------------------------------------ Load_Profile
    ws = wb.create_sheet("Load_Profile")
    _header(ws, 1, ["Hour", "Mean load kW", "P10 kW", "P90 kW", "Max kW"])
    hourly = load.reshape(365, 24)
    for h in range(24):
        ws.cell(row=h + 2, column=1, value=h)
        ws.cell(row=h + 2, column=2, value=round(float(hourly[:, h].mean()), 3))
        ws.cell(row=h + 2, column=3, value=round(float(np.percentile(hourly[:, h], 10)), 3))
        ws.cell(row=h + 2, column=4, value=round(float(np.percentile(hourly[:, h], 90)), 3))
        ws.cell(row=h + 2, column=5, value=round(float(hourly[:, h].max()), 3))
    ws["A27"] = "Mean daily load kWh (formula)"; ws["B27"] = "=SUM(B2:B25)"; ws["B27"].fill = FORMFILL
    ws["A28"] = "Annual load kWh (formula)"; ws["B28"] = "=B27*365"; ws["B28"].fill = FORMFILL
    ws["A30"] = "Sessions by vehicle class (served)"; ws["A30"].font = Font(bold=True)
    _header(ws, 31, ["Vehicle class", "Sessions/yr", "kWh/yr", "Mean kWh/session (formula)", "Share of energy (formula)"])
    r0 = 32
    classes = list(load_sum["kwh_by_class"].keys())
    for i, k in enumerate(classes):
        r = r0 + i
        ws.cell(row=r, column=1, value=k); ws.cell(row=r, column=2, value=int(load_sum["sessions_by_class"][k]))
        ws.cell(row=r, column=3, value=float(load_sum["kwh_by_class"][k]))
        ws.cell(row=r, column=4, value=f"=C{r}/B{r}").fill = FORMFILL
        ws.cell(row=r, column=5, value=f"=C{r}/SUM($C${r0}:$C${r0+len(classes)-1})").fill = FORMFILL
    rr = r0 + len(classes) + 1
    ws.cell(row=rr, column=1, value="Sessions lost (queue > 60 min)"); ws.cell(row=rr, column=2, value=load_sum["sessions_lost_queue"])
    ws.cell(row=rr + 1, column=1, value="Note: DECLARED SYNTHETIC load - Poisson arrivals, seeded RNG (see Assumptions_Sources)")
    lc = LineChart(); lc.title = "Average daily charging profile"; lc.y_axis.title = "kW"; lc.x_axis.title = "hour"
    lc.add_data(Reference(ws, min_col=2, max_col=4, min_row=1, max_row=25), titles_from_data=True)
    lc.set_categories(Reference(ws, min_col=1, min_row=2, max_row=25)); lc.height, lc.width = 7, 16
    ws.add_chart(lc, "G2")
    _autowidth(ws)

    # ------------------------------------------------------------- Sizing_Grid
    ws = wb.create_sheet("Sizing_Grid")
    cols = ["pv_kwp", "batt_kwh", "lpsp", "served_kwh", "unmet_kwh", "curtailed_kwh", "curtailment_fraction",
            "battery_cycles_per_yr", "npc_inr", "lcoe_inr_per_kwh"]
    _header(ws, 1, cols + ["Capex INR (formula)", "Feasible? (formula)"])
    for i, r in enumerate(grid[cols].itertuples(index=False), 2):
        for j, v in enumerate(r, 1):
            ws.cell(row=i, column=j, value=float(v) if isinstance(v, (np.floating, float)) else int(v))
        ws.cell(row=i, column=11, value=(f"=A{i}*{ref['PV capex']}+B{i}*{ref['Battery capex']}"
                                         f"+{ref['AC charger cost (each)']}*{ref['Number of AC chargers']}"
                                         f"+{ref['DC charger cost (each)']}*{ref['Number of DC chargers']}+{ref['Civil / misc']}")).fill = FORMFILL
        ws.cell(row=i, column=12, value=f'=IF(C{i}<={ref["LPSP target"]},"Yes","No")').fill = FORMFILL
    n = len(grid) + 1
    ws.cell(row=n + 2, column=1, value="Min NPC among feasible (formula)")
    ws.cell(row=n + 2, column=2, value=f'=_xlfn.MINIFS(I2:I{n},L2:L{n},"Yes")').fill = FORMFILL
    ws.cell(row=n + 3, column=1, value="Chosen PV kWp (formula)")
    ws.cell(row=n + 3, column=2, value=f'=INDEX(A2:A{n},MATCH(B{n+2},I2:I{n},0))').fill = FORMFILL
    ws.cell(row=n + 4, column=1, value="Chosen battery kWh (formula)")
    ws.cell(row=n + 4, column=2, value=f'=INDEX(B2:B{n},MATCH(B{n+2},I2:I{n},0))').fill = FORMFILL
    ws.freeze_panes = "A2"
    _autowidth(ws)

    # ---------------------------------------------------------------- Dispatch
    ws = wb.create_sheet("Dispatch_Annual")
    _header(ws, 1, ["Quantity (chosen design, 8760-h simulation)", "Value", "Unit"])
    items = [("PV generation", dispatch_sum["pv_generation_kwh"], "kWh/yr"),
             ("EV load", dispatch_sum["load_kwh"], "kWh/yr"),
             ("Served load", dispatch_sum["served_kwh"], "kWh/yr"),
             ("Unmet load", dispatch_sum["unmet_kwh"], "kWh/yr"),
             ("PV direct to load", dispatch_sum["pv_direct_to_load_kwh"], "kWh/yr"),
             ("Battery discharge to load", dispatch_sum["battery_discharge_kwh"], "kWh/yr"),
             ("Battery charge (terminal)", dispatch_sum["battery_charge_kwh"], "kWh/yr"),
             ("Curtailed PV", dispatch_sum["curtailed_kwh"], "kWh/yr"),
             ("Battery equivalent full cycles", dispatch_sum["battery_equivalent_full_cycles_per_year"], "cycles/yr")]
    for i, (k, v, u) in enumerate(items, 2):
        ws.cell(row=i, column=1, value=k); ws.cell(row=i, column=2, value=round(float(v), 2)); ws.cell(row=i, column=3, value=u)
    ws["A12"] = "LPSP (formula)"; ws["B12"] = "=B5/B3"; ws["B12"].fill = FORMFILL
    ws["A13"] = "Curtailment fraction (formula)"; ws["B13"] = "=B9/B2"; ws["B13"].fill = FORMFILL
    ws["A14"] = "Energy balance check PV - direct - charge - curtailed (formula, should be ~0)"
    ws["B14"] = "=B2-B6-B8-B9"; ws["B14"].fill = FORMFILL
    ws["A15"] = "Battery years to reach cycle life (formula)"; ws["B15"] = f"={BATTERY.cycle_life}/B10"; ws["B15"].fill = FORMFILL
    _autowidth(ws, {1: 70})

    # --------------------------------------------------------------- Economics
    ws = wb.create_sheet("Economics")
    _header(ws, 1, ["Item", "Formula result", "Unit", "Formula / explanation"])
    R = ref
    rows = [
        ("PV array capex", f"={R['PV array size']}*{R['PV capex']}", "INR", "kWp x INR/kWp"),
        ("Battery capex", f"={R['Battery bank size']}*{R['Battery capex']}", "INR", "kWh x INR/kWh"),
        ("AC chargers", f"={R['AC charger cost (each)']}*{R['Number of AC chargers']}", "INR", ""),
        ("DC chargers", f"={R['DC charger cost (each)']}*{R['Number of DC chargers']}", "INR", ""),
        ("Civil / misc", f"={R['Civil / misc']}", "INR", ""),
        ("Total capex", "=SUM(B2:B6)", "INR", ""),
        ("Annual O&M", f"={R['PV array size']}*{R['PV O&M']}+{R['Battery bank size']}*{R['Battery O&M']}", "INR/yr", ""),
        ("CRF", f"={R['Discount rate (real)']}*(1+{R['Discount rate (real)']})^{R['Project life']}/((1+{R['Discount rate (real)']})^{R['Project life']}-1)", "-", "r(1+r)^N/((1+r)^N-1)"),
        ("Annuity factor (PV of 1/yr)", "=1/B9", "yr", ""),
        ("PV of O&M", "=B8*B10", "INR", ""),
        ("Discount factor at replacement year", f"=1/(1+{R['Discount rate (real)']})^{R['Replacement year']}", "-", ""),
        ("PV of inverter replacement", f"={R['PV array size']}*{R['Inverter replacement (yr 10)']}*B12", "INR", ""),
        ("PV of battery replacement", f"={R['Battery bank size']}*{R['Battery capex']}*{R['Battery replacement cost factor (yr 10)']}*B12", "INR", ""),
        ("Net present cost (NPC)", "=B7+B11+B13+B14", "INR", "capex + PV(O&M) + PV(replacements)"),
        ("Annualised cost", "=B15*B9", "INR/yr", "NPC x CRF"),
        ("Discounted served energy", f"={R['Annual served energy (chosen design)']}*B10", "kWh", "served kWh/yr x annuity factor"),
        ("LCOE", "=B15/B17", "INR/kWh", "NPC / discounted energy"),
        ("Grid alternative capex", f"=B4+B5+B6+{R['Grid connection cost (alternative)']}", "INR", "same chargers + civil + grid connection"),
        ("Grid energy cost year 1", f"={R['Annual served energy (chosen design)']}*{R['Grid tariff (LMV-11 EV)']}", "INR/yr", ""),
        ("Escalating annuity factor", f"=IF({R['Discount rate (real)']}={R['Grid tariff escalation']},{R['Project life']}/(1+{R['Discount rate (real)']}),(1-((1+{R['Grid tariff escalation']})/(1+{R['Discount rate (real)']}))^{R['Project life']})/({R['Discount rate (real)']}-{R['Grid tariff escalation']}))", "yr", "growing annuity, closed form"),
        ("Grid alternative NPC", "=B19+B20*B21", "INR", ""),
        ("Grid alternative LCOE", "=B22/B17", "INR/kWh", ""),
        ("Incremental capex (solar - grid)", "=B7-B19", "INR", ""),
        ("Annual saving vs grid (yr 1)", "=B20-B8", "INR/yr", "grid bill avoided minus solar O&M"),
        ("Simple payback vs grid tariff", '=IF(B25>0,B24/B25,"never")', "yr", ""),
        ("Annual revenue at retail price", f"={R['Annual served energy (chosen design)']}*{R['Retail charging price']}", "INR/yr", ""),
        ("Simple payback on revenue", '=IF(B27-B8>0,B7/(B27-B8),"never")', "yr", ""),
        ("NPV of station (revenue vs NPC)", "=B27*B10-B15", "INR", "PV(revenue) - NPC"),
    ]
    for i, (k, f, u, note) in enumerate(rows, 2):
        ws.cell(row=i, column=1, value=k)
        c = ws.cell(row=i, column=2, value=f); c.fill = FORMFILL; c.number_format = "#,##0.00"
        ws.cell(row=i, column=3, value=u); ws.cell(row=i, column=4, value=note)
    ws["A32"] = "Python cross-check"; ws["A32"].font = Font(bold=True)
    ws["A33"] = "NPC (python)"; ws["B33"] = round(econ["npc_inr"], 2)
    ws["A34"] = "LCOE (python)"; ws["B34"] = round(econ["lcoe_inr_per_kwh"], 4)
    ws["A35"] = "LCOE difference (formula)"; ws["B35"] = "=B18-B34"; ws["B35"].fill = FORMFILL
    _autowidth(ws, {1: 38, 2: 18, 3: 10, 4: 45})

    # ------------------------------------------------------ Assumptions_Sources
    ws = wb.create_sheet("Assumptions_Sources")
    _header(ws, 1, ["ID", "Source", "URL"])
    for i, (sid, desc, url) in enumerate(SOURCES, 2):
        ws.cell(row=i, column=1, value=sid); ws.cell(row=i, column=2, value=desc); ws.cell(row=i, column=3, value=url)
    r = len(SOURCES) + 3
    _header(ws, r, ["#", "Assumption", "Basis"])
    for i, (a, b) in enumerate(ASSUMPTIONS, 1):
        ws.cell(row=r + i, column=1, value=i); ws.cell(row=r + i, column=2, value=a); ws.cell(row=r + i, column=3, value=b)
    ws.cell(row=r + len(ASSUMPTIONS) + 2, column=1,
            value="Legend: yellow cells = inputs, green cells = live formulas. Change Inputs!B to re-run the economics.")
    _autowidth(ws, {1: 6, 2: 90, 3: 80})

    wb.save(path)
    return path
