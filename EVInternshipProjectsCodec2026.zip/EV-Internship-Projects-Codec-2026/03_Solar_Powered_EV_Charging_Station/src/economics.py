"""
HOMER-style techno-economics: capital cost, net present cost (NPC), levelised cost of
energy (LCOE), and payback against buying the same energy from the grid.

NPC  = CAPEX + PV(O&M) + PV(replacements)          (20-year real discounting)
LCOE = NPC / sum_t served_kWh_t / (1+r)^t          (Rs per kWh actually delivered)
CRF  = r(1+r)^N / ((1+r)^N - 1)
"""
from __future__ import annotations

from .config import CHARGERS, ECON, ChargerParams, Economics


def crf(r: float, n: int) -> float:
    return r * (1 + r) ** n / ((1 + r) ** n - 1)


def pv_factor(r: float, n: int) -> float:
    """Present value of Rs 1 per year for n years (annuity factor)."""
    return 1.0 / crf(r, n)


def escalating_annuity_pv(r: float, g: float, n: int) -> float:
    """PV of Rs 1 in year 1 growing at g per year for n years."""
    return sum((1 + g) ** (t - 1) / (1 + r) ** t for t in range(1, n + 1))


def capex(pv_kwp: float, batt_kwh: float, ec: Economics = ECON, ch: ChargerParams = CHARGERS) -> dict:
    items = {
        "pv_array_inr": pv_kwp * ec.pv_capex_per_kwp,
        "battery_inr": batt_kwh * ec.batt_capex_per_kwh,
        "ac_chargers_inr": ch.n_ac * ec.ac_charger_cost,
        "dc_chargers_inr": ch.n_dc * ec.dc_charger_cost,
        "civil_misc_inr": ec.civil_land_misc,
    }
    items["total_capex_inr"] = sum(items.values())
    return items


def evaluate(pv_kwp: float, batt_kwh: float, served_kwh_yr: float, load_kwh_yr: float,
             ec: Economics = ECON, ch: ChargerParams = CHARGERS) -> dict:
    r, n = ec.discount_rate, ec.project_life_yr
    cx = capex(pv_kwp, batt_kwh, ec, ch)
    om_yr = pv_kwp * ec.pv_om_per_kwp_yr + batt_kwh * ec.batt_om_per_kwh_yr
    om_pv = om_yr * pv_factor(r, n)
    repl_year = 10
    disc10 = 1 / (1 + r) ** repl_year
    inverter_repl_pv = pv_kwp * ec.inverter_repl_per_kwp * disc10
    batt_repl_pv = batt_kwh * ec.batt_capex_per_kwh * ec.batt_repl_cost_factor * disc10
    npc = cx["total_capex_inr"] + om_pv + inverter_repl_pv + batt_repl_pv
    energy_pv = served_kwh_yr * pv_factor(r, n)       # discounted kWh
    lcoe = npc / energy_pv
    annualised_cost = npc * crf(r, n)

    # Grid alternative: same chargers + civil + grid connection, energy bought at LMV-11 tariff
    grid_alt_capex = ch.n_ac * ec.ac_charger_cost + ch.n_dc * ec.dc_charger_cost + ec.civil_land_misc + 300_000
    grid_energy_cost_yr1 = served_kwh_yr * ec.grid_tariff_per_kwh
    grid_npc = grid_alt_capex + grid_energy_cost_yr1 * escalating_annuity_pv(r, ec.grid_tariff_escalation, n)
    grid_lcoe = grid_npc / energy_pv
    incremental_capex = cx["total_capex_inr"] - grid_alt_capex
    annual_saving = grid_energy_cost_yr1 - om_yr
    simple_payback_vs_grid = incremental_capex / annual_saving if annual_saving > 0 else float("inf")
    revenue_yr = served_kwh_yr * ec.charging_price_per_kwh
    simple_payback_revenue = cx["total_capex_inr"] / (revenue_yr - om_yr) if revenue_yr > om_yr else float("inf")

    return {
        **cx,
        "om_per_year_inr": om_yr,
        "om_pv_inr": om_pv,
        "inverter_replacement_pv_inr": inverter_repl_pv,
        "battery_replacement_pv_inr": batt_repl_pv,
        "npc_inr": npc,
        "annualised_cost_inr_per_yr": annualised_cost,
        "discounted_energy_kwh": energy_pv,
        "lcoe_inr_per_kwh": lcoe,
        "grid_alternative_npc_inr": grid_npc,
        "grid_alternative_lcoe_inr_per_kwh": grid_lcoe,
        "simple_payback_vs_grid_yr": simple_payback_vs_grid,
        "simple_payback_on_revenue_yr": simple_payback_revenue,
        "crf": crf(r, n),
    }
