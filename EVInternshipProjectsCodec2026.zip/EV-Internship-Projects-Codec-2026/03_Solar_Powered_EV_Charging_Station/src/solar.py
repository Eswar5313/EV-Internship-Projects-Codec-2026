"""
Solar resource + PV array model.

1. Load NASA POWER hourly GHI (Wh/m^2 per hour == W/m^2 average) and ambient temperature.
2. Transpose GHI to plane-of-array (POA) irradiance on a fixed tilted surface:
     - solar geometry (declination, hour angle, zenith, incidence angle)
     - Erbs (1982) correlation for diffuse fraction from clearness index
     - isotropic-sky model: POA = B*Rb + D*(1+cos b)/2 + GHI*rho*(1-cos b)/2
3. Cell temperature via NOCT and PV DC power with temperature coefficient.
4. Inverter efficiency + clipping -> AC kWh per hour per kWp.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import NASA_FILE, PV, SITE, PVParams, Site

SOLAR_CONSTANT = 1367.0  # W/m^2


def load_nasa_power(path=NASA_FILE) -> pd.DataFrame:
    """Read the NASA POWER CSV saved in data/. Returns 8760-row DataFrame with
    columns: time (naive local), ghi_wm2, t_amb_c, month, day, hour, doy."""
    df = pd.read_csv(path, comment="-", skiprows=lambda i: i < 10)
    df = df.rename(columns={"ALLSKY_SFC_SW_DWN": "ghi_wm2", "T2M": "t_amb_c"})
    if (df[["ghi_wm2", "t_amb_c"]] == -999).any().any():
        raise ValueError("NASA POWER file contains -999 fill values; clean before use")
    df["time"] = pd.to_datetime(dict(year=df.YEAR, month=df.MO, day=df.DY, hour=df.HR))
    df = df.rename(columns={"MO": "month", "DY": "day", "HR": "hour"})
    df["doy"] = df["time"].dt.dayofyear
    return df[["time", "month", "day", "hour", "doy", "ghi_wm2", "t_amb_c"]].reset_index(drop=True)


def poa_irradiance(df: pd.DataFrame, site: Site = SITE) -> np.ndarray:
    """Plane-of-array irradiance (W/m^2) for each hour using isotropic sky model.
    NASA POWER hourly values are in local standard time (LST) and are the mean
    over the hour, so the hour-centre (h + 0.5) is used for solar geometry."""
    lat = np.radians(site.latitude)
    tilt = np.radians(site.tilt_deg)
    az_s = np.radians(site.azimuth_deg - 180.0)  # surface azimuth, 0 = south
    doy = df["doy"].to_numpy(dtype=float)
    hour = df["hour"].to_numpy(dtype=float) + 0.5
    ghi = df["ghi_wm2"].to_numpy(dtype=float)

    # Equation of time & longitude correction -> solar time
    B = 2 * np.pi * (doy - 81) / 364.0
    eot = 9.87 * np.sin(2 * B) - 7.53 * np.cos(B) - 1.5 * np.sin(B)  # minutes
    lstm = 15.0 * 5.5  # India Standard Time meridian 82.5 E
    solar_time = hour + (4.0 * (site.longitude - lstm) + eot) / 60.0
    omega = np.radians(15.0 * (solar_time - 12.0))                     # hour angle
    decl = np.radians(23.45 * np.sin(2 * np.pi * (284 + doy) / 365.0))  # declination

    cos_zen = np.sin(lat) * np.sin(decl) + np.cos(lat) * np.cos(decl) * np.cos(omega)
    cos_zen = np.clip(cos_zen, 0.0, 1.0)

    # incidence angle on tilted surface (Duffie & Beckman eq. 1.6.2)
    cos_inc = (np.sin(decl) * np.sin(lat) * np.cos(tilt)
               - np.sin(decl) * np.cos(lat) * np.sin(tilt) * np.cos(az_s)
               + np.cos(decl) * np.cos(lat) * np.cos(tilt) * np.cos(omega)
               + np.cos(decl) * np.sin(lat) * np.sin(tilt) * np.cos(az_s) * np.cos(omega)
               + np.cos(decl) * np.sin(tilt) * np.sin(az_s) * np.sin(omega))
    cos_inc = np.clip(cos_inc, 0.0, 1.0)

    # extraterrestrial horizontal irradiance & clearness index
    g_on = SOLAR_CONSTANT * (1 + 0.033 * np.cos(2 * np.pi * doy / 365.0))
    g_o = g_on * cos_zen
    with np.errstate(divide="ignore", invalid="ignore"):
        kt = np.where(g_o > 1.0, ghi / g_o, 0.0)
    kt = np.clip(kt, 0.0, 1.0)

    # Erbs et al. (1982) diffuse fraction
    fd = np.where(kt <= 0.22, 1.0 - 0.09 * kt,
         np.where(kt <= 0.80,
                  0.9511 - 0.1604 * kt + 4.388 * kt**2 - 16.638 * kt**3 + 12.336 * kt**4,
                  0.165))
    dhi = ghi * fd
    bhi = ghi - dhi

    # beam ratio Rb, limited to avoid blow-up at sunrise/sunset
    with np.errstate(divide="ignore", invalid="ignore"):
        rb = np.where(cos_zen > 0.087, cos_inc / cos_zen, 0.0)  # zenith < ~85 deg
    rb = np.clip(rb, 0.0, 5.0)

    poa = (bhi * rb
           + dhi * (1 + np.cos(tilt)) / 2.0
           + ghi * site.albedo * (1 - np.cos(tilt)) / 2.0)
    poa = np.where(ghi <= 0, 0.0, poa)
    return poa


def pv_ac_per_kwp(df: pd.DataFrame, pv: PVParams = PV, site: Site = SITE) -> np.ndarray:
    """Hourly AC energy (kWh) delivered per 1 kWp of installed DC capacity."""
    poa = poa_irradiance(df, site)
    t_amb = df["t_amb_c"].to_numpy(dtype=float)
    t_cell = t_amb + (pv.noct_c - 20.0) / 800.0 * poa
    temp_factor = 1.0 + pv.temp_coeff_per_c * (t_cell - 25.0)
    dc_kwh = (poa / 1000.0) * temp_factor * pv.soiling * pv.wiring_mismatch  # per kWp, 1-h step
    ac_kwh = dc_kwh * pv.inverter_eff
    ac_kwh = np.minimum(ac_kwh, 1.0 / pv.dc_ac_ratio)  # inverter clipping (kW AC rating per kWp)
    ac_kwh *= pv.availability
    return np.clip(ac_kwh, 0.0, None)


def monthly_solar_table(df: pd.DataFrame, ac_per_kwp: np.ndarray) -> pd.DataFrame:
    """Daily mean GHI, POA and specific yield per month."""
    poa = poa_irradiance(df)
    tmp = df[["month"]].copy()
    tmp["ghi_kwh_m2"] = df["ghi_wm2"] / 1000.0
    tmp["poa_kwh_m2"] = poa / 1000.0
    tmp["ac_kwh_per_kwp"] = ac_per_kwp
    tmp["t_amb_c"] = df["t_amb_c"]
    g = tmp.groupby("month")
    days = df.groupby("month")["day"].nunique()
    out = pd.DataFrame({
        "days": days,
        "ghi_kwh_m2_day": g["ghi_kwh_m2"].sum() / days,
        "poa_kwh_m2_day": g["poa_kwh_m2"].sum() / days,
        "yield_kwh_per_kwp_day": g["ac_kwh_per_kwp"].sum() / days,
        "yield_kwh_per_kwp_month": g["ac_kwh_per_kwp"].sum(),
        "t_amb_mean_c": g["t_amb_c"].mean(),
    })
    out.index.name = "month"
    return out
