"""
Grid search over PV kWp x battery kWh (HOMER "search space" style).
For every combination: run the 8760-h dispatch, record LPSP, curtailment, NPC, LCOE.
The chosen design is the lowest-NPC combination with LPSP <= target.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import SEARCH, SizingSearch
from .dispatch import simulate
from .economics import evaluate


def run_grid(ac_per_kwp: np.ndarray, load: np.ndarray, search: SizingSearch = SEARCH) -> pd.DataFrame:
    rows = []
    load_yr = float(load.sum())
    for kwp in search.pv_kwp_grid:
        pv = ac_per_kwp * kwp
        for kwh in search.batt_kwh_grid:
            res = simulate(pv, load, kwh)
            s = res.annual_summary()
            ec = evaluate(kwp, kwh, s["served_kwh"], load_yr)
            rows.append({
                "pv_kwp": kwp, "batt_kwh": kwh,
                "lpsp": s["lpsp"], "served_kwh": s["served_kwh"], "unmet_kwh": s["unmet_kwh"],
                "curtailed_kwh": s["curtailed_kwh"], "curtailment_fraction": s["curtailment_fraction"],
                "battery_cycles_per_yr": s["battery_equivalent_full_cycles_per_year"],
                "capex_inr": ec["total_capex_inr"], "npc_inr": ec["npc_inr"],
                "lcoe_inr_per_kwh": ec["lcoe_inr_per_kwh"],
                "feasible": s["lpsp"] <= search.lpsp_target,
            })
    return pd.DataFrame(rows)


def choose_design(grid: pd.DataFrame) -> pd.Series:
    feas = grid[grid.feasible]
    if feas.empty:
        raise RuntimeError("No PV/battery combination in the search grid meets the LPSP target")
    return feas.sort_values("npc_inr").iloc[0]
