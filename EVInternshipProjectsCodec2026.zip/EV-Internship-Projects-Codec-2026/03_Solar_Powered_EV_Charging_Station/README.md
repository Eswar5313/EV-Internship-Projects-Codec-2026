# Off-Grid Solar-Powered EV Charging Station - Ghaziabad, UP

**Project 03 - EV Internship, Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026
**Stack:** Python 3, NumPy, pandas, matplotlib, openpyxl

> ## Data provenance - read this first
> * **Solar irradiance and air temperature are REAL.** I downloaded 8,760 hourly values
>   (GHI `ALLSKY_SFC_SW_DWN` in Wh/m² and `T2M` in °C) for 28.67 N, 77.42 E for calendar
>   year 2025 from the **NASA POWER** public API and saved them unmodified in
>   `data/nasa_power_hourly_2025.csv` (no missing values).
> * **The EV charging demand is SYNTHETIC.** I have no measured session logs from a real
>   station, so `src/load_profile.py` generates seeded stochastic arrivals. The numbers
>   below describe *this* assumed demand, not a measured one.
> * **HOMER Pro / PVsyst were not available to me**, so I wrote a HOMER-style
>   techno-economic simulation in Python (hourly dispatch, sizing search, NPC/LCOE).
>   The method mirrors HOMER's; the software is my own.
> * Every cost and efficiency figure is either cited (S1-S8 below) or explicitly
>   declared as an assumption - in this README and in the `Assumptions_Sources` sheet of
>   the workbook.

---

## 1. Overview

The brief was:

> *"Design an off-grid solar EV charging station. Use HOMER or PVsyst for simulation.
> Include battery storage system. Calculate daily solar input and EV charging demand."*

What I built:

1. **Solar resource + PV model** - real NASA POWER hourly GHI, transposed to a 28°
   south-facing array with the isotropic-sky model, with temperature, soiling, wiring,
   inverter and clipping losses (`src/solar.py`).
2. **EV demand model** - 2 × 7.4 kW AC chargers + 1 × 30 kW DC charger serving
   e-scooters, AC cars and DC cars with Poisson daily arrivals, Gaussian-mixture
   arrival hours, uniform kWh per session, and a first-come-first-served port queue
   (`src/load_profile.py`).
3. **Hourly dispatch** for a full 8,760-h year: PV → load → LiFePO4 battery → curtail;
   unmet load tracked (`src/dispatch.py`).
4. **Sizing search** over 13 PV sizes × 19 battery sizes = 247 combinations; the design
   is the cheapest one (lowest net present cost) with LPSP ≤ 5 % (`src/sizing.py`).
5. **Economics** - capex, NPC, LCOE, payback against the UP EV-charging grid tariff
   (`src/economics.py`), replicated as live formulas in the Excel workbook.

`python main.py` regenerates everything in `results/` in about 8 s.

## 2. Method and equations

### 2.1 Solar resource → PV output
For every hour (hour-centre used for geometry):

* Declination δ = 23.45° sin(360 (284+n)/365); hour angle ω from solar time
  (IST meridian 82.5 °E, equation of time).
* cos θz = sin φ sin δ + cos φ cos δ cos ω; incidence angle θ on the tilted plane
  from Duffie & Beckman eq. 1.6.2.
* Clearness index k_T = GHI / G_o; diffuse fraction from the **Erbs (1982)** correlation
  [S8]; beam B = GHI − D.
* **Isotropic-sky POA** [S2]:
  `POA = B·R_b + D·(1+cos β)/2 + GHI·ρ·(1−cos β)/2`, R_b = cos θ / cos θz.
* Cell temperature `T_c = T_amb + (NOCT−20)/800 · POA`;
  `P_dc = kWp · POA/1000 · [1 + γ (T_c − 25)] · f_soil · f_wire`;
  `P_ac = min(P_dc · η_inv, kWp / DC:AC) · availability`.

### 2.2 Battery (LiFePO4)
Energy-in-tank model with SOC window 10-90 % (80 % DoD), round-trip efficiency 92 %
split as √η on each leg, and 0.5C charge/discharge limits:

```
charge_t    = min(surplus_t, (E_max − E_t)/√η, 0.5·C)
discharge_t = min(deficit_t, (E_t − E_min)·√η, 0.5·C·√η)
unmet_t     = deficit_t − discharge_t ;   curtail_t = surplus_t − charge_t
LPSP        = Σ unmet / Σ load
```

### 2.3 Economics (HOMER definitions [S7])
```
CRF   = r(1+r)^N / ((1+r)^N − 1)                    r = 8 % real, N = 20 yr
NPC   = CAPEX + O&M/CRF + (inverter + battery replacement at yr 10)/(1+r)^10
LCOE  = NPC / Σ_t served_kWh/(1+r)^t                 (₹/kWh delivered)
Grid alternative NPC = chargers + civil + connection + Σ_t served·tariff·(1+g)^(t−1)/(1+r)^t
```

## 3. How to run

```bash
pip install -r requirements.txt
python main.py        # ~8 s, regenerates results/
pytest -q             # 11 tests
```

If `data/nasa_power_hourly_2025.csv` is missing, re-download it with the URL in
`src/config.py` (`SOURCES[0]`) - it is a public NASA API, no key needed.

## 4. Results (actual numbers from `results/summary.json`)

### 4.1 Daily solar input (real NASA POWER 2025, Ghaziabad)

| Month | GHI kWh/m²/day | POA (28° tilt) kWh/m²/day | AC yield kWh/kWp/day |
|---|---|---|---|
| Jan | 3.10 | 3.70 | 3.10 |
| Feb | 4.39 | 5.32 | 4.32 |
| Mar | 5.99 | 6.68 | 5.22 |
| Apr | 6.66 | 6.64 | 5.09 |
| May | 5.90 | 5.52 | 4.30 |
| Jun | 5.11 | 4.69 | 3.68 |
| Jul | 4.50 | 4.21 | 3.39 |
| Aug | 3.99 | 3.82 | 3.12 |
| Sep | 4.84 | 5.02 | 4.02 |
| Oct | 4.11 | 4.61 | 3.75 |
| Nov | 3.59 | 4.55 | 3.79 |
| Dec | 2.95 | 3.67 | 3.08 |
| **Year** | **1,676 kWh/m² (4.59/day)** | | **1,423 kWh/kWp/yr** |

The monsoon dip (Jul-Aug) and the winter fog/low-sun dip (Dec-Jan) are both visible in
the real data; the tilted plane recovers most of the winter loss.

![Daily solar input](results/daily_solar_input.png)

### 4.2 EV charging demand (synthetic, seed = 2026)

| Quantity | Value |
|---|---|
| Annual demand | **55,672 kWh** (152.5 kWh/day average) |
| Peak hourly load | 44.4 kW (installed charger power 44.8 kW) |
| Sessions served / lost to queue (> 60 min wait) | 5,257 / 848 |
| 2-W scooters (AC, ~1 kW) | 2,187 sessions, 4,890 kWh |
| Cars on AC 7.2 kW | 835 sessions, 11,649 kWh |
| Cars on DC 30 kW | 2,235 sessions, 39,137 kWh |

The 848 lost sessions are almost all scooters and AC cars - two AC ports are the
bottleneck, not energy. Adding a third AC port would be the first upgrade I'd test.

![EV demand](results/ev_demand_profile.png)

### 4.3 Sizing search and chosen design

247 combinations simulated; 178 meet LPSP ≤ 5 %. Cheapest feasible design:

| Item | Value |
|---|---|
| **PV array** | **70 kWp** (DC:AC 1.15 → ~61 kW inverter) |
| **Battery** | **125 kWh LiFePO4** (100 kWh usable = 15.7 h of average load) |
| PV generation | 99,602 kWh/yr |
| Load served / unmet | 53,524 / 2,148 kWh → **LPSP 3.86 %** (96.1 % served) |
| PV direct to load / via battery | 30,086 / 23,438 kWh |
| Curtailed PV | 44,053 kWh (**44 %** of generation - typical for off-grid) |
| Battery throughput | 187.5 equivalent full cycles/yr → 6,000-cycle life not reached before the 10-yr calendar replacement |

![Sizing heatmap](results/sizing_heatmap.png)

![Dispatch April](results/dispatch_week_april.png)
![Dispatch monsoon](results/dispatch_week_monsoon.png)

### 4.4 Monthly energy balance (MWh)

| Month | PV | Load | PV→load | Battery→load | Unmet | Curtailed |
|---|---|---|---|---|---|---|
| Jan | 6.72 | 4.83 | 2.36 | 2.15 | 0.31 | 2.06 |
| Feb | 8.46 | 4.50 | 2.47 | 1.84 | 0.19 | 3.98 |
| Mar | 11.33 | 4.64 | 2.57 | 2.02 | 0.05 | 6.57 |
| Apr | 10.69 | 4.48 | 2.71 | 1.73 | 0.04 | 6.05 |
| May | 9.33 | 5.04 | 2.71 | 2.19 | 0.14 | 4.22 |
| Jun | 7.74 | 4.80 | 2.68 | 1.96 | 0.16 | 3.01 |
| Jul | 7.36 | 4.64 | 2.55 | 1.90 | 0.19 | 2.75 |
| Aug | 6.76 | 4.97 | 2.64 | 2.11 | 0.22 | 1.83 |
| Sep | 8.43 | 4.31 | 2.27 | 1.89 | 0.15 | 4.11 |
| Oct | 8.15 | 4.66 | 2.59 | 1.88 | 0.19 | 3.47 |
| Nov | 7.95 | 4.22 | 2.37 | 1.78 | 0.07 | 3.68 |
| Dec | 6.68 | 4.59 | 2.17 | 1.99 | 0.44 | 2.32 |

Unmet load is concentrated in December-January (fog, short days) - exactly what the
70 kWp / 125 kWh trade-off accepts to stay under the 5 % target.

![Monthly balance](results/monthly_energy_balance.png)

### 4.5 Economics (20 yr, 8 % real)

| Item | ₹ |
|---|---|
| PV array 70 kWp @ ₹48,000/kWp [S3] | 33,60,000 |
| Battery 125 kWh @ ₹20,000/kWh (assumption, anchored on [S4]) | 25,00,000 |
| 2 × AC chargers + 1 × DC charger (assumption) | 7,40,000 |
| Civil / canopy / misc (assumption) | 5,00,000 |
| **Total capex** | **71,00,000 (₹7.10 M)** |
| O&M | 95,000 / yr |
| PV of replacements (inverter + battery at yr 10) | 10,05,130 |
| **Net present cost** | **₹90,37,854 (₹9.04 M)** |
| **LCOE** | **₹17.20 / kWh delivered** |
| Grid-connected alternative NPC (same chargers, energy at ₹7.46/kWh [S5] +3 %/yr) | ₹64,31,307 → LCOE ₹12.24/kWh |
| Simple payback vs grid tariff | 18.3 yr |
| Simple payback on retail revenue (₹15/kWh, assumption) | 10.0 yr |

**Honest conclusion:** with today's assumed prices, a fully off-grid station costs about
40 % more per kWh than a grid-connected one at the UP LMV-11 EV tariff. Off-grid only
makes sense where the grid is absent/unreliable, or with subsidy. The main cost driver is
the 44 % curtailment: the array must be oversized for winter, so 4 of every 9 kWh
produced are thrown away. A grid-tied/hybrid variant that exports the surplus would
change the picture completely - that is the obvious next study.

## 5. Excel workbook (`results/solar_ev_station.xlsx`)

| Sheet | Content |
|---|---|
| `Inputs` | every price, rate and size (yellow cells) - change them and the workbook recalculates |
| `Solar_Monthly` | real monthly irradiation + `= yield × Inputs!PV_kWp` formulas + chart |
| `Load_Profile` | 24-h mean/P10/P90 profile, per-class table with share formulas + chart |
| `Sizing_Grid` | all 247 runs; capex and feasibility are formulas; `MINIFS/INDEX/MATCH` picks the design |
| `Dispatch_Annual` | annual dispatch numbers with LPSP / curtailment / energy-balance check formulas |
| `Economics` | 29 live formulas (capex → CRF → NPC → LCOE → grid NPC → paybacks) plus a Python cross-check row (difference 3 × 10⁻⁵ ₹/kWh) |
| `Assumptions_Sources` | this section 7/8 as a table |

I verified the workbook by recalculating it headlessly in LibreOffice: no `#REF!`,
`#DIV/0!` or `#NAME?` cells, and the formula LCOE equals the Python LCOE.

## 6. Tests (`pytest -q` → 11 passed)

* NASA file is complete (8,760 rows, no fill values) and annual GHI plausible
* POA ≥ 0, zero at night, yield within 1,200-1,800 kWh/kWp, clipping respected
* load reproducible (seeded), non-negative, never above installed charger power
* hourly energy balance closes to < 1e-9 kWh; battery energy balance closes to < 1e-6 kWh
* SOC stays within 10-90 %; C-rate limits respected
* battery reduces LPSP; chosen design meets LPSP ≤ 5 % and is the min-NPC feasible point
* LCOE > 0, NPC > capex, CRF(8 %, 20 yr) = 0.1019
* `summary.json` served + unmet = load

## 7. Limitations

* **No HOMER/PVsyst licence** - my dispatch is a simple load-following strategy; HOMER
  would also try cycle-charging and could include a diesel genset or grid export.
* **Single weather year (2025)** repeated for 20 years, no PV degradation (0.5 %/yr
  would raise LCOE ~5 %), no interannual variability.
* **Synthetic demand.** Arrival rates, kWh per session and time-of-day peaks are my
  assumptions. Real station data would change the sizing; the code takes any 8,760-h
  load array.
* **Hourly resolution** hides sub-hour peaks (a 30 kW DC session plus two AC sessions
  can hit 44.8 kW instantaneously; the inverter is sized at ~61 kW so this is OK here).
* **Isotropic-sky transposition** (not Perez) and NASA POWER's 0.5° × 0.625° grid cell
  - errors of ±5-10 % in POA are normal.
* **Prices**: MNRE benchmark is from FY2019-20 (module prices fell since, but duties
  and ALMM rules rose); battery ₹20,000/kWh is my estimate for a small C&I LFP system.
  All are single-point inputs in the workbook - the sensitivity is one cell edit away.
* Land, permits, GST, insurance, and financing costs are not modelled.

## 8. Sources

| ID | Source | URL |
|---|---|---|
| S1 | NASA POWER hourly API, `ALLSKY_SFC_SW_DWN`, `T2M`, 2025, 28.67 N 77.42 E (**real data**, saved in `data/`) | https://power.larc.nasa.gov/api/temporal/hourly/point?parameters=ALLSKY_SFC_SW_DWN,T2M&community=RE&longitude=77.42&latitude=28.67&start=20250101&end=20251231&format=CSV |
| S2 | Duffie & Beckman, *Solar Engineering of Thermal Processes* - isotropic-sky transposition, incidence angle | https://onlinelibrary.wiley.com/doi/book/10.1002/9781118671603 |
| S3 | MNRE rooftop solar benchmark cost FY2019-20: ₹48/W for 10-100 kW (Saur Energy, 19 Jul 2019) | https://www.saurenergy.com/solar-energy-news/mnre-benchmark-costs-rooftop-solar-installations |
| S4 | Ember analysis via RESI India (Dec 2025): utility-scale BESS capex ≈ US$125/kWh; India auctions imply ≈ US$120/kWh | https://www.resiindia.org/post/battery-storage-costs-plummet-utility-scale-projects-now-at-125-kwh-lcos-hits-65-mwh |
| S5 | UPERC Tariff Order FY2024-25 (10 Oct 2024) - LMV-11 Electric Vehicle charging, average billing rate ₹7.46/kWh (p. 667) | https://dvvnl.org/UploadFiles/tariffPlan/UPPCL%20Tariff%20Order%202024-25%20dt%2010.10.2024.pdf |
| S6 | ICCT (Bieker, 2021) Table A.8 - Tata Nexon EV 30.2 kWh; Indian EV real-world consumption | https://theicct.org/sites/default/files/publications/Global-LCA-passenger-cars-jul2021_0.pdf |
| S7 | HOMER Pro documentation - NPC, LCOE, CRF and load-following dispatch definitions | https://homerenergy.com/products/pro/docs/latest/index.html |
| S8 | Erbs, Klein & Duffie (1982), diffuse-fraction correlation, *Solar Energy* 28(4) | https://doi.org/10.1016/0038-092X(82)90302-4 |

### Declared assumptions (also in the workbook)

| # | Assumption | Basis |
|---|---|---|
| 1 | Tilt 28°, south, albedo 0.20 | tilt ≈ latitude |
| 2 | Soiling 4 %, wiring/mismatch 3 %, inverter 96 %, availability 98 %, NOCT 45 °C, γ = −0.35 %/°C | typical datasheet values |
| 3 | DC:AC 1.15 with clipping | design practice |
| 4 | LFP SOC 10-90 %, RTE 92 %, 0.5C, 6,000 cycles, 10-yr replacement at 70 % cost | LFP datasheets, falling prices |
| 5 | Arrivals: scooters 8/weekday (1.5-3 kWh @ 1 kW), AC cars 3/weekday (8-20 kWh @ 7.2 kW), DC cars 6/weekday (10-25 kWh @ 30 kW); weekend factors 0.8/0.9/1.1; 60-min max wait | no measured data - synthetic |
| 6 | 20-yr life, 8 % real discount rate | common for Indian RE appraisals |
| 7 | Battery ₹20,000/kWh, AC charger ₹70k, DC 30 kW ₹6 L, civil ₹5 L, grid connection ₹3 L, O&M ₹1,000/kWp + ₹200/kWh per yr, inverter ₹6,000/kWp at yr 10 | estimates |
| 8 | Grid tariff escalation 3 %/yr; retail charging price ₹15/kWh | estimates |
| 9 | Weather year 2025 repeated; no degradation | simplification |

## 9. File tree

```
03_Solar_Powered_EV_Charging_Station/
├── README.md, requirements.txt, main.py
├── data/nasa_power_hourly_2025.csv        # REAL NASA POWER download (8,760 h)
├── src/
│   ├── config.py        # all parameters + SOURCES + ASSUMPTIONS
│   ├── solar.py         # NASA loader, POA transposition, PV model
│   ├── load_profile.py  # synthetic EV sessions + port queue -> 8760-h load
│   ├── dispatch.py      # hourly PV/battery/unmet dispatch
│   ├── sizing.py        # PV x battery grid search
│   ├── economics.py     # capex, NPC, LCOE, payback
│   ├── plots.py         # all figures
│   └── excel_report.py  # openpyxl workbook with live formulas
├── tests/test_station.py
└── results/
    ├── summary.json, solar_monthly.csv, ev_sessions.csv, sizing_grid.csv,
    │   hourly_dispatch.csv, monthly_energy_balance.csv
    ├── daily_solar_input.png, ev_demand_profile.png, dispatch_week_april.png,
    │   dispatch_week_monsoon.png, sizing_heatmap.png, monthly_energy_balance.png
    └── solar_ev_station.xlsx
```
