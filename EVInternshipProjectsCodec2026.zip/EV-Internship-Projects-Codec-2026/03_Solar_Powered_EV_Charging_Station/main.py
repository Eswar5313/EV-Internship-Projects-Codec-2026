"""
Off-grid solar EV charging station - HOMER-style techno-economic simulation.
Run:  python main.py          (regenerates everything in results/ in well under a minute)
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict

import numpy as np
import pandas as pd

from src.config import (ASSUMPTIONS, BATTERY, CHARGERS, ECON, NASA_FILE, PV, RESULTS_DIR,
                        SEARCH, SITE, SOURCES)
from src.dispatch import simulate
from src.economics import evaluate
from src.excel_report import build_workbook
from src.load_profile import build_load, load_summary
from src.plots import (plot_daily_solar, plot_load_profile, plot_monthly_balance,
                       plot_sizing_heatmap, plot_week_dispatch)
from src.sizing import choose_design, run_grid
from src.solar import load_nasa_power, monthly_solar_table, pv_ac_per_kwp


def main() -> dict:
    t0 = time.time()
    RESULTS_DIR.mkdir(exist_ok=True)

    # 1. Solar resource (REAL NASA POWER data) and PV model
    if not NASA_FILE.exists():
        raise SystemExit(f"{NASA_FILE} missing - download it with the URL in src/config.py SOURCES[0]")
    wx = load_nasa_power()
    ac_per_kwp = pv_ac_per_kwp(wx)
    monthly = monthly_solar_table(wx, ac_per_kwp)
    monthly.round(3).to_csv(RESULTS_DIR / "solar_monthly.csv")
    print(f"[solar] annual GHI {wx.ghi_wm2.sum()/1000:.0f} kWh/m2, specific yield {ac_per_kwp.sum():.0f} kWh/kWp/yr")

    # 2. EV charging demand (DECLARED SYNTHETIC, seeded)
    load, sessions = build_load()
    lsum = load_summary(load, sessions)
    sessions.round(3).to_csv(RESULTS_DIR / "ev_sessions.csv", index=False)
    print(f"[load] {lsum['annual_load_kwh']:.0f} kWh/yr, {lsum['mean_daily_load_kwh']:.0f} kWh/day, "
          f"peak {lsum['peak_hourly_load_kw']:.1f} kW, lost sessions {lsum['sessions_lost_queue']}")

    # 3. Sizing search
    grid = run_grid(ac_per_kwp, load)
    grid.round(4).to_csv(RESULTS_DIR / "sizing_grid.csv", index=False)
    chosen = choose_design(grid)
    print(f"[sizing] chosen {chosen.pv_kwp:.0f} kWp PV + {chosen.batt_kwh:.0f} kWh battery, "
          f"LPSP {chosen.lpsp*100:.2f} %, NPC Rs {chosen.npc_inr/1e6:.2f} M, LCOE Rs {chosen.lcoe_inr_per_kwh:.2f}/kWh")

    # 4. Detailed dispatch of chosen design
    pv = ac_per_kwp * chosen.pv_kwp
    res = simulate(pv, load, float(chosen.batt_kwh))
    dsum = res.annual_summary()
    hourly = pd.DataFrame({"time": wx.time, "pv_kwh": res.pv_kwh, "load_kwh": res.load_kwh,
                           "pv_to_load": res.pv_to_load, "batt_charge": res.batt_charge,
                           "batt_discharge": res.batt_discharge, "curtailed": res.curtailed,
                           "unmet": res.unmet, "soc": res.soc})
    hourly.to_csv(RESULTS_DIR / "hourly_dispatch.csv", index=False, float_format="%.4f")
    econ = evaluate(float(chosen.pv_kwp), float(chosen.batt_kwh), dsum["served_kwh"], dsum["load_kwh"])

    # 5. Plots
    plot_daily_solar(monthly)
    plot_load_profile(load, sessions)
    plot_week_dispatch(res, 90, "Typical week dispatch - April (high sun), chosen design", RESULTS_DIR / "dispatch_week_april.png")
    plot_week_dispatch(res, 210, "Typical week dispatch - late July / monsoon, chosen design", RESULTS_DIR / "dispatch_week_monsoon.png")
    plot_sizing_heatmap(grid, chosen, SEARCH.lpsp_target)
    mbal = plot_monthly_balance(res, wx.month.to_numpy())
    mbal.round(3).to_csv(RESULTS_DIR / "monthly_energy_balance.csv")

    # 6. Summary JSON
    summary = {
        "project": "Off-grid solar EV charging station, Ghaziabad (HOMER-style Python simulation)",
        "author": "Eswar Mahalingam", "organisation": "Codec Technologies India", "date": "September 2026",
        "data_provenance": {
            "irradiance_temperature": "REAL - NASA POWER hourly 2025 (data/nasa_power_hourly_2025.csv)",
            "ev_load": "SYNTHETIC - seeded stochastic model (src/load_profile.py)",
            "costs": "MNRE / UPERC / Ember cited where available; remainder declared assumptions",
        },
        "site": asdict(SITE),
        "solar": {"annual_ghi_kwh_m2": float(wx.ghi_wm2.sum() / 1000),
                  "mean_daily_ghi_kwh_m2": float(wx.ghi_wm2.sum() / 1000 / 365),
                  "specific_yield_kwh_per_kwp_yr": float(ac_per_kwp.sum()),
                  "monthly_daily_ghi_kwh_m2": monthly.ghi_kwh_m2_day.round(3).to_dict()},
        "load": lsum,
        "chargers": asdict(CHARGERS),
        "battery_params": asdict(BATTERY),
        "pv_params": asdict(PV),
        "sizing": {"search_space": {"pv_kwp": list(SEARCH.pv_kwp_grid), "batt_kwh": list(SEARCH.batt_kwh_grid)},
                   "lpsp_target": SEARCH.lpsp_target,
                   "n_combinations": int(len(grid)), "n_feasible": int(grid.feasible.sum()),
                   "chosen_pv_kwp": float(chosen.pv_kwp), "chosen_batt_kwh": float(chosen.batt_kwh),
                   "battery_hours_of_mean_load": float(chosen.batt_kwh * (BATTERY.soc_max - BATTERY.soc_min) / lsum["mean_daily_load_kwh"] * 24)},
        "dispatch_annual": dsum,
        "monthly_energy_balance_mwh": mbal.round(3).to_dict(orient="index"),
        "economics": {k: (float(v) if isinstance(v, (int, float, np.floating)) else v) for k, v in econ.items()},
        "economics_params": asdict(ECON),
        "checks": {"hourly_energy_balance_max_error_kwh": res.energy_balance_error(),
                   "battery_energy_balance_error_kwh": res.battery_balance_error(np.sqrt(BATTERY.round_trip_eff), np.sqrt(BATTERY.round_trip_eff), BATTERY.soc_initial),
                   "soc_min": float(res.soc.min()), "soc_max": float(res.soc.max())},
        "sources": [{"id": s[0], "description": s[1], "url": s[2]} for s in SOURCES],
        "assumptions": [{"assumption": a, "basis": b} for a, b in ASSUMPTIONS],
        "runtime_s": None,
    }

    # 7. Excel workbook with live formulas
    build_workbook(RESULTS_DIR / "solar_ev_station.xlsx", monthly, load, lsum, grid, chosen, dsum, econ)

    summary["runtime_s"] = round(time.time() - t0, 1)
    with open(RESULTS_DIR / "summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=float)
    print(f"[econ] capex Rs {econ['total_capex_inr']/1e6:.2f} M, NPC Rs {econ['npc_inr']/1e6:.2f} M, "
          f"LCOE Rs {econ['lcoe_inr_per_kwh']:.2f}/kWh vs grid-alternative LCOE Rs {econ['grid_alternative_lcoe_inr_per_kwh']:.2f}/kWh")
    print(f"done in {summary['runtime_s']} s -> {RESULTS_DIR}")
    return summary


if __name__ == "__main__":
    main()
