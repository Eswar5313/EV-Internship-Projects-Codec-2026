// Dynamic Expo config: layers API keys from .env on top of app.json so that
// the Google Maps key never has to be committed. `expo start` loads .env
// automatically (Expo SDK 49+).
//
//   GOOGLE_MAPS_API_KEY      -> android.config.googleMaps.apiKey (react-native-maps, PROVIDER_GOOGLE)
//                            -> ios.config.googleMapsApiKey
//                            -> extra.googleMapsApiKey  (Directions API calls from src/services/directions.ts)
//   OPEN_CHARGE_MAP_API_KEY  -> extra.openChargeMapApiKey (src/services/stations.ts)
//   FIREBASE_DATABASE_URL    -> extra.firebaseDatabaseUrl (optional real-time availability)
//   THINGSPEAK_CHANNEL_ID    -> extra.thingSpeakChannelId (optional alternative)

const base = require('./app.json');

module.exports = ({ config }) => {
  const googleMapsApiKey = process.env.GOOGLE_MAPS_API_KEY || '';
  return {
    ...base.expo,
    ...config,
    android: {
      ...base.expo.android,
      config: { googleMaps: { apiKey: googleMapsApiKey } },
    },
    ios: {
      ...base.expo.ios,
      config: { googleMapsApiKey },
    },
    extra: {
      googleMapsApiKey,
      openChargeMapApiKey: process.env.OPEN_CHARGE_MAP_API_KEY || '',
      firebaseDatabaseUrl: process.env.FIREBASE_DATABASE_URL || '',
      thingSpeakChannelId: process.env.THINGSPEAK_CHANNEL_ID || '',
      thingSpeakReadKey: process.env.THINGSPEAK_READ_KEY || '',
    },
  };
};
