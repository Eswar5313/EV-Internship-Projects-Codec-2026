import type { NativeStackScreenProps } from '@react-navigation/native-stack';

import type { Station } from './types';

export type RootStackParamList = {
  Map: undefined;
  StationDetail: { station: Station; distanceKm?: number };
};

export type MapScreenProps = NativeStackScreenProps<RootStackParamList, 'Map'>;
export type StationDetailProps = NativeStackScreenProps<RootStackParamList, 'StationDetail'>;
