import React, { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Callout, Marker } from 'react-native-maps';

import { maxPowerKw } from '../logic/nearest';
import { STATUS_COLORS, STATUS_LABELS } from '../theme';
import type { Station } from '../types';

interface Props {
  station: Station;
  /** Highlight as a planned charging stop (numbered). */
  stopIndex?: number;
  selected?: boolean;
  onPress: (station: Station) => void;
}

function StationMarkerBase({ station, stopIndex, selected, onPress }: Props) {
  const colour = STATUS_COLORS[station.availability.status];
  const kw = maxPowerKw(station);
  return (
    <Marker
      coordinate={{ latitude: station.lat, longitude: station.lon }}
      onPress={() => onPress(station)}
      tracksViewChanges={false}
      anchor={{ x: 0.5, y: 1 }}
    >
      <View style={[styles.pin, { backgroundColor: colour }, selected && styles.selected]}>
        <Text style={styles.pinText}>{stopIndex !== undefined ? String(stopIndex + 1) : '⚡'}</Text>
      </View>
      <View style={[styles.tail, { borderTopColor: colour }]} />
      <Callout tooltip={false}>
        <View style={styles.callout}>
          <Text style={styles.title}>{station.name}</Text>
          <Text style={styles.sub}>
            {STATUS_LABELS[station.availability.status]} · {station.availability.available}/
            {station.availability.total} free · {kw} kW
          </Text>
          <Text style={styles.sub}>
            {station.currency} {station.pricePerKwh}/kWh · {station.operator}
          </Text>
        </View>
      </Callout>
    </Marker>
  );
}

export const StationMarker = memo(StationMarkerBase);

const styles = StyleSheet.create({
  pin: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
    elevation: 3,
  },
  selected: { transform: [{ scale: 1.25 }], borderColor: '#0B3D2E' },
  pinText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  tail: {
    alignSelf: 'center',
    width: 0,
    height: 0,
    borderLeftWidth: 5,
    borderRightWidth: 5,
    borderTopWidth: 7,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
  },
  callout: { minWidth: 180, padding: 4 },
  title: { fontWeight: '700', marginBottom: 2 },
  sub: { fontSize: 12, color: '#444' },
});
