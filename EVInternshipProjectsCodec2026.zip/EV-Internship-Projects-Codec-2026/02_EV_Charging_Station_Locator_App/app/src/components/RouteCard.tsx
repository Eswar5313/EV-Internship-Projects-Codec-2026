import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import type { RoutePlan, RouteResult } from '../logic/routeOptimizer';
import { COLORS } from '../theme';

interface Props {
  result: RouteResult | null;
  /** True while Google Directions is refining the estimate. */
  refining?: boolean;
  /** Whether Google road distances (vs haversine estimate) are in use. */
  roadDistances?: boolean;
  onClose: () => void;
  onStopPress?: (stopIndex: number) => void;
}

const mins = (m: number) => {
  const h = Math.floor(m / 60);
  const r = Math.round(m % 60);
  return h > 0 ? `${h} h ${r} min` : `${r} min`;
};
const pct = (soc: number) => `${Math.round(soc * 100)} %`;

function PlanBody({ plan, onStopPress }: { plan: RoutePlan; onStopPress?: (i: number) => void }) {
  return (
    <View>
      <View style={styles.summaryRow}>
        <Stat label="Total" value={mins(plan.totalMinutes)} strong />
        <Stat label="Drive" value={mins(plan.driveMinutes)} />
        <Stat label="Charge" value={mins(plan.chargeMinutes)} />
        <Stat label="Wait" value={mins(plan.waitMinutes)} />
        <Stat label="Distance" value={`${plan.totalDistanceKm.toFixed(0)} km`} />
      </View>
      {plan.stops.length === 0 ? (
        <Text style={styles.ok}>
          No charging needed — arrive with {pct(plan.finalSoc)} battery.
        </Text>
      ) : (
        plan.stops.map((stop, i) => (
          <TouchableOpacity
            key={stop.station.id}
            style={styles.stop}
            onPress={() => onStopPress?.(i)}
            accessibilityRole="button"
          >
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{i + 1}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.stopName}>{stop.station.name}</Text>
              <Text style={styles.stopMeta}>
                Arrive {pct(stop.arrivalSoc)} → leave {pct(stop.departureSoc)} · {stop.chargeKwh.toFixed(1)} kWh @{' '}
                {stop.powerKw} kW · {mins(stop.chargeMinutes)}
                {stop.waitMinutes > 0 ? ` · wait ${mins(stop.waitMinutes)}` : ''}
              </Text>
            </View>
          </TouchableOpacity>
        ))
      )}
      {plan.stops.length > 0 && (
        <Text style={styles.foot}>
          Arrive with {pct(plan.finalSoc)}. {plan.candidatesConsidered} stations considered
          {plan.greedyMinutes !== null && plan.greedyMinutes - plan.totalMinutes > 0.5
            ? ` · ${mins(plan.greedyMinutes - plan.totalMinutes)} faster than greedy`
            : ''}
          .
        </Text>
      )}
    </View>
  );
}

function Stat({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <View style={styles.stat}>
      <Text style={[styles.statValue, strong && styles.statStrong]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

/** Bottom card summarising the optimised route (or why none exists). */
export function RouteCard({ result, refining, roadDistances, onClose, onStopPress }: Props) {
  if (!result) return null;
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <Text style={styles.title}>
          {result.ok ? 'Optimised route' : 'Destination unreachable'}
          {refining ? '  · refining…' : ''}
        </Text>
        <TouchableOpacity onPress={onClose} accessibilityRole="button" accessibilityLabel="Close route">
          <Text style={styles.close}>✕</Text>
        </TouchableOpacity>
      </View>
      {result.ok ? (
        <PlanBody plan={result.plan} onStopPress={onStopPress} />
      ) : (
        <Text style={styles.err}>{result.message}</Text>
      )}
      <Text style={styles.source}>
        {roadDistances ? 'Road distances from Google Directions.' : 'Estimated distances (haversine × 1.3).'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.card,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
    elevation: 8,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 8,
  },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  close: { fontSize: 18, color: COLORS.muted, padding: 4 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 10 },
  stat: { alignItems: 'center', flex: 1 },
  statValue: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  statStrong: { color: COLORS.route, fontSize: 16 },
  statLabel: { fontSize: 11, color: COLORS.muted },
  ok: { color: COLORS.accent, fontWeight: '600' },
  err: { color: COLORS.danger, marginTop: 8 },
  stop: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  badge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.route,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  badgeText: { color: '#fff', fontWeight: '700', fontSize: 12 },
  stopName: { fontWeight: '600', color: COLORS.text },
  stopMeta: { fontSize: 12, color: COLORS.muted },
  foot: { fontSize: 12, color: COLORS.muted, marginTop: 6 },
  source: { fontSize: 11, color: COLORS.muted, marginTop: 8, fontStyle: 'italic' },
});
