import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import type { StationFilter } from '../logic/nearest';
import { COLORS } from '../theme';
import type { ConnectorType } from '../types';

interface Props {
  filter: StationFilter;
  onChange: (next: StationFilter) => void;
}

const CONNECTORS: ConnectorType[] = ['CCS2', 'CHAdeMO', 'Type2', 'GB/T', 'Bharat-DC-001'];
const POWER_STEPS = [
  { label: 'Any kW', value: undefined },
  { label: '≥ 22 kW', value: 22 },
  { label: '≥ 50 kW', value: 50 },
  { label: '≥ 100 kW', value: 100 },
];

function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      style={[styles.chip, active && styles.chipActive]}
    >
      <Text style={[styles.chipText, active && styles.chipTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

/** Horizontal chip row: availability toggle, power threshold, connector types. */
export function FilterBar({ filter, onChange }: Props) {
  const types = new Set(filter.connectorTypes ?? []);
  const toggleType = (t: ConnectorType) => {
    const next = new Set(types);
    if (next.has(t)) next.delete(t);
    else next.add(t);
    onChange({ ...filter, connectorTypes: next.size ? [...next] : undefined });
  };
  return (
    <View style={styles.wrap}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
        <Chip
          label="Free now"
          active={!!filter.onlyAvailable}
          onPress={() => onChange({ ...filter, onlyAvailable: !filter.onlyAvailable })}
        />
        {POWER_STEPS.map((p) => (
          <Chip
            key={p.label}
            label={p.label}
            active={filter.minPowerKw === p.value}
            onPress={() => onChange({ ...filter, minPowerKw: p.value })}
          />
        ))}
        <View style={styles.divider} />
        {CONNECTORS.map((t) => (
          <Chip key={t} label={t} active={types.has(t)} onPress={() => toggleType(t)} />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { backgroundColor: 'transparent' },
  row: { paddingHorizontal: 12, paddingVertical: 8, alignItems: 'center' },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginRight: 8,
    elevation: 2,
  },
  chipActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  chipText: { fontSize: 13, color: COLORS.text },
  chipTextActive: { color: '#fff', fontWeight: '600' },
  divider: { width: 1, height: 20, backgroundColor: COLORS.border, marginRight: 8 },
});
