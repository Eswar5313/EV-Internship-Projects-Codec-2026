/**
 * Google Directions API client.
 *
 * Given the ordered stops chosen by the route optimiser, ask Google for the
 * actual road route through them and decode the overview polyline for the
 * map. Also exposed: refineWithRoadDistances(), which re-runs the optimiser's
 * time model with Google's leg distances/durations instead of the haversine
 * * detourFactor estimate.
 *
 * Requires "Directions API" to be enabled for GOOGLE_MAPS_API_KEY.
 */
import { CONFIG } from '../config';
import { decodePolyline } from '../logic/polyline';
import type { RoutePlan } from '../logic/routeOptimizer';
import type { LatLng } from '../types';

const DIRECTIONS_BASE = 'https://maps.googleapis.com/maps/api/directions/json';

export interface DirectionsLeg {
  distanceKm: number;
  durationMin: number;
  startAddress: string;
  endAddress: string;
}

export interface DirectionsResult {
  polyline: LatLng[];
  legs: DirectionsLeg[];
  distanceKm: number;
  durationMin: number;
  /** Google's own summary, e.g. "NH 9". */
  summary: string;
}

interface GoogleDirectionsResponse {
  status: string;
  error_message?: string;
  routes: Array<{
    summary: string;
    overview_polyline: { points: string };
    legs: Array<{
      distance: { value: number };
      duration: { value: number };
      start_address: string;
      end_address: string;
    }>;
  }>;
}

const fmt = (p: LatLng) => `${p.lat.toFixed(6)},${p.lon.toFixed(6)}`;

export function buildDirectionsUrl(origin: LatLng, destination: LatLng, waypoints: LatLng[]): string {
  const q = new URLSearchParams({
    origin: fmt(origin),
    destination: fmt(destination),
    mode: 'driving',
    region: 'in',
    key: CONFIG.googleMapsApiKey,
  });
  if (waypoints.length > 0) {
    // Stops are already in travel order from the optimiser, so no "optimize:true".
    q.set('waypoints', waypoints.map(fmt).join('|'));
  }
  return `${DIRECTIONS_BASE}?${q.toString()}`;
}

export async function getDirections(
  origin: LatLng,
  destination: LatLng,
  waypoints: LatLng[] = [],
  signal?: AbortSignal,
): Promise<DirectionsResult> {
  if (!CONFIG.googleMapsApiKey) throw new Error('GOOGLE_MAPS_API_KEY is not configured');
  const res = await fetch(buildDirectionsUrl(origin, destination, waypoints), { signal });
  if (!res.ok) throw new Error(`Directions HTTP ${res.status}`);
  const body = (await res.json()) as GoogleDirectionsResponse;
  if (body.status !== 'OK' || body.routes.length === 0) {
    throw new Error(`Directions API: ${body.status}${body.error_message ? ` - ${body.error_message}` : ''}`);
  }
  const route = body.routes[0];
  const legs = route.legs.map((l) => ({
    distanceKm: l.distance.value / 1000,
    durationMin: l.duration.value / 60,
    startAddress: l.start_address,
    endAddress: l.end_address,
  }));
  return {
    polyline: decodePolyline(route.overview_polyline.points),
    legs,
    distanceKm: legs.reduce((s, l) => s + l.distanceKm, 0),
    durationMin: legs.reduce((s, l) => s + l.durationMin, 0),
    summary: route.summary,
  };
}

/** Directions for a finished RoutePlan (origin -> stops -> destination). */
export function getDirectionsForPlan(plan: RoutePlan, signal?: AbortSignal): Promise<DirectionsResult> {
  return getDirections(
    plan.origin,
    plan.destination,
    plan.stops.map((s) => ({ lat: s.station.lat, lon: s.station.lon })),
    signal,
  );
}

/**
 * Replace the estimated drive distance/time in a plan with Google's values,
 * keeping the optimiser's charge and wait estimates. Leg count must match.
 */
export function refineWithRoadDistances(plan: RoutePlan, dirs: DirectionsResult): RoutePlan {
  if (dirs.legs.length !== plan.legs.length) return plan;
  const legs = plan.legs.map((leg, i) => ({
    ...leg,
    distanceKm: dirs.legs[i].distanceKm,
    driveMinutes: dirs.legs[i].durationMin,
  }));
  const driveMinutes = legs.reduce((s, l) => s + l.driveMinutes, 0);
  return {
    ...plan,
    legs,
    totalDistanceKm: dirs.distanceKm,
    driveMinutes,
    totalMinutes: driveMinutes + plan.chargeMinutes + plan.waitMinutes + plan.overheadMinutes,
  };
}
