/**
 * Station data source: Open Charge Map (OCM) with a bundled fallback.
 *
 *  - fetchStations() queries https://api.openchargemap.io/v3/poi around a
 *    point, maps each POI to our Station type and returns it.
 *  - If the key is missing, the network fails, or OCM returns nothing, the
 *    bundled data/stations_sample.json is returned instead — flagged with
 *    `source: 'synthetic'` so the UI can show a "sample data" banner.
 */
import { CONFIG } from '../config';
import type { ConnectorType, LatLng, Station } from '../types';
import sample from '../data/stations_sample.json';

const OCM_BASE = 'https://api.openchargemap.io/v3/poi';

/** Open Charge Map connection-type ids -> our connector enum. */
const OCM_CONNECTION_TYPES: Record<number, ConnectorType> = {
  33: 'CCS2', // CCS (Type 2)
  2: 'CHAdeMO',
  25: 'Type2', // Type 2 (Socket Only)
  1036: 'Type2', // Type 2 (Tethered)
  1040: 'GB/T', // GB-T DC
  1039: 'GB/T', // GB-T AC
  1042: 'Bharat-DC-001',
  1041: 'Bharat-AC-001',
};

/** Minimal shape of the OCM POI fields we use. */
interface OcmPoi {
  ID: number;
  UUID: string;
  AddressInfo: {
    Title: string;
    AddressLine1?: string;
    Town?: string;
    Latitude: number;
    Longitude: number;
    AccessComments?: string;
  };
  OperatorInfo?: { Title?: string } | null;
  StatusType?: { IsOperational?: boolean; Title?: string } | null;
  UsageCost?: string | null;
  NumberOfPoints?: number | null;
  Connections?: Array<{
    ConnectionTypeID?: number;
    PowerKW?: number | null;
    Quantity?: number | null;
    StatusType?: { IsOperational?: boolean } | null;
  }> | null;
  DateLastStatusUpdate?: string | null;
}

/** Parse "₹18/kWh", "Rs. 15 per kWh", "18.5 INR/kWh" -> 18.5; NaN when absent. */
export function parsePricePerKwh(text: string | null | undefined): number {
  if (!text) return Number.NaN;
  const m = text.replace(/,/g, '').match(/(\d+(?:\.\d+)?)\s*(?:INR|Rs\.?|₹)?\s*(?:\/|per)\s*kWh/i);
  if (m) return parseFloat(m[1]);
  const m2 = text.match(/(?:₹|Rs\.?|INR)\s*(\d+(?:\.\d+)?)/i);
  return m2 ? parseFloat(m2[1]) : Number.NaN;
}

export function mapOcmPoi(poi: OcmPoi): Station {
  const conns = (poi.Connections ?? []).map((c) => ({
    type: OCM_CONNECTION_TYPES[c.ConnectionTypeID ?? -1] ?? ('Other' as ConnectorType),
    powerKw: c.PowerKW ?? 0,
    count: c.Quantity ?? 1,
  }));
  const total = conns.reduce((s, c) => s + c.count, 0) || poi.NumberOfPoints || 0;
  const operational = poi.StatusType?.IsOperational !== false;
  const price = parsePricePerKwh(poi.UsageCost);
  return {
    id: `OCM-${poi.ID}`,
    name: poi.AddressInfo.Title,
    operator: poi.OperatorInfo?.Title ?? 'Unknown operator',
    address: [poi.AddressInfo.AddressLine1, poi.AddressInfo.Town].filter(Boolean).join(', '),
    lat: poi.AddressInfo.Latitude,
    lon: poi.AddressInfo.Longitude,
    connectors: conns,
    pricePerKwh: Number.isNaN(price) ? 0 : price,
    currency: 'INR',
    hours: poi.AddressInfo.AccessComments ?? '',
    availability: {
      total,
      available: 0,
      // OCM is a directory, not a live feed: it knows "operational" but not
      // "free right now". Real-time counts come from availability.ts.
      status: operational ? 'unknown' : 'offline',
      waitMinutes: 0,
      updatedAt: poi.DateLastStatusUpdate ?? new Date(0).toISOString(),
    },
    source: 'openchargemap',
  };
}

export interface FetchResult {
  stations: Station[];
  /** 'openchargemap' when live data was used, 'synthetic' for the bundled file. */
  source: Station['source'];
  /** Human-readable reason when the fallback was used. */
  fallbackReason?: string;
}

/** Bundled sample data (declared synthetic — see data/stations_sample.json). */
export function bundledStations(): Station[] {
  return (sample.stations as Station[]).map((s) => ({ ...s, source: 'synthetic' as const }));
}

export function buildOcmUrl(centre: LatLng, radiusKm: number, maxResults = 100): string {
  const q = new URLSearchParams({
    output: 'json',
    countrycode: 'IN',
    latitude: centre.lat.toString(),
    longitude: centre.lon.toString(),
    distance: radiusKm.toString(),
    distanceunit: 'km',
    maxresults: maxResults.toString(),
    compact: 'true',
    verbose: 'false',
  });
  return `${OCM_BASE}?${q.toString()}`;
}

export async function fetchStations(
  centre: LatLng = CONFIG.defaultCentre,
  radiusKm: number = CONFIG.searchRadiusKm,
  opts: { signal?: AbortSignal; timeoutMs?: number } = {},
): Promise<FetchResult> {
  if (!CONFIG.openChargeMapApiKey) {
    return {
      stations: bundledStations(),
      source: 'synthetic',
      fallbackReason: 'OPEN_CHARGE_MAP_API_KEY not set',
    };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 10_000);
  try {
    const res = await fetch(buildOcmUrl(centre, radiusKm), {
      headers: { 'X-API-Key': CONFIG.openChargeMapApiKey, Accept: 'application/json' },
      signal: opts.signal ?? controller.signal,
    });
    if (!res.ok) throw new Error(`Open Charge Map HTTP ${res.status}`);
    const pois = (await res.json()) as OcmPoi[];
    const stations = pois
      .filter((p) => p.AddressInfo && Number.isFinite(p.AddressInfo.Latitude))
      .map(mapOcmPoi);
    if (stations.length === 0) {
      return { stations: bundledStations(), source: 'synthetic', fallbackReason: 'OCM returned 0 POIs' };
    }
    return { stations, source: 'openchargemap' };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { stations: bundledStations(), source: 'synthetic', fallbackReason: msg };
  } finally {
    clearTimeout(timer);
  }
}
