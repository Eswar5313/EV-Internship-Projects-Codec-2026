/**
 * Real-time availability.
 *
 * Three interchangeable sources behind one `subscribeAvailability()` call:
 *
 *   'firebase'   Firebase Realtime Database listener on /availability/{stationId}
 *                (push; sub-second latency). Schema in README section 6.
 *   'thingspeak' Polls a ThingSpeak channel whose fields carry
 *                stationId/available/total/status — cheap option for a
 *                student build with an ESP32 at each charger.
 *   'simulated'  Random-walks the bundled sample availability so the UI can
 *                be demonstrated without any backend. Clearly labelled.
 *
 * The source is chosen automatically from CONFIG unless overridden.
 */
import { CONFIG } from '../config';
import type { Availability, Station } from '../types';

export type AvailabilitySource = 'firebase' | 'thingspeak' | 'simulated';

export type AvailabilityUpdate = Record<string, Availability>;
export type Unsubscribe = () => void;

export interface SubscribeOptions {
  source?: AvailabilitySource;
  /** Poll interval for thingspeak / simulated (ms). */
  intervalMs?: number;
  onError?: (e: Error) => void;
}

export function pickSource(): AvailabilitySource {
  if (CONFIG.firebaseDatabaseUrl) return 'firebase';
  if (CONFIG.thingSpeakChannelId) return 'thingspeak';
  return 'simulated';
}

/** Merge an availability update into a station list (immutable). */
export function applyAvailability(stations: Station[], update: AvailabilityUpdate): Station[] {
  return stations.map((s) => (update[s.id] ? { ...s, availability: update[s.id] } : s));
}

/* -------------------------------------------------------------------- */
/* Firebase Realtime Database                                            */
/* -------------------------------------------------------------------- */

/**
 * Schema (one node per station, written by the charger controller / CPO):
 *
 *   /availability/{stationId}: {
 *     total: 4, available: 2, status: "available" | "busy" | "offline",
 *     waitMinutes: 0, updatedAt: 1725267600000
 *   }
 *
 * A single `onValue` on /availability streams every station; for very large
 * fleets subscribe per station id instead (see README).
 */
function subscribeFirebase(
  stationIds: string[],
  onUpdate: (u: AvailabilityUpdate) => void,
  onError?: (e: Error) => void,
): Unsubscribe {
  let cancelled = false;
  let detach: Unsubscribe = () => undefined;
  const wanted = new Set(stationIds);

  // Lazy import keeps firebase out of the bundle for users who never enable it.
  Promise.all([import('firebase/app'), import('firebase/database')])
    .then(([appMod, dbMod]) => {
      if (cancelled) return;
      const app =
        appMod.getApps().length > 0
          ? appMod.getApp()
          : appMod.initializeApp({ databaseURL: CONFIG.firebaseDatabaseUrl });
      const db = dbMod.getDatabase(app);
      const node = dbMod.ref(db, 'availability');
      detach = dbMod.onValue(
        node,
        (snap) => {
          const raw = (snap.val() ?? {}) as Record<string, Partial<Availability> & { updatedAt?: number | string }>;
          const update: AvailabilityUpdate = {};
          for (const [id, v] of Object.entries(raw)) {
            if (!wanted.has(id)) continue;
            update[id] = {
              total: v.total ?? 0,
              available: v.available ?? 0,
              status: v.status ?? 'unknown',
              waitMinutes: v.waitMinutes ?? 0,
              updatedAt:
                typeof v.updatedAt === 'number'
                  ? new Date(v.updatedAt).toISOString()
                  : v.updatedAt ?? new Date().toISOString(),
            };
          }
          onUpdate(update);
        },
        (err) => onError?.(err instanceof Error ? err : new Error(String(err))),
      );
    })
    .catch((e) => onError?.(e instanceof Error ? e : new Error(String(e))));

  return () => {
    cancelled = true;
    detach();
  };
}

/* -------------------------------------------------------------------- */
/* ThingSpeak polling                                                    */
/* -------------------------------------------------------------------- */

interface ThingSpeakFeed {
  created_at: string;
  field1?: string | null; // stationId
  field2?: string | null; // available
  field3?: string | null; // total
  field4?: string | null; // status
  field5?: string | null; // waitMinutes
}

export function parseThingSpeakFeeds(feeds: ThingSpeakFeed[]): AvailabilityUpdate {
  const update: AvailabilityUpdate = {};
  // Feeds arrive oldest-first; the last entry per station wins.
  for (const f of feeds) {
    if (!f.field1) continue;
    const total = parseInt(f.field3 ?? '0', 10) || 0;
    const available = parseInt(f.field2 ?? '0', 10) || 0;
    const status = (f.field4 as Availability['status']) || (available > 0 ? 'available' : 'busy');
    update[f.field1] = {
      total,
      available,
      status,
      waitMinutes: parseInt(f.field5 ?? '0', 10) || 0,
      updatedAt: f.created_at,
    };
  }
  return update;
}

function subscribeThingSpeak(
  onUpdate: (u: AvailabilityUpdate) => void,
  intervalMs: number,
  onError?: (e: Error) => void,
): Unsubscribe {
  const url =
    `https://api.thingspeak.com/channels/${CONFIG.thingSpeakChannelId}/feeds.json?results=200` +
    (CONFIG.thingSpeakReadKey ? `&api_key=${CONFIG.thingSpeakReadKey}` : '');
  let stopped = false;
  const tick = async () => {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`ThingSpeak HTTP ${res.status}`);
      const body = (await res.json()) as { feeds: ThingSpeakFeed[] };
      if (!stopped) onUpdate(parseThingSpeakFeeds(body.feeds ?? []));
    } catch (e) {
      onError?.(e instanceof Error ? e : new Error(String(e)));
    }
  };
  void tick();
  const handle = setInterval(tick, intervalMs);
  return () => {
    stopped = true;
    clearInterval(handle);
  };
}

/* -------------------------------------------------------------------- */
/* Simulated (demo only)                                                 */
/* -------------------------------------------------------------------- */

/** One random-walk step over a set of availabilities. Exported for tests/demo. */
export function simulateStep(
  current: Record<string, Availability>,
  rand: () => number = Math.random,
): AvailabilityUpdate {
  const next: AvailabilityUpdate = {};
  for (const [id, a] of Object.entries(current)) {
    if (a.status === 'offline') {
      next[id] = a;
      continue;
    }
    const r = rand();
    let available = a.available;
    if (r < 0.2 && available < a.total) available += 1;
    else if (r > 0.8 && available > 0) available -= 1;
    next[id] = {
      total: a.total,
      available,
      status: available > 0 ? 'available' : 'busy',
      waitMinutes: available > 0 ? 0 : Math.max(5, Math.round(10 + rand() * 25)),
      updatedAt: new Date().toISOString(),
    };
  }
  return next;
}

function subscribeSimulated(
  stations: Station[],
  onUpdate: (u: AvailabilityUpdate) => void,
  intervalMs: number,
): Unsubscribe {
  let state: Record<string, Availability> = Object.fromEntries(
    stations.map((s) => [s.id, s.availability]),
  );
  const handle = setInterval(() => {
    state = simulateStep(state);
    onUpdate(state);
  }, intervalMs);
  return () => clearInterval(handle);
}

/* -------------------------------------------------------------------- */

/**
 * Subscribe to availability for the given stations. Returns an unsubscribe
 * function; call it in a React effect cleanup.
 */
export function subscribeAvailability(
  stations: Station[],
  onUpdate: (u: AvailabilityUpdate) => void,
  opts: SubscribeOptions = {},
): Unsubscribe {
  const source = opts.source ?? pickSource();
  const interval = opts.intervalMs ?? CONFIG.availabilityPollMs;
  switch (source) {
    case 'firebase':
      return subscribeFirebase(
        stations.map((s) => s.id),
        onUpdate,
        opts.onError,
      );
    case 'thingspeak':
      return subscribeThingSpeak(onUpdate, interval, opts.onError);
    default:
      return subscribeSimulated(stations, onUpdate, Math.min(interval, 8_000));
  }
}
