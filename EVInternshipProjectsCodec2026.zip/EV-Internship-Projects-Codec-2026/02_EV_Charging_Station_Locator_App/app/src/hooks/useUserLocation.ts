import * as Location from 'expo-location';
import { useEffect, useState } from 'react';

import { CONFIG } from '../config';
import type { LatLng } from '../types';

export interface UserLocation {
  position: LatLng;
  /** True when the position is the default centre because permission was denied. */
  isFallback: boolean;
  error?: string;
}

/**
 * Ask for foreground location permission, take one fix, then watch for
 * movement (every 25 m / 10 s). Falls back to Ghaziabad centre so the app is
 * usable in an emulator without GPS.
 */
export function useUserLocation(): UserLocation {
  const [state, setState] = useState<UserLocation>({
    position: CONFIG.defaultCentre,
    isFallback: true,
  });

  useEffect(() => {
    let sub: Location.LocationSubscription | undefined;
    let cancelled = false;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        if (!cancelled) setState((s) => ({ ...s, error: 'Location permission denied' }));
        return;
      }
      const fix = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      if (cancelled) return;
      setState({
        position: { lat: fix.coords.latitude, lon: fix.coords.longitude },
        isFallback: false,
      });
      sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.Balanced, distanceInterval: 25, timeInterval: 10_000 },
        (loc) =>
          setState({
            position: { lat: loc.coords.latitude, lon: loc.coords.longitude },
            isFallback: false,
          }),
      );
    })().catch((e: unknown) => {
      if (!cancelled) setState((s) => ({ ...s, error: e instanceof Error ? e.message : String(e) }));
    });
    return () => {
      cancelled = true;
      sub?.remove();
    };
  }, []);

  return state;
}
