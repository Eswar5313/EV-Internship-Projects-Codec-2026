import type { Station, StationWithDistance } from '../types';
import { maxPowerKw } from './nearest';

/** Relative importance of each criterion. Need not sum to 1. */
export interface ScoreWeights {
  distance: number;
  availability: number;
  power: number;
  price: number;
}

export const DEFAULT_WEIGHTS: ScoreWeights = {
  distance: 0.4,
  availability: 0.3,
  power: 0.2,
  price: 0.1,
};

/** Normalisation constants: values at or beyond these saturate to 0 or 1. */
export interface ScoreScales {
  /** Distance at which the distance sub-score reaches 0 (km). */
  maxDistanceKm: number;
  /** Power at which the power sub-score reaches 1 (kW). */
  maxPowerKw: number;
  /** Cheapest tariff considered (sub-score 1). */
  minPricePerKwh: number;
  /** Dearest tariff considered (sub-score 0). */
  maxPricePerKwh: number;
}

export const DEFAULT_SCALES: ScoreScales = {
  maxDistanceKm: 25,
  maxPowerKw: 150,
  minPricePerKwh: 8,
  maxPricePerKwh: 25,
};

const clamp01 = (x: number): number => Math.max(0, Math.min(1, x));

export interface ScoreBreakdown {
  distance: number;
  availability: number;
  power: number;
  price: number;
  /** Weighted total in [0, 1]. */
  total: number;
}

/** Individual sub-scores, each in [0, 1] where 1 is best. */
export function scoreBreakdown(
  station: Station,
  distanceKm: number,
  weights: ScoreWeights = DEFAULT_WEIGHTS,
  scales: ScoreScales = DEFAULT_SCALES,
): ScoreBreakdown {
  const distance = clamp01(1 - distanceKm / scales.maxDistanceKm);

  // Availability: fraction of free outlets, cut to zero when offline, and
  // penalised by expected wait when everything is taken.
  let availability: number;
  const a = station.availability;
  if (a.status === 'offline') {
    availability = 0;
  } else if (a.total <= 0 || a.status === 'unknown') {
    availability = 0.3; // unknown: neither trusted nor dismissed
  } else if (a.available > 0) {
    availability = 0.5 + 0.5 * clamp01(a.available / a.total);
  } else {
    availability = 0.4 * clamp01(1 - a.waitMinutes / 60);
  }

  const power = clamp01(maxPowerKw(station) / scales.maxPowerKw);

  const priceRange = scales.maxPricePerKwh - scales.minPricePerKwh;
  const price =
    priceRange <= 0
      ? 1
      : clamp01(1 - (station.pricePerKwh - scales.minPricePerKwh) / priceRange);

  const wsum = weights.distance + weights.availability + weights.power + weights.price;
  const total =
    wsum <= 0
      ? 0
      : (weights.distance * distance +
          weights.availability * availability +
          weights.power * power +
          weights.price * price) /
        wsum;
  return { distance, availability, power, price, total };
}

/** Convenience: just the weighted total. */
export function scoreStation(
  station: Station,
  distanceKm: number,
  weights: ScoreWeights = DEFAULT_WEIGHTS,
  scales: ScoreScales = DEFAULT_SCALES,
): number {
  return scoreBreakdown(station, distanceKm, weights, scales).total;
}

export interface RankedStation extends StationWithDistance {
  score: number;
  breakdown: ScoreBreakdown;
}

/** Sort stations best-first by composite score (stable on ties by id). */
export function rankStations(
  stations: StationWithDistance[],
  weights: ScoreWeights = DEFAULT_WEIGHTS,
  scales: ScoreScales = DEFAULT_SCALES,
): RankedStation[] {
  return stations
    .map((s) => {
      const breakdown = scoreBreakdown(s, s.distanceKm, weights, scales);
      return { ...s, score: breakdown.total, breakdown };
    })
    .sort((x, y) => y.score - x.score || x.id.localeCompare(y.id));
}
