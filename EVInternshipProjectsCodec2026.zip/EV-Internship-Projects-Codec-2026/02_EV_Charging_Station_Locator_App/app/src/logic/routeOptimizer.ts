/**
 * Charging-stop route optimiser.
 *
 * Given an origin, a destination, the vehicle's battery state and a list of
 * candidate stations, choose the charging stops that minimise total trip time
 * (driving + waiting + charging) subject to never dropping below a reserve
 * state of charge.
 *
 * Approach (see README section 7 for the full write-up):
 *   1. Greedy corridor pruning — keep only stations whose detour
 *      (origin->station->destination) is within a ratio of the direct
 *      distance. This shrinks the graph before the expensive step.
 *   2. Greedy feasibility probe — "drive to the reachable station that gets
 *      you closest to the destination" — gives a fast yes/no and a baseline.
 *   3. Dijkstra on a station graph whose edges are the legs the car can drive
 *      on the energy it has when it leaves each node. Edge weight is minutes.
 *      Because the car is always charged to the same target SOC when it
 *      leaves a station, the energy on arrival at any node depends only on
 *      the last leg, so edge costs are static and Dijkstra is exact under
 *      this model.
 *   4. Post-processing: the final stop is charged only as much as the last
 *      leg needs (plus reserve), which never changes the chosen path but
 *      tightens the reported charge time.
 *
 * Distances are haversine * detourFactor, an estimate of road distance. The
 * app can swap in Google Directions distances for the chosen legs.
 */
import type { LatLng, Station, Vehicle } from '../types';
import { haversineKm } from './haversine';
import { maxPowerKw } from './nearest';

export interface RouteOptions {
  /** Road distance / great-circle distance. 1.3 is typical for Indian NCR roads. */
  detourFactor: number;
  /** Assumed average speed including stops, km/h. */
  avgSpeedKmh: number;
  /** Never plan to arrive anywhere below this SOC (0..1). */
  reserveSoc: number;
  /** SOC to charge to at each stop (0..1). DC fast charging slows sharply above ~80 %. */
  targetSoc: number;
  /** Grid->battery efficiency for charge time estimates. */
  chargeEfficiency: number;
  /** Fixed minutes per stop for parking, plugging in, payment. */
  stopOverheadMin: number;
  /** Ignore stations whose fastest outlet is slower than this (kW). */
  minStopPowerKw: number;
  /** Stations with origin->s->dest longer than direct*(1+ratio) are pruned. */
  maxDetourRatio: number;
  /** Include offline stations as candidates (normally false). */
  includeOffline: boolean;
}

export const DEFAULT_ROUTE_OPTIONS: RouteOptions = {
  detourFactor: 1.3,
  avgSpeedKmh: 40,
  reserveSoc: 0.1,
  targetSoc: 0.8,
  chargeEfficiency: 0.9,
  stopOverheadMin: 5,
  minStopPowerKw: 20,
  maxDetourRatio: 0.6,
  includeOffline: false,
};

export interface RouteLeg {
  fromId: string;
  toId: string;
  fromName: string;
  toName: string;
  from: LatLng;
  to: LatLng;
  distanceKm: number;
  driveMinutes: number;
  energyKwh: number;
  /** SOC when leaving `from` and when arriving at `to` (0..1). */
  socAtDeparture: number;
  socAtArrival: number;
}

export interface ChargingStop {
  station: Station;
  arrivalSoc: number;
  departureSoc: number;
  chargeKwh: number;
  chargeMinutes: number;
  waitMinutes: number;
  overheadMinutes: number;
  /** Charging power actually usable = min(station, vehicle) in kW. */
  powerKw: number;
}

export interface RoutePlan {
  origin: LatLng;
  destination: LatLng;
  stops: ChargingStop[];
  legs: RouteLeg[];
  directDistanceKm: number;
  totalDistanceKm: number;
  driveMinutes: number;
  chargeMinutes: number;
  waitMinutes: number;
  overheadMinutes: number;
  totalMinutes: number;
  /** SOC on arrival at the destination (0..1). */
  finalSoc: number;
  /** True when no charging stop was needed. */
  feasibleWithoutCharging: boolean;
  /** Number of stations that survived corridor pruning. */
  candidatesConsidered: number;
  /** Time the greedy baseline would take, for comparison (minutes), or null. */
  greedyMinutes: number | null;
}

export class UnreachableError extends Error {
  readonly reason: 'no-candidates' | 'gap-too-large';
  constructor(reason: 'no-candidates' | 'gap-too-large', message: string) {
    super(message);
    this.name = 'UnreachableError';
    this.reason = reason;
  }
}

export type RouteResult =
  | { ok: true; plan: RoutePlan }
  | { ok: false; reason: UnreachableError['reason']; message: string };

/* ---------- internal helpers ---------- */

interface Node {
  id: string;
  name: string;
  pos: LatLng;
  station: Station | null;
}

function usableKwhFromSoc(v: Vehicle, soc: number, reserveSoc: number): number {
  return Math.max(0, (soc - reserveSoc) * v.batteryKwh);
}

function stopPowerKw(station: Station, v: Vehicle): number {
  return Math.min(maxPowerKw(station), v.maxChargeKw);
}

/** Minutes spent at `station` to bring the battery from arrivalKwh to targetKwh. */
function chargeMinutes(
  station: Station,
  v: Vehicle,
  arrivalKwh: number,
  targetKwh: number,
  o: RouteOptions,
): { minutes: number; kwh: number } {
  const kwh = Math.max(0, targetKwh - arrivalKwh);
  const p = stopPowerKw(station, v);
  if (p <= 0) return { minutes: Number.POSITIVE_INFINITY, kwh };
  return { minutes: (kwh / (p * o.chargeEfficiency)) * 60, kwh };
}

function waitMinutes(station: Station): number {
  const a = station.availability;
  if (a.status === 'offline') return Number.POSITIVE_INFINITY;
  if (a.available > 0) return 0;
  return a.waitMinutes;
}

/* ---------- step 1: corridor pruning ---------- */

export function corridorCandidates(
  origin: LatLng,
  destination: LatLng,
  stations: Station[],
  o: RouteOptions = DEFAULT_ROUTE_OPTIONS,
): Station[] {
  const direct = haversineKm(origin, destination);
  const limit = direct * (1 + o.maxDetourRatio);
  return stations.filter((s) => {
    if (!o.includeOffline && s.availability.status === 'offline') return false;
    if (maxPowerKw(s) < o.minStopPowerKw) return false;
    return haversineKm(origin, s) + haversineKm(s, destination) <= limit;
  });
}

/* ---------- step 2: greedy baseline ---------- */

/**
 * Greedy planner: at each step drive to the reachable station that is
 * closest to the destination. O(stops * n). Returns stop ids or null when
 * stuck. Fast, but not optimal — used as a feasibility probe and baseline.
 */
export function greedyStops(
  origin: LatLng,
  destination: LatLng,
  vehicle: Vehicle,
  candidates: Station[],
  o: RouteOptions = DEFAULT_ROUTE_OPTIONS,
): Station[] | null {
  const road = (a: LatLng, b: LatLng) => haversineKm(a, b) * o.detourFactor;
  let pos: LatLng = origin;
  let energy = usableKwhFromSoc(vehicle, vehicle.soc, o.reserveSoc);
  const fullEnergy = usableKwhFromSoc(vehicle, o.targetSoc, o.reserveSoc);
  const used = new Set<string>();
  const stops: Station[] = [];
  for (let iter = 0; iter <= candidates.length; iter++) {
    const range = energy / vehicle.consumptionKwhPerKm;
    if (road(pos, destination) <= range) return stops;
    let best: Station | null = null;
    let bestRemaining = Number.POSITIVE_INFINITY;
    for (const s of candidates) {
      if (used.has(s.id) || road(pos, s) > range) continue;
      const remaining = road(s, destination);
      if (remaining < bestRemaining) {
        bestRemaining = remaining;
        best = s;
      }
    }
    if (!best || bestRemaining >= road(pos, destination)) return null;
    used.add(best.id);
    stops.push(best);
    pos = best;
    energy = fullEnergy;
  }
  return null;
}

/* ---------- step 3: Dijkstra ---------- */

/**
 * Plan the fastest route. Throws UnreachableError when no sequence of stops
 * gets the car to the destination.
 */
export function planRoute(
  origin: LatLng,
  destination: LatLng,
  vehicle: Vehicle,
  stations: Station[],
  options: Partial<RouteOptions> = {},
): RoutePlan {
  const o: RouteOptions = { ...DEFAULT_ROUTE_OPTIONS, ...options };
  if (vehicle.batteryKwh <= 0 || vehicle.consumptionKwhPerKm <= 0) {
    throw new Error('vehicle.batteryKwh and consumptionKwhPerKm must be positive');
  }
  const road = (a: LatLng, b: LatLng) => haversineKm(a, b) * o.detourFactor;
  const driveMin = (km: number) => (km / o.avgSpeedKmh) * 60;
  const kwhFor = (km: number) => km * vehicle.consumptionKwhPerKm;

  const directKm = road(origin, destination);
  const startKwh = usableKwhFromSoc(vehicle, vehicle.soc, o.reserveSoc);
  const fullKwh = usableKwhFromSoc(vehicle, o.targetSoc, o.reserveSoc);
  const targetAbsKwh = o.targetSoc * vehicle.batteryKwh;
  const reserveAbsKwh = o.reserveSoc * vehicle.batteryKwh;

  const candidates = corridorCandidates(origin, destination, stations, o);
  const greedy = greedyStops(origin, destination, vehicle, candidates, o);

  // Nodes: 0 = origin, 1..n = stations, n+1 = destination.
  const nodes: Node[] = [
    { id: '__origin__', name: 'Origin', pos: origin, station: null },
    ...candidates.map((s) => ({ id: s.id, name: s.name, pos: s, station: s })),
    { id: '__destination__', name: 'Destination', pos: destination, station: null },
  ];
  const n = nodes.length;
  const DEST = n - 1;

  /** Usable energy when leaving node i. */
  const leaveKwh = (i: number): number => (i === 0 ? startKwh : fullKwh);

  /** Static edge weight in minutes, or +Infinity when the leg is undrivable. */
  const edgeCost = (i: number, j: number): number => {
    if (i === j || j === 0 || i === DEST) return Number.POSITIVE_INFINITY;
    const km = road(nodes[i].pos, nodes[j].pos);
    const need = kwhFor(km);
    if (need > leaveKwh(i) + 1e-9) return Number.POSITIVE_INFINITY;
    let cost = driveMin(km);
    const st = nodes[j].station;
    if (st) {
      const absArrival = (i === 0 ? vehicle.soc * vehicle.batteryKwh : targetAbsKwh) - need;
      const c = chargeMinutes(st, vehicle, absArrival, targetAbsKwh, o);
      cost += o.stopOverheadMin + waitMinutes(st) + c.minutes;
    }
    return cost;
  };

  // Array Dijkstra — O(n^2), n is at most a few hundred.
  const dist = new Array<number>(n).fill(Number.POSITIVE_INFINITY);
  const prev = new Array<number>(n).fill(-1);
  const done = new Array<boolean>(n).fill(false);
  dist[0] = 0;
  for (let iter = 0; iter < n; iter++) {
    let u = -1;
    for (let i = 0; i < n; i++) {
      if (!done[i] && (u === -1 || dist[i] < dist[u])) u = i;
    }
    if (u === -1 || dist[u] === Number.POSITIVE_INFINITY || u === DEST) break;
    done[u] = true;
    for (let v = 1; v < n; v++) {
      if (done[v]) continue;
      const w = edgeCost(u, v);
      if (w === Number.POSITIVE_INFINITY) continue;
      const nd = dist[u] + w;
      if (nd < dist[v] - 1e-9) {
        dist[v] = nd;
        prev[v] = u;
      }
    }
  }

  if (dist[DEST] === Number.POSITIVE_INFINITY) {
    const direct = kwhFor(directKm) <= startKwh;
    if (direct) {
      // Cannot happen (direct edge would have been found) but keep the invariant explicit.
      throw new Error('internal: direct leg feasible but Dijkstra failed');
    }
    if (candidates.length === 0) {
      throw new UnreachableError(
        'no-candidates',
        `Destination is ${directKm.toFixed(1)} km away by road, beyond the ` +
          `${(startKwh / vehicle.consumptionKwhPerKm).toFixed(0)} km usable range, ` +
          'and no suitable charging station lies in the corridor.',
      );
    }
    const startRangeKm = startKwh / vehicle.consumptionKwhPerKm;
    const firstHopOk = candidates.some((s) => kwhFor(road(origin, s)) <= startKwh + 1e-9);
    if (!firstHopOk) {
      const nearestKm = Math.min(...candidates.map((s) => road(origin, s)));
      throw new UnreachableError(
        'gap-too-large',
        `Only ${startRangeKm.toFixed(0)} km of usable range at ${Math.round(vehicle.soc * 100)} % SOC, ` +
          `but the nearest suitable charger (>= ${o.minStopPowerKw} kW, online) is ` +
          `${nearestKm.toFixed(0)} km away by road.`,
      );
    }
    throw new UnreachableError(
      'gap-too-large',
      `No sequence of the ${candidates.length} corridor stations keeps every leg within ` +
        `${(fullKwh / vehicle.consumptionKwhPerKm).toFixed(0)} km (range after charging to ` +
        `${Math.round(o.targetSoc * 100)} %).`,
    );
  }

  // Reconstruct path.
  const path: number[] = [];
  for (let v = DEST; v !== -1; v = prev[v]) path.push(v);
  path.reverse();

  // Simulate the chosen path to produce legs and stops, trimming the last charge.
  const legs: RouteLeg[] = [];
  const stops: ChargingStop[] = [];
  let absKwh = vehicle.soc * vehicle.batteryKwh;
  let totalKm = 0;
  let drive = 0;
  let charge = 0;
  let wait = 0;
  let overhead = 0;

  for (let k = 0; k < path.length - 1; k++) {
    const a = nodes[path[k]];
    const b = nodes[path[k + 1]];
    const km = road(a.pos, b.pos);
    const need = kwhFor(km);
    const socDep = absKwh / vehicle.batteryKwh;
    absKwh -= need;
    totalKm += km;
    drive += driveMin(km);
    legs.push({
      fromId: a.id,
      toId: b.id,
      fromName: a.name,
      toName: b.name,
      from: a.pos,
      to: b.pos,
      distanceKm: km,
      driveMinutes: driveMin(km),
      energyKwh: need,
      socAtDeparture: socDep,
      socAtArrival: absKwh / vehicle.batteryKwh,
    });

    if (b.station) {
      const isLastStop = k + 2 === path.length - 1;
      let target = targetAbsKwh;
      if (isLastStop) {
        // Charge only what the final leg needs plus reserve, capped at target.
        const finalKm = road(b.pos, destination);
        target = Math.min(targetAbsKwh, Math.max(absKwh, kwhFor(finalKm) + reserveAbsKwh));
      }
      const c = chargeMinutes(b.station, vehicle, absKwh, target, o);
      const w = waitMinutes(b.station);
      stops.push({
        station: b.station,
        arrivalSoc: absKwh / vehicle.batteryKwh,
        departureSoc: target / vehicle.batteryKwh,
        chargeKwh: c.kwh,
        chargeMinutes: c.minutes,
        waitMinutes: w,
        overheadMinutes: o.stopOverheadMin,
        powerKw: stopPowerKw(b.station, vehicle),
      });
      charge += c.minutes;
      wait += w;
      overhead += o.stopOverheadMin;
      absKwh = target;
    }
  }

  const greedyMinutes = greedy ? simulateMinutes(origin, destination, vehicle, greedy, o) : null;

  return {
    origin,
    destination,
    stops,
    legs,
    directDistanceKm: directKm,
    totalDistanceKm: totalKm,
    driveMinutes: drive,
    chargeMinutes: charge,
    waitMinutes: wait,
    overheadMinutes: overhead,
    totalMinutes: drive + charge + wait + overhead,
    finalSoc: absKwh / vehicle.batteryKwh,
    feasibleWithoutCharging: stops.length === 0,
    candidatesConsidered: candidates.length,
    greedyMinutes,
  };
}

/** Total minutes for a fixed stop sequence under the same cost model. */
export function simulateMinutes(
  origin: LatLng,
  destination: LatLng,
  vehicle: Vehicle,
  stops: Station[],
  options: Partial<RouteOptions> = {},
): number {
  const o: RouteOptions = { ...DEFAULT_ROUTE_OPTIONS, ...options };
  const road = (a: LatLng, b: LatLng) => haversineKm(a, b) * o.detourFactor;
  const points: LatLng[] = [origin, ...stops, destination];
  const targetAbsKwh = o.targetSoc * vehicle.batteryKwh;
  let absKwh = vehicle.soc * vehicle.batteryKwh;
  let minutes = 0;
  for (let k = 0; k < points.length - 1; k++) {
    const km = road(points[k], points[k + 1]);
    absKwh -= km * vehicle.consumptionKwhPerKm;
    minutes += (km / o.avgSpeedKmh) * 60;
    if (k + 1 < points.length - 1) {
      const st = stops[k];
      const c = chargeMinutes(st, vehicle, absKwh, targetAbsKwh, o);
      minutes += o.stopOverheadMin + waitMinutes(st) + c.minutes;
      absKwh = targetAbsKwh;
    }
  }
  return minutes;
}

/** Non-throwing wrapper for UI code. */
export function planRouteSafe(
  origin: LatLng,
  destination: LatLng,
  vehicle: Vehicle,
  stations: Station[],
  options: Partial<RouteOptions> = {},
): RouteResult {
  try {
    return { ok: true, plan: planRoute(origin, destination, vehicle, stations, options) };
  } catch (e) {
    if (e instanceof UnreachableError) return { ok: false, reason: e.reason, message: e.message };
    throw e;
  }
}
