import type { LatLng } from '../types';

/** Mean Earth radius in km (IUGG). */
export const EARTH_RADIUS_KM = 6371.0088;

const toRad = (deg: number): number => (deg * Math.PI) / 180;
const toDeg = (rad: number): number => (rad * 180) / Math.PI;

/**
 * Great-circle distance between two points in kilometres using the haversine
 * formula. Accurate to ~0.3 % (spherical Earth), which is more than enough
 * for ranking stations and pre-filtering route candidates.
 */
export function haversineKm(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing from a to b in degrees clockwise from true north, 0..360. */
export function bearingDeg(a: LatLng, b: LatLng): number {
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const dLon = toRad(b.lon - a.lon);
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

/**
 * Cross-track distance (km) of point p from the great-circle path a -> b.
 * Positive = right of the path, negative = left. Used to build the route
 * corridor in the optimiser.
 */
export function crossTrackKm(p: LatLng, a: LatLng, b: LatLng): number {
  const d13 = haversineKm(a, p) / EARTH_RADIUS_KM;
  const b13 = toRad(bearingDeg(a, p));
  const b12 = toRad(bearingDeg(a, b));
  return Math.asin(Math.sin(d13) * Math.sin(b13 - b12)) * EARTH_RADIUS_KM;
}

/** Bounding box [minLat, minLon, maxLat, maxLon] for a radius (km) around c. */
export function boundingBox(c: LatLng, radiusKm: number): [number, number, number, number] {
  const dLat = toDeg(radiusKm / EARTH_RADIUS_KM);
  const dLon = toDeg(radiusKm / (EARTH_RADIUS_KM * Math.cos(toRad(c.lat))));
  return [c.lat - dLat, c.lon - dLon, c.lat + dLat, c.lon + dLon];
}
