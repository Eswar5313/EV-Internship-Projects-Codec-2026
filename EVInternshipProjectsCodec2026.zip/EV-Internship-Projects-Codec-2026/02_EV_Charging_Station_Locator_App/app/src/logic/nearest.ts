import type { ConnectorType, LatLng, Station, StationWithDistance } from '../types';
import { haversineKm } from './haversine';

export interface StationFilter {
  /** Keep stations that have at least one connector of any listed type. */
  connectorTypes?: ConnectorType[];
  /** Keep stations whose best outlet delivers at least this many kW. */
  minPowerKw?: number;
  /** Keep only stations with a free outlet right now. */
  onlyAvailable?: boolean;
  /** Drop stations reported offline. */
  excludeOffline?: boolean;
  /** Keep stations at or below this tariff. */
  maxPricePerKwh?: number;
  /** Keep stations within this radius of the origin (requires origin). */
  maxDistanceKm?: number;
}

/** Highest single-outlet power at the station, in kW. */
export function maxPowerKw(station: Station): number {
  return station.connectors.reduce((m, c) => (c.powerKw > m ? c.powerKw : m), 0);
}

/** True when the station satisfies every provided filter field. */
export function matchesFilter(
  station: Station,
  filter: StationFilter,
  distanceKm?: number,
): boolean {
  if (filter.connectorTypes && filter.connectorTypes.length > 0) {
    const wanted = new Set(filter.connectorTypes);
    if (!station.connectors.some((c) => wanted.has(c.type))) return false;
  }
  if (filter.minPowerKw !== undefined && maxPowerKw(station) < filter.minPowerKw) return false;
  if (filter.onlyAvailable && station.availability.available <= 0) return false;
  if (filter.excludeOffline && station.availability.status === 'offline') return false;
  if (filter.maxPricePerKwh !== undefined && station.pricePerKwh > filter.maxPricePerKwh) {
    return false;
  }
  if (
    filter.maxDistanceKm !== undefined &&
    distanceKm !== undefined &&
    distanceKm > filter.maxDistanceKm
  ) {
    return false;
  }
  return true;
}

/** Apply a filter to a list (distance-aware only when origin is given). */
export function filterStations(
  stations: Station[],
  filter: StationFilter,
  origin?: LatLng,
): Station[] {
  return stations.filter((s) =>
    matchesFilter(s, filter, origin ? haversineKm(origin, s) : undefined),
  );
}

/** Attach the haversine distance from origin to every station. */
export function withDistances(origin: LatLng, stations: Station[]): StationWithDistance[] {
  return stations.map((s) => ({ ...s, distanceKm: haversineKm(origin, s) }));
}

/**
 * k nearest stations to `origin` that satisfy `filter`, sorted ascending by
 * distance. O(n log n) — fine for the few hundred POIs a map viewport holds.
 * Ties are broken by station id so the result is deterministic.
 */
export function nearestStations(
  origin: LatLng,
  stations: Station[],
  k: number,
  filter: StationFilter = {},
): StationWithDistance[] {
  if (k <= 0) return [];
  return withDistances(origin, stations)
    .filter((s) => matchesFilter(s, filter, s.distanceKm))
    .sort((a, b) => a.distanceKm - b.distanceKm || a.id.localeCompare(b.id))
    .slice(0, k);
}
