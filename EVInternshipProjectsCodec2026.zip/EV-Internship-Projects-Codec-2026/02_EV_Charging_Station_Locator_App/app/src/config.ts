import Constants from 'expo-constants';

/** Keys injected by app.config.js from .env (see .env.example). */
interface Extra {
  googleMapsApiKey?: string;
  openChargeMapApiKey?: string;
  firebaseDatabaseUrl?: string;
  thingSpeakChannelId?: string;
  thingSpeakReadKey?: string;
}

const extra: Extra = (Constants.expoConfig?.extra ?? {}) as Extra;

export const CONFIG = {
  googleMapsApiKey: extra.googleMapsApiKey ?? '',
  openChargeMapApiKey: extra.openChargeMapApiKey ?? '',
  firebaseDatabaseUrl: extra.firebaseDatabaseUrl ?? '',
  thingSpeakChannelId: extra.thingSpeakChannelId ?? '',
  thingSpeakReadKey: extra.thingSpeakReadKey ?? '',
  /** Default map centre: Ghaziabad, Uttar Pradesh. */
  defaultCentre: { lat: 28.66, lon: 77.43 },
  /** Search radius for station queries (km). */
  searchRadiusKm: 40,
  /** Poll interval for availability when no push source is configured (ms). */
  availabilityPollMs: 30_000,
};
