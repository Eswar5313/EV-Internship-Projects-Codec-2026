import type { AvailabilityStatus } from './types';

export const COLORS = {
  primary: '#0B3D2E',
  accent: '#1DB954',
  background: '#F6F8F7',
  card: '#FFFFFF',
  text: '#10231C',
  muted: '#5F6F68',
  border: '#DCE5E0',
  danger: '#D64545',
  warning: '#E8A317',
  route: '#1A73E8',
};

export const STATUS_COLORS: Record<AvailabilityStatus, string> = {
  available: '#1DB954',
  busy: '#E8A317',
  offline: '#9AA5A0',
  unknown: '#1A73E8',
};

export const STATUS_LABELS: Record<AvailabilityStatus, string> = {
  available: 'Available',
  busy: 'Busy',
  offline: 'Offline',
  unknown: 'No live data',
};
