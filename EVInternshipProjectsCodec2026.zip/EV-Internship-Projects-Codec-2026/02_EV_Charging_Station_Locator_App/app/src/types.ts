/** Shared domain types. Pure TypeScript — no React Native imports so that
 *  the logic modules and their Jest tests can run under plain Node. */

export interface LatLng {
  lat: number;
  lon: number;
}

export type ConnectorType =
  | 'CCS2'
  | 'CHAdeMO'
  | 'Type2'
  | 'GB/T'
  | 'Bharat-AC-001'
  | 'Bharat-DC-001'
  | 'Other';

export interface Connector {
  type: ConnectorType;
  /** Rated power of one outlet in kW. */
  powerKw: number;
  /** Number of outlets of this type at the station. */
  count: number;
}

export type AvailabilityStatus = 'available' | 'busy' | 'offline' | 'unknown';

export interface Availability {
  total: number;
  available: number;
  status: AvailabilityStatus;
  /** Expected wait for a free outlet when none is available (minutes). */
  waitMinutes: number;
  /** ISO-8601 timestamp of the last update. */
  updatedAt: string;
}

export interface Station extends LatLng {
  id: string;
  name: string;
  operator: string;
  address: string;
  connectors: Connector[];
  /** Tariff in currency units per kWh. */
  pricePerKwh: number;
  currency: string;
  hours: string;
  amenities?: string[];
  availability: Availability;
  /** Where the record came from. */
  source: 'openchargemap' | 'synthetic' | 'firebase' | 'thingspeak';
}

export interface StationWithDistance extends Station {
  distanceKm: number;
}

/** Vehicle state used by the route optimiser. */
export interface Vehicle {
  /** Usable battery capacity in kWh. */
  batteryKwh: number;
  /** Average consumption in kWh per km (e.g. 0.15 for a compact EV). */
  consumptionKwhPerKm: number;
  /** State of charge now, 0..1. */
  soc: number;
  /** Maximum DC charge power the car accepts in kW. */
  maxChargeKw: number;
}
