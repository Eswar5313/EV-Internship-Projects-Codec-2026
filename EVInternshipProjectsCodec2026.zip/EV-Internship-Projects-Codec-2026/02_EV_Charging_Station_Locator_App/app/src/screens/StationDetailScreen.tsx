import React, { useEffect, useState } from 'react';
import { Linking, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { maxPowerKw } from '../logic/nearest';
import { scoreBreakdown } from '../logic/scoring';
import type { StationDetailProps } from '../navigation';
import { subscribeAvailability } from '../services/availability';
import { COLORS, STATUS_COLORS, STATUS_LABELS } from '../theme';
import type { Availability } from '../types';

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.row}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );
}

function Bar({ label, v }: { label: string; v: number }) {
  return (
    <View style={styles.barRow}>
      <Text style={styles.barLabel}>{label}</Text>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${Math.round(v * 100)}%` }]} />
      </View>
      <Text style={styles.barPct}>{Math.round(v * 100)}</Text>
    </View>
  );
}

export function StationDetailScreen({ route }: StationDetailProps) {
  const { station, distanceKm } = route.params;
  const [availability, setAvailability] = useState<Availability>(station.availability);

  // Keep this screen live too — a single-station subscription.
  useEffect(
    () =>
      subscribeAvailability([station], (u) => {
        if (u[station.id]) setAvailability(u[station.id]);
      }),
    [station],
  );

  const live = { ...station, availability };
  const breakdown = scoreBreakdown(live, distanceKm ?? 5);
  const colour = STATUS_COLORS[availability.status];

  const openNavigation = () =>
    Linking.openURL(
      `https://www.google.com/maps/dir/?api=1&destination=${station.lat},${station.lon}&travelmode=driving`,
    );

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.name}>{station.name}</Text>
      <Text style={styles.operator}>
        {station.operator} · {station.address}
      </Text>

      <View style={[styles.statusCard, { borderColor: colour }]}>
        <View style={[styles.statusDot, { backgroundColor: colour }]} />
        <View style={{ flex: 1 }}>
          <Text style={styles.statusText}>
            {STATUS_LABELS[availability.status]} · {availability.available} of {availability.total} outlets free
          </Text>
          <Text style={styles.updated}>
            {availability.waitMinutes > 0 ? `Estimated wait ${availability.waitMinutes} min · ` : ''}
            Updated {new Date(availability.updatedAt).toLocaleTimeString()}
          </Text>
        </View>
      </View>

      <Text style={styles.h2}>Connectors</Text>
      {station.connectors.map((c, i) => (
        <Row key={`${c.type}-${i}`} label={`${c.type} × ${c.count}`} value={`${c.powerKw} kW`} />
      ))}

      <Text style={styles.h2}>Details</Text>
      <Row label="Fastest outlet" value={`${maxPowerKw(station)} kW`} />
      <Row label="Tariff" value={station.pricePerKwh > 0 ? `${station.currency} ${station.pricePerKwh}/kWh` : 'Not listed'} />
      <Row label="Hours" value={station.hours || 'Not listed'} />
      {distanceKm !== undefined && <Row label="Distance" value={`${distanceKm.toFixed(1)} km`} />}
      {station.amenities?.length ? <Row label="Amenities" value={station.amenities.join(', ')} /> : null}
      <Row label="Source" value={station.source === 'synthetic' ? 'Bundled sample (synthetic)' : 'Open Charge Map'} />

      <Text style={styles.h2}>Score {(breakdown.total * 100).toFixed(0)} / 100</Text>
      <Bar label="Distance" v={breakdown.distance} />
      <Bar label="Availability" v={breakdown.availability} />
      <Bar label="Power" v={breakdown.power} />
      <Bar label="Price" v={breakdown.price} />

      <TouchableOpacity style={styles.button} onPress={openNavigation} accessibilityRole="button">
        <Text style={styles.buttonText}>Navigate with Google Maps</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  name: { fontSize: 22, fontWeight: '700', color: COLORS.text },
  operator: { color: COLORS.muted, marginBottom: 12 },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    borderWidth: 2,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  statusDot: { width: 14, height: 14, borderRadius: 7, marginRight: 12 },
  statusText: { fontWeight: '600', color: COLORS.text },
  updated: { fontSize: 12, color: COLORS.muted },
  h2: { fontSize: 15, fontWeight: '700', marginTop: 16, marginBottom: 6, color: COLORS.primary },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  label: { color: COLORS.muted },
  value: { color: COLORS.text, fontWeight: '500' },
  barRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 3 },
  barLabel: { width: 90, fontSize: 12, color: COLORS.muted },
  barTrack: { flex: 1, height: 8, backgroundColor: COLORS.border, borderRadius: 4, overflow: 'hidden' },
  barFill: { height: 8, backgroundColor: COLORS.accent },
  barPct: { width: 32, textAlign: 'right', fontSize: 12, color: COLORS.muted },
  button: { marginTop: 24, backgroundColor: COLORS.primary, padding: 14, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700' },
});
