import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE, Polyline, type LongPressEvent } from 'react-native-maps';

import { FilterBar } from '../components/FilterBar';
import { RouteCard } from '../components/RouteCard';
import { StationMarker } from '../components/StationMarker';
import { CONFIG } from '../config';
import { useUserLocation } from '../hooks/useUserLocation';
import { nearestStations, type StationFilter } from '../logic/nearest';
import { planRouteSafe, type RouteResult } from '../logic/routeOptimizer';
import { rankStations } from '../logic/scoring';
import type { MapScreenProps } from '../navigation';
import { applyAvailability, pickSource, subscribeAvailability } from '../services/availability';
import { getDirectionsForPlan, refineWithRoadDistances } from '../services/directions';
import { fetchStations, type FetchResult } from '../services/stations';
import { COLORS, STATUS_COLORS } from '../theme';
import type { LatLng, Station, Vehicle } from '../types';

/** Demo vehicle: a 30 kWh compact EV at 45 % — enough to make stops interesting. */
const DEMO_VEHICLE: Vehicle = { batteryKwh: 30, consumptionKwhPerKm: 0.15, soc: 0.45, maxChargeKw: 50 };

export function MapScreen({ navigation }: MapScreenProps) {
  const mapRef = useRef<MapView>(null);
  const user = useUserLocation();
  const [fetchResult, setFetchResult] = useState<FetchResult | null>(null);
  const [stations, setStations] = useState<Station[]>([]);
  const [filter, setFilter] = useState<StationFilter>({ excludeOffline: true });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [destination, setDestination] = useState<LatLng | null>(null);
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [roadPolyline, setRoadPolyline] = useState<LatLng[] | null>(null);
  const [refining, setRefining] = useState(false);
  const [showList, setShowList] = useState(false);

  // 1. Load stations (OCM or bundled fallback).
  useEffect(() => {
    let cancelled = false;
    fetchStations(user.isFallback ? CONFIG.defaultCentre : user.position).then((r) => {
      if (cancelled) return;
      setFetchResult(r);
      setStations(r.stations);
    });
    return () => {
      cancelled = true;
    };
    // Re-fetch only when the user moves from fallback to a real fix.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user.isFallback]);

  // 2. Real-time availability stream merged into station state.
  useEffect(() => {
    if (stations.length === 0) return undefined;
    const unsubscribe = subscribeAvailability(stations, (update) =>
      setStations((prev) => applyAvailability(prev, update)),
    );
    return unsubscribe;
    // Subscribe once per data load, not per availability tick.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fetchResult]);

  // 3. Derived: filtered + ranked nearest stations.
  const nearest = useMemo(
    () => rankStations(nearestStations(user.position, stations, 15, filter)),
    [user.position, stations, filter],
  );

  // 4. Route optimisation whenever the destination, position or availability changes.
  //    Cheap (a few ms), so it simply re-runs on every availability tick.
  const estimate = useMemo<RouteResult | null>(
    () => (destination ? planRouteSafe(user.position, destination, DEMO_VEHICLE, stations) : null),
    [destination, user.position, stations],
  );

  // A key that only changes when the *shape* of the route changes (origin,
  // destination, stop sequence) — availability ticks that keep the same stops
  // must not trigger another Directions request.
  const routeKey = useMemo(() => {
    if (!estimate?.ok) return null;
    const p = estimate.plan;
    const pt = (q: LatLng) => `${q.lat.toFixed(4)},${q.lon.toFixed(4)}`;
    return [pt(p.origin), ...p.stops.map((s) => s.station.id), pt(p.destination)].join('|');
  }, [estimate]);

  // 5. Refine with Google Directions (road polyline + real leg distances/times).
  useEffect(() => {
    if (!estimate) {
      setRoute(null);
      setRoadPolyline(null);
      return undefined;
    }
    if (!estimate.ok || !CONFIG.googleMapsApiKey) {
      setRoute(estimate);
      setRoadPolyline(null);
      return undefined;
    }
    setRoute(estimate);
    const controller = new AbortController();
    setRefining(true);
    getDirectionsForPlan(estimate.plan, controller.signal)
      .then((dirs) => {
        setRoadPolyline(dirs.polyline);
        setRoute({ ok: true, plan: refineWithRoadDistances(estimate.plan, dirs) });
      })
      .catch(() => undefined) // keep the estimate if Directions fails
      .finally(() => setRefining(false));
    return () => controller.abort();
    // Deliberately keyed on routeKey, not `estimate`: see comment above.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeKey]);

  // Keep wait/charge figures fresh on availability ticks while no road data
  // has replaced the estimate yet (same stops, so no new Directions call).
  useEffect(() => {
    if (estimate && !roadPolyline) setRoute(estimate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [estimate]);

  const onLongPress = useCallback((e: LongPressEvent) => {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setDestination({ lat: latitude, lon: longitude });
  }, []);

  const openStation = useCallback(
    (station: Station) => {
      setSelectedId(station.id);
      const d = nearest.find((s) => s.id === station.id)?.distanceKm;
      navigation.navigate('StationDetail', { station, distanceKm: d });
    },
    [navigation, nearest],
  );

  const focusStop = useCallback(
    (i: number) => {
      if (!route?.ok) return;
      const s = route.plan.stops[i].station;
      mapRef.current?.animateToRegion(
        { latitude: s.lat, longitude: s.lon, latitudeDelta: 0.03, longitudeDelta: 0.03 },
        500,
      );
    },
    [route],
  );

  const stopIndexById = useMemo(() => {
    const m = new Map<string, number>();
    if (route?.ok) route.plan.stops.forEach((s, i) => m.set(s.station.id, i));
    return m;
  }, [route]);

  const estimatePolyline = useMemo<LatLng[]>(() => {
    if (!route?.ok) return [];
    return [route.plan.origin, ...route.plan.stops.map((s) => ({ lat: s.station.lat, lon: s.station.lon })), route.plan.destination];
  }, [route]);

  const visible = useMemo(() => {
    const ids = new Set(nearest.map((s) => s.id));
    // Always show planned stops even if a filter hides them.
    return stations.filter((s) => ids.has(s.id) || stopIndexById.has(s.id));
  }, [stations, nearest, stopIndexById]);

  const initialRegion = {
    latitude: user.position.lat,
    longitude: user.position.lon,
    latitudeDelta: 0.18,
    longitudeDelta: 0.18,
  };

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        provider={PROVIDER_GOOGLE}
        initialRegion={initialRegion}
        showsUserLocation={!user.isFallback}
        showsMyLocationButton
        onLongPress={onLongPress}
      >
        {user.isFallback && (
          <Marker coordinate={{ latitude: user.position.lat, longitude: user.position.lon }} title="You (default)" pinColor={COLORS.route} />
        )}
        {visible.map((s) => (
          <StationMarker
            key={s.id}
            station={s}
            stopIndex={stopIndexById.get(s.id)}
            selected={s.id === selectedId}
            onPress={openStation}
          />
        ))}
        {destination && (
          <Marker
            coordinate={{ latitude: destination.lat, longitude: destination.lon }}
            title="Destination"
            pinColor={COLORS.danger}
            draggable
            onDragEnd={(e) =>
              setDestination({ lat: e.nativeEvent.coordinate.latitude, lon: e.nativeEvent.coordinate.longitude })
            }
          />
        )}
        {roadPolyline ? (
          <Polyline coordinates={roadPolyline.map((p) => ({ latitude: p.lat, longitude: p.lon }))} strokeColor={COLORS.route} strokeWidth={4} />
        ) : (
          estimatePolyline.length > 1 && (
            <Polyline
              coordinates={estimatePolyline.map((p) => ({ latitude: p.lat, longitude: p.lon }))}
              strokeColor={COLORS.route}
              strokeWidth={3}
              lineDashPattern={[8, 6]}
            />
          )
        )}
      </MapView>

      <View style={styles.top}>
        {fetchResult?.source === 'synthetic' && (
          <View style={styles.banner}>
            <Text style={styles.bannerText}>
              Sample data (synthetic) — {fetchResult.fallbackReason}. Availability: {pickSource()}.
            </Text>
          </View>
        )}
        <FilterBar filter={filter} onChange={setFilter} />
        <Text style={styles.hint}>Long-press the map to set a destination.</Text>
      </View>

      {!fetchResult && <ActivityIndicator style={styles.loader} size="large" color={COLORS.primary} />}

      <View style={styles.bottom}>
        {route ? (
          <RouteCard
            result={route}
            refining={refining}
            roadDistances={roadPolyline !== null}
            onClose={() => setDestination(null)}
            onStopPress={focusStop}
          />
        ) : (
          <>
            <TouchableOpacity style={styles.listToggle} onPress={() => setShowList((v) => !v)}>
              <Text style={styles.listToggleText}>
                {showList ? 'Hide' : 'Show'} {nearest.length} nearest stations
              </Text>
            </TouchableOpacity>
            {showList && (
              <FlatList
                style={styles.list}
                data={nearest}
                keyExtractor={(s) => s.id}
                renderItem={({ item, index }) => (
                  <TouchableOpacity style={styles.row} onPress={() => openStation(item)}>
                    <View style={[styles.dot, { backgroundColor: STATUS_COLORS[item.availability.status] }]} />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.rowTitle}>
                        {index + 1}. {item.name}
                      </Text>
                      <Text style={styles.rowMeta}>
                        {item.distanceKm.toFixed(1)} km · {item.availability.available}/{item.availability.total} free · score{' '}
                        {(item.score * 100).toFixed(0)}
                      </Text>
                    </View>
                  </TouchableOpacity>
                )}
              />
            )}
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  top: { position: 'absolute', top: 0, left: 0, right: 0 },
  banner: { backgroundColor: COLORS.warning, paddingHorizontal: 12, paddingVertical: 6 },
  bannerText: { color: '#1a1a1a', fontSize: 12 },
  hint: { alignSelf: 'center', fontSize: 11, color: COLORS.muted, backgroundColor: '#ffffffcc', paddingHorizontal: 8, borderRadius: 8 },
  loader: { position: 'absolute', top: '50%', alignSelf: 'center' },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, maxHeight: '55%' },
  listToggle: { alignSelf: 'center', backgroundColor: COLORS.primary, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, marginBottom: 8, elevation: 4 },
  listToggleText: { color: '#fff', fontWeight: '600' },
  list: { backgroundColor: COLORS.card, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  dot: { width: 12, height: 12, borderRadius: 6, marginRight: 12 },
  rowTitle: { fontWeight: '600', color: COLORS.text },
  rowMeta: { fontSize: 12, color: COLORS.muted },
});
