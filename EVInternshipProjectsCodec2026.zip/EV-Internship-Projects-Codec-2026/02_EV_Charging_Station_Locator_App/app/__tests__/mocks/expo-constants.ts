/** Jest stand-in for expo-constants so services can be tested under Node. */
const Constants = { expoConfig: { extra: {} } };
export default Constants;
