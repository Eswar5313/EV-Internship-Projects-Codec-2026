import type { Connector, LatLng, Station, Vehicle } from '../../src/types';
import sample from '../../src/data/stations_sample.json';

export const GHAZIABAD: LatLng = { lat: 28.6692, lon: 77.4538 }; // Ghaziabad (city centre)
export const NEW_DELHI: LatLng = { lat: 28.6139, lon: 77.209 }; // New Delhi (Connaught Place)
export const AGRA: LatLng = { lat: 27.1767, lon: 78.0081 };
export const JAIPUR: LatLng = { lat: 26.9124, lon: 75.7873 };

export const SAMPLE_STATIONS: Station[] = sample.stations as Station[];

export const COMPACT_EV: Vehicle = {
  batteryKwh: 30,
  consumptionKwhPerKm: 0.15, // 200 km nominal range
  soc: 0.8,
  maxChargeKw: 50,
};

let counter = 0;
export function makeStation(
  pos: LatLng,
  overrides: Partial<Station> & { connectors?: Connector[] } = {},
): Station {
  counter += 1;
  const id = overrides.id ?? `T${counter.toString().padStart(3, '0')}`;
  const connectors = overrides.connectors ?? [{ type: 'CCS2', powerKw: 50, count: 2 }];
  const total = connectors.reduce((s, c) => s + c.count, 0);
  return {
    id,
    name: overrides.name ?? `Station ${id}`,
    operator: 'Test',
    address: 'test',
    lat: pos.lat,
    lon: pos.lon,
    connectors,
    pricePerKwh: 15,
    currency: 'INR',
    hours: '24x7',
    source: 'synthetic',
    ...overrides,
    availability: {
      total,
      available: total,
      status: 'available',
      waitMinutes: 0,
      updatedAt: '2026-09-02T09:00:00Z',
      ...(overrides.availability ?? {}),
    },
  };
}

/** Point `km` kilometres due east of `from` (small-angle approximation). */
export function eastOf(from: LatLng, km: number): LatLng {
  const dLon = km / (111.32 * Math.cos((from.lat * Math.PI) / 180));
  return { lat: from.lat, lon: from.lon + dLon };
}
