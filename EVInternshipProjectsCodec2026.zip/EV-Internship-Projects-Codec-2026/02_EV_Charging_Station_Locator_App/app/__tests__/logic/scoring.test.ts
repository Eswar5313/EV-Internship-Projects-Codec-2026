import { withDistances } from '../../src/logic/nearest';
import { DEFAULT_WEIGHTS, rankStations, scoreBreakdown, scoreStation } from '../../src/logic/scoring';
import { GHAZIABAD, SAMPLE_STATIONS, eastOf, makeStation } from './fixtures';

const base = () => makeStation(eastOf(GHAZIABAD, 5));

describe('scoreStation monotonicity', () => {
  it('scores lie in [0, 1]', () => {
    for (const s of SAMPLE_STATIONS) {
      const v = scoreStation(s, 7);
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(1);
    }
  });

  it('closer is better, all else equal', () => {
    const s = base();
    const scores = [1, 3, 8, 15, 24].map((d) => scoreStation(s, d));
    for (let i = 1; i < scores.length; i++) expect(scores[i]).toBeLessThan(scores[i - 1]);
    // beyond the scale the distance term saturates at 0 but never goes negative
    expect(scoreStation(s, 100)).toBeCloseTo(scoreStation(s, 25), 9);
  });

  it('more free outlets is better; busy beats offline; longer wait is worse', () => {
    const mk = (available: number, status: 'available' | 'busy' | 'offline', wait = 0) =>
      makeStation(eastOf(GHAZIABAD, 5), {
        availability: { total: 4, available, status, waitMinutes: wait, updatedAt: '' },
      });
    expect(scoreStation(mk(4, 'available'), 5)).toBeGreaterThan(scoreStation(mk(2, 'available'), 5));
    expect(scoreStation(mk(2, 'available'), 5)).toBeGreaterThan(scoreStation(mk(1, 'available'), 5));
    expect(scoreStation(mk(1, 'available'), 5)).toBeGreaterThan(scoreStation(mk(0, 'busy', 10), 5));
    expect(scoreStation(mk(0, 'busy', 10), 5)).toBeGreaterThan(scoreStation(mk(0, 'busy', 40), 5));
    expect(scoreStation(mk(0, 'busy', 40), 5)).toBeGreaterThan(scoreStation(mk(0, 'offline'), 5));
    expect(scoreBreakdown(mk(0, 'offline'), 5).availability).toBe(0);
  });

  it('higher power is better', () => {
    const mk = (kw: number) =>
      makeStation(eastOf(GHAZIABAD, 5), { connectors: [{ type: 'CCS2', powerKw: kw, count: 1 }] });
    expect(scoreStation(mk(120), 5)).toBeGreaterThan(scoreStation(mk(60), 5));
    expect(scoreStation(mk(60), 5)).toBeGreaterThan(scoreStation(mk(22), 5));
    expect(scoreStation(mk(22), 5)).toBeGreaterThan(scoreStation(mk(7.4), 5));
  });

  it('cheaper is better', () => {
    const mk = (p: number) => makeStation(eastOf(GHAZIABAD, 5), { pricePerKwh: p });
    expect(scoreStation(mk(10), 5)).toBeGreaterThan(scoreStation(mk(15), 5));
    expect(scoreStation(mk(15), 5)).toBeGreaterThan(scoreStation(mk(22), 5));
  });

  it('weights change the ranking: a price-only weighting prefers the cheap slow charger', () => {
    const cheapSlow = makeStation(eastOf(GHAZIABAD, 6), {
      id: 'cheap',
      pricePerKwh: 9,
      connectors: [{ type: 'Type2', powerKw: 7.4, count: 2 }],
    });
    const dearFast = makeStation(eastOf(GHAZIABAD, 6), {
      id: 'fast',
      pricePerKwh: 22,
      connectors: [{ type: 'CCS2', powerKw: 120, count: 2 }],
    });
    const list = withDistances(GHAZIABAD, [cheapSlow, dearFast]);
    expect(rankStations(list)[0].id).toBe('fast'); // default weights favour power over price
    expect(rankStations(list, { distance: 0, availability: 0, power: 0, price: 1 })[0].id).toBe(
      'cheap',
    );
    expect(DEFAULT_WEIGHTS.distance).toBeGreaterThan(DEFAULT_WEIGHTS.price);
  });

  it('rankStations is sorted best-first and carries a breakdown', () => {
    const ranked = rankStations(withDistances(GHAZIABAD, SAMPLE_STATIONS));
    expect(ranked).toHaveLength(SAMPLE_STATIONS.length);
    for (let i = 1; i < ranked.length; i++) expect(ranked[i].score).toBeLessThanOrEqual(ranked[i - 1].score);
    expect(ranked[0].breakdown.total).toBeCloseTo(ranked[0].score, 12);
    // An offline station should never outrank everything.
    expect(ranked[0].availability.status).not.toBe('offline');
  });
});
