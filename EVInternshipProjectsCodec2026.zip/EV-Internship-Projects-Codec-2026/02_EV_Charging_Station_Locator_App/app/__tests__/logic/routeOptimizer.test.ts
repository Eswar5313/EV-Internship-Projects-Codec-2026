import { haversineKm } from '../../src/logic/haversine';
import {
  DEFAULT_ROUTE_OPTIONS,
  UnreachableError,
  corridorCandidates,
  greedyStops,
  planRoute,
  planRouteSafe,
  simulateMinutes,
} from '../../src/logic/routeOptimizer';
import type { Station, Vehicle } from '../../src/types';
import { COMPACT_EV, GHAZIABAD, NEW_DELHI, SAMPLE_STATIONS, eastOf, makeStation } from './fixtures';

const O = DEFAULT_ROUTE_OPTIONS;
/** Usable range in km when leaving a station after charging to targetSoc. */
const rangeAfterCharge = (v: Vehicle) =>
  ((O.targetSoc - O.reserveSoc) * v.batteryKwh) / v.consumptionKwhPerKm; // 140 km for COMPACT_EV
/** Usable range in km at the start of the trip. */
const rangeAtStart = (v: Vehicle) => ((v.soc - O.reserveSoc) * v.batteryKwh) / v.consumptionKwhPerKm;

/** Assert the physical invariants every plan must satisfy. */
function expectValidPlan(plan: ReturnType<typeof planRoute>, vehicle: Vehicle) {
  expect(plan.legs.length).toBe(plan.stops.length + 1);
  expect(plan.legs[0].fromId).toBe('__origin__');
  expect(plan.legs[plan.legs.length - 1].toId).toBe('__destination__');
  for (const leg of plan.legs) {
    expect(leg.socAtArrival).toBeGreaterThanOrEqual(O.reserveSoc - 1e-9);
    expect(leg.energyKwh).toBeLessThanOrEqual(vehicle.batteryKwh);
  }
  for (const stop of plan.stops) {
    expect(stop.departureSoc).toBeGreaterThanOrEqual(stop.arrivalSoc - 1e-9);
    expect(stop.departureSoc).toBeLessThanOrEqual(O.targetSoc + 1e-9);
    expect(stop.station.availability.status).not.toBe('offline');
  }
  expect(plan.finalSoc).toBeGreaterThanOrEqual(O.reserveSoc - 1e-9);
  expect(plan.totalMinutes).toBeCloseTo(
    plan.driveMinutes + plan.chargeMinutes + plan.waitMinutes + plan.overheadMinutes,
    6,
  );
  const sumKm = plan.legs.reduce((s, l) => s + l.distanceKm, 0);
  expect(plan.totalDistanceKm).toBeCloseTo(sumKm, 6);
}

describe('planRoute — range suffices', () => {
  it('Ghaziabad -> New Delhi at 80 % SOC needs no stop', () => {
    const plan = planRoute(GHAZIABAD, NEW_DELHI, COMPACT_EV, SAMPLE_STATIONS);
    expectValidPlan(plan, COMPACT_EV);
    expect(plan.stops).toHaveLength(0);
    expect(plan.feasibleWithoutCharging).toBe(true);
    expect(plan.chargeMinutes).toBe(0);
    expect(plan.waitMinutes).toBe(0);
    expect(plan.directDistanceKm).toBeCloseTo(haversineKm(GHAZIABAD, NEW_DELHI) * O.detourFactor, 6);
    expect(plan.totalMinutes).toBeCloseTo((plan.directDistanceKm / O.avgSpeedKmh) * 60, 6);
    expect(plan.greedyMinutes).toBeCloseTo(plan.totalMinutes, 6);
  });

  it('does not add a stop just because stations exist on the way', () => {
    const dest = eastOf(GHAZIABAD, 60); // 78 km by road < 140 km start range
    const stations = [makeStation(eastOf(GHAZIABAD, 30))];
    const plan = planRoute(GHAZIABAD, dest, COMPACT_EV, stations);
    expect(plan.stops).toHaveLength(0);
    expect(plan.candidatesConsidered).toBe(1);
  });
});

describe('planRoute — charging stops needed', () => {
  const dest = eastOf(GHAZIABAD, 200); // 260 km by road
  const lineOfStations = [40, 80, 120, 160].map((km, i) =>
    makeStation(eastOf(GHAZIABAD, km), { id: `L${i}`, name: `Line ${km} km` }),
  );
  const lowSoc: Vehicle = { ...COMPACT_EV, soc: 0.5 }; // 80 km usable at start

  it('reaches the destination using stops, every leg within range', () => {
    const plan = planRoute(GHAZIABAD, dest, lowSoc, lineOfStations);
    expectValidPlan(plan, lowSoc);
    expect(plan.stops.length).toBeGreaterThanOrEqual(2);
    expect(plan.feasibleWithoutCharging).toBe(false);
    expect(plan.legs[0].distanceKm).toBeLessThanOrEqual(rangeAtStart(lowSoc) + 1e-6);
    for (const leg of plan.legs.slice(1)) {
      expect(leg.distanceKm).toBeLessThanOrEqual(rangeAfterCharge(lowSoc) + 1e-6);
    }
    // stops are visited in travel order (increasing longitude here)
    const lons = plan.stops.map((s) => s.station.lon);
    expect([...lons].sort((a, b) => a - b)).toEqual(lons);
    expect(plan.chargeMinutes).toBeGreaterThan(0);
  });

  it('Dijkstra is never slower than the greedy baseline', () => {
    const plan = planRoute(GHAZIABAD, dest, lowSoc, lineOfStations);
    expect(plan.greedyMinutes).not.toBeNull();
    expect(plan.totalMinutes).toBeLessThanOrEqual((plan.greedyMinutes as number) + 1e-6);
    const g = greedyStops(GHAZIABAD, dest, lowSoc, lineOfStations);
    expect(g).not.toBeNull();
    expect(simulateMinutes(GHAZIABAD, dest, lowSoc, g as Station[])).toBeCloseTo(
      plan.greedyMinutes as number,
      6,
    );
  });

  it('prefers a fast charger over a slow one at the same place', () => {
    const slow = makeStation(eastOf(GHAZIABAD, 55), {
      id: 'slow',
      connectors: [{ type: 'CCS2', powerKw: 25, count: 2 }],
    });
    const fast = makeStation(eastOf(GHAZIABAD, 55.5), {
      id: 'fast',
      connectors: [{ type: 'CCS2', powerKw: 120, count: 2 }],
    });
    const d = eastOf(GHAZIABAD, 150);
    const plan = planRoute(GHAZIABAD, d, lowSoc, [slow, fast]);
    expect(plan.stops.map((s) => s.station.id)).toEqual(['fast']);
    // usable power is capped by the car's own limit
    expect(plan.stops[0].powerKw).toBe(COMPACT_EV.maxChargeKw);
  });

  it('avoids a busy station with a long wait when a free one is nearby', () => {
    const busy = makeStation(eastOf(GHAZIABAD, 55), {
      id: 'busy',
      availability: { total: 2, available: 0, status: 'busy', waitMinutes: 45, updatedAt: '' },
    });
    const free = makeStation(eastOf(GHAZIABAD, 52), { id: 'free' });
    const d = eastOf(GHAZIABAD, 150);
    const plan = planRoute(GHAZIABAD, d, lowSoc, [busy, free]);
    expect(plan.stops.map((s) => s.station.id)).toEqual(['free']);
    expect(plan.waitMinutes).toBe(0);
    // ...but accepts the wait when it is the only option
    const only = planRoute(GHAZIABAD, d, lowSoc, [busy]);
    expect(only.stops[0].station.id).toBe('busy');
    expect(only.waitMinutes).toBe(45);
  });

  it('never routes through an offline station', () => {
    const off = makeStation(eastOf(GHAZIABAD, 55), {
      id: 'off',
      availability: { total: 2, available: 0, status: 'offline', waitMinutes: 0, updatedAt: '' },
    });
    const d = eastOf(GHAZIABAD, 150);
    expect(() => planRoute(GHAZIABAD, d, lowSoc, [off])).toThrow(UnreachableError);
    expect(corridorCandidates(GHAZIABAD, d, [off])).toHaveLength(0);
  });

  it('trims the final charge to what the last leg needs', () => {
    const plan = planRoute(GHAZIABAD, dest, lowSoc, lineOfStations);
    const last = plan.stops[plan.stops.length - 1];
    expect(last.departureSoc).toBeLessThanOrEqual(O.targetSoc + 1e-9);
    expect(plan.finalSoc).toBeGreaterThanOrEqual(O.reserveSoc - 1e-9);
    expect(plan.finalSoc).toBeLessThan(O.targetSoc); // did not over-charge at the last stop
  });

  it('sample data: Modinagar -> Pari Chowk at 15 % SOC routes via a bundled (synthetic) sample station', () => {
    const modinagar = { lat: 28.8302, lon: 77.5802 };
    const pariChowk = { lat: 28.4662, lon: 77.5102 };
    const v: Vehicle = { ...COMPACT_EV, soc: 0.15 }; // 10 km usable at start
    const plan = planRoute(modinagar, pariChowk, v, SAMPLE_STATIONS);
    expectValidPlan(plan, v);
    expect(plan.stops.length).toBeGreaterThanOrEqual(1);
    expect(SAMPLE_STATIONS.map((s) => s.id)).toContain(plan.stops[0].station.id);
    expect(plan.candidatesConsidered).toBeGreaterThan(0);
    expect(plan.candidatesConsidered).toBeLessThan(SAMPLE_STATIONS.length); // corridor pruned some
  });
});

describe('planRoute — unreachable', () => {
  it('throws no-candidates when there is no station at all', () => {
    const dest = eastOf(GHAZIABAD, 200);
    expect(() => planRoute(GHAZIABAD, dest, COMPACT_EV, [])).toThrow(UnreachableError);
    try {
      planRoute(GHAZIABAD, dest, COMPACT_EV, []);
    } catch (e) {
      expect((e as UnreachableError).reason).toBe('no-candidates');
    }
  });

  it('throws gap-too-large when the stations cannot bridge the distance', () => {
    const dest = eastOf(GHAZIABAD, 200); // 260 km road; 140 km after charging
    const stations = [makeStation(eastOf(GHAZIABAD, 40))]; // 52 + 208 -> second leg too long
    const res = planRouteSafe(GHAZIABAD, dest, { ...COMPACT_EV, soc: 0.5 }, stations);
    expect(res.ok).toBe(false);
    if (!res.ok) {
      expect(res.reason).toBe('gap-too-large');
      expect(res.message).toMatch(/140 km/);
    }
  });

  it('planRouteSafe returns ok:true on success', () => {
    const res = planRouteSafe(GHAZIABAD, NEW_DELHI, COMPACT_EV, SAMPLE_STATIONS);
    expect(res.ok).toBe(true);
  });

  it('rejects an impossible vehicle', () => {
    expect(() => planRoute(GHAZIABAD, NEW_DELHI, { ...COMPACT_EV, batteryKwh: 0 }, [])).toThrow(
      /positive/,
    );
  });
});
