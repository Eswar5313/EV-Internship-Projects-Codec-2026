import { haversineKm } from '../../src/logic/haversine';
import { filterStations, matchesFilter, maxPowerKw, nearestStations } from '../../src/logic/nearest';
import { GHAZIABAD, SAMPLE_STATIONS, eastOf, makeStation } from './fixtures';

describe('nearestStations', () => {
  it('returns k stations sorted by ascending distance', () => {
    const res = nearestStations(GHAZIABAD, SAMPLE_STATIONS, 5);
    expect(res).toHaveLength(5);
    for (let i = 1; i < res.length; i++) {
      expect(res[i].distanceKm).toBeGreaterThanOrEqual(res[i - 1].distanceKm);
    }
    // The k-th nearest must be closer than every station not returned.
    const ids = new Set(res.map((s) => s.id));
    const kth = res[res.length - 1].distanceKm;
    for (const s of SAMPLE_STATIONS) {
      if (!ids.has(s.id)) expect(haversineKm(GHAZIABAD, s)).toBeGreaterThanOrEqual(kth);
    }
  });

  it('nearest station to Ghaziabad centre is the railway-station charger', () => {
    const [first] = nearestStations(GHAZIABAD, SAMPLE_STATIONS, 1);
    expect(first.name).toMatch(/Ghaziabad Railway Station|Nehru Nagar|Kavi Nagar/);
    expect(first.distanceKm).toBeLessThan(3);
  });

  it('handles k larger than the list and k <= 0', () => {
    expect(nearestStations(GHAZIABAD, SAMPLE_STATIONS, 1000)).toHaveLength(SAMPLE_STATIONS.length);
    expect(nearestStations(GHAZIABAD, SAMPLE_STATIONS, 0)).toHaveLength(0);
  });

  it('is deterministic on equal distances (tie broken by id)', () => {
    const a = makeStation(eastOf(GHAZIABAD, 5), { id: 'B' });
    const b = makeStation(eastOf(GHAZIABAD, 5), { id: 'A' });
    const res = nearestStations(GHAZIABAD, [a, b], 2);
    expect(res.map((s) => s.id)).toEqual(['A', 'B']);
  });
});

describe('filters', () => {
  const dc = makeStation(eastOf(GHAZIABAD, 2), {
    id: 'DC',
    connectors: [{ type: 'CCS2', powerKw: 60, count: 2 }],
    pricePerKwh: 18,
  });
  const ac = makeStation(eastOf(GHAZIABAD, 1), {
    id: 'AC',
    connectors: [{ type: 'Type2', powerKw: 7.4, count: 4 }],
    pricePerKwh: 12,
  });
  const busy = makeStation(eastOf(GHAZIABAD, 3), {
    id: 'BUSY',
    availability: { total: 2, available: 0, status: 'busy', waitMinutes: 20, updatedAt: '' },
  });
  const offline = makeStation(eastOf(GHAZIABAD, 4), {
    id: 'OFF',
    availability: { total: 2, available: 0, status: 'offline', waitMinutes: 0, updatedAt: '' },
  });
  const all = [dc, ac, busy, offline];

  it('maxPowerKw picks the fastest outlet', () => {
    expect(maxPowerKw(dc)).toBe(60);
    expect(maxPowerKw(ac)).toBe(7.4);
  });

  it('filters by connector type', () => {
    expect(filterStations(all, { connectorTypes: ['Type2'] }).map((s) => s.id)).toEqual(['AC']);
    expect(filterStations(all, { connectorTypes: ['CCS2'] }).map((s) => s.id)).toEqual([
      'DC',
      'BUSY',
      'OFF',
    ]);
    expect(filterStations(all, { connectorTypes: ['CHAdeMO'] })).toHaveLength(0);
  });

  it('filters by minimum power', () => {
    expect(filterStations(all, { minPowerKw: 20 }).map((s) => s.id)).not.toContain('AC');
    expect(filterStations(all, { minPowerKw: 100 })).toHaveLength(0);
  });

  it('filters by availability and offline status', () => {
    expect(filterStations(all, { onlyAvailable: true }).map((s) => s.id)).toEqual(['DC', 'AC']);
    expect(filterStations(all, { excludeOffline: true }).map((s) => s.id)).toEqual([
      'DC',
      'AC',
      'BUSY',
    ]);
  });

  it('filters by price and distance', () => {
    expect(filterStations(all, { maxPricePerKwh: 15 }).map((s) => s.id)).toEqual([
      'AC',
      'BUSY',
      'OFF',
    ]);
    expect(filterStations(all, { maxDistanceKm: 2.5 }, GHAZIABAD).map((s) => s.id)).toEqual([
      'DC',
      'AC',
    ]);
    // Without an origin the distance filter is ignored rather than failing.
    expect(filterStations(all, { maxDistanceKm: 0.1 })).toHaveLength(4);
  });

  it('combined filters are ANDed and flow through nearestStations', () => {
    const res = nearestStations(GHAZIABAD, all, 10, {
      connectorTypes: ['CCS2'],
      onlyAvailable: true,
      minPowerKw: 50,
    });
    expect(res.map((s) => s.id)).toEqual(['DC']);
    expect(matchesFilter(dc, {})).toBe(true);
  });

  it('sample data: every station with a >= 50 kW outlet has CCS2', () => {
    const fast = filterStations(SAMPLE_STATIONS, { minPowerKw: 50 });
    expect(fast.length).toBeGreaterThan(5);
    expect(fast.every((s) => s.connectors.some((c) => c.type === 'CCS2'))).toBe(true);
  });
});
