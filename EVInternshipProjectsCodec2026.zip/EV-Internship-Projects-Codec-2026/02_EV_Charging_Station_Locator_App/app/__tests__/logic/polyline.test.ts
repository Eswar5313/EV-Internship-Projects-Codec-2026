import { decodePolyline, encodePolyline } from '../../src/logic/polyline';

describe('polyline', () => {
  it('decodes the example from the Google documentation', () => {
    const pts = decodePolyline('_p~iF~ps|U_ulLnnqC_mqNvxq`@');
    expect(pts).toEqual([
      { lat: 38.5, lon: -120.2 },
      { lat: 40.7, lon: -120.95 },
      { lat: 43.252, lon: -126.453 },
    ]);
  });

  it('round-trips NCR coordinates', () => {
    const pts = [
      { lat: 28.6692, lon: 77.4538 },
      { lat: 28.6372, lon: 77.3721 },
      { lat: 28.6139, lon: 77.209 },
    ];
    expect(decodePolyline(encodePolyline(pts))).toEqual(pts);
  });

  it('handles the empty string', () => {
    expect(decodePolyline('')).toEqual([]);
  });
});
