import { bearingDeg, boundingBox, crossTrackKm, haversineKm } from '../../src/logic/haversine';
import { GHAZIABAD, NEW_DELHI, eastOf } from './fixtures';

describe('haversineKm', () => {
  it('is zero for identical points', () => {
    expect(haversineKm(GHAZIABAD, GHAZIABAD)).toBe(0);
  });

  it('is symmetric', () => {
    expect(haversineKm(GHAZIABAD, NEW_DELHI)).toBeCloseTo(haversineKm(NEW_DELHI, GHAZIABAD), 9);
  });

  it('Delhi (Connaught Place) to Ghaziabad is about 20-25 km', () => {
    const d = haversineKm(NEW_DELHI, GHAZIABAD);
    // Great-circle distance between the two city-centre coordinates is ~24.6 km;
    // the commonly quoted "~20 km" figure is from the Delhi border. Both are covered.
    expect(d).toBeGreaterThan(19);
    expect(d).toBeLessThan(26);
    expect(d).toBeCloseTo(24.6, 0);
  });

  it('matches a textbook value: London to Paris ~343.5 km', () => {
    const london = { lat: 51.5074, lon: -0.1278 };
    const paris = { lat: 48.8566, lon: 2.3522 };
    expect(haversineKm(london, paris)).toBeCloseTo(343.5, 0);
  });

  it('one degree of latitude is ~111.2 km', () => {
    expect(haversineKm({ lat: 0, lon: 0 }, { lat: 1, lon: 0 })).toBeCloseTo(111.19, 1);
  });

  it('half the Earth circumference between antipodes', () => {
    expect(haversineKm({ lat: 0, lon: 0 }, { lat: 0, lon: 180 })).toBeCloseTo(20015.1, 0);
  });
});

describe('bearingDeg / crossTrackKm / boundingBox', () => {
  it('bearing due east is ~90 degrees', () => {
    expect(bearingDeg(GHAZIABAD, eastOf(GHAZIABAD, 10))).toBeCloseTo(90, 0);
  });

  it('a point on the path has ~0 cross-track distance', () => {
    const b = eastOf(GHAZIABAD, 40);
    const mid = eastOf(GHAZIABAD, 20);
    expect(Math.abs(crossTrackKm(mid, GHAZIABAD, b))).toBeLessThan(0.05);
  });

  it('a point 5 km north of an eastward path is ~5 km left (negative)', () => {
    const b = eastOf(GHAZIABAD, 40);
    const p = { lat: GHAZIABAD.lat + 5 / 111.19, lon: eastOf(GHAZIABAD, 20).lon };
    const xt = crossTrackKm(p, GHAZIABAD, b);
    expect(xt).toBeLessThan(0);
    expect(Math.abs(xt)).toBeCloseTo(5, 0);
  });

  it('bounding box contains the circle', () => {
    const [minLat, minLon, maxLat, maxLon] = boundingBox(GHAZIABAD, 10);
    expect(haversineKm(GHAZIABAD, { lat: minLat, lon: GHAZIABAD.lon })).toBeCloseTo(10, 1);
    expect(haversineKm(GHAZIABAD, { lat: maxLat, lon: GHAZIABAD.lon })).toBeCloseTo(10, 1);
    expect(haversineKm(GHAZIABAD, { lat: GHAZIABAD.lat, lon: minLon })).toBeCloseTo(10, 1);
    expect(haversineKm(GHAZIABAD, { lat: GHAZIABAD.lat, lon: maxLon })).toBeCloseTo(10, 1);
  });
});
