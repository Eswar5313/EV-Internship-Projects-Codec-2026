import { applyAvailability, parseThingSpeakFeeds, pickSource, simulateStep } from '../../src/services/availability';
import { buildDirectionsUrl, refineWithRoadDistances } from '../../src/services/directions';
import { buildOcmUrl, bundledStations, fetchStations, mapOcmPoi, parsePricePerKwh } from '../../src/services/stations';
import { planRoute } from '../../src/logic/routeOptimizer';
import { COMPACT_EV, GHAZIABAD, NEW_DELHI } from '../logic/fixtures';

describe('stations service', () => {
  it('bundled data is 40 stations, all flagged synthetic', () => {
    const s = bundledStations();
    expect(s).toHaveLength(40);
    expect(s.every((x) => x.source === 'synthetic')).toBe(true);
    expect(s.every((x) => x.lat > 28.4 && x.lat < 28.9 && x.lon > 77.1 && x.lon < 77.7)).toBe(true);
  });

  it('falls back to bundled data when no API key is configured', async () => {
    const r = await fetchStations();
    expect(r.source).toBe('synthetic');
    expect(r.fallbackReason).toMatch(/OPEN_CHARGE_MAP_API_KEY/);
    expect(r.stations).toHaveLength(40);
  });

  it('builds a correct Open Charge Map query', () => {
    const url = buildOcmUrl({ lat: 28.66, lon: 77.43 }, 40, 50);
    expect(url).toContain('countrycode=IN');
    expect(url).toContain('latitude=28.66');
    expect(url).toContain('distance=40');
    expect(url).toContain('maxresults=50');
  });

  it('maps an OCM POI to a Station', () => {
    const st = mapOcmPoi({
      ID: 1234,
      UUID: 'x',
      AddressInfo: { Title: 'Test POI', AddressLine1: 'NH-9', Town: 'Ghaziabad', Latitude: 28.7, Longitude: 77.4 },
      OperatorInfo: { Title: 'Some CPO' },
      StatusType: { IsOperational: true },
      UsageCost: '₹18/kWh',
      Connections: [
        { ConnectionTypeID: 33, PowerKW: 60, Quantity: 2 },
        { ConnectionTypeID: 25, PowerKW: 22, Quantity: 1 },
        { ConnectionTypeID: 9999, PowerKW: 3, Quantity: 1 },
      ],
    });
    expect(st.id).toBe('OCM-1234');
    expect(st.connectors.map((c) => c.type)).toEqual(['CCS2', 'Type2', 'Other']);
    expect(st.availability.total).toBe(4);
    expect(st.availability.status).toBe('unknown'); // directory, not live
    expect(st.pricePerKwh).toBe(18);
    expect(st.source).toBe('openchargemap');
  });

  it('parses common Indian tariff strings', () => {
    expect(parsePricePerKwh('₹18/kWh')).toBe(18);
    expect(parsePricePerKwh('Rs. 15.5 per kWh')).toBe(15.5);
    expect(parsePricePerKwh('INR 20 / kWh incl. GST')).toBe(20);
    expect(parsePricePerKwh('Free')).toBeNaN();
    expect(parsePricePerKwh(null)).toBeNaN();
  });
});

describe('availability service', () => {
  it('defaults to simulated source when nothing is configured', () => {
    expect(pickSource()).toBe('simulated');
  });

  it('applyAvailability merges immutably', () => {
    const s = bundledStations();
    const next = applyAvailability(s, { [s[0].id]: { ...s[0].availability, available: 0, status: 'busy' } });
    expect(next[0].availability.status).toBe('busy');
    expect(s[0].availability.status).not.toBe('busy');
    expect(next[1]).toBe(s[1]);
  });

  it('parses ThingSpeak feeds, latest per station wins', () => {
    const u = parseThingSpeakFeeds([
      { created_at: '2026-09-02T09:00:00Z', field1: 'S1', field2: '0', field3: '2', field4: 'busy', field5: '15' },
      { created_at: '2026-09-02T09:05:00Z', field1: 'S1', field2: '1', field3: '2' },
      { created_at: '2026-09-02T09:05:00Z', field1: null },
    ]);
    expect(Object.keys(u)).toEqual(['S1']);
    expect(u.S1.available).toBe(1);
    expect(u.S1.status).toBe('available');
  });

  it('simulateStep keeps counts within [0,total] and offline stations offline', () => {
    const s = bundledStations();
    let state = Object.fromEntries(s.map((x) => [x.id, x.availability]));
    for (let i = 0; i < 50; i++) state = simulateStep(state);
    for (const x of s) {
      const a = state[x.id];
      expect(a.available).toBeGreaterThanOrEqual(0);
      expect(a.available).toBeLessThanOrEqual(a.total);
      if (x.availability.status === 'offline') expect(a.status).toBe('offline');
      else expect(a.status).toBe(a.available > 0 ? 'available' : 'busy');
    }
  });
});

describe('directions service', () => {
  it('builds a Directions URL with ordered waypoints', () => {
    const url = buildDirectionsUrl(GHAZIABAD, NEW_DELHI, [{ lat: 28.64, lon: 77.34 }]);
    expect(url).toContain('origin=28.669200%2C77.453800');
    expect(url).toContain('waypoints=28.640000%2C77.340000');
    expect(url).not.toContain('optimize');
  });

  it('refineWithRoadDistances swaps in road legs and recomputes totals', () => {
    const plan = planRoute(GHAZIABAD, NEW_DELHI, COMPACT_EV, bundledStations());
    const refined = refineWithRoadDistances(plan, {
      polyline: [],
      legs: [{ distanceKm: 30, durationMin: 55, startAddress: '', endAddress: '' }],
      distanceKm: 30,
      durationMin: 55,
      summary: 'NH 9',
    });
    expect(refined.totalDistanceKm).toBe(30);
    expect(refined.totalMinutes).toBeCloseTo(55, 6);
    // leg-count mismatch leaves the plan untouched
    expect(refineWithRoadDistances(plan, { polyline: [], legs: [], distanceKm: 0, durationMin: 0, summary: '' })).toBe(plan);
  });
});
