#!/usr/bin/env node
/**
 * Build web-demo/index.html from web-demo/index.template.html by inlining
 *   - the SAME logic modules the app uses (app/src/logic/*.ts), transpiled to
 *     plain JS with the TypeScript compiler and import/export lines stripped
 *   - data/stations_sample.json
 * so the demo is a single self-contained file.
 *
 * Run from the project root:  node scripts/build_web_demo.js
 * (needs app/node_modules — run `npm install` inside app/ first)
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const ts = require(path.join(root, 'app', 'node_modules', 'typescript'));

const LOGIC = ['haversine', 'nearest', 'scoring', 'routeOptimizer'];

function transpile(file) {
  const src = fs.readFileSync(file, 'utf8');
  const out = ts.transpileModule(src, {
    compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext, removeComments: false },
    fileName: file,
  }).outputText;
  return out
    .replace(/^import[^;]*;\s*$/gm, '') // drop imports (everything lives in one scope)
    .replace(/^export\s+(?=(const|function|class|let|var)\b)/gm, '') // keep declarations, drop `export`
    .replace(/^export\s*\{[^}]*\};?\s*$/gm, '');
}

const logicJs = LOGIC.map((m) => {
  const file = path.join(root, 'app', 'src', 'logic', `${m}.ts`);
  return `// ---- app/src/logic/${m}.ts (transpiled, unmodified logic) ----\n${transpile(file)}`;
}).join('\n');

const data = fs.readFileSync(path.join(root, 'data', 'stations_sample.json'), 'utf8');
const template = fs.readFileSync(path.join(root, 'web-demo', 'index.template.html'), 'utf8');

const html = template
  .replace('/*__LOGIC_JS__*/', logicJs)
  .replace('/*__STATIONS_JSON__*/', `const STATION_DATA = ${data.trim()};`);

const outFile = path.join(root, 'web-demo', 'index.html');
fs.writeFileSync(outFile, html);
console.log(`wrote ${outFile} (${(html.length / 1024).toFixed(0)} kB, logic ${LOGIC.join(', ')})`);
