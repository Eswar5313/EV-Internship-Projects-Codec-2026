"""Render web-demo/index.html headlessly and save results/web_demo.png.

In the build sandbox Chromium cannot open TLS tunnels itself, so external
requests (Leaflet from unpkg, OSM tiles) are fetched with `requests` — which
honours HTTPS_PROXY and the CA bundle — and handed to the page. Outside the
sandbox the page loads them directly and this interception is a no-op cost.
"""
import json, os, sys, time
from pathlib import Path

import requests
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
html = (root / "web-demo" / "index.html").resolve()
OFFLINE = "--offline" in sys.argv  # exercise the SVG fallback
out = root / "results" / ("web_demo_offline_fallback.png" if OFFLINE else "web_demo.png")
errors, fetched = [], {"ok": 0, "fail": 0}
session = requests.Session()
session.headers["User-Agent"] = "EV-Charging-Locator-demo-screenshot/1.0 (internship project; contact via repo)"


def relay(route, request):
    try:
        r = session.get(request.url, timeout=30)
        fetched["ok"] += 1
        route.fulfill(status=r.status_code, body=r.content,
                      headers={"content-type": r.headers.get("content-type", "application/octet-stream")})
    except Exception as e:  # noqa: BLE001
        fetched["fail"] += 1
        errors.append(f"relay {request.url}: {e}")
        route.abort()


with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1400, "height": 860})
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    pg.route(lambda url: url.startswith("https://"), (lambda route, req: route.abort()) if OFFLINE else relay)
    pg.goto(html.as_uri(), wait_until="load")
    time.sleep(6)  # let tiles arrive
    info = pg.evaluate("""() => ({
        leaflet: !!window.__usingLeaflet,
        plan: window.__lastPlan && {stops: window.__lastPlan.stops.map(s => s.station.name),
               total: window.__lastPlan.totalMinutes, charge: window.__lastPlan.chargeMinutes,
               drive: window.__lastPlan.driveMinutes, wait: window.__lastPlan.waitMinutes,
               km: window.__lastPlan.totalDistanceKm, greedy: window.__lastPlan.greedyMinutes,
               finalSoc: window.__lastPlan.finalSoc, cand: window.__lastPlan.candidatesConsidered},
        nearest: [...document.querySelectorAll('#nearest li b')].map(b => b.textContent),
        tiles: document.querySelectorAll('img.leaflet-tile-loaded').length
    })""")
    pg.screenshot(path=str(out), full_page=False)
    b.close()
print(json.dumps(info, indent=1))
print("relayed:", fetched, "errors:", errors[:5])
print("wrote", out)
(root / "results" / ("web_demo_offline_run.json" if OFFLINE else "web_demo_run.json")).write_text(json.dumps({"info": info, "relayed": fetched, "errors": errors}, indent=1))
