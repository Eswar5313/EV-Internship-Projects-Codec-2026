#!/usr/bin/env node
/** Run the optimiser on a few NCR scenarios with the bundled sample data and
 *  write results/route_examples.json (numbers quoted in the README). */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.resolve(__dirname, '..');
const ts = require(path.join(root, 'app', 'node_modules', 'typescript'));

const src = ['haversine', 'nearest', 'scoring', 'routeOptimizer']
  .map((m) => fs.readFileSync(path.join(root, 'app/src/logic', `${m}.ts`), 'utf8'))
  .map((s) => ts.transpileModule(s, { compilerOptions: { target: 'ES2020', module: 'ESNext' } }).outputText)
  .join('\n')
  .replace(/^import[^;]*;\s*$/gm, '')
  .replace(/^export\s+(?=(const|function|class|let|var)\b)/gm, '');
const ctx = { console };
vm.createContext(ctx);
vm.runInContext(src + '\nthis.api = { planRouteSafe, nearestStations, rankStations, haversineKm };', ctx);
const { planRouteSafe, nearestStations, rankStations, haversineKm } = ctx.api;

const stations = JSON.parse(fs.readFileSync(path.join(root, 'data/stations_sample.json'), 'utf8')).stations;
const P = {
  ghaziabad: { lat: 28.6692, lon: 77.4538 },
  modinagar: { lat: 28.8302, lon: 77.5802 },
  pariChowk: { lat: 28.4662, lon: 77.5102 },
  connaught: { lat: 28.6322, lon: 77.2192 },
  loni: { lat: 28.7502, lon: 77.2902 },
  hapur: { lat: 28.7102, lon: 77.6502 },
};
const car = (soc) => ({ batteryKwh: 30, consumptionKwhPerKm: 0.15, soc, maxChargeKw: 50 });
const scenarios = [
  ['Ghaziabad -> Connaught Place, 80 % SOC', P.ghaziabad, P.connaught, car(0.8)],
  ['Modinagar -> Pari Chowk, 20 % SOC', P.modinagar, P.pariChowk, car(0.2)],
  ['Modinagar -> Pari Chowk, 12 % SOC', P.modinagar, P.pariChowk, car(0.12)],
  ['Hapur bypass -> Loni, 15 % SOC', P.hapur, P.loni, car(0.15)],
  ['Loni -> Pari Chowk, 25 % SOC, only >=50 kW', P.loni, P.pariChowk, car(0.25), { minStopPowerKw: 50 }],
];
const out = { generatedAt: new Date().toISOString(), dataNotice: 'synthetic sample stations', scenarios: [] };
for (const [name, o, d, v, opts] of scenarios) {
  const t0 = process.hrtime.bigint();
  const r = planRouteSafe(o, d, v, stations, opts || {});
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  const row = { name, ok: r.ok, computeMs: +ms.toFixed(2) };
  if (r.ok) {
    const p = r.plan;
    Object.assign(row, {
      stops: p.stops.map((s) => `${s.station.name} (arrive ${Math.round(s.arrivalSoc * 100)} %, +${s.chargeKwh.toFixed(1)} kWh, ${s.chargeMinutes.toFixed(0)} min charge, ${s.waitMinutes} min wait)`),
      totalMinutes: +p.totalMinutes.toFixed(1), driveMinutes: +p.driveMinutes.toFixed(1), chargeMinutes: +p.chargeMinutes.toFixed(1),
      waitMinutes: p.waitMinutes, distanceKm: +p.totalDistanceKm.toFixed(1), directKm: +p.directDistanceKm.toFixed(1),
      finalSocPct: Math.round(p.finalSoc * 100), candidates: p.candidatesConsidered,
      greedyMinutes: p.greedyMinutes === null ? null : +p.greedyMinutes.toFixed(1),
    });
  } else Object.assign(row, { reason: r.reason, message: r.message });
  out.scenarios.push(row);
}
const near = rankStations(nearestStations(P.ghaziabad, stations, 5, { excludeOffline: true }));
out.nearestToGhaziabad = near.map((s) => ({ name: s.name, km: +s.distanceKm.toFixed(2), status: s.availability.status, score: +(s.score * 100).toFixed(0) }));
out.delhiToGhaziabadKm = +haversineKm({ lat: 28.6139, lon: 77.209 }, P.ghaziabad).toFixed(2);
fs.writeFileSync(path.join(root, 'results/route_examples.json'), JSON.stringify(out, null, 2) + '\n');
console.log(JSON.stringify(out, null, 2));
