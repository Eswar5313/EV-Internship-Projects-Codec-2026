"""Generate data/stations_sample.json — DECLARED-SYNTHETIC sample data.

Why synthetic: the Open Charge Map API requires an API key (HTTP 403 without
one) and the OpenStreetMap Overpass mirrors were unreachable from the build
environment, so I could not download real station records. This script builds
40 plausible stations at real Delhi-NCR / Ghaziabad localities with fictional
operator names, connector mixes, tariffs and availability. Nothing here is a
real charging site. The app replaces this file with live Open Charge Map data
as soon as an API key is configured.

Run:  python scripts/make_sample_stations.py
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timezone
from pathlib import Path

random.seed(2026)

# (name, locality/address, lat, lon) — coordinates are approximate centres of
# well-known localities, NOT surveyed charger positions.
SITES = [
    ("Raj Nagar Extension Hub", "NH-58 service road, Raj Nagar Extension, Ghaziabad", 28.7005, 77.4262),
    ("Shipra Mall Parking", "Indirapuram, Ghaziabad", 28.6372, 77.3721),
    ("Vaishali Sector 4 Fast Charge", "Vaishali, Ghaziabad", 28.6412, 77.3402),
    ("Kaushambi Metro Park & Charge", "Kaushambi, Ghaziabad", 28.6453, 77.3234),
    ("Vasundhara Sector 10 Plaza", "Vasundhara, Ghaziabad", 28.6604, 77.3752),
    ("Mohan Nagar Junction", "Mohan Nagar, Ghaziabad", 28.6753, 77.3852),
    ("Crossings Republik Gate 1", "Crossings Republik, NH-24, Ghaziabad", 28.6323, 77.4303),
    ("Wave City Expressway Stop", "Wave City, NH-24, Ghaziabad", 28.6522, 77.4752),
    ("Sahibabad Industrial Area Depot", "Site 4, Sahibabad, Ghaziabad", 28.6782, 77.3551),
    ("Ghaziabad Railway Station Parking", "Station Road, Ghaziabad", 28.6672, 77.4401),
    ("Kavi Nagar Market", "Kavi Nagar, Ghaziabad", 28.6752, 77.4452),
    ("Nehru Nagar Community Charger", "Nehru Nagar III, Ghaziabad", 28.6652, 77.4553),
    ("Loni Road Depot", "Loni, Ghaziabad", 28.7502, 77.2902),
    ("Dasna Toll Plaza Fast Charge", "Dasna, NH-9, Ghaziabad", 28.6802, 77.5302),
    ("Muradnagar Canal Road", "Muradnagar, Ghaziabad", 28.7802, 77.5002),
    ("Modinagar Highway Stop", "NH-58, Modinagar", 28.8302, 77.5802),
    ("Hapur Bypass Truck Stop", "NH-9, Pilkhuwa", 28.7102, 77.6502),
    ("Anand Vihar ISBT Charging Bay", "Anand Vihar, East Delhi", 28.6472, 77.3162),
    ("Mayur Vihar Phase 1 Market", "Mayur Vihar Ph-1, East Delhi", 28.6062, 77.2932),
    ("Laxmi Nagar District Centre", "Laxmi Nagar, East Delhi", 28.6362, 77.2782),
    ("Preet Vihar Metro Parking", "Preet Vihar, East Delhi", 28.6402, 77.2952),
    ("Connaught Place Block-A", "Connaught Place, New Delhi", 28.6322, 77.2192),
    ("Nehru Place Multi-Level Parking", "Nehru Place, South Delhi", 28.5492, 77.2512),
    ("Dilshad Garden Metro Depot", "Dilshad Garden, North East Delhi", 28.6812, 77.3212),
    ("Karkardooma Court Complex", "Karkardooma, East Delhi", 28.6532, 77.3022),
    ("Akshardham Parking Lot", "NH-24, Akshardham, East Delhi", 28.6132, 77.2782),
    ("Shastri Park Depot", "Shastri Park, North East Delhi", 28.6692, 77.2532),
    ("ITO Ring Road Charger", "ITO, Central Delhi", 28.6282, 77.2412),
    ("Shahdara Flyover Stop", "GT Road, Shahdara, Delhi", 28.6732, 77.2902),
    ("Sector 18 Atta Market Parking", "Sector 18, Noida", 28.5702, 77.3252),
    ("Sector 62 IT Park", "Sector 62, Noida", 28.6282, 77.3652),
    ("Sector 15 Metro Charging Point", "Sector 15, Noida", 28.5852, 77.3132),
    ("Sector 137 Expressway Plaza", "Sector 137, Noida", 28.5102, 77.3952),
    ("Pari Chowk Hub", "Pari Chowk, Greater Noida", 28.4662, 77.5102),
    ("Sector 50 Market Charger", "Sector 50, Noida", 28.5702, 77.3652),
    ("Film City Sector 16A", "Sector 16A, Noida", 28.5782, 77.3122),
    ("Sector 128 Expressway Stop", "Noida-Greater Noida Expressway, Sector 128", 28.5352, 77.3652),
    ("Sector 104 Society Charger", "Sector 104, Noida", 28.5452, 77.3452),
    ("Botanical Garden Metro Parking", "Sector 38A, Noida", 28.5642, 77.3342),
    ("Gaur City Centre", "Greater Noida West (Noida Extension)", 28.6052, 77.4352),
]

# Fictional operators — deliberately not real charging networks.
OPERATORS = ["VoltGrid NCR", "AmpDock", "GreenPlug India", "ChargeSetu", "NCR e-Mobility Co-op"]

CONNECTOR_PROFILES = [
    # (label, list of (type, kW, count))
    ("dc_fast", [("CCS2", 60, 2), ("Type2", 22, 2)]),
    ("dc_ultra", [("CCS2", 120, 2), ("CHAdeMO", 50, 1), ("Type2", 22, 1)]),
    ("dc_mixed", [("CCS2", 30, 2), ("GB/T", 30, 1), ("Bharat-DC-001", 15, 2)]),
    ("ac_only", [("Type2", 7.4, 4), ("Bharat-AC-001", 3.3, 2)]),
    ("ac_fast", [("Type2", 22, 3)]),
]
PROFILE_WEIGHTS = [0.3, 0.15, 0.2, 0.2, 0.15]


def main() -> None:
    out_path = Path(__file__).resolve().parents[1] / "data" / "stations_sample.json"
    stations = []
    now = datetime(2026, 9, 2, 9, 0, tzinfo=timezone.utc)
    for i, (name, addr, lat, lon) in enumerate(SITES, start=1):
        label, conns = random.choices(CONNECTOR_PROFILES, PROFILE_WEIGHTS)[0]
        connectors = [{"type": t, "powerKw": kw, "count": c} for t, kw, c in conns]
        total = sum(c["count"] for c in connectors)
        status_roll = random.random()
        if status_roll < 0.08:
            status, available = "offline", 0
        else:
            available = random.randint(0, total)
            status = "available" if available > 0 else "busy"
        wait = 0 if available > 0 else (random.randint(5, 40) if status == "busy" else 0)
        max_kw = max(c["powerKw"] for c in connectors)
        price = round(random.uniform(11.0, 15.0) if max_kw < 25 else random.uniform(16.0, 22.0), 1)
        stations.append(
            {
                "id": f"SYN-{i:03d}",
                "name": name,
                "operator": random.choice(OPERATORS),
                "address": addr,
                "lat": lat,
                "lon": lon,
                "connectors": connectors,
                "pricePerKwh": price,
                "currency": "INR",
                "hours": random.choice(["24x7", "24x7", "06:00-23:00", "08:00-22:00"]),
                "amenities": random.sample(["restroom", "cafe", "wifi", "parking", "shop"], k=random.randint(1, 3)),
                "availability": {
                    "total": total,
                    "available": available,
                    "status": status,
                    "waitMinutes": wait,
                    "updatedAt": now.isoformat().replace("+00:00", "Z"),
                },
                "source": "synthetic",
            }
        )

    doc = {
        "_notice": (
            "DECLARED-SYNTHETIC SAMPLE DATA. These 40 stations are fictional. Coordinates "
            "are approximate centres of real Delhi-NCR / Ghaziabad localities, but the "
            "chargers, operators, tariffs and availability figures were generated by "
            "scripts/make_sample_stations.py and do not describe any real charging site. "
            "The app replaces this file with live Open Charge Map data when an API key is set."
        ),
        "generatedAt": now.isoformat().replace("+00:00", "Z"),
        "generator": "scripts/make_sample_stations.py (seed 2026)",
        "centre": {"lat": 28.66, "lon": 77.43, "label": "Ghaziabad, Uttar Pradesh"},
        "stations": stations,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(doc, indent=2) + "\n")
    print(f"wrote {len(stations)} stations -> {out_path}")


if __name__ == "__main__":
    main()
