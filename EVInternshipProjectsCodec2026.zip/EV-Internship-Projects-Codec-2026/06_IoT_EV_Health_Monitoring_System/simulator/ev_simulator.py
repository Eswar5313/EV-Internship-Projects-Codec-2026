#!/usr/bin/env python3
"""
ev_simulator.py - synthetic EV pack telemetry generator + ThingSpeak-style poster.

Plays the role of the NodeMCU when no hardware is connected: it generates a
plausible drive / charge / idle profile for a 48 V two-wheeler pack and posts
one sample every `--interval` seconds to a ThingSpeak-compatible `/update`
endpoint (the local mock_cloud.py by default, the real ThingSpeak if you pass
--url https://api.thingspeak.com/update).

    python simulator/ev_simulator.py --url http://127.0.0.1:5000/update \
        --api-key DEMOKEY --interval 2 --speed 30

`--speed 30` means each posted sample advances the *vehicle* clock by
30x the wall-clock interval so that a 15-minute demo shows a full
drive-charge-idle cycle. Use `--speed 1 --interval 15` to mimic the real
firmware timing exactly.

All values are SIMULATED. Nothing here is a measurement.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pack_model import (Telemetry, estimate_soc, health_flags, soc_to_ocv,  # noqa: E402
                        Thresholds, DEFAULT_THRESHOLDS)


class PackConfig:
    """48 V, 13s 30 Ah (~1.4 kWh) Li-ion pack typical of an Indian e-scooter."""
    series_cells = 13
    capacity_ah = 30.0
    resistance_ohm = 0.080          # whole-pack DC resistance (13s4p of ~25 mOhm cells + busbars)
    thermal_mass_j_per_k = 5000.0   # ~ 6 kg of cells+case at ~830 J/kgK
    thermal_conductance_w_per_k = 2.0  # enclosed pack, little airflow
    ambient_c = 35.0                # Chennai pre-monsoon afternoon


class EVSimulator:
    """
    Discrete-time (dt seconds) hybrid model:
      state machine  idle -> drive -> idle -> charge -> idle ...
      drive current  = random urban duty cycle (accel bursts + regen)
      charge current = CC-CV charger, 10 A tapering above 4.1 V/cell
      SOC            = coulomb counting of the *true* pack (ground truth)
      pack voltage   = OCV(SOC) * series - I * R
      temperature    = lumped mass, I^2 R heating, convection to ambient
      aux 12 V       = slow discharge while idle, DC-DC charges it while on
    """

    IDLE, DRIVE, CHARGE = 0, 1, 2

    def __init__(self, seed: int = 42, cfg: PackConfig | None = None,
                 thresholds: Thresholds = DEFAULT_THRESHOLDS,
                 initial_soc: float = 85.0, sensor_noise: bool = True):
        self.rng = random.Random(seed)
        self.cfg = cfg or PackConfig()
        self.th = thresholds
        self.soc_true = initial_soc
        self.temp_c = self.cfg.ambient_c + 1.0
        self.aux_v = 12.6
        self.state = self.IDLE
        self.state_time_left = 60.0
        self.t = 0.0
        self.current_a = 0.0
        self.sensor_noise = sensor_noise
        self._drive_target = 0.0

    # ---- state machine ----------------------------------------------------
    def _next_state(self):
        r = self.rng
        if self.state == self.IDLE:
            if self.soc_true < 30 and r.random() < 0.7:
                self.state, self.state_time_left = self.CHARGE, r.uniform(1800, 4800)
            else:
                self.state, self.state_time_left = self.DRIVE, r.uniform(600, 2400)
        elif self.state == self.DRIVE:
            self.state, self.state_time_left = self.IDLE, r.uniform(120, 900)
        else:  # CHARGE
            self.state, self.state_time_left = self.IDLE, r.uniform(300, 1200)

    # ---- current profiles -------------------------------------------------
    def _drive_current(self, dt: float) -> float:
        r = self.rng
        # new target every few seconds: cruise 6-14 A, bursts 20-38 A, regen -6..-2 A
        if r.random() < dt / 6.0:
            u = r.random()
            if u < 0.60:
                self._drive_target = r.uniform(6, 14)
            elif u < 0.85:
                self._drive_target = r.uniform(18, 38)
            elif u < 0.95:
                self._drive_target = r.uniform(-6, -2)
            else:
                self._drive_target = 0.0
        # first-order lag towards target
        return self.current_a + (self._drive_target - self.current_a) * min(1.0, dt / 2.0)

    def _charge_current(self) -> float:
        v_cell = soc_to_ocv(self.soc_true)
        if self.soc_true >= 99.5:
            return 0.0
        if v_cell < 4.10:
            return -10.0                       # CC phase
        return -10.0 * max(0.05, (4.20 - v_cell) / 0.10)  # CV taper

    # ---- one step -----------------------------------------------------------
    def step(self, dt: float) -> Telemetry:
        c = self.cfg
        self.state_time_left -= dt
        if self.state_time_left <= 0:
            self._next_state()

        if self.state == self.DRIVE:
            if self.soc_true <= 3.0:
                self.state, self.state_time_left = self.IDLE, 300
                self.current_a = 0.0
            else:
                self.current_a = self._drive_current(dt)
        elif self.state == self.CHARGE:
            self.current_a = self._charge_current()
            if self.soc_true >= 99.5:
                self.state, self.state_time_left = self.IDLE, 600
        else:
            self.current_a += (0.15 - self.current_a) * min(1.0, dt / 2.0)  # quiescent draw

        # coulomb count the true SOC
        self.soc_true -= self.current_a * dt / 3600.0 / c.capacity_ah * 100.0
        self.soc_true = min(100.0, max(0.0, self.soc_true))

        # electrical
        v_ocv = soc_to_ocv(self.soc_true) * c.series_cells
        v_pack = v_ocv - self.current_a * c.resistance_ohm

        # thermal
        q_gen = self.current_a ** 2 * c.resistance_ohm
        q_loss = c.thermal_conductance_w_per_k * (self.temp_c - c.ambient_c)
        self.temp_c += (q_gen - q_loss) / c.thermal_mass_j_per_k * dt

        # 12 V aux battery
        if self.state == self.IDLE:
            self.aux_v -= 0.02 * dt / 600.0
        else:
            self.aux_v += (13.8 - self.aux_v) * min(1.0, dt / 300.0)
        self.aux_v = max(10.5, min(14.4, self.aux_v))

        self.t += dt

        # sensor readings (what the NodeMCU would see)
        n = self.rng.gauss if self.sensor_noise else (lambda mu, sd: 0.0)
        v_meas = v_pack + n(0, 0.02)
        i_meas = self.current_a + n(0, 0.05)
        t_meas = self.temp_c + n(0, 0.1)
        aux_meas = self.aux_v + n(0, 0.03)

        soc_est = estimate_soc(v_meas, i_meas, c.series_cells, c.resistance_ohm)
        flags = health_flags(v_meas, i_meas, t_meas, soc_est, aux_meas,
                             c.series_cells, True, self.th)
        return Telemetry(
            pack_voltage_v=v_meas, current_a=i_meas, temp_c=t_meas, soc_pct=soc_est,
            power_w=v_meas * i_meas, aux_voltage_v=aux_meas, health_flags=flags,
            state_code=self.state,
        )


# ---------------------------------------------------------------------------
# posting
# ---------------------------------------------------------------------------
def post_update(url: str, api_key: str, sample: Telemetry, timeout: float = 5.0,
                created_at: str | None = None) -> str:
    """HTTP GET <url>?api_key=...&field1=...  (exactly what the firmware does).
    created_at (ISO-8601) is optional and supported by both ThingSpeak and mock_cloud."""
    params = {"api_key": api_key, **sample.to_fields()}
    if created_at:
        params["created_at"] = created_at
    full = url + "?" + urllib.parse.urlencode(params)
    with urllib.request.urlopen(full, timeout=timeout) as resp:
        return resp.read().decode().strip()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default="http://127.0.0.1:5000/update",
                    help="ThingSpeak-compatible update endpoint (real: https://api.thingspeak.com/update)")
    ap.add_argument("--api-key", default="DEMOKEY", help="channel write API key")
    ap.add_argument("--interval", type=float, default=15.0, help="seconds between posts (ThingSpeak free tier min 15 s)")
    ap.add_argument("--speed", type=float, default=1.0, help="vehicle-time acceleration factor")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--samples", type=int, default=0, help="stop after N posts (0 = run forever)")
    ap.add_argument("--csv", type=str, default="", help="also append every sample to this CSV")
    ap.add_argument("--offline", action="store_true", help="do not post, just generate (use with --csv/--samples)")
    ap.add_argument("--dt", type=float, default=1.0, help="internal model step (s)")
    ap.add_argument("--sim-timestamps", action="store_true",
                    help="stamp each post with the simulated vehicle time instead of wall time")
    args = ap.parse_args(argv)

    sim = EVSimulator(seed=args.seed)
    import datetime as _dt
    t_start = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0)
    writer = None
    if args.csv:
        p = Path(args.csv)
        p.parent.mkdir(parents=True, exist_ok=True)
        fh = open(p, "w", newline="")
        writer = csv.writer(fh)
        writer.writerow(["t_s", "state", "pack_voltage_v", "current_a", "temp_c",
                         "soc_est_pct", "soc_true_pct", "power_w", "aux_voltage_v", "health_flags"])

    n = 0
    try:
        while args.samples == 0 or n < args.samples:
            sim_seconds = args.interval * args.speed
            steps = max(1, int(round(sim_seconds / args.dt)))
            for _ in range(steps):
                s = sim.step(sim_seconds / steps)
            if writer:
                writer.writerow([round(sim.t, 1), sim.state, round(s.pack_voltage_v, 3),
                                 round(s.current_a, 3), round(s.temp_c, 2), round(s.soc_pct, 1),
                                 round(sim.soc_true, 2), round(s.power_w, 1),
                                 round(s.aux_voltage_v, 2), s.health_flags])
            msg = ""
            if not args.offline:
                try:
                    stamp = None
                    if args.sim_timestamps:
                        stamp = (t_start + _dt.timedelta(seconds=sim.t)).strftime("%Y-%m-%dT%H:%M:%SZ")
                    msg = post_update(args.url, args.api_key, s, created_at=stamp)
                except Exception as exc:  # network errors must not kill the demo
                    msg = f"POST FAILED: {exc}"
            print(f"[{n:5d}] t={sim.t:8.0f}s state={s.state_code} V={s.pack_voltage_v:6.2f} "
                  f"I={s.current_a:6.2f} T={s.temp_c:5.1f} SOC={s.soc_pct:5.1f} flags={s.health_flags:#04x} {msg}",
                  flush=True)
            n += 1
            if args.samples == 0 or n < args.samples:
                if not args.offline:
                    time.sleep(args.interval)
    except KeyboardInterrupt:
        pass
    finally:
        if writer:
            fh.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
