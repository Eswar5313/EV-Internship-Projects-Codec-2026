"""
pack_model.py - shared battery-pack helper logic for the EV health monitor.

This module holds the *same* SOC lookup table and health-flag rules that the
NodeMCU firmware (firmware/nodemcu_ev_monitor/nodemcu_ev_monitor.ino) uses,
so the Python simulator, the Raspberry Pi alternative and the unit tests all
agree with the firmware bit-for-bit on:

  * OCV -> SOC lookup (per-cell open-circuit voltage, linear interpolation)
  * health-flag bitmask (field 7 on ThingSpeak)
  * ThingSpeak field mapping (field1..field8)

Author: Eswar Mahalingam, Codec Technologies EV internship, Sept 2026.
All numbers here are synthetic / representative, not measurements.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict

# ---------------------------------------------------------------------------
# OCV-SOC lookup table (per cell, NMC/graphite-like, rested at 25 degC).
# Must stay identical to OCV_TABLE[] in the .ino file.
# ---------------------------------------------------------------------------
OCV_TABLE_V = [3.00, 3.30, 3.45, 3.55, 3.60, 3.65, 3.70, 3.75, 3.82, 3.90, 4.00, 4.10, 4.20]
OCV_TABLE_SOC = [0, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100]

# Health-flag bit positions (field 7). Must match the #defines in the .ino.
FLAG_OVER_TEMP = 1 << 0   # pack temp > TEMP_MAX_C
FLAG_UNDER_TEMP = 1 << 1  # pack temp < TEMP_MIN_C (charging below 0 degC is unsafe)
FLAG_LOW_SOC = 1 << 2     # SOC < SOC_LOW_PCT
FLAG_OVER_CURRENT = 1 << 3  # |I| > CURRENT_MAX_A
FLAG_OVER_VOLTAGE = 1 << 4  # pack V > series * 4.25
FLAG_UNDER_VOLTAGE = 1 << 5  # pack V < series * 3.0
FLAG_AUX_LOW = 1 << 6     # 12 V auxiliary battery < AUX_LOW_V
FLAG_SENSOR_FAULT = 1 << 7  # DS18B20 / INA219 read failed

FLAG_NAMES = {
    FLAG_OVER_TEMP: "OVER_TEMP",
    FLAG_UNDER_TEMP: "UNDER_TEMP",
    FLAG_LOW_SOC: "LOW_SOC",
    FLAG_OVER_CURRENT: "OVER_CURRENT",
    FLAG_OVER_VOLTAGE: "OVER_VOLTAGE",
    FLAG_UNDER_VOLTAGE: "UNDER_VOLTAGE",
    FLAG_AUX_LOW: "AUX_LOW",
    FLAG_SENSOR_FAULT: "SENSOR_FAULT",
}


@dataclass
class Thresholds:
    """Alarm thresholds - same defaults as config.h.example."""
    temp_max_c: float = 45.0
    temp_min_c: float = 0.0
    soc_low_pct: float = 20.0
    current_max_a: float = 30.0
    cell_v_max: float = 4.25
    cell_v_min: float = 3.00
    aux_low_v: float = 11.8


DEFAULT_THRESHOLDS = Thresholds()


def ocv_to_soc(cell_voltage: float) -> float:
    """Per-cell open-circuit voltage -> SOC in percent (0..100), linear interp."""
    if cell_voltage <= OCV_TABLE_V[0]:
        return 0.0
    if cell_voltage >= OCV_TABLE_V[-1]:
        return 100.0
    for i in range(len(OCV_TABLE_V) - 1):
        v0, v1 = OCV_TABLE_V[i], OCV_TABLE_V[i + 1]
        if v0 <= cell_voltage <= v1:
            s0, s1 = OCV_TABLE_SOC[i], OCV_TABLE_SOC[i + 1]
            return s0 + (s1 - s0) * (cell_voltage - v0) / (v1 - v0)
    return 100.0  # unreachable, keeps type checkers happy


def soc_to_ocv(soc_pct: float) -> float:
    """Inverse lookup used by the simulator (SOC % -> per-cell OCV)."""
    soc = min(max(soc_pct, 0.0), 100.0)
    for i in range(len(OCV_TABLE_SOC) - 1):
        s0, s1 = OCV_TABLE_SOC[i], OCV_TABLE_SOC[i + 1]
        if s0 <= soc <= s1:
            v0, v1 = OCV_TABLE_V[i], OCV_TABLE_V[i + 1]
            return v0 + (v1 - v0) * (soc - s0) / (s1 - s0)
    return OCV_TABLE_V[-1]


def estimate_soc(pack_voltage: float, current_a: float, series_cells: int,
                 pack_resistance_ohm: float) -> float:
    """
    Firmware SOC estimator: compensate the terminal voltage for the IR drop
    (V_ocv = V_term + I*R, I > 0 = discharge), divide by the cell count and
    look the per-cell OCV up in the table.
    """
    v_ocv = pack_voltage + current_a * pack_resistance_ohm
    return ocv_to_soc(v_ocv / series_cells)


def health_flags(pack_v: float, current_a: float, temp_c: float, soc_pct: float,
                 aux_v: float, series_cells: int, sensor_ok: bool = True,
                 th: Thresholds = DEFAULT_THRESHOLDS) -> int:
    """Bitmask exactly as computed by computeHealthFlags() in the firmware."""
    flags = 0
    if temp_c > th.temp_max_c:
        flags |= FLAG_OVER_TEMP
    if temp_c < th.temp_min_c:
        flags |= FLAG_UNDER_TEMP
    if soc_pct < th.soc_low_pct:
        flags |= FLAG_LOW_SOC
    if abs(current_a) > th.current_max_a:
        flags |= FLAG_OVER_CURRENT
    if pack_v > series_cells * th.cell_v_max:
        flags |= FLAG_OVER_VOLTAGE
    if pack_v < series_cells * th.cell_v_min:
        flags |= FLAG_UNDER_VOLTAGE
    if aux_v < th.aux_low_v:
        flags |= FLAG_AUX_LOW
    if not sensor_ok:
        flags |= FLAG_SENSOR_FAULT
    return flags


def decode_flags(flags: int) -> list[str]:
    return [name for bit, name in FLAG_NAMES.items() if flags & bit]


@dataclass
class Telemetry:
    """One sample, in the order of ThingSpeak fields 1..8."""
    pack_voltage_v: float   # field1
    current_a: float        # field2 (+ discharge, - charge)
    temp_c: float           # field3
    soc_pct: float          # field4
    power_w: float          # field5
    aux_voltage_v: float    # field6
    health_flags: int       # field7
    state_code: int         # field8: 0 idle, 1 drive, 2 charge

    def to_fields(self) -> dict:
        return {
            "field1": round(self.pack_voltage_v, 3),
            "field2": round(self.current_a, 3),
            "field3": round(self.temp_c, 2),
            "field4": round(self.soc_pct, 1),
            "field5": round(self.power_w, 1),
            "field6": round(self.aux_voltage_v, 2),
            "field7": int(self.health_flags),
            "field8": int(self.state_code),
        }

    def as_dict(self) -> dict:
        return asdict(self)


STATE_NAMES = {0: "idle", 1: "drive", 2: "charge"}
