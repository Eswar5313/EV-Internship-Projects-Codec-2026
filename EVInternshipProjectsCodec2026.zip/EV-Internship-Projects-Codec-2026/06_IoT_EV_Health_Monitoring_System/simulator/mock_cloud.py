#!/usr/bin/env python3
"""
mock_cloud.py - a tiny local stand-in for the ThingSpeak REST API.

Implements just enough of ThingSpeak so the firmware / simulator and the
dashboard can be exercised end-to-end without internet access:

  GET|POST /update?api_key=KEY&field1=..&field8=..       -> entry_id (text)
  GET      /channels/<id>/feeds.json?results=N[&api_key=] -> {"channel":..,"feeds":[..]}
  GET      /channels/<id>/feeds/last.json                 -> last feed entry
  GET      /channels/<id>/fields/<n>.json?results=N       -> one field only
  GET      /                                              -> the dashboard (dashboard/index.html)
  GET      /health                                        -> {"ok": true, "entries": N}

Response shapes copy the real ThingSpeak JSON (created_at, entry_id,
field1..field8 as strings), so the dashboard works unchanged against
https://api.thingspeak.com - only the base URL differs.

    python simulator/mock_cloud.py --port 5000 --write-key DEMOKEY --channel 1

Feeds are kept in RAM (last --max-entries) and optionally mirrored to a CSV.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import threading
from collections import deque
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_from_directory

FIELDS = [f"field{i}" for i in range(1, 9)]
FIELD_NAMES = {
    "field1": "Pack voltage (V)", "field2": "Current (A)", "field3": "Pack temp (degC)",
    "field4": "SOC (%)", "field5": "Power (W)", "field6": "Aux 12V (V)",
    "field7": "Health flags", "field8": "State",
}


def create_app(write_key: str = "DEMOKEY", read_key: str = "", channel_id: int = 1,
               max_entries: int = 8000, csv_path: str | None = None,
               dashboard_dir: str | None = None) -> Flask:
    app = Flask(__name__, static_folder=None)
    store: deque = deque(maxlen=max_entries)
    lock = threading.Lock()
    counter = {"n": 0}
    dashboard_dir = dashboard_dir or str(Path(__file__).resolve().parent.parent / "dashboard")
    csv_fh = None
    csv_writer = None
    if csv_path:
        Path(csv_path).parent.mkdir(parents=True, exist_ok=True)
        csv_fh = open(csv_path, "a", newline="")
        csv_writer = csv.writer(csv_fh)
        if csv_fh.tell() == 0:
            csv_writer.writerow(["created_at", "entry_id", *FIELDS])

    app.config.update(WRITE_KEY=write_key, READ_KEY=read_key, CHANNEL_ID=channel_id, STORE=store)

    @app.after_request
    def cors(resp):
        # lets dashboard/index.html be opened straight from file:// as well
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    def _channel_meta():
        return {
            "id": channel_id, "name": "EV Health Monitor (mock)",
            "description": "Local ThingSpeak-compatible mock; all data simulated",
            **FIELD_NAMES,
            "created_at": "2026-09-01T00:00:00Z",
            "updated_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "last_entry_id": store[-1]["entry_id"] if store else 0,
        }

    @app.route("/update", methods=["GET", "POST"])
    def update():
        src = request.values
        key = src.get("api_key") or request.headers.get("X-THINGSPEAKAPIKEY", "")
        if key != write_key:
            return Response("0", status=401, mimetype="text/plain")  # ThingSpeak returns 0 on bad key
        entry = {}
        for f in FIELDS:
            v = src.get(f)
            entry[f] = None if v is None or v == "" else str(v)
        if all(v is None for v in entry.values()):
            return Response("0", status=400, mimetype="text/plain")
        with lock:
            counter["n"] += 1
            entry["entry_id"] = counter["n"]
            # ThingSpeak lets a writer supply created_at (ISO-8601); default is server time
            entry["created_at"] = src.get("created_at") or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            store.append(entry)
            if csv_writer:
                csv_writer.writerow([entry["created_at"], entry["entry_id"], *[entry[f] or "" for f in FIELDS]])
                csv_fh.flush()
        return Response(str(entry["entry_id"]), mimetype="text/plain")

    def _check_read():
        if read_key and request.args.get("api_key") != read_key:
            return jsonify({"error": "invalid read key"}), 401
        return None

    @app.route("/channels/<int:cid>/feeds.json")
    def feeds(cid):
        if cid != channel_id:
            return jsonify({"error": "channel not found"}), 404
        err = _check_read()
        if err:
            return err
        n = min(int(request.args.get("results", 100)), 8000)
        with lock:
            items = list(store)[-n:]
            meta = _channel_meta()
        return jsonify({"channel": meta, "feeds": items})

    @app.route("/channels/<int:cid>/feeds/last.json")
    def last(cid):
        if cid != channel_id:
            return jsonify({"error": "channel not found"}), 404
        err = _check_read()
        if err:
            return err
        with lock:
            return jsonify(store[-1] if store else {})

    @app.route("/channels/<int:cid>/fields/<int:fn>.json")
    def field(cid, fn):
        if cid != channel_id or not 1 <= fn <= 8:
            return jsonify({"error": "not found"}), 404
        err = _check_read()
        if err:
            return err
        n = min(int(request.args.get("results", 100)), 8000)
        with lock:
            items = [{"created_at": e["created_at"], "entry_id": e["entry_id"], f"field{fn}": e[f"field{fn}"]}
                     for e in list(store)[-n:]]
            meta = _channel_meta()
        return jsonify({"channel": meta, "feeds": items})

    @app.route("/health")
    def health():
        return jsonify({"ok": True, "entries": len(store), "channel": channel_id})

    @app.route("/")
    @app.route("/dashboard")
    def dashboard():
        return send_from_directory(dashboard_dir, "index.html")

    return app


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--write-key", default="DEMOKEY")
    ap.add_argument("--read-key", default="", help="if set, feeds.json requires ?api_key=")
    ap.add_argument("--channel", type=int, default=1)
    ap.add_argument("--csv", default="", help="mirror every accepted update to this CSV")
    ap.add_argument("--max-entries", type=int, default=8000)
    args = ap.parse_args(argv)
    app = create_app(args.write_key, args.read_key, args.channel, args.max_entries, args.csv or None)
    print(f"mock ThingSpeak on http://{args.host}:{args.port}  (write key {args.write_key}, channel {args.channel})")
    print(f"dashboard: http://{args.host}:{args.port}/   feeds: /channels/{args.channel}/feeds.json")
    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
