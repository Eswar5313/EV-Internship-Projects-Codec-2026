# Wiring - NodeMCU EV health monitor

All prices/estimates in `bom.csv`. Hardware was **not** assembled during the internship; this
is the intended wiring the firmware was written against.

| Signal | NodeMCU pin | GPIO | Peripheral pin | Notes |
|---|---|---|---|---|
| I2C SCL | D1 | GPIO5 | INA219 SCL | INA219 has on-board pull-ups |
| I2C SDA | D2 | GPIO4 | INA219 SDA | |
| 3V3 | 3V3 | - | INA219 VCC, DS18B20 VDD | INA219 works from 3.3 V |
| GND | GND | - | INA219 GND, DS18B20 GND, divider GND, pack negative | one common ground |
| OneWire | D4 | GPIO2 | DS18B20 DATA | 4.7 kohm pull-up to 3V3; D4 is also the on-board LED |
| Aux ADC | A0 | ADC0 | divider midpoint | 30 k (top, to +12 V) / 7.5 k (bottom, to GND) -> 16.5 V full scale |
| Pack + | - | - | INA219 VIN+ | INA219 VIN- goes to the load; bus voltage is measured at VIN- |
| Load + | - | - | INA219 VIN- | current flows VIN+ -> VIN- (positive = discharge) |

```
   pack +  ----- VIN+ [ INA219 ] VIN- ----- load / motor controller +
   pack -  ----------------------------------- load -  ---- GND (NodeMCU)
                     | SDA  SCL  VCC  GND
                     | D2   D1   3V3  GND

   +12 V aux ---[30k]---+---[7k5]--- GND        DS18B20: VDD 3V3, GND, DATA -> D4 (+4k7 to 3V3)
                        |
                       A0
```

## Scaling to a real 48 V / 72 V pack
* INA219 bus input is limited to 26 V. For a 13s (48 V) or 20s (72 V) pack use an **INA226** (36 V)
  with the pack voltage brought in through a divider, or better an **isolated** sensor
  (e.g. ACS758 Hall current sensor + isolated divider/ADC), because the NodeMCU ground must
  not float at pack potential. The firmware only needs `PACK_SERIES_CELLS`, the INA driver and
  `readAuxVoltage()` changed; SOC/flag logic is unchanged.
* The on-board 0.1 ohm shunt limits INA219 to 3.2 A; for tens of amps replace it with a
  50 A / 75 mV shunt and set `ina219.setCalibration_*` accordingly (or use the INA226).
* Keep the DS18B20 probe clamped to the hottest cell group with thermal tape; the pack case
  can be 5-10 degC cooler than the cells.
