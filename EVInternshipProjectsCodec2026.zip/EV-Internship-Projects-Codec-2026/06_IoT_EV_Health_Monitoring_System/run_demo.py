#!/usr/bin/env python3
"""
run_demo.py - one-command offline demo + results generator.

  1. starts simulator/mock_cloud.py on a free port
  2. runs simulator/ev_simulator.py against it (time-compressed)
  3. opens dashboard/index.html in headless Chromium (Playwright) and saves
     results/dashboard_live.png (desktop) and results/dashboard_mobile.png
  4. dumps results/sample_feed.json, results/telemetry.csv and
     results/telemetry_overview.png (matplotlib)

    python run_demo.py                 # ~40 s, everything under results/
    python run_demo.py --no-browser    # skip Playwright screenshots

Everything produced is SIMULATED data - no hardware was connected.
"""

from __future__ import annotations

import argparse
import csv
import json
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RES = ROOT / "results"
sys.path.insert(0, str(ROOT / "simulator"))


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_http(url: str, timeout: float = 15.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            urllib.request.urlopen(url, timeout=2).read()
            return
        except Exception:
            time.sleep(0.3)
    raise RuntimeError(f"{url} did not come up")


def overview_plot(csv_path: Path, png_path: Path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from pack_model import decode_flags

    rows = list(csv.DictReader(open(csv_path)))
    t = [float(r["t_s"]) / 60 for r in rows]
    g = lambda k: [float(r[k]) for r in rows]  # noqa: E731
    fig, ax = plt.subplots(4, 1, figsize=(11, 10), sharex=True)
    ax[0].plot(t, g("pack_voltage_v"), color="#0284c7"); ax[0].set_ylabel("Pack V")
    ax[1].plot(t, g("current_a"), color="#db2777"); ax[1].axhline(30, ls="--", c="r", lw=.8); ax[1].axhline(-30, ls="--", c="r", lw=.8)
    ax[1].set_ylabel("Current A\n(+ discharge)")
    ax[2].plot(t, g("temp_c"), color="#ea580c"); ax[2].axhline(45, ls="--", c="r", lw=.8); ax[2].set_ylabel("Temp degC")
    ax[3].plot(t, g("soc_true_pct"), color="#16a34a", label="true (coulomb count)")
    ax[3].plot(t, g("soc_est_pct"), color="#16a34a", ls=":", label="estimate (OCV lookup)")
    ax[3].axhline(20, ls="--", c="r", lw=.8); ax[3].set_ylabel("SOC %"); ax[3].legend(loc="upper right", fontsize=8)
    ax[3].set_xlabel("simulated vehicle time (min)")
    # shade states
    names = {0: "idle", 1: "drive", 2: "charge"}
    cols = {0: "#e2e8f0", 1: "#fde68a", 2: "#bbf7d0"}
    seen = set()
    for i in range(1, len(rows)):
        st = int(rows[i]["state"])
        for a in ax:
            a.axvspan(t[i - 1], t[i], color=cols[st], alpha=.35, lw=0, label=names[st] if st not in seen else None)
        seen.add(st)
    ax[0].legend(loc="upper right", fontsize=8, ncol=3)
    n_alerts = sum(1 for r in rows if int(r["health_flags"]))
    fig.suptitle(f"Simulated 48 V e-scooter pack telemetry ({len(rows)} samples, {n_alerts} with an active alert)\n"
                 "SIMULATED DATA - ev_simulator.py, seed 42 - no hardware measurement", fontsize=11)
    for a in ax:
        a.grid(alpha=.3)
    fig.tight_layout()
    fig.savefig(png_path, dpi=130)
    plt.close(fig)
    flags = {}
    for r in rows:
        for f in decode_flags(int(r["health_flags"])):
            flags[f] = flags.get(f, 0) + 1
    return {"samples": len(rows), "samples_with_alert": n_alerts, "alert_counts": flags,
            "soc_est_abs_err_mean": sum(abs(float(r["soc_est_pct"]) - float(r["soc_true_pct"])) for r in rows) / len(rows),
            "v_min": min(g("pack_voltage_v")), "v_max": max(g("pack_voltage_v")),
            "i_min": min(g("current_a")), "i_max": max(g("current_a")),
            "t_min": min(g("temp_c")), "t_max": max(g("temp_c"))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--samples", type=int, default=960, help="posts to make (each = 15 s x speed of vehicle time)")
    ap.add_argument("--interval", type=float, default=0.02, help="wall seconds between posts")
    ap.add_argument("--speed", type=float, default=750, help="vehicle-time compression")
    args = ap.parse_args()
    RES.mkdir(exist_ok=True)
    port = free_port()
    base = f"http://127.0.0.1:{port}"
    csv_path = RES / "telemetry.csv"

    cloud = subprocess.Popen([sys.executable, str(ROOT / "simulator/mock_cloud.py"), "--port", str(port),
                              "--write-key", "DEMOKEY", "--channel", "1"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        wait_http(base + "/health")
        print("mock cloud on", base)
        # interval*speed vehicle seconds per post: default 0.05*300 = 15 s of vehicle time per post
        sim = subprocess.run([sys.executable, str(ROOT / "simulator/ev_simulator.py"), "--url", base + "/update",
                              "--api-key", "DEMOKEY", "--interval", str(args.interval), "--speed", str(args.speed),
                              "--samples", str(args.samples), "--csv", str(csv_path), "--seed", "42", "--sim-timestamps"],
                             capture_output=True, text=True)
        print(sim.stdout.splitlines()[-1])
        feed = json.loads(urllib.request.urlopen(f"{base}/channels/1/feeds.json?results=100").read())
        feed["channel"]["description"] = "SIMULATED DATA from simulator/ev_simulator.py (seed 42) via mock_cloud.py - not a hardware measurement"
        (RES / "sample_feed.json").write_text(json.dumps(feed, indent=1))
        print("wrote sample_feed.json with", len(feed["feeds"]), "feeds")

        stats = overview_plot(csv_path, RES / "telemetry_overview.png")

        if not args.no_browser:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                b = p.chromium.launch()
                for name, vp in [("dashboard_live.png", {"width": 1366, "height": 900}),
                                 ("dashboard_mobile.png", {"width": 390, "height": 1400})]:
                    pg = b.new_page(viewport=vp, device_scale_factor=1)
                    pg.goto(f"{base}/?results=60&poll=2")
                    pg.wait_for_timeout(6000)
                    engine = pg.text_content("#engine")
                    status = pg.text_content("#status")
                    pg.screenshot(path=str(RES / name), full_page=True)
                    print(f"{name}: {engine} | {status}")
                    stats[f"screenshot_{name}"] = {"chart_engine": engine, "status": status}
                    pg.close()
                b.close()
        stats["note"] = "all values simulated (ev_simulator.py seed 42); dashboard screenshots taken against mock_cloud.py"
        (RES / "demo_summary.json").write_text(json.dumps(stats, indent=1))
        print(json.dumps(stats, indent=1))
    finally:
        cloud.terminate()


if __name__ == "__main__":
    main()
