"""Verification suite for the IoT EV health monitor (run: python -m pytest tests)."""
import json
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "simulator"))

import pack_model as pm  # noqa: E402
from ev_simulator import EVSimulator, PackConfig  # noqa: E402
from mock_cloud import create_app  # noqa: E402


# --------------------------------------------------------------------- SOC lookup
def test_soc_lookup_monotonic_and_bounded():
    prev = -1.0
    for mv in range(2800, 4400, 5):
        soc = pm.ocv_to_soc(mv / 1000.0)
        assert 0.0 <= soc <= 100.0
        assert soc >= prev, f"SOC not monotonic at {mv} mV"
        prev = soc
    assert pm.ocv_to_soc(3.0) == 0.0 and pm.ocv_to_soc(4.2) == 100.0
    assert pm.ocv_to_soc(2.5) == 0.0 and pm.ocv_to_soc(4.5) == 100.0


def test_soc_inverse_round_trip():
    for soc in [0, 7, 15, 33, 50, 64, 77, 88, 95, 100]:
        assert pm.ocv_to_soc(pm.soc_to_ocv(soc)) == pytest.approx(soc, abs=1e-6)


def test_ir_compensation_direction():
    """Under discharge the terminal voltage sags; compensation must raise SOC back."""
    v_rest = 13 * pm.soc_to_ocv(60)
    soc_rest = pm.estimate_soc(v_rest, 0.0, 13, 0.045)
    soc_loaded_raw = pm.ocv_to_soc((v_rest - 20 * 0.045) / 13)
    soc_loaded_comp = pm.estimate_soc(v_rest - 20 * 0.045, 20.0, 13, 0.045)
    assert soc_loaded_raw < soc_rest
    assert soc_loaded_comp == pytest.approx(soc_rest, abs=1e-6)


def test_ocv_table_matches_firmware():
    """The lookup table in the .ino must be byte-identical to pack_model.py."""
    ino = (ROOT / "firmware/nodemcu_ev_monitor/nodemcu_ev_monitor.ino").read_text()
    m = re.search(r"OCV_TABLE_V\[\]\s*=\s*\{([^}]*)\}", ino)
    fw_v = [float(x.strip().rstrip("f")) for x in m.group(1).split(",")]
    m = re.search(r"OCV_TABLE_SOC\[\]\s*=\s*\{([^}]*)\}", ino)
    fw_soc = [float(x.strip()) for x in m.group(1).split(",")]
    assert fw_v == pytest.approx(pm.OCV_TABLE_V)
    assert fw_soc == pytest.approx(pm.OCV_TABLE_SOC)
    for name in ["FLAG_OVER_TEMP", "FLAG_UNDER_TEMP", "FLAG_LOW_SOC", "FLAG_OVER_CURRENT",
                 "FLAG_OVER_VOLTAGE", "FLAG_UNDER_VOLTAGE", "FLAG_AUX_LOW", "FLAG_SENSOR_FAULT"]:
        m = re.search(rf"#define {name}\s+\(1 << (\d)\)", ino)
        assert m, name
        assert 1 << int(m.group(1)) == getattr(pm, name)


# --------------------------------------------------------------------- alert logic
def test_alert_flags():
    s = 13
    assert pm.health_flags(48.0, 5.0, 30.0, 60.0, 12.6, s) == 0
    assert pm.health_flags(48.0, 5.0, 46.0, 60.0, 12.6, s) & pm.FLAG_OVER_TEMP
    assert pm.health_flags(48.0, 5.0, -1.0, 60.0, 12.6, s) & pm.FLAG_UNDER_TEMP
    assert pm.health_flags(48.0, 5.0, 30.0, 19.9, 12.6, s) & pm.FLAG_LOW_SOC
    assert pm.health_flags(48.0, 31.0, 30.0, 60.0, 12.6, s) & pm.FLAG_OVER_CURRENT
    assert pm.health_flags(48.0, -31.0, 30.0, 60.0, 12.6, s) & pm.FLAG_OVER_CURRENT
    assert pm.health_flags(13 * 4.26, 0.0, 30.0, 100.0, 12.6, s) & pm.FLAG_OVER_VOLTAGE
    assert pm.health_flags(13 * 2.99, 0.0, 30.0, 0.0, 12.6, s) & pm.FLAG_UNDER_VOLTAGE
    assert pm.health_flags(48.0, 5.0, 30.0, 60.0, 11.7, s) & pm.FLAG_AUX_LOW
    assert pm.health_flags(48.0, 5.0, 30.0, 60.0, 12.6, s, sensor_ok=False) & pm.FLAG_SENSOR_FAULT
    multi = pm.health_flags(48.0, 35.0, 50.0, 10.0, 11.0, s)
    assert set(pm.decode_flags(multi)) == {"OVER_TEMP", "LOW_SOC", "OVER_CURRENT", "AUX_LOW"}


def test_thresholds_match_config_example():
    cfg = (ROOT / "firmware/nodemcu_ev_monitor/config.h.example").read_text()
    th = pm.DEFAULT_THRESHOLDS
    for macro, val in [("TEMP_MAX_C", th.temp_max_c), ("TEMP_MIN_C", th.temp_min_c), ("SOC_LOW_PCT", th.soc_low_pct),
                       ("CURRENT_MAX_A", th.current_max_a), ("CELL_V_MAX", th.cell_v_max),
                       ("CELL_V_MIN", th.cell_v_min), ("AUX_LOW_V", th.aux_low_v)]:
        m = re.search(rf"#define {macro}\s+([0-9.]+)f?", cfg)
        assert m and float(m.group(1)) == pytest.approx(val), macro


# --------------------------------------------------------------------- simulator
def test_simulator_values_in_physical_ranges():
    sim = EVSimulator(seed=7)
    c = PackConfig()
    states = set()
    for _ in range(6 * 3600):          # 6 simulated hours, 1 s steps
        s = sim.step(1.0)
        states.add(s.state_code)
        assert c.series_cells * 2.9 <= s.pack_voltage_v <= c.series_cells * 4.25
        assert -12.0 <= s.current_a <= 42.0
        assert 25.0 <= s.temp_c <= 60.0
        assert 0.0 <= s.soc_pct <= 100.0
        assert 10.0 <= s.aux_voltage_v <= 14.5
        assert s.power_w == pytest.approx(s.pack_voltage_v * s.current_a)
        assert 0 <= s.health_flags <= 255
        assert 0 <= sim.soc_true <= 100
    assert states == {0, 1, 2}, "simulator must visit idle, drive and charge"


def test_simulator_soc_estimate_tracks_truth():
    sim = EVSimulator(seed=3, sensor_noise=False)
    errs = []
    for _ in range(4 * 3600):
        s = sim.step(1.0)
        errs.append(abs(s.soc_pct - sim.soc_true))
    assert max(errs) < 1.0, "IR-compensated OCV estimate should match coulomb-counted truth without noise"


def test_simulator_deterministic_with_seed():
    a = [EVSimulator(seed=11).step(5.0).pack_voltage_v for _ in range(1)]
    b = [EVSimulator(seed=11).step(5.0).pack_voltage_v for _ in range(1)]
    assert a == b


def test_telemetry_field_mapping():
    t = pm.Telemetry(48.1234, -9.87654, 31.456, 55.55, -475.1, 12.345, 5, 2)
    fields = t.to_fields()
    assert list(fields) == [f"field{i}" for i in range(1, 9)]
    assert fields["field1"] == 48.123 and fields["field7"] == 5 and fields["field8"] == 2


# --------------------------------------------------------------------- mock cloud
@pytest.fixture
def client():
    app = create_app(write_key="TESTKEY", read_key="", channel_id=7, max_entries=50)
    app.testing = True
    return app.test_client()


def test_mock_cloud_round_trip(client):
    r = client.get("/update?api_key=TESTKEY&field1=48.2&field2=-5.1&field3=31.0&field4=72.5&field5=-245.8&field6=12.7&field7=0&field8=2")
    assert r.status_code == 200 and r.data.decode() == "1"
    r = client.post("/update", data={"api_key": "TESTKEY", "field1": "47.9", "field4": "70.0"})
    assert r.data.decode() == "2"
    j = client.get("/channels/7/feeds.json?results=10").get_json()
    assert j["channel"]["id"] == 7 and len(j["feeds"]) == 2
    assert j["feeds"][0]["field1"] == "48.2" and j["feeds"][0]["field8"] == "2"
    assert j["feeds"][1]["field2"] is None
    assert re.match(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ", j["feeds"][1]["created_at"])
    last = client.get("/channels/7/feeds/last.json").get_json()
    assert last["entry_id"] == 2
    fld = client.get("/channels/7/fields/4.json?results=1").get_json()
    assert fld["feeds"][0]["field4"] == "70.0" and "field1" not in fld["feeds"][0]


def test_mock_cloud_rejects_bad_key_and_channel(client):
    assert client.get("/update?api_key=WRONG&field1=1").status_code == 401
    assert client.get("/update?api_key=TESTKEY").status_code == 400
    assert client.get("/channels/99/feeds.json").status_code == 404
    assert client.get("/health").get_json()["ok"] is True


def test_mock_cloud_read_key_enforced():
    app = create_app(write_key="W", read_key="R", channel_id=1)
    app.testing = True
    c = app.test_client()
    c.get("/update?api_key=W&field1=1")
    assert c.get("/channels/1/feeds.json").status_code == 401
    assert c.get("/channels/1/feeds.json?api_key=R").status_code == 200


def test_mock_cloud_ring_buffer():
    app = create_app(write_key="W", channel_id=1, max_entries=5)
    app.testing = True
    c = app.test_client()
    for i in range(8):
        c.get(f"/update?api_key=W&field1={i}")
    feeds = c.get("/channels/1/feeds.json?results=100").get_json()["feeds"]
    assert [f["field1"] for f in feeds] == ["3", "4", "5", "6", "7"]
    assert feeds[-1]["entry_id"] == 8


def test_simulator_posts_to_mock_cloud(client, monkeypatch):
    """End-to-end: simulator sample -> /update -> feeds.json parses back to the same numbers."""
    import ev_simulator
    sample = EVSimulator(seed=5).step(15.0)

    def fake_urlopen(url, timeout=0):
        path = url.split("http://x", 1)[1]
        resp = client.get(path)

        class R:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def read(self):
                return resp.data
        return R()

    monkeypatch.setattr(ev_simulator.urllib.request, "urlopen", fake_urlopen)
    assert ev_simulator.post_update("http://x/update", "TESTKEY", sample) == "1"
    feed = client.get("/channels/7/feeds/last.json").get_json()
    assert float(feed["field1"]) == pytest.approx(sample.pack_voltage_v, abs=1e-3)
    assert int(feed["field7"]) == sample.health_flags


# --------------------------------------------------------------------- dashboard
def test_dashboard_polls_feeds_and_has_fallback():
    html = (ROOT / "dashboard/index.html").read_text()
    assert "feeds.json" in html and "class MiniChart" in html
    assert "OVER_TEMP" in html and "LOW_SOC" in html and "OVER_CURRENT" in html
    assert 'name="viewport"' in html


def test_sample_feed_file_declared_simulated():
    p = ROOT / "results/sample_feed.json"
    if not p.exists():
        pytest.skip("results not generated yet")
    j = json.loads(p.read_text())
    assert "simulated" in json.dumps(j["channel"]).lower()
    assert len(j["feeds"]) > 0
