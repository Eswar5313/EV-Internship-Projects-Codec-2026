# IoT-Based EV Health Monitoring System

**EV Internship Project 06 - Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026

> **Honesty note.** I did not have a NodeMCU, INA219 or DS18B20 available during the
> internship, so the hardware side of this project was **not run on a physical board**.
> What I deliver instead is (a) firmware that is *compile-checked* with `arduino-cli`
> against the official ESP8266 core, (b) a software simulator that plays the role of the
> vehicle and pushes the *identical* payload the firmware would push, (c) a local
> ThingSpeak-compatible mock cloud so the whole loop runs offline, and (d) the web/mobile
> dashboard, tested end-to-end in a headless browser. **Every number in `results/` is
> simulated.** Nothing in this folder is presented as a measurement from a real vehicle.

---

## 1. Overview

Task brief: *"Build a dashboard that shows real-time health data from an EV. Use NodeMCU or
Raspberry Pi with sensors (voltage, current, temp). Send data to a cloud platform
(ThingSpeak or Firebase). Display live data on a mobile/web dashboard."*

What I built:

| Layer | What | Where |
|---|---|---|
| Sensing node | ESP8266 NodeMCU firmware: INA219 (V, I over I2C), DS18B20 (temperature, OneWire), 12 V aux battery on A0 through a divider. Computes SOC (IR-compensated OCV lookup), power and an 8-bit health-flag mask. Uploads every 15 s to **ThingSpeak** (HTTP GET, fields 1-8) or **Firebase RTDB** (REST PUT/PATCH), selected with one `#define`. Wi-Fi auto-reconnect, sensor-fault flag, averaging of 1 s samples. | `firmware/nodemcu_ev_monitor/` |
| Sensing node (alt.) | Raspberry Pi version of the same node in Python (`smbus2` INA219 driver, `w1thermsensor`, ADS1115 for the aux voltage), same field map. | `firmware/raspberry_pi/` |
| Vehicle simulator | Seeded drive / charge / idle model of a 48 V 13s 30 Ah e-scooter pack; posts to any ThingSpeak-compatible `/update` URL. | `simulator/ev_simulator.py` |
| Mock cloud | Flask service exposing ThingSpeak's `/update`, `/channels/<id>/feeds.json`, `feeds/last.json`, `fields/<n>.json`, plus the dashboard on `/`. | `simulator/mock_cloud.py` |
| Shared logic | The OCV-SOC table, flag bits and thresholds in one Python module, unit-tested against the `.ino` text so firmware and simulator cannot drift apart. | `simulator/pack_model.py` |
| Dashboard | Single-file responsive HTML/JS: cards, SOC ring gauge, three rolling charts, alert banner, history table; polls `feeds.json` every 5 s. Chart.js from CDN with a **built-in canvas fallback** when the CDN is blocked. | `dashboard/index.html` |
| Demo runner | Starts mock cloud + simulator, screenshots the dashboard with Playwright, writes CSV/JSON/PNG results. | `run_demo.py` |

## 2. Architecture

```
  +---------------------- vehicle -----------------------+
  |  pack +  --VIN+[ INA219 ]VIN- -- motor controller     |
  |                |  I2C (D1/D2)                          |
  |  DS18B20 --OneWire(D4)--> +------------------+        |        HTTPS GET /update?api_key&field1..8   +------------------+
  |  12 V aux --30k/7k5--> A0 |  NodeMCU ESP8266 | -- Wi-Fi ----------------------------------------> |  ThingSpeak       |
  |                           |  1 s sampling    |        |    or  PUT/PATCH <path>.json?auth=          |  (or Firebase)    |
  |                           |  15 s average    |        |                                             +---------+--------+
  |                           |  SOC, flags      |        |                                                       | GET feeds.json every 5 s
  |                           +------------------+        |                                             +---------v--------+
  +-------------------------------------------------------+                                             | dashboard/       |
                                                                                                        | index.html       |
       software stand-ins used in this repo (no hardware):                                              | phone / laptop   |
       simulator/ev_simulator.py  ==>  simulator/mock_cloud.py  (same URLs as ThingSpeak)  ==>          +------------------+
```

ThingSpeak field map (identical in firmware, simulator, dashboard):

| field | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|---|---|---|---|---|---|---|---|---|
| meaning | pack V | current A (+ discharge) | pack temp degC | SOC % | power W | aux 12 V | health flags (bitmask) | state 0 idle / 1 drive / 2 charge |

Health-flag bits (field 7): `0 OVER_TEMP (>45 C)`, `1 UNDER_TEMP (<0 C)`, `2 LOW_SOC (<20 %)`,
`3 OVER_CURRENT (>30 A)`, `4 OVER_VOLTAGE (>4.25 V/cell)`, `5 UNDER_VOLTAGE (<3.0 V/cell)`,
`6 AUX_LOW (<11.8 V)`, `7 SENSOR_FAULT`. Thresholds live in `config.h` and `pack_model.Thresholds`
and a test asserts they match.

## 3. Hardware: wiring and bill of materials

Full table with a diagram and notes on scaling to a real 48 V/72 V pack: [`hardware/wiring.md`](hardware/wiring.md).

| Signal | NodeMCU | Peripheral | Note |
|---|---|---|---|
| I2C SCL / SDA | D1 / D2 | INA219 SCL / SDA | 3V3 supply, common GND |
| OneWire | D4 | DS18B20 DATA | 4.7 k pull-up to 3V3 |
| Aux ADC | A0 | 30 k / 7.5 k divider on the 12 V aux battery | 16.5 V full scale |
| Pack current | - | pack+ -> INA219 VIN+, VIN- -> load | positive = discharge |

BOM (from `hardware/bom.csv`; **all prices are Sept-2026 estimates**, +/-30 %):

| Item | Qty | Approx. INR |
|---|---|---|
| NodeMCU 1.0 ESP8266 | 1 | 350 |
| INA219 breakout | 1 | 180 |
| DS18B20 waterproof probe + 4.7 k | 1 | 122 |
| 30 k + 7.5 k 1 % resistors | 1 each | 4 |
| 6s 18650 bench pack with BMS | 1 | 1500 |
| 12 V aux battery (optional) | 1 | 600 |
| Breadboard, jumpers, USB cable, 5 V supply | 1 set | 250 |
| **Total (NodeMCU path)** | | **~3,000** |
| Raspberry Pi 4 + ADS1115 (alternative node only) | 1 | ~4,500 |

Important limit I found while writing the firmware: the INA219 accepts at most **26 V** on
its bus input and **3.2 A** through its on-board shunt. That is fine for a 6s bench pack
(the `PACK_SERIES_CELLS 6` default in `config.h.example`) but *not* for a real 48 V scooter
pack. `hardware/wiring.md` explains the INA226 / external-shunt / isolated-sensor route; the
simulator therefore models the real 13s pack while the firmware defaults to the bench pack.

## 4. Firmware (`firmware/nodemcu_ev_monitor/nodemcu_ev_monitor.ino`)

Flow: `setup()` -> init I2C/INA219 (32 V / 2 A calibration), OneWire/DS18B20 (11-bit),
Wi-Fi STA with auto-reconnect -> `loop()`:

1. every `SAMPLE_INTERVAL_MS` (1 s): read INA219 bus+shunt voltage and current, DS18B20
   temperature, A0 aux voltage; accumulate; mark `SENSOR_FAULT` if any read fails.
2. every `UPLOAD_INTERVAL_MS` (15 s, ThingSpeak's free-tier minimum): average the samples,
   `estimateSoc()` (V_ocv = V + I*R_pack, divide by cell count, 13-point OCV table with linear
   interpolation), `computeHealthFlags()`, derive state from the sign of the current,
   reconnect Wi-Fi if needed, then either
   * `uploadThingSpeak()` - `HTTPClient` GET over `WiFiClientSecure` (`setInsecure()`, 512-byte
     buffers to stay inside ESP8266 RAM); success = HTTP 200 and body != "0"; or
   * `uploadFirebase()` - `PUT <FIREBASE_PATH>/latest.json?auth=` with a JSON body that includes a
     server timestamp (`{".sv":"timestamp"}`) and `PATCH <FIREBASE_PATH>/history.json` keyed by
     chip-id + uptime so the history is append-only.
3. serial log of every sample/upload and free-heap for debugging.

Secrets and calibration are in `config.h` (copy `config.h.example`; git-ignored). Every macro has
a fallback so the sketch compiles even without `config.h`. `types.h` holds the two data structs
(a header is needed because the Arduino build inserts auto-generated prototypes above structs
defined in the `.ino`).

### Compile status (done in this repo, on 2 Sept 2026)

```
arduino-cli core install esp8266:esp8266 --additional-urls https://arduino.esp8266.com/stable/package_esp8266com_index.json
arduino-cli lib install "Adafruit INA219" OneWire DallasTemperature
arduino-cli compile --fqbn esp8266:esp8266:nodemcuv2 firmware/nodemcu_ev_monitor
```

| Variant | Core | Result |
|---|---|---|
| ThingSpeak (default) | esp8266:esp8266 **3.1.2**, Adafruit INA219 1.2.3, OneWire 2.3.8, DallasTemperature 4.0.6 | **compiles**, 370,332 B flash (35 %), 29,992 B RAM (37 %) |
| Firebase (`-DCLOUD_THINGSPEAK=0 -DCLOUD_FIREBASE=1`) | same | **compiles**, 370,444 B flash, 30,132 B RAM |

Zero warnings from the sketch with `--warnings all`. **Compiled != tested:** the board was never
flashed, so Wi-Fi/TLS behaviour, sensor calibration and INA219 sign conventions still need a
bench check (section 9).

### How to flash

1. Arduino IDE 2.x -> Preferences -> Additional boards URL: `https://arduino.esp8266.com/stable/package_esp8266com_index.json`; Boards Manager -> install *esp8266*.
2. Library Manager -> *Adafruit INA219*, *OneWire*, *DallasTemperature*.
3. `cp config.h.example config.h`, fill in SSID/password and the ThingSpeak **write** key (or Firebase host/secret and set `CLOUD_FIREBASE 1`).
4. Board *NodeMCU 1.0 (ESP-12E Module)*, 115200 baud, Upload. Or: `arduino-cli upload -p /dev/ttyUSB0 --fqbn esp8266:esp8266:nodemcuv2 firmware/nodemcu_ev_monitor`.
5. Open the serial monitor: you should see `[ina219] OK`, `[ds18b20] 1 sensor(s)`, `[wifi] connected` and then `[thingspeak] HTTP 200 entry_id=1` every 15 s.

To point the firmware at the local mock cloud instead of ThingSpeak: `THINGSPEAK_HOST "192.168.x.x"`, `THINGSPEAK_PORT 5000`, `THINGSPEAK_USE_TLS 0`.

### Raspberry Pi alternative

`firmware/raspberry_pi/ev_monitor_pi.py` - enable I2C and 1-Wire with `raspi-config`,
`pip install smbus2 w1thermsensor requests`, then
`python3 ev_monitor_pi.py --key <write key>`. `--fake` swaps the sensors for the simulator so
the script can be tried on any PC. Same SOC/flag code (it imports `pack_model.py`).

## 5. Running the simulator, mock cloud and dashboard

```bash
pip install -r requirements.txt
python simulator/mock_cloud.py --port 5000 --write-key DEMOKEY          # terminal 1
python simulator/ev_simulator.py --url http://127.0.0.1:5000/update \
       --api-key DEMOKEY --interval 2 --speed 30                          # terminal 2
# open http://127.0.0.1:5000/  (dashboard served by the mock) - or open dashboard/index.html directly
```

`--interval 15 --speed 1` reproduces the firmware timing exactly; `--speed 30` compresses a
2-hour drive/charge cycle into 4 minutes for demos. `--sim-timestamps` stamps posts with vehicle
time (ThingSpeak also accepts `created_at`).

**Switching to the real cloud = changing one URL**:
* simulator: `--url https://api.thingspeak.com/update --api-key <your write key>`
* dashboard: `index.html?api=https://api.thingspeak.com&channel=<id>&key=<read key>`
  (the read key is only needed for private channels). The JSON shape of the mock copies
  ThingSpeak's (`channel`, `feeds[]`, `created_at`, `entry_id`, `field1..8` as strings), so no
  dashboard code changes.

One-shot demo that regenerates everything under `results/` (about 60 s):

```bash
playwright install chromium      # once, only for the screenshots
python run_demo.py               # add --no-browser to skip screenshots
python -m pytest tests -q
```

The dashboard is a plain file - it works from a phone browser on the same Wi-Fi as the mock
(`http://<pc-ip>:5000/`) or from anywhere when pointed at ThingSpeak.

## 6. Results (all simulated - `run_demo.py`, seed 42)

4 simulated hours of a 13s 30 Ah pack, 960 uploads at 15 s vehicle-time spacing:

| Metric | Value |
|---|---|
| Samples uploaded / read back via `feeds.json` | 960 / 960 |
| Pack voltage range | 43.76 - 51.36 V |
| Current range | -10.1 A (charge) ... +37.5 A (acceleration burst) |
| Pack temperature range | 35.9 - 43.1 degC (ambient 35 degC) |
| SOC true (coulomb-counted) vs firmware estimate (OCV lookup), mean abs error | **0.23 %** |
| Samples with an active alert | 44 of 960 (28 OVER_CURRENT, 16 LOW_SOC) |
| States visited | idle, drive, charge (see shaded plot) |
| Dashboard status in headless Chromium | `LIVE`, all 3 charts populated, `chart: built-in fallback` (the Chart.js CDN was blocked in my sandbox - the fallback is exactly what an offline lab PC would see) |

Files: `results/telemetry.csv` (every sample incl. true SOC), `results/sample_feed.json`
(a real `feeds.json` response from the mock, channel description says *SIMULATED*),
`results/telemetry_overview.png`, `results/dashboard_live.png` (1366 px desktop),
`results/dashboard_mobile.png` (390 px phone), `results/demo_summary.json`.

![overview](results/telemetry_overview.png)
![dashboard](results/dashboard_live.png)

The SOC estimator error of 0.23 % is optimistic: the simulator's pack is the same model the
estimator assumes (known R, no hysteresis, no ageing). On a real pack an OCV lookup is only
trustworthy at rest; the number to expect while driving is a few percent, which is why the
firmware IR-compensates and averages over 15 s.

## 7. Tests (`python -m pytest tests` - 17 passed)

* SOC lookup monotonic and bounded on a 5 mV sweep; inverse lookup round-trips; IR
  compensation restores the rest SOC under load.
* The OCV table and flag bit numbers parsed **out of the `.ino` text** equal `pack_model.py`;
  thresholds in `config.h.example` equal `Thresholds()`.
* Alert logic: every flag individually and a multi-flag case.
* Simulator: 6 h run stays inside physical ranges, visits all three states, is seed-deterministic,
  noise-free estimate tracks the coulomb-counted truth within 1 %.
* Mock cloud: post -> `feeds.json` / `last.json` / `fields/<n>.json` round trip, ThingSpeak-style
  string fields and ISO timestamps, bad key -> 401, empty update -> 400, read-key enforcement,
  ring buffer; simulator `post_update()` end-to-end through the Flask test client.
* Dashboard file contains the poll URL, alert names, viewport meta and the fallback chart class.

## 8. Limitations

* **No hardware was tested.** Firmware is compile-verified only. Untested in particular:
  INA219 sign convention for the chosen VIN+/VIN- orientation, DS18B20 timing on D4 (shared
  with the on-board LED), ADC calibration (`AUX_ADC_CAL`), TLS handshake memory on the ESP8266
  (`setInsecure()` + 512 B buffers is the known-working recipe but I could not confirm it).
* `setInsecure()` skips certificate validation; for a deployment pin the ThingSpeak/Firebase
  certificate fingerprint.
* INA219 limits (26 V, 3.2 A) mean the default firmware configuration measures a 6s bench pack,
  not a road-going 48 V pack (see `hardware/wiring.md`).
* SOC from OCV alone is not a BMS-grade estimator; project 01 in this repository has the
  EKF that should replace it.
* ThingSpeak free tier: 1 update / 15 s, 3 M messages/year, 4 channels - fine for one vehicle.
* The simulator is a lumped, first-order model; it is meant to exercise the pipeline, not to
  predict a specific vehicle.

## 9. What I would do with the hardware

1. Bench: 6s pack + 2 A load, compare INA219 readings against a DMM, set `AUX_ADC_CAL`.
2. Verify uploads on the real ThingSpeak channel and the dashboard on a phone over 4G.
3. Swap INA219 for INA226 + 50 A shunt with an isolated supply, move to a 48 V scooter.
4. Add deep-sleep between uploads (ESP8266 `ESP.deepSleep`) for a battery-powered node.

## 10. References

* ThingSpeak REST API: https://www.mathworks.com/help/thingspeak/writedata.html and readdata.html
* Firebase Realtime Database REST API: https://firebase.google.com/docs/database/rest/save-data
* Adafruit INA219 guide and library: https://learn.adafruit.com/adafruit-ina219-current-sensor-breakout
* Maxim/Analog DS18B20 datasheet; Miles Burton DallasTemperature library
* ESP8266 Arduino core docs (WiFiClientSecure, HTTPClient): https://arduino-esp8266.readthedocs.io
* Plett, G. L., *Battery Management Systems, Vol. II* (OCV-SOC lookup and IR compensation background)
* Chart.js 4 docs: https://www.chartjs.org/docs/latest/
