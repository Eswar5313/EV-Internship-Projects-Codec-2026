#!/usr/bin/env python3
"""
ev_monitor_pi.py - Raspberry Pi alternative to the NodeMCU firmware.

Same sensors, same payload, same ThingSpeak field map:
  INA219  on I2C bus 1 (address 0x40)   -> pack voltage / current   (smbus2)
  DS18B20 on GPIO4 (w1-gpio overlay)     -> pack temperature        (w1thermsensor)
  ADS1115 on I2C (address 0x48, AIN0)    -> 12 V aux via divider   (the Pi has no ADC)

Run:   sudo raspi-config  -> enable I2C and 1-Wire
       pip install smbus2 w1thermsensor requests
       python3 ev_monitor_pi.py --key XXXX --url https://api.thingspeak.com/update
Test without sensors:  python3 ev_monitor_pi.py --fake --url http://127.0.0.1:5000/update

NOT run on real hardware during the internship - see README limitations.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

# reuse the exact SOC / flag logic shared with the firmware and the simulator
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "simulator"))
from pack_model import Telemetry, estimate_soc, health_flags  # noqa: E402

SERIES_CELLS = 6
PACK_R_OHM = 0.045
AUX_R1, AUX_R2 = 30000.0, 7500.0


class INA219:
    """Minimal INA219 driver (32 V / 2 A calibration, 0.1 ohm shunt) over smbus2."""
    REG_CONFIG, REG_SHUNT, REG_BUS, REG_POWER, REG_CURRENT, REG_CAL = range(6)

    def __init__(self, bus=1, addr=0x40):
        from smbus2 import SMBus
        self.bus, self.addr = SMBus(bus), addr
        self._w(self.REG_CAL, 4096)              # same as Adafruit setCalibration_32V_2A
        self._w(self.REG_CONFIG, 0x399F)         # 32 V, 320 mV PGA, 12-bit, continuous
        self.current_lsb_ma = 0.1

    def _w(self, reg, val):
        self.bus.write_i2c_block_data(self.addr, reg, [(val >> 8) & 0xFF, val & 0xFF])

    def _r(self, reg):
        hi, lo = self.bus.read_i2c_block_data(self.addr, reg, 2)
        v = (hi << 8) | lo
        return v - 65536 if v & 0x8000 else v

    def bus_voltage(self):
        return ((self._r(self.REG_BUS) >> 3) * 4) / 1000.0

    def shunt_voltage(self):
        return self._r(self.REG_SHUNT) * 0.01 / 1000.0

    def current(self):
        self._w(self.REG_CAL, 4096)
        return self._r(self.REG_CURRENT) * self.current_lsb_ma / 1000.0


class ADS1115:
    """Single-shot read of AIN0, +-4.096 V range."""

    def __init__(self, bus=1, addr=0x48):
        from smbus2 import SMBus
        self.bus, self.addr = SMBus(bus), addr

    def read_ain0(self):
        cfg = 0xC383  # start, AIN0/GND, +-4.096 V, single-shot, 128 SPS
        self.bus.write_i2c_block_data(self.addr, 1, [cfg >> 8, cfg & 0xFF])
        time.sleep(0.01)
        hi, lo = self.bus.read_i2c_block_data(self.addr, 0, 2)
        raw = (hi << 8) | lo
        raw = raw - 65536 if raw & 0x8000 else raw
        return raw * 4.096 / 32767.0


def read_real():
    ina = ADS = ds = None
    from w1thermsensor import W1ThermSensor
    ina, ads, ds = INA219(), ADS1115(), W1ThermSensor()
    while True:
        try:
            v = ina.bus_voltage() + ina.shunt_voltage()
            i = ina.current()
            t = ds.get_temperature()
            aux = ads.read_ain0() * (AUX_R1 + AUX_R2) / AUX_R2
            yield v, i, t, aux, True
        except Exception as exc:  # I2C / 1-wire glitch: flag it, keep going
            print("sensor error:", exc)
            yield 0.0, 0.0, 0.0, 0.0, False


def read_fake():
    from ev_simulator import EVSimulator
    sim = EVSimulator(seed=1)
    while True:
        s = sim.step(15.0)
        yield s.pack_voltage_v, s.current_a, s.temp_c, s.aux_voltage_v, True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="https://api.thingspeak.com/update")
    ap.add_argument("--key", default="XXXXXXXXXXXXXXXX")
    ap.add_argument("--interval", type=float, default=15.0)
    ap.add_argument("--fake", action="store_true", help="use the software simulator instead of sensors")
    args = ap.parse_args()
    import requests

    src = read_fake() if args.fake else read_real()
    for v, i, t, aux, ok in src:
        soc = estimate_soc(v, i, SERIES_CELLS, PACK_R_OHM)
        flags = health_flags(v, i, t, soc, aux, SERIES_CELLS, ok)
        state = 1 if i > 0.5 else 2 if i < -0.5 else 0
        tele = Telemetry(v, i, t, soc, v * i, aux, flags, state)
        try:
            r = requests.get(args.url, params={"api_key": args.key, **tele.to_fields()}, timeout=8)
            print(time.strftime("%H:%M:%S"), tele.to_fields(), "->", r.status_code, r.text.strip())
        except Exception as exc:
            print("upload failed:", exc)
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
