/*
 * nodemcu_ev_monitor.ino - IoT EV health monitor node (ESP8266 NodeMCU 1.0)
 *
 * EV Internship Project 06 - Codec Technologies India
 * Author: Eswar Mahalingam, September 2026
 *
 * Reads:   INA219   - pack bus voltage + current (I2C, D1=SCL, D2=SDA)
 *          DS18B20  - pack temperature (OneWire on D4)
 *          A0       - 12 V auxiliary battery through a 30k/7k5 divider
 * Derives: SOC (IR-compensated OCV lookup), power, 8-bit health flag mask
 * Sends:   ThingSpeak  HTTP(S) GET /update?api_key=..&field1..field8   every 15 s
 *      or  Firebase    HTTPS  PUT  <FIREBASE_PATH>.json  + PATCH /history.json
 * Robust:  Wi-Fi auto-reconnect, sensor-fault flag, uploads the average of the
 *          1 s samples taken since the last upload (not a single noisy read).
 *
 * Field map (identical to simulator/pack_model.py and dashboard/index.html):
 *   field1 pack V   field2 current A (+ discharge)   field3 temp degC  field4 SOC %
 *   field5 power W  field6 aux 12 V                  field7 flags      field8 state
 *
 * Libraries (Arduino Library Manager): Adafruit INA219, OneWire, DallasTemperature.
 * Board: "NodeMCU 1.0 (ESP-12E Module)", core esp8266 >= 3.1.
 *
 * NOTE: this firmware has been compile-checked with arduino-cli but NOT run on
 * physical hardware during the internship (no board available) - see README.
 */

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Wire.h>
#include <Adafruit_INA219.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include "types.h"   // Sample / Payload structs (own header so the Arduino prototype generator sees them)

// ---------------------------------------------------------------------------
// Configuration: real secrets live in config.h (copied from config.h.example).
// Every macro has a fallback so the sketch still compiles without config.h.
// ---------------------------------------------------------------------------
#if __has_include("config.h")
#include "config.h"
#endif
#ifndef WIFI_SSID
#define WIFI_SSID "YourHotspotName"
#endif
#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD "YourHotspotPassword"
#endif
#ifndef CLOUD_THINGSPEAK
#define CLOUD_THINGSPEAK 1
#endif
#ifndef CLOUD_FIREBASE
#define CLOUD_FIREBASE 0
#endif
#if CLOUD_THINGSPEAK && CLOUD_FIREBASE
#error "Select only one cloud backend (CLOUD_THINGSPEAK or CLOUD_FIREBASE)"
#endif
#ifndef THINGSPEAK_HOST
#define THINGSPEAK_HOST "api.thingspeak.com"
#endif
#ifndef THINGSPEAK_PORT
#define THINGSPEAK_PORT 443
#endif
#ifndef THINGSPEAK_USE_TLS
#define THINGSPEAK_USE_TLS 1
#endif
#ifndef THINGSPEAK_WRITE_KEY
#define THINGSPEAK_WRITE_KEY "XXXXXXXXXXXXXXXX"
#endif
#ifndef FIREBASE_HOST
#define FIREBASE_HOST "your-project-default-rtdb.firebaseio.com"
#endif
#ifndef FIREBASE_AUTH
#define FIREBASE_AUTH "YOUR_DATABASE_SECRET"
#endif
#ifndef FIREBASE_PATH
#define FIREBASE_PATH "/ev/scooter01"
#endif
#ifndef UPLOAD_INTERVAL_MS
#define UPLOAD_INTERVAL_MS 15000UL
#endif
#ifndef SAMPLE_INTERVAL_MS
#define SAMPLE_INTERVAL_MS 1000UL
#endif
#ifndef PACK_SERIES_CELLS
#define PACK_SERIES_CELLS 6
#endif
#ifndef PACK_RESISTANCE_OHM
#define PACK_RESISTANCE_OHM 0.045f
#endif
#ifndef INA219_SHUNT_MODE
#define INA219_SHUNT_MODE 1
#endif
#ifndef AUX_DIVIDER_R1_OHM
#define AUX_DIVIDER_R1_OHM 30000.0f
#endif
#ifndef AUX_DIVIDER_R2_OHM
#define AUX_DIVIDER_R2_OHM 7500.0f
#endif
#ifndef AUX_ADC_CAL
#define AUX_ADC_CAL 1.0f
#endif
#ifndef TEMP_SENSOR_INDEX
#define TEMP_SENSOR_INDEX 0
#endif
#ifndef TEMP_MAX_C
#define TEMP_MAX_C 45.0f
#endif
#ifndef TEMP_MIN_C
#define TEMP_MIN_C 0.0f
#endif
#ifndef SOC_LOW_PCT
#define SOC_LOW_PCT 20.0f
#endif
#ifndef CURRENT_MAX_A
#define CURRENT_MAX_A 30.0f
#endif
#ifndef CELL_V_MAX
#define CELL_V_MAX 4.25f
#endif
#ifndef CELL_V_MIN
#define CELL_V_MIN 3.00f
#endif
#ifndef AUX_LOW_V
#define AUX_LOW_V 11.8f
#endif

// ---------------------------------------------------------------------------
// Pins (NodeMCU labels -> GPIO)
// ---------------------------------------------------------------------------
static const uint8_t PIN_ONEWIRE = D4;   // GPIO2, 4k7 pull-up to 3V3
static const uint8_t PIN_LED     = LED_BUILTIN;  // active LOW on NodeMCU
// I2C uses the default D1 (SCL, GPIO5) / D2 (SDA, GPIO4)

// ---------------------------------------------------------------------------
// Health-flag bits (field7) - keep identical to simulator/pack_model.py
// ---------------------------------------------------------------------------
#define FLAG_OVER_TEMP     (1 << 0)
#define FLAG_UNDER_TEMP    (1 << 1)
#define FLAG_LOW_SOC       (1 << 2)
#define FLAG_OVER_CURRENT  (1 << 3)
#define FLAG_OVER_VOLTAGE  (1 << 4)
#define FLAG_UNDER_VOLTAGE (1 << 5)
#define FLAG_AUX_LOW       (1 << 6)
#define FLAG_SENSOR_FAULT  (1 << 7)

// Vehicle state (field8): derived from current sign
#define STATE_IDLE   0
#define STATE_DRIVE  1
#define STATE_CHARGE 2

// ---------------------------------------------------------------------------
// OCV -> SOC lookup (per cell). Keep identical to pack_model.py OCV_TABLE_*.
// ---------------------------------------------------------------------------
static const float OCV_TABLE_V[]   = {3.00f, 3.30f, 3.45f, 3.55f, 3.60f, 3.65f, 3.70f, 3.75f, 3.82f, 3.90f, 4.00f, 4.10f, 4.20f};
static const float OCV_TABLE_SOC[] = {0,     5,     10,    20,    30,    40,    50,    60,    70,    80,    90,    95,    100};
static const uint8_t OCV_POINTS = sizeof(OCV_TABLE_V) / sizeof(OCV_TABLE_V[0]);

float ocvToSoc(float cellV) {
  if (cellV <= OCV_TABLE_V[0]) return 0.0f;
  if (cellV >= OCV_TABLE_V[OCV_POINTS - 1]) return 100.0f;
  for (uint8_t i = 0; i < OCV_POINTS - 1; i++) {
    float v0 = OCV_TABLE_V[i], v1 = OCV_TABLE_V[i + 1];
    if (cellV >= v0 && cellV <= v1) {
      return OCV_TABLE_SOC[i] + (OCV_TABLE_SOC[i + 1] - OCV_TABLE_SOC[i]) * (cellV - v0) / (v1 - v0);
    }
  }
  return 100.0f;
}

float estimateSoc(float packV, float currentA) {
  // IR compensation: V_ocv = V_term + I*R  (I > 0 = discharge)
  float vOcv = packV + currentA * PACK_RESISTANCE_OHM;
  return ocvToSoc(vOcv / PACK_SERIES_CELLS);
}

uint8_t computeHealthFlags(float packV, float currentA, float tempC, float socPct, float auxV, bool sensorOk) {
  uint8_t f = 0;
  if (tempC > TEMP_MAX_C) f |= FLAG_OVER_TEMP;
  if (tempC < TEMP_MIN_C) f |= FLAG_UNDER_TEMP;
  if (socPct < SOC_LOW_PCT) f |= FLAG_LOW_SOC;
  if (fabsf(currentA) > CURRENT_MAX_A) f |= FLAG_OVER_CURRENT;
  if (packV > PACK_SERIES_CELLS * CELL_V_MAX) f |= FLAG_OVER_VOLTAGE;
  if (packV < PACK_SERIES_CELLS * CELL_V_MIN) f |= FLAG_UNDER_VOLTAGE;
  if (auxV < AUX_LOW_V) f |= FLAG_AUX_LOW;
  if (!sensorOk) f |= FLAG_SENSOR_FAULT;
  return f;
}

// ---------------------------------------------------------------------------
// Sensors
// ---------------------------------------------------------------------------
Adafruit_INA219 ina219;          // default address 0x40
OneWire oneWire(PIN_ONEWIRE);
DallasTemperature ds18b20(&oneWire);
bool inaPresent = false;
bool dsPresent = false;

// Accumulators for the 15 s average
struct Accum {
  double packV = 0, currentA = 0, tempC = 0, auxV = 0;
  uint16_t n = 0;
  bool anyFault = false;
  void add(const Sample& s) {
    packV += s.packV; currentA += s.currentA; tempC += s.tempC; auxV += s.auxV; n++;
    if (!s.ok) anyFault = true;
  }
  void reset() { packV = currentA = tempC = auxV = 0; n = 0; anyFault = false; }
} accum;

float readAuxVoltage() {
  // NodeMCU A0: 0..3.3 V full scale = 0..1023 (on-board 220k/100k divider already included)
  const int raw = analogRead(A0);
  const float vAdc = raw * (3.3f / 1023.0f);
  return vAdc * (AUX_DIVIDER_R1_OHM + AUX_DIVIDER_R2_OHM) / AUX_DIVIDER_R2_OHM * AUX_ADC_CAL;
}

Sample readSensors() {
  Sample s = {0, 0, 0, 0, true};
  if (inaPresent) {
    s.packV = ina219.getBusVoltage_V() + ina219.getShuntVoltage_mV() / 1000.0f;  // load-side voltage
    s.currentA = ina219.getCurrent_mA() / 1000.0f;
    if (isnan(s.packV) || isnan(s.currentA) || s.packV < 0.5f) s.ok = false;
  } else {
    s.ok = false;
  }
  if (dsPresent) {
    ds18b20.requestTemperatures();
    float t = ds18b20.getTempCByIndex(TEMP_SENSOR_INDEX);
    if (t == DEVICE_DISCONNECTED_C || t < -50.0f || t > 125.0f) { s.ok = false; t = 0.0f; }
    s.tempC = t;
  } else {
    s.ok = false;
  }
  s.auxV = readAuxVoltage();
  return s;
}

// ---------------------------------------------------------------------------
// Wi-Fi
// ---------------------------------------------------------------------------
void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("[wifi] connecting to %s", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000UL) {
    delay(250);
    Serial.print('.');
    digitalWrite(PIN_LED, !digitalRead(PIN_LED));
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[wifi] connected, IP %s RSSI %d dBm\n", WiFi.localIP().toString().c_str(), WiFi.RSSI());
    digitalWrite(PIN_LED, HIGH);  // LED off
  } else {
    Serial.println("\n[wifi] FAILED - will retry on next upload");
  }
}

// ---------------------------------------------------------------------------
// Cloud upload
// ---------------------------------------------------------------------------
#if CLOUD_THINGSPEAK
bool uploadThingSpeak(const Payload& p) {
  String url;
  url.reserve(220);
  url += THINGSPEAK_USE_TLS ? "https://" : "http://";
  url += THINGSPEAK_HOST;
  url += ":" + String(THINGSPEAK_PORT);
  url += "/update?api_key=" THINGSPEAK_WRITE_KEY;
  url += "&field1=" + String(p.packV, 3);
  url += "&field2=" + String(p.currentA, 3);
  url += "&field3=" + String(p.tempC, 2);
  url += "&field4=" + String(p.socPct, 1);
  url += "&field5=" + String(p.powerW, 1);
  url += "&field6=" + String(p.auxV, 2);
  url += "&field7=" + String(p.flags);
  url += "&field8=" + String(p.state);

  HTTPClient http;
  int code;
  String body;
#if THINGSPEAK_USE_TLS
  WiFiClientSecure client;
  client.setInsecure();   // TODO: pin the ThingSpeak certificate fingerprint for production
  client.setBufferSizes(512, 512);  // keeps RAM usage small on the ESP8266
  if (!http.begin(client, url)) return false;
#else
  WiFiClient client;
  if (!http.begin(client, url)) return false;
#endif
  http.setTimeout(8000);
  code = http.GET();
  body = http.getString();
  http.end();
  Serial.printf("[thingspeak] HTTP %d entry_id=%s\n", code, body.c_str());
  // ThingSpeak answers 200 with the new entry id; "0" means rejected (bad key / rate limit)
  return code == 200 && body != "0";
}
#endif

#if CLOUD_FIREBASE
String payloadJson(const Payload& p) {
  String j;
  j.reserve(200);
  j += "{\"pack_v\":" + String(p.packV, 3);
  j += ",\"current_a\":" + String(p.currentA, 3);
  j += ",\"temp_c\":" + String(p.tempC, 2);
  j += ",\"soc_pct\":" + String(p.socPct, 1);
  j += ",\"power_w\":" + String(p.powerW, 1);
  j += ",\"aux_v\":" + String(p.auxV, 2);
  j += ",\"flags\":" + String(p.flags);
  j += ",\"state\":" + String(p.state);
  j += ",\"uptime_s\":" + String(millis() / 1000UL);
  j += ",\"ts\":{\".sv\":\"timestamp\"}";   // server-side timestamp
  j += "}";
  return j;
}

bool firebaseRequest(const char* method, const String& path, const String& body) {
  WiFiClientSecure client;
  client.setInsecure();   // TODO: pin certificate for production
  client.setBufferSizes(1024, 512);
  HTTPClient http;
  String url = String("https://") + FIREBASE_HOST + path + ".json?auth=" FIREBASE_AUTH;
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(8000);
  int code = http.sendRequest(method, body);
  Serial.printf("[firebase] %s %s -> HTTP %d\n", method, path.c_str(), code);
  http.end();
  return code == 200;
}

bool uploadFirebase(const Payload& p) {
  const String json = payloadJson(p);
  bool ok = firebaseRequest("PUT", String(FIREBASE_PATH) + "/latest", json);     // overwrite "latest"
  // append to history keyed by boot-time + uptime so the dashboard can chart it
  String key = String(ESP.getChipId(), HEX) + "_" + String(millis() / 1000UL);
  ok &= firebaseRequest("PATCH", String(FIREBASE_PATH) + "/history", "{\"" + key + "\":" + json + "}");
  return ok;
}
#endif

bool uploadPayload(const Payload& p) {
#if CLOUD_THINGSPEAK
  return uploadThingSpeak(p);
#elif CLOUD_FIREBASE
  return uploadFirebase(p);
#else
  (void)p;
  return false;
#endif
}

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------
uint32_t lastSampleMs = 0, lastUploadMs = 0;
uint32_t uploadsOk = 0, uploadsFailed = 0;

void setup() {
  Serial.begin(115200);
  delay(100);
  Serial.println("\n\n=== NodeMCU EV health monitor (Codec EV internship, E. Mahalingam) ===");
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, LOW);

  Wire.begin();  // D2 = SDA, D1 = SCL
  inaPresent = ina219.begin();
  if (inaPresent) {
#if INA219_SHUNT_MODE == 2
    ina219.setCalibration_32V_1A();
#else
    ina219.setCalibration_32V_2A();
#endif
    Serial.println("[ina219] OK");
  } else {
    Serial.println("[ina219] NOT FOUND at 0x40 - check wiring");
  }

  ds18b20.begin();
  dsPresent = ds18b20.getDeviceCount() > 0;
  ds18b20.setResolution(11);   // 0.125 degC, ~375 ms conversion
  Serial.printf("[ds18b20] %d sensor(s)\n", ds18b20.getDeviceCount());

  connectWiFi();
  lastUploadMs = millis();
}

void loop() {
  const uint32_t now = millis();

  if (now - lastSampleMs >= SAMPLE_INTERVAL_MS) {
    lastSampleMs = now;
    Sample s = readSensors();
    accum.add(s);
    Serial.printf("[sample] V=%.3f I=%.3f T=%.2f aux=%.2f ok=%d\n", s.packV, s.currentA, s.tempC, s.auxV, s.ok);
  }

  if (now - lastUploadMs >= UPLOAD_INTERVAL_MS) {
    lastUploadMs = now;
    if (accum.n == 0) return;

    Payload p;
    p.packV    = accum.packV / accum.n;
    p.currentA = accum.currentA / accum.n;
    p.tempC    = accum.tempC / accum.n;
    p.auxV     = accum.auxV / accum.n;
    p.socPct   = estimateSoc(p.packV, p.currentA);
    p.powerW   = p.packV * p.currentA;
    p.flags    = computeHealthFlags(p.packV, p.currentA, p.tempC, p.socPct, p.auxV, !accum.anyFault);
    p.state    = (p.currentA > 0.5f) ? STATE_DRIVE : (p.currentA < -0.5f) ? STATE_CHARGE : STATE_IDLE;
    accum.reset();

    Serial.printf("[upload] V=%.2f I=%.2f T=%.1f SOC=%.1f P=%.0f aux=%.2f flags=0x%02X state=%d\n",
                  p.packV, p.currentA, p.tempC, p.socPct, p.powerW, p.auxV, p.flags, p.state);

    connectWiFi();
    if (WiFi.status() == WL_CONNECTED) {
      digitalWrite(PIN_LED, LOW);
      if (uploadPayload(p)) uploadsOk++; else uploadsFailed++;
      digitalWrite(PIN_LED, HIGH);
    } else {
      uploadsFailed++;
    }
    Serial.printf("[stats] ok=%lu failed=%lu heap=%u\n", (unsigned long)uploadsOk, (unsigned long)uploadsFailed, ESP.getFreeHeap());
  }
  delay(10);
}
