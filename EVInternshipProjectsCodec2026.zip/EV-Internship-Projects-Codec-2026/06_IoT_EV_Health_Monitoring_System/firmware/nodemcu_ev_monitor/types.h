// types.h - plain data structs shared by the sketch functions.
// Kept in a header because the Arduino build inserts auto-generated function
// prototypes above any struct defined inside the .ino file.
#pragma once
#include <stdint.h>

struct Sample {
  float packV, currentA, tempC, auxV;
  bool ok;
};

struct Payload {
  float packV, currentA, tempC, socPct, powerW, auxV;
  uint8_t flags, state;
};
