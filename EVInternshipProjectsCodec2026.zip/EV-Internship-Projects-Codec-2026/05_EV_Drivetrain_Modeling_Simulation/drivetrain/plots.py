"""Matplotlib figures for the drivetrain study. Each function saves one PNG."""

from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from . import motors as mot  # noqa: E402

COLORS = {"PMSM": "#1f77b4", "IM": "#ff7f0e", "DC": "#2ca02c"}
plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 110})


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def efficiency_maps(motors: dict, out_dir: str) -> str:
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.6))
    levels = [0.5, 0.6, 0.7, 0.8, 0.85, 0.88, 0.9, 0.92, 0.94, 0.95, 0.96]
    for ax, (key, m) in zip(axes, motors.items()):
        W, T, eta = mot.efficiency_map(m)
        rpm = W / mot.RPM
        cf = ax.contourf(rpm, T, eta, levels=levels, cmap="viridis", extend="min")
        cs = ax.contour(rpm, T, eta, levels=levels, colors="k", linewidths=0.4)
        ax.clabel(cs, fmt="%.2f", fontsize=6)
        w = np.linspace(1, m.omega_max, 300)
        ax.plot(w / mot.RPM, mot.torque_limit(w, m), "r-", lw=1.5, label="torque envelope")
        ax.plot(m.omega_base / mot.RPM, m.t_max, "r*", ms=10, label=f"rated point, eta={mot.rated_point_efficiency(m):.3f}")
        ax.set(xlabel="speed (rpm)", ylabel="torque (Nm)", title=m.name, ylim=(0, m.t_max * 1.05))
        ax.legend(loc="upper right", fontsize=7)
        fig.colorbar(cf, ax=ax, label="efficiency (motoring)")
    return _save(fig, os.path.join(out_dir, "efficiency_maps.png"))


def drive_cycles(cycles: dict, out_dir: str) -> str:
    fig, axes = plt.subplots(len(cycles), 1, figsize=(12, 3.2 * len(cycles)))
    for ax, (key, c) in zip(np.atleast_1d(axes), cycles.items()):
        ax.plot(c.t, c.v * 3.6, lw=1)
        for i, (name, (a, b)) in enumerate(c.phases.items()):
            ax.axvspan(a, b, color=f"C{i}", alpha=0.08)
            ax.text((a + b) / 2, c.v.max() * 3.6 * 0.95, name, ha="center", fontsize=8)
        ax.set(title=f"{c.name}: {c.duration_s:.0f} s, {c.distance_m/1000:.2f} km, max {c.v.max()*3.6:.1f} km/h",
               xlabel="time (s)", ylabel="speed (km/h)")
    return _save(fig, os.path.join(out_dir, "drive_cycles.png"))


def cycle_traces(res: dict, out_dir: str, fname: str) -> str:
    tr = res["traces"]
    fig, axes = plt.subplots(4, 1, figsize=(12, 10), sharex=True)
    axes[0].plot(tr["t"], tr["v"] * 3.6, label="vehicle", lw=1)
    if res["mode"] == "forward":
        axes[0].plot(tr["t"], tr["v_ref"] * 3.6, "k--", lw=0.7, label="reference")
    axes[0].set(ylabel="speed (km/h)", title=f"{res['cycle']} - {res['motor']} motor ({res['mode']}-facing)")
    axes[0].legend(loc="upper left")
    axes[1].plot(tr["t"], tr["t_motor"], lw=0.8, color="C1")
    axes[1].set(ylabel="motor torque (Nm)")
    axes[2].plot(tr["t"], tr["p_wheel"] / 1e3, lw=0.8, label="wheel (motor path)")
    axes[2].plot(tr["t"], tr["p_batt_chem"] / 1e3, lw=0.8, label="battery (chemical)")
    axes[2].set(ylabel="power (kW)")
    axes[2].legend(loc="upper left")
    axes[3].stackplot(tr["t"], tr["p_batt_loss"] / 1e3, tr["p_inv_loss"] / 1e3, tr["p_motor_loss"] / 1e3,
                      tr["p_gb_loss"] / 1e3, labels=["battery", "inverter", "motor", "gearbox"], alpha=0.8)
    axes[3].set(ylabel="losses (kW)", xlabel="time (s)")
    axes[3].legend(loc="upper left", ncol=4)
    return _save(fig, os.path.join(out_dir, fname))


def energy_flow(results: dict, cycle_key: str, out_dir: str) -> str:
    """Sankey-style stacked bars: where the battery's chemical energy goes."""
    keys = list(results.keys())
    stages = [("E_batt_loss_Wh", "battery I^2R"), ("E_inv_loss_Wh", "inverter"), ("E_motor_loss_Wh", "motor"),
              ("E_gb_loss_Wh", "gearbox"), ("E_aux_Wh", "auxiliaries"), ("E_friction_brake_Wh", "friction brakes")]
    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(keys))
    bottom = np.zeros(len(keys))
    net_wheel = np.array([results[k]["E_wheel_traction_Wh"] - results[k]["E_wheel_regen_Wh"] for k in keys])
    ax.bar(x, net_wheel, color="#444", label="net wheel energy (traction - regen)")
    bottom += net_wheel
    for i, (kk, lab) in enumerate(stages):
        vals = np.array([results[k][kk] for k in keys])
        ax.bar(x, vals, bottom=bottom, label=lab, color=f"C{i}")
        bottom += vals
    for xi, k in zip(x, keys):
        ax.text(xi, bottom[xi] * 1.01, f"{results[k]['E_batt_chem_Wh']:.0f} Wh\n{results[k]['Wh_per_km']:.0f} Wh/km",
                ha="center", fontsize=8)
    ax.set(xticks=x, xticklabels=keys, ylabel="energy over cycle (Wh)",
           title=f"Energy flow battery -> wheels, {cycle_key} cycle (bar height = battery chemical energy + friction braking)")
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(1.0, 1.0))
    return _save(fig, os.path.join(out_dir, f"energy_flow_{cycle_key.lower()}.png"))


def gear_sweep(sweep: dict, base_ratio: float, out_dir: str) -> str:
    fig, ax1 = plt.subplots(figsize=(8, 4.5))
    r, t100, vt = sweep["ratio"], sweep["t_0_100_s"], sweep["v_top_kmh"]
    ok = np.isfinite(t100)
    ax1.plot(r[ok], t100[ok], "o-", color="C0", label="0-100 km/h time")
    if (~ok).any():
        ax1.plot(r[~ok], np.full((~ok).sum(), np.nanmax(t100[ok]) * 1.05), "x", color="C0", label="100 km/h unreachable")
    ax1.set(xlabel="gearbox ratio (-)", ylabel="0-100 km/h time (s)", title="Gear ratio trade-off (PMSM, 80 kW)")
    ax2 = ax1.twinx()
    ax2.plot(r, vt, "s-", color="C3", label="top speed")
    ax2.set_ylabel("top speed (km/h)")
    ax2.grid(False)
    ax1.axvline(base_ratio, color="k", ls="--", lw=0.8)
    ax1.text(base_ratio, ax1.get_ylim()[1] * 0.98, f" design ratio {base_ratio}", va="top", fontsize=8)
    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc="center right", fontsize=8)
    return _save(fig, os.path.join(out_dir, "gear_ratio_sweep.png"))


def motor_comparison(table: dict, out_dir: str) -> str:
    keys = list(table.keys())
    metrics = [("rated_point_eff", "rated-point eff."), ("motor_cycle_eff_WLTP", "cycle eff. WLTP"),
               ("motor_cycle_eff_MIDC", "cycle eff. MIDC")]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    x = np.arange(len(keys))
    w = 0.26
    for i, (mk, lab) in enumerate(metrics):
        vals = [table[k][mk] for k in keys]
        b = axes[0].bar(x + (i - 1) * w, vals, w, label=lab)
        axes[0].bar_label(b, fmt="%.3f", fontsize=7)
    axes[0].set(xticks=x, xticklabels=keys, ylabel="efficiency", ylim=(0.6, 1.0), title="Motor efficiency")
    axes[0].legend(fontsize=8)
    for i, ck in enumerate(["WLTP", "MIDC"]):
        vals = [table[k][f"Wh_per_km_{ck}"] for k in keys]
        b = axes[1].bar(x + (i - 0.5) * w, vals, w, label=ck)
        axes[1].bar_label(b, fmt="%.0f", fontsize=7)
        vals = [table[k][f"range_km_{ck}"] for k in keys]
        b = axes[2].bar(x + (i - 0.5) * w, vals, w, label=ck)
        axes[2].bar_label(b, fmt="%.0f", fontsize=7)
    axes[1].set(xticks=x, xticklabels=keys, ylabel="Wh/km (battery)", title="Consumption")
    axes[2].set(xticks=x, xticklabels=keys, ylabel="range (km), 36 kWh usable", title="Range")
    axes[1].legend(fontsize=8)
    axes[2].legend(fontsize=8)
    return _save(fig, os.path.join(out_dir, "motor_comparison.png"))


def inverter_efficiency(curves: dict, out_dir: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 4))
    for name, (load, eta) in curves.items():
        ax.plot(load * 100, eta * 100, label=name)
    ax.set(xlabel="load (% of rated output)", ylabel="inverter efficiency (%)", ylim=(85, 100),
           title="Inverter efficiency vs load (V_dc = 360 V, M = 1, cos phi = 0.9)")
    ax.legend()
    return _save(fig, os.path.join(out_dir, "inverter_efficiency.png"))


def forward_tracking(res: dict, out_dir: str) -> str:
    tr = res["traces"]
    fig, axes = plt.subplots(2, 1, figsize=(12, 6), sharex=True)
    axes[0].plot(tr["t"], tr["v_ref"] * 3.6, "k--", lw=0.8, label="reference")
    axes[0].plot(tr["t"], tr["v"] * 3.6, lw=0.8, label="PI driver")
    axes[0].set(ylabel="speed (km/h)", title=f"Forward-facing PI driver, {res['cycle']} - RMSE "
               f"{res['energy']['tracking_rmse_kmh']:.2f} km/h, max error {res['energy']['tracking_max_err_kmh']:.2f} km/h")
    axes[0].legend()
    axes[1].plot(tr["t"], (tr["v"] - tr["v_ref"]) * 3.6, lw=0.7)
    axes[1].set(ylabel="speed error (km/h)", xlabel="time (s)")
    return _save(fig, os.path.join(out_dir, "forward_tracking.png"))
