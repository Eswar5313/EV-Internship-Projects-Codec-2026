"""Power-electronics loss models (Simulink equivalent: 'Average-Value Inverter'
with conduction/switching loss tables).

Three-phase VSI (for PMSM / IM), sinusoidal PWM, per-switch average losses
(Infineon AN2008-03 "Thermal equivalent circuit models" / IGBT loss formulas):

    P_cond,sw = V0 I_pk (1/(2 pi) + M cos(phi)/8) + r I_pk^2 (1/8 + M cos(phi)/(3 pi))
    P_cond,d  = Vd0 I_pk (1/(2 pi) - M cos(phi)/8) + rd I_pk^2 (1/8 - M cos(phi)/(3 pi))
    P_sw      = f_sw (E_on + E_off + E_rr) / pi * (I_pk / I_ref) (V_dc / V_ref)
    P_inv     = 6 (P_cond,sw + P_cond,d + P_sw)

Two-quadrant DC chopper (brushed DC motor), duty D = V_arm / V_dc:

    P_cond = D (V0 I + r I^2) + (1-D)(Vd0 I + rd I^2)
    P_sw   = f_sw (E_on + E_off + E_rr) (I / I_ref)(V_dc / V_ref)
    P_chop = P_cond + P_sw                (one switch + one diode conduct per period)

Device data (datasheet values, 125 degC junction):
  * IGBT: Infineon FS400R07A3E3 (650 V, 400 A, HybridPACK): V_ce0 0.9 V,
    r_ce 2.7 mOhm, E_on+E_off = 27 mJ @ 300 V/400 A, diode V_f0 1.0 V, r_d 2.0 mOhm,
    E_rr 8 mJ. f_sw = 10 kHz.
  * SiC MOSFET: Wolfspeed CAB450M12XM3 (1200 V, 450 A): R_ds(on) 2.6 mOhm
    (used as V0 = 0, r = 3.5 mOhm hot), E_on+E_off = 8.5 mJ @ 600 V/400 A,
    body/SBD diode V_f0 1.5 V, r_d 3 mOhm, E_rr ~ 0.5 mJ. f_sw = 20 kHz.
  Values are rounded from the datasheets; exact figures depend on gate drive.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class InverterParams:
    name: str
    v0: float          # V, switch knee voltage
    r_on: float        # ohm, switch slope resistance
    vd0: float         # V, diode knee
    r_d: float         # ohm, diode slope
    e_sw: float        # J, E_on + E_off + E_rr per switching event at (i_ref, v_ref)
    i_ref: float       # A
    v_ref: float       # V
    f_sw: float        # Hz
    p_control: float = 40.0   # W, gate drive + control board (assumed)
    cos_phi: float = 0.90     # motor power factor at load (assumed)


def igbt_params() -> InverterParams:
    return InverterParams("IGBT (Si, FS400R07A3E3-class)", v0=0.9, r_on=2.7e-3, vd0=1.0, r_d=2.0e-3,
                          e_sw=35e-3, i_ref=400.0, v_ref=300.0, f_sw=10e3)


def sic_params() -> InverterParams:
    return InverterParams("SiC MOSFET (CAB450M12XM3-class)", v0=0.0, r_on=3.5e-3, vd0=1.5, r_d=3.0e-3,
                          e_sw=9.0e-3, i_ref=400.0, v_ref=600.0, f_sw=20e3)


def modulation_index(omega: np.ndarray, omega_base: float) -> np.ndarray:
    """Voltage rises linearly with speed up to base speed, then saturates (M = 1)."""
    return np.clip(np.abs(np.asarray(omega, dtype=float)) / omega_base, 0.05, 1.0)


def vsi_loss(i_pk: np.ndarray, v_dc: np.ndarray, m_idx: np.ndarray, p: InverterParams) -> np.ndarray:
    """Total loss (W) of a 3-phase two-level inverter."""
    i = np.abs(np.asarray(i_pk, dtype=float))
    mc = m_idx * p.cos_phi
    p_sw_cond = p.v0 * i * (1 / (2 * np.pi) + mc / 8) + p.r_on * i ** 2 * (1 / 8 + mc / (3 * np.pi))
    p_d_cond = p.vd0 * i * (1 / (2 * np.pi) - mc / 8) + p.r_d * i ** 2 * (1 / 8 - mc / (3 * np.pi))
    p_sw = p.f_sw * p.e_sw / np.pi * (i / p.i_ref) * (np.asarray(v_dc) / p.v_ref)
    return 6.0 * (p_sw_cond + np.maximum(p_d_cond, 0.0) + p_sw) + p.p_control


def chopper_loss(i_a: np.ndarray, v_dc: np.ndarray, duty: np.ndarray, p: InverterParams) -> np.ndarray:
    """Total loss (W) of a two-quadrant DC chopper feeding a brushed DC armature."""
    i = np.abs(np.asarray(i_a, dtype=float))
    d = np.clip(duty, 0.0, 1.0)
    p_cond = d * (p.v0 * i + p.r_on * i ** 2) + (1 - d) * (p.vd0 * i + p.r_d * i ** 2)
    p_sw = p.f_sw * p.e_sw * (i / p.i_ref) * (np.asarray(v_dc) / p.v_ref)
    return p_cond + p_sw + p.p_control


def efficiency_vs_load(p: InverterParams, v_dc: float = 360.0, i_max: float = 400.0, m_idx: float = 1.0,
                       v_ll_peak: float | None = None, n: int = 60):
    """Inverter efficiency as a function of output power fraction (VSI)."""
    i = np.linspace(0.02, 1.0, n) * i_max
    v_ph = (v_ll_peak if v_ll_peak else v_dc / 2) * m_idx          # peak phase voltage
    p_out = 1.5 * v_ph * i * p.cos_phi
    loss = vsi_loss(i, v_dc, m_idx, p)
    return p_out / p_out.max(), p_out / (p_out + loss)
