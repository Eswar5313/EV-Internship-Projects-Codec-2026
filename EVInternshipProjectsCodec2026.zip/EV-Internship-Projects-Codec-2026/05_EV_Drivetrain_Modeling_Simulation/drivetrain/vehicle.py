"""Longitudinal vehicle dynamics (Simulink equivalent: 'Vehicle Body' block).

    m_eff dv/dt = F_tractive - F_roll - F_aero - F_grade
    F_roll  = Crr m g cos(theta)
    F_aero  = 0.5 rho CdA v^2
    F_grade = m g sin(theta)

Parameter sources:
  * Mass, CdA, wheel radius: representative of a Nissan Leaf-class compact EV
    (kerb ~1 580 kg incl. 75 kg driver; Cd 0.28, A 2.27 m^2, 205/55R16 tyre).
  * Crr = 0.010: typical EV low-rolling-resistance tyre on asphalt
    (Larminie & Lowry, "Electric Vehicle Technology Explained", ch. 8).
  * Rotational-inertia mass factor 1.05: Ehsani et al., "Modern Electric, Hybrid
    Electric and Fuel Cell Vehicles", eq. 2.29 (assumed value for single-speed EV).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

G = 9.81  # m/s^2
RHO_AIR = 1.20  # kg/m^3, 20 degC sea level


@dataclass
class VehicleParams:
    mass: float = 1580.0          # kg, incl. driver
    crr: float = 0.010            # rolling resistance coefficient
    cd_a: float = 0.28 * 2.27     # m^2, drag coefficient x frontal area
    wheel_radius: float = 0.316   # m, 205/55R16 rolling radius
    mass_factor: float = 1.05     # rotational inertia factor
    mu_traction: float = 0.90     # tyre-road friction (dry asphalt, assumed)
    driven_axle_share: float = 0.55  # fraction of weight on driven (front) axle, assumed

    @property
    def m_eff(self) -> float:
        return self.mass * self.mass_factor

    @property
    def f_traction_limit(self) -> float:
        """Maximum force the driven tyres can transmit before slip (N)."""
        return self.mu_traction * self.driven_axle_share * self.mass * G


def resistive_force(v: np.ndarray, p: VehicleParams, grade_rad: float = 0.0) -> np.ndarray:
    """Road load F_roll + F_aero + F_grade for speed v (m/s). Rolling term
    switches sign with direction of travel and is zero at standstill."""
    v = np.asarray(v, dtype=float)
    f_roll = p.crr * p.mass * G * np.cos(grade_rad) * np.sign(v)
    f_aero = 0.5 * RHO_AIR * p.cd_a * v * np.abs(v)
    f_grade = p.mass * G * np.sin(grade_rad)
    return f_roll + f_aero + f_grade


def tractive_force_required(v: np.ndarray, a: np.ndarray, p: VehicleParams, grade_rad: float = 0.0) -> np.ndarray:
    """Force at the tyre contact patch needed to follow speed v with acceleration a."""
    return p.m_eff * np.asarray(a, dtype=float) + resistive_force(v, p, grade_rad)


def road_load_power(v: np.ndarray, p: VehicleParams, grade_rad: float = 0.0) -> np.ndarray:
    """Steady-state power at the wheels (W)."""
    return resistive_force(v, p, grade_rad) * np.asarray(v, dtype=float)
