"""Drivetrain simulation: backward-facing (quasi-static) energy calculation and
forward-facing PI-driver simulation, plus acceleration / top-speed analysis.

Simulink equivalence
--------------------
  backward_simulate : the "Drive Cycle Source -> Vehicle -> Gear -> Motor -> Inverter
                      -> Battery" signal chain evaluated with the cycle as the
                      *input* (like Simulink's quasi-static Powertrain Blockset
                      'Mapped' components).
  forward_simulate  : closed loop 'Longitudinal Driver' -> torque command ->
                      plant integration with a fixed-step (0.1 s) Euler solver,
                      i.e. what Simulink does with a 'Discrete' solver.

Sign convention: positive power = flow from battery towards the wheels.
Energy bookkeeping for every sample k:

    P_batt_chem = P_wheel(motor path) + P_gb_loss + P_motor_loss + P_inv_loss + P_aux + P_batt_loss

Regenerative braking (assumptions): the motor recovers braking force up to its
torque envelope; below 1.5 m/s regen is disabled (blending, typical of
production EVs) and the friction brakes dissipate the remainder.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

from . import battery as bat
from . import gearbox as gbx
from . import inverter as inv
from . import motors as mot
from . import vehicle as veh
from .cycles import DriveCycle
from .driver import DriverParams, PIDriver

V_TOP_DESIGN = 150.0 / 3.6      # m/s; gear ratio chosen so each motor's omega_max maps to 150 km/h
V_REGEN_CUTOFF = 1.5            # m/s


@dataclass
class Drivetrain:
    motor: mot.MotorParams
    inverter: inv.InverterParams = field(default_factory=inv.igbt_params)
    vehicle: veh.VehicleParams = field(default_factory=veh.VehicleParams)
    battery: bat.BatteryParams = field(default_factory=bat.BatteryParams)
    gearbox: gbx.GearboxParams | None = None
    soc0: float = 0.60

    def __post_init__(self):
        if self.gearbox is None:
            ratio = gbx.ratio_for_top_speed(self.motor.omega_max, self.vehicle.wheel_radius, V_TOP_DESIGN)
            self.gearbox = gbx.GearboxParams(ratio=round(ratio, 2))


def build(motor_key: str = "PMSM", inverter_key: str = "IGBT", **kw) -> Drivetrain:
    inverter = inv.igbt_params() if inverter_key.upper() == "IGBT" else inv.sic_params()
    return Drivetrain(motor=mot.ALL_MOTORS[motor_key](), inverter=inverter, **kw)


# --------------------------------------------------------------------------- torque split
def split_wheel_force(f_req: np.ndarray, v: np.ndarray, dt: Drivetrain):
    """Split the required tyre force into motor-path force and friction-brake force,
    respecting the motor envelope.  Returns (T_motor, F_motor_wheel, F_brake, violation)."""
    gb, p = dt.gearbox, dt.vehicle
    omega = gbx.motor_speed(v, gb, p.wheel_radius)
    t_lim = mot.torque_limit(omega, dt.motor)
    t_req = gbx.motor_torque_from_wheel(f_req * p.wheel_radius, gb)
    t_motor = np.clip(t_req, -t_lim, t_lim)
    t_motor = np.where((t_motor < 0) & (v < V_REGEN_CUTOFF), 0.0, t_motor)
    f_motor_wheel = gbx.wheel_torque_from_motor(t_motor, gb) / p.wheel_radius
    f_brake = np.minimum(f_req - f_motor_wheel, 0.0)         # friction brakes only ever retard
    violation = t_req > t_lim + 1e-9                         # traction demand exceeded the motor
    return t_motor, f_motor_wheel, f_brake, violation


# --------------------------------------------------------------------------- component chain
def evaluate_chain(v: np.ndarray, t_motor: np.ndarray, dt_s: float, dt: Drivetrain) -> Dict[str, np.ndarray]:
    """Evaluate every component for the (speed, motor torque) trajectory.  Vectorised
    except for the battery SOC integration (sequential by nature)."""
    m, gb, p = dt.motor, dt.gearbox, dt.vehicle
    omega = gbx.motor_speed(v, gb, p.wheel_radius)
    p_motor_mech = t_motor * omega
    p_gb_loss = gbx.gearbox_loss(t_motor, omega, gb)
    p_wheel = p_motor_mech - p_gb_loss          # motor-path power at the tyre (loss always subtracts)
    ml = mot.losses(t_motor, omega, m)
    p_motor_loss = sum(ml.values())
    p_motor_elec = p_motor_mech + p_motor_loss
    i_pk = mot.phase_current_peak(t_motor, omega, m)

    # DC-bus voltage: nominal at SOC0 (the drop with SOC over one cycle is < 5 %)
    v_dc = dt.battery.ocv(dt.soc0)
    if m.kind == "DC":
        phi = mot.flux_ratio(omega, m)
        v_arm = m.kt * phi * omega + np.sign(t_motor) * (i_pk * m.r_ph + m.extra["v_brush"])
        p_inv_loss = inv.chopper_loss(i_pk, v_dc, np.abs(v_arm) / v_dc, dt.inverter)
    else:
        p_inv_loss = inv.vsi_loss(i_pk, v_dc, inv.modulation_index(omega, m.omega_base), dt.inverter)
    p_inv_loss = np.where(i_pk < 1e-6, dt.inverter.p_control, p_inv_loss)
    p_dc = p_motor_elec + p_inv_loss + dt.battery.p_aux

    # battery, sequential
    n = len(v)
    i_batt, v_term, p_batt_loss, soc = np.zeros(n), np.zeros(n), np.zeros(n), np.zeros(n)
    s = dt.soc0
    q_pack_as = dt.battery.e_nominal_wh * 3600.0 / dt.battery.ocv(0.5)   # coulomb capacity, As
    for k in range(n):
        voc = dt.battery.ocv(s)
        i, vt, pl = bat.pack_losses(p_dc[k], voc, dt.battery.r_pack)
        i_batt[k], v_term[k], p_batt_loss[k], soc[k] = i, vt, pl, s
        s -= i * dt_s / q_pack_as
    p_batt_chem = p_dc + p_batt_loss

    return {
        "v": v, "omega": omega, "t_motor": t_motor, "p_wheel": p_wheel, "p_motor_mech": p_motor_mech,
        "p_gb_loss": p_gb_loss, "p_motor_loss": p_motor_loss, "p_motor_elec": p_motor_elec,
        "p_inv_loss": p_inv_loss, "p_dc": p_dc, "p_batt_loss": p_batt_loss, "p_batt_chem": p_batt_chem,
        "p_aux": np.full(n, dt.battery.p_aux), "i_batt": i_batt, "v_term": v_term, "soc": soc,
        "i_pk": i_pk, **{f"p_motor_{k}": val for k, val in ml.items()},
    }


def energy_summary(tr: Dict[str, np.ndarray], dt_s: float, distance_m: float, dt: Drivetrain) -> Dict[str, float]:
    """Integrate the power traces into Wh and derive efficiencies / consumption."""
    wh = lambda p: float(np.sum(p) * dt_s / 3600.0)  # noqa: E731
    pos = lambda p: np.maximum(p, 0.0)               # noqa: E731
    motoring = tr["p_motor_mech"] > 0
    e = {
        "E_batt_chem_Wh": wh(tr["p_batt_chem"]),
        "E_batt_loss_Wh": wh(tr["p_batt_loss"]),
        "E_inv_loss_Wh": wh(tr["p_inv_loss"]),
        "E_motor_loss_Wh": wh(tr["p_motor_loss"]),
        "E_gb_loss_Wh": wh(tr["p_gb_loss"]),
        "E_aux_Wh": wh(tr["p_aux"]),
        "E_wheel_traction_Wh": wh(pos(tr["p_wheel"])),
        "E_wheel_regen_Wh": wh(pos(-tr["p_wheel"])),
        "E_motor_mech_motoring_Wh": wh(pos(tr["p_motor_mech"])),
        "E_motor_elec_motoring_Wh": wh(np.where(motoring, tr["p_motor_elec"], 0.0)),
        "E_batt_discharge_Wh": wh(pos(tr["p_batt_chem"])),
        "E_batt_charge_Wh": wh(pos(-tr["p_batt_chem"])),
    }
    for k in ("copper", "iron", "mechanical", "stray", "extra"):
        e[f"E_motor_{k}_Wh"] = wh(tr[f"p_motor_{k}"])
    e["distance_km"] = distance_m / 1000.0
    e["Wh_per_km"] = e["E_batt_chem_Wh"] / e["distance_km"]
    e["range_km"] = dt.battery.e_nominal_wh * dt.battery.usable_fraction / e["Wh_per_km"]
    e["motor_cycle_eff"] = e["E_motor_mech_motoring_Wh"] / e["E_motor_elec_motoring_Wh"]
    e["drivetrain_cycle_eff"] = e["E_wheel_traction_Wh"] / e["E_batt_discharge_Wh"]
    e["regen_fraction"] = e["E_wheel_regen_Wh"] / max(e["E_wheel_traction_Wh"], 1e-9)
    # energy-balance residual (should be ~0)
    e["balance_residual_Wh"] = e["E_batt_chem_Wh"] - (
        e["E_wheel_traction_Wh"] - e["E_wheel_regen_Wh"] + e["E_gb_loss_Wh"] + e["E_motor_loss_Wh"]
        + e["E_inv_loss_Wh"] + e["E_aux_Wh"] + e["E_batt_loss_Wh"])
    return e


# --------------------------------------------------------------------------- backward
def backward_simulate(cycle: DriveCycle, dt: Drivetrain) -> Dict:
    v, a = cycle.v, cycle.accel
    dt_s = float(cycle.t[1] - cycle.t[0])
    f_req = veh.tractive_force_required(v, a, dt.vehicle)
    t_motor, f_mw, f_brake, viol = split_wheel_force(f_req, v, dt)
    tr = evaluate_chain(v, t_motor, dt_s, dt)
    tr.update({"t": cycle.t, "v_ref": v, "f_req": f_req, "f_brake": f_brake, "p_brake_loss": -f_brake * v})
    e = energy_summary(tr, dt_s, cycle.distance_m, dt)
    e["E_friction_brake_Wh"] = float(np.sum(tr["p_brake_loss"]) * dt_s / 3600)
    e["envelope_violations"] = int(np.sum(viol))
    e["gear_ratio"] = dt.gearbox.ratio
    return {"traces": tr, "energy": e, "cycle": cycle.name, "motor": dt.motor.kind, "mode": "backward"}


# --------------------------------------------------------------------------- forward
def forward_simulate(cycle: DriveCycle, dt: Drivetrain, dt_s: float = 0.1,
                     driver: DriverParams | None = None) -> Dict:
    p, gb, m = dt.vehicle, dt.gearbox, dt.motor
    t = np.arange(0.0, cycle.duration_s + 1e-9, dt_s)
    v_ref = np.interp(t, cycle.t, cycle.v)
    a_ref = np.gradient(v_ref, t)
    pid = PIDriver(driver)
    n = len(t)
    v = np.zeros(n)
    t_motor = np.zeros(n)
    f_brake = np.zeros(n)
    for k in range(n - 1):
        omega = gb.ratio * v[k] / p.wheel_radius
        t_lim = float(mot.torque_limit(omega, m))
        f_max = min(float(gbx.wheel_torque_from_motor(t_lim, gb)) / p.wheel_radius, p.f_traction_limit)
        f_min = -p.f_traction_limit
        f_res = float(veh.resistive_force(v[k], p))
        f_ff = p.m_eff * a_ref[k] + float(veh.resistive_force(v_ref[k], p))
        f_cmd = pid.step(v_ref[k], v[k], f_ff, dt_s, f_min, f_max)
        tm, fmw, fb, _ = split_wheel_force(np.array([f_cmd]), np.array([v[k]]), dt)
        t_motor[k], f_brake[k] = tm[0], fb[0]
        v[k + 1] = max(0.0, v[k] + dt_s * (fmw[0] + fb[0] - f_res) / p.m_eff)
    tr = evaluate_chain(v, t_motor, dt_s, dt)
    dist = float(np.trapezoid(v, t))
    tr.update({"t": t, "v_ref": v_ref, "f_brake": f_brake, "p_brake_loss": -f_brake * v})
    e = energy_summary(tr, dt_s, dist, dt)
    e["tracking_rmse_kmh"] = float(np.sqrt(np.mean((v - v_ref) ** 2)) * 3.6)
    e["tracking_max_err_kmh"] = float(np.max(np.abs(v - v_ref)) * 3.6)
    e["gear_ratio"] = gb.ratio
    return {"traces": tr, "energy": e, "cycle": cycle.name, "motor": m.kind, "mode": "forward"}


# --------------------------------------------------------------------------- performance
def accel_time(dt: Drivetrain, ratio: float | None = None, v_target: float = 100 / 3.6, dt_s: float = 0.01,
               t_max: float = 40.0) -> float:
    """0 -> v_target time (s) at full torque; inf if the target is unreachable."""
    p, m = dt.vehicle, dt.motor
    gb = gbx.GearboxParams(ratio or dt.gearbox.ratio, dt.gearbox.efficiency)
    v, t = 0.0, 0.0
    while v < v_target:
        omega = gb.ratio * v / p.wheel_radius
        if omega > m.omega_max or t > t_max:
            return float("inf")
        f = min(float(gbx.wheel_torque_from_motor(float(mot.torque_limit(omega, m)), gb)) / p.wheel_radius,
                p.f_traction_limit) - float(veh.resistive_force(v, p))
        if f <= 0:
            return float("inf")
        v += dt_s * f / p.m_eff
        t += dt_s
    return t


def top_speed(dt: Drivetrain, ratio: float | None = None) -> float:
    """Steady-state top speed (m/s): min(road-load balance, motor speed limit)."""
    p, m = dt.vehicle, dt.motor
    gb = gbx.GearboxParams(ratio or dt.gearbox.ratio, dt.gearbox.efficiency)
    v_lim = m.omega_max * p.wheel_radius / gb.ratio
    v = np.linspace(0.1, v_lim, 2000)
    omega = gb.ratio * v / p.wheel_radius
    f_avail = np.minimum(gbx.wheel_torque_from_motor(mot.torque_limit(omega, m), gb) / p.wheel_radius,
                         p.f_traction_limit)
    surplus = f_avail - veh.resistive_force(v, p)
    idx = np.where(surplus <= 0)[0]
    return float(v[idx[0]]) if len(idx) else float(v_lim)


def gear_ratio_sweep(dt: Drivetrain, ratios=np.arange(4.0, 14.01, 0.5)) -> Dict[str, np.ndarray]:
    return {"ratio": np.asarray(ratios),
            "t_0_100_s": np.array([accel_time(dt, r) for r in ratios]),
            "v_top_kmh": np.array([top_speed(dt, r) * 3.6 for r in ratios])}
