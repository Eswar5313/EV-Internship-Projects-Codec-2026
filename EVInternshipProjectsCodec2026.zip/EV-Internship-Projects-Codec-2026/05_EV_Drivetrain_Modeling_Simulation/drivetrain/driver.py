"""Driver model: PI speed follower (Simulink equivalent: 'Longitudinal Driver' block).

    e(t)      = v_ref(t) - v(t)
    F_cmd(t)  = Kp e + Ki integral(e)  + F_feedforward
    T_motor   = clip(F_cmd r / (g eta_gb), -T_lim, +T_lim)

Feed-forward of the road load (F_res(v_ref) + m_eff dv_ref/dt) means the PI
term only corrects modelling error, which keeps tracking tight with modest
gains.  Gains are tuned by hand (assumption): Kp = 800 N per (m/s),
Ki = 80 N per m, anti-windup by clamping the integrator when saturated.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DriverParams:
    kp: float = 800.0    # N/(m/s)
    ki: float = 80.0     # N/m
    use_feedforward: bool = True


class PIDriver:
    def __init__(self, p: DriverParams | None = None):
        self.p = p or DriverParams()
        self.integral = 0.0

    def reset(self):
        self.integral = 0.0

    def step(self, v_ref: float, v: float, f_ff: float, dt: float, f_min: float, f_max: float) -> float:
        e = v_ref - v
        f = self.p.kp * e + self.p.ki * self.integral + (f_ff if self.p.use_feedforward else 0.0)
        saturated = (f > f_max and e > 0) or (f < f_min and e < 0)
        if not saturated:
            self.integral += e * dt
        return min(max(f, f_min), f_max)
