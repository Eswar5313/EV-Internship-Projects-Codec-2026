"""Single-speed reduction gearbox (Simulink equivalent: 'Simple Gear' + loss).

    omega_motor = g * v / r_wheel
    T_wheel     = g * eta_gb * T_motor           (traction, T_motor > 0)
    T_wheel     = g / eta_gb * T_motor           (regeneration, T_motor < 0)

A constant mesh efficiency is used (two-stage helical reduction, 97 %;
Larminie & Lowry ch. 8 quote 95-98 % for EV single-speed reducers).
Gear ratio reference points: Nissan Leaf 8.19:1, Tesla Model 3 9.0:1.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class GearboxParams:
    ratio: float = 9.0      # overall reduction ratio (motor rev / wheel rev)
    efficiency: float = 0.97


def motor_speed(v: np.ndarray, gb: GearboxParams, wheel_radius: float) -> np.ndarray:
    """Motor angular speed (rad/s) for vehicle speed v (m/s)."""
    return gb.ratio * np.asarray(v, dtype=float) / wheel_radius


def motor_torque_from_wheel(t_wheel: np.ndarray, gb: GearboxParams) -> np.ndarray:
    """Motor torque needed to deliver wheel torque t_wheel (sign-aware losses)."""
    t_wheel = np.asarray(t_wheel, dtype=float)
    return np.where(t_wheel >= 0, t_wheel / (gb.ratio * gb.efficiency), t_wheel * gb.efficiency / gb.ratio)


def wheel_torque_from_motor(t_motor: np.ndarray, gb: GearboxParams) -> np.ndarray:
    """Wheel torque delivered by motor torque t_motor (sign-aware losses)."""
    t_motor = np.asarray(t_motor, dtype=float)
    return np.where(t_motor >= 0, t_motor * gb.ratio * gb.efficiency, t_motor * gb.ratio / gb.efficiency)


def gearbox_loss(t_motor: np.ndarray, omega_motor: np.ndarray, gb: GearboxParams) -> np.ndarray:
    """Power dissipated in the gears (W), always >= 0."""
    p_in = np.asarray(t_motor, dtype=float) * np.asarray(omega_motor, dtype=float)
    return np.abs(p_in) * (1.0 - gb.efficiency) * np.where(p_in >= 0, 1.0, 1.0 / gb.efficiency)


def ratio_for_top_speed(omega_max: float, wheel_radius: float, v_top: float) -> float:
    """Ratio that maps motor max speed to the design top speed v_top (m/s)."""
    return omega_max * wheel_radius / v_top
