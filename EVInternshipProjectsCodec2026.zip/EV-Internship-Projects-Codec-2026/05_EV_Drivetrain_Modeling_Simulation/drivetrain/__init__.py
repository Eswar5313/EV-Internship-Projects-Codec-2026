"""EV drivetrain modelling package (Python equivalent of a Simulink block model).

Blocks: cycles -> driver -> battery -> inverter -> motor -> gearbox -> vehicle.
Author: Eswar Mahalingam (EV internship, Codec Technologies India, Sept 2026)
"""

from . import battery, cycles, driver, gearbox, inverter, motors, simulate, vehicle  # noqa: F401

__all__ = ["battery", "cycles", "driver", "gearbox", "inverter", "motors", "simulate", "vehicle"]
