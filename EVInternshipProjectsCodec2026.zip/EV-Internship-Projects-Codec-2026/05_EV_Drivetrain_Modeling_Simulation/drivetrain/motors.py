"""Traction motor models: PMSM (AC), induction motor (AC) and brushed DC.

Simulink equivalent: 'Mapped Motor' / 'PMSM' / 'Induction Machine' / 'DC Machine'
blocks of Simscape Electrical, here reduced to a quasi-static torque-speed
envelope plus analytical loss models evaluated on (torque, speed) arrays.

All three machines are ~80 kW class.  Every loss is returned separately so
that energy conservation (P_elec = P_mech + sum losses) can be tested.

Common loss structure
---------------------
  copper     P_cu  = 1.5 R_ph I_pk^2   (3-phase, I_pk = peak phase current)   [AC]
             P_a   = R_a I_a^2                                             [DC]
  iron       P_fe  = (k_h w + k_e w^2) (phi/phi0)^2   (Steinmetz: hysteresis + eddy)
  mechanical P_mec = k_f w + k_w w^3                  (bearing friction + windage)
  stray      P_str = P_stray0 * (T/T_rated)^2         (IEC 60034-2-1 style)

Parameter sources (see README section 9)
  * PMSM sized on the Nissan Leaf EM57 motor: 80 kW, 280 Nm, 10 390 rpm max
    (Nissan press data; ORNL Leaf teardown report ORNL/TM-2013/...).
    Phase resistance / kt values are ASSUMED to reproduce ~95 % peak efficiency.
  * Induction motor: 80 kW / 250 Nm rated; rated slip 2.5 % (typical for a
    50-100 kW cage rotor, Chapman "Electric Machinery Fundamentals" ch. 6).
  * Brushed DC: separately-excited 80 kW; brush drop 2 V total (Chapman ch. 8),
    R_a, field power ASSUMED to reproduce ~90 % rated efficiency, max 6 500 rpm
    (commutator limited, typical of DC traction motors of this size).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

RPM = 2 * np.pi / 60.0


@dataclass
class MotorParams:
    name: str
    kind: str                 # "PMSM", "IM" or "DC"
    p_max: float              # W, continuous/peak power limit used here
    t_max: float              # Nm, maximum torque (constant-torque region)
    omega_max: float          # rad/s, maximum mechanical speed
    kt: float                 # Nm per A (peak phase current for AC, armature A for DC)
    r_ph: float               # ohm (phase-to-neutral for AC, armature for DC)
    k_h: float                # W/(rad/s) hysteresis coefficient
    k_e: float                # W/(rad/s)^2 eddy coefficient
    k_f: float                # W/(rad/s) friction
    k_w: float                # W/(rad/s)^3 windage
    p_stray0: float           # W stray load loss at rated torque
    extra: Dict[str, float] = field(default_factory=dict)
    mass_kg: float = 0.0
    cost_note: str = ""

    @property
    def omega_base(self) -> float:
        """Corner speed where the torque limit meets the power limit."""
        return self.p_max / self.t_max


def pmsm_params() -> MotorParams:
    return MotorParams(
        name="PMSM (AC, interior permanent magnet)", kind="PMSM",
        p_max=80e3, t_max=280.0, omega_max=10390 * RPM, kt=0.70, r_ph=0.012,
        k_h=1.5, k_e=0.007, k_f=0.3, k_w=1.0e-7, p_stray0=200.0,
        extra={"i_char": 250.0},   # A, characteristic (field-weakening) current, assumed
        mass_kg=58.0, cost_note="highest: NdFeB magnets, tight tolerances",
    )


def im_params() -> MotorParams:
    return MotorParams(
        name="Induction motor (AC, squirrel cage)", kind="IM",
        p_max=80e3, t_max=250.0, omega_max=12000 * RPM, kt=0.60, r_ph=0.010,
        k_h=1.3, k_e=0.006, k_f=0.3, k_w=1.0e-7, p_stray0=300.0,
        extra={"r_rotor": 0.008, "i_mag": 100.0, "s_rated": 0.025, "s_max": 0.20},
        mass_kg=70.0, cost_note="lowest: no magnets, copper/aluminium rotor",
    )


def dc_params() -> MotorParams:
    return MotorParams(
        name="Brushed DC (separately excited)", kind="DC",
        p_max=80e3, t_max=280.0, omega_max=6500 * RPM, kt=0.80, r_ph=0.030,
        k_h=1.5, k_e=0.012, k_f=1.0, k_w=1.5e-7, p_stray0=300.0,
        extra={"v_brush": 2.0, "p_field": 1500.0},
        mass_kg=110.0, cost_note="medium: simple drive, but commutator/brush maintenance",
    )


ALL_MOTORS = {"PMSM": pmsm_params, "IM": im_params, "DC": dc_params}


# --------------------------------------------------------------------------- envelope
def torque_limit(omega: np.ndarray, m: MotorParams) -> np.ndarray:
    """Maximum |torque| available at speed omega (constant torque then constant power)."""
    w = np.abs(np.asarray(omega, dtype=float))
    lim = np.minimum(m.t_max, m.p_max / np.maximum(w, 1e-6))
    return np.where(w > m.omega_max, 0.0, lim)


def flux_ratio(omega: np.ndarray, m: MotorParams) -> np.ndarray:
    """phi/phi0: full flux below base speed, 1/w field weakening above."""
    w = np.abs(np.asarray(omega, dtype=float))
    return np.minimum(1.0, m.omega_base / np.maximum(w, 1e-6))


# --------------------------------------------------------------------------- losses
def losses(torque: np.ndarray, omega: np.ndarray, m: MotorParams) -> Dict[str, np.ndarray]:
    """Loss breakdown (W, each >= 0) for operating points (torque, omega).

    Works for motoring and generating (|torque| used).  Returned keys are
    'copper', 'iron', 'mechanical', 'stray', 'extra' (rotor / field / brush)."""
    t = np.abs(np.asarray(torque, dtype=float))
    w = np.abs(np.asarray(omega, dtype=float))
    phi = flux_ratio(w, m)
    p_fe = (m.k_h * w + m.k_e * w ** 2) * phi ** 2
    p_mec = m.k_f * w + m.k_w * w ** 3
    p_str = m.p_stray0 * (t / m.t_max) ** 2

    if m.kind == "PMSM":
        i_q = t / (m.kt * phi)                                 # torque-producing current
        i_d = m.extra["i_char"] * (1.0 - phi)                 # field-weakening current
        i_pk = np.sqrt(i_q ** 2 + i_d ** 2)
        p_cu = 1.5 * m.r_ph * i_pk ** 2
        p_extra = np.zeros_like(p_cu)
    elif m.kind == "IM":
        i_q = t / (m.kt * phi)
        i_m = m.extra["i_mag"] * phi                           # magnetising current
        p_cu = 1.5 * m.r_ph * (i_q ** 2 + i_m ** 2)
        # slip: s = s_rated * (T/T_rated) / phi^2 (linear torque-slip region)
        s = np.minimum(m.extra["s_max"], m.extra["s_rated"] * (t / m.t_max) / phi ** 2)
        p_mech = t * w
        p_extra = s / (1.0 - s) * p_mech                       # rotor copper loss = s * P_airgap
    elif m.kind == "DC":
        i_a = t / (m.kt * phi)                                 # T = K phi I_a
        p_cu = m.r_ph * i_a ** 2
        active = ((w > 1.0) | (t > 1.0)).astype(float)          # field de-excited at standstill (assumed)
        p_extra = m.extra["v_brush"] * i_a + m.extra["p_field"] * phi ** 2 * active
    else:
        raise ValueError(m.kind)

    return {"copper": p_cu, "iron": p_fe, "mechanical": p_mec, "stray": p_str, "extra": p_extra}


def total_loss(torque, omega, m: MotorParams) -> np.ndarray:
    return sum(losses(torque, omega, m).values())


def electrical_power(torque, omega, m: MotorParams) -> np.ndarray:
    """DC-side power drawn by the motor (W). Positive = motoring, negative = generating."""
    return np.asarray(torque, dtype=float) * np.asarray(omega, dtype=float) + total_loss(torque, omega, m)


def phase_current_peak(torque, omega, m: MotorParams) -> np.ndarray:
    """Peak phase current (AC) or armature current (DC) for the inverter model."""
    t = np.abs(np.asarray(torque, dtype=float))
    phi = flux_ratio(omega, m)
    i_q = t / (m.kt * phi)
    if m.kind == "PMSM":
        return np.sqrt(i_q ** 2 + (m.extra["i_char"] * (1.0 - phi)) ** 2)
    if m.kind == "IM":
        return np.sqrt(i_q ** 2 + (m.extra["i_mag"] * phi) ** 2)
    return i_q


def efficiency_map(m: MotorParams, n_w: int = 120, n_t: int = 100):
    """Motoring efficiency eta = P_mech / P_elec on a (omega, torque) grid.
    Points outside the envelope are NaN."""
    w = np.linspace(0.02 * m.omega_max, m.omega_max, n_w)
    t = np.linspace(0.01 * m.t_max, m.t_max, n_t)
    W, T = np.meshgrid(w, t)
    p_mech = W * T
    eta = p_mech / (p_mech + total_loss(T, W, m))
    eta = np.where(T <= torque_limit(W, m), eta, np.nan)
    return W, T, eta


def rated_point_efficiency(m: MotorParams) -> float:
    """Efficiency at the rated (corner) point: T_max at omega_base."""
    w = m.omega_base
    return float(m.p_max / (m.p_max + total_loss(m.t_max, w, m)))
