"""Drive-cycle speed profiles (1 Hz).

IMPORTANT - these are SYNTHETIC APPROXIMATIONS.  The official second-by-second
tables (UNECE GTR 15 Annex 1 for WLTC class 3b; AIS-137 / MoRTH for the Indian
MIDC) are not bundled here.  The profiles below are piecewise-linear knot
sequences that reproduce the *phase structure, durations, maximum speeds and
approximate distances* of the real cycles:

  WLTC class 3b (GTR 15): Low 589 s / 56.5 km/h, Medium 433 s / 76.6 km/h,
     High 455 s / 97.4 km/h, Extra-high 323 s / 131.3 km/h; 1800 s, 23.27 km.
  MIDC (AIS-137 Part 2, the Indian passenger-car type-approval cycle): 4 x
     ECE-15 urban units (195 s, max 50 km/h) + extra-urban unit capped at
     90 km/h (400 s); 1180 s, 10.65 km.  (The 108 s "IDC" is the two/three-
     wheeler cycle and is not used here.)

Every knot list is (time_s, speed_kmh).  Speed between knots is linear, which
is also how the regulatory tables are defined.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class DriveCycle:
    name: str
    t: np.ndarray        # s
    v: np.ndarray        # m/s
    phases: dict         # name -> (t_start, t_end)

    @property
    def distance_m(self) -> float:
        return float(np.trapezoid(self.v, self.t))

    @property
    def duration_s(self) -> float:
        return float(self.t[-1])

    @property
    def accel(self) -> np.ndarray:
        return np.gradient(self.v, self.t)


def _from_knots(knots, dt: float = 1.0):
    tk = np.array([k[0] for k in knots], dtype=float)
    vk = np.array([k[1] for k in knots], dtype=float) / 3.6
    t = np.arange(0.0, tk[-1] + 1e-9, dt)
    return t, np.interp(t, tk, vk)


def _micro_trips(trips, t0=0.0):
    """Build knots from (t_accel, v_peak_kmh, t_cruise, t_decel, t_stop) tuples."""
    knots, t = [(t0, 0.0)], t0
    for ta, vp, tc, td, ts in trips:
        t += ta; knots.append((t, vp))
        t += tc; knots.append((t, vp))
        t += td; knots.append((t, 0.0))
        t += ts; knots.append((t, 0.0))
    return knots, t


def _shift(knots, t0):
    return [(t + t0, v) for t, v in knots]


def wltp_class3_like() -> DriveCycle:
    # (t_accel, v_peak km/h, t_cruise, t_decel, t_stop) - tuned so that each phase reproduces
    # the GTR 15 duration, maximum speed and distance to within a few percent
    low = [(8, 20, 6, 6, 14), (12, 35, 12, 10, 10), (10, 25, 10, 8, 18), (18, 56.5, 20, 20, 12),
           (12, 30, 15, 10, 8), (16, 45, 25, 16, 22), (10, 28, 18, 10, 8), (14, 42, 30, 16, 25),
           (10, 22, 10, 8, 20), (16, 50, 18, 18, 40)]
    med = [(18, 50, 25, 14, 6), (24, 76.6, 45, 24, 8), (14, 40, 15, 12, 10), (22, 65, 55, 24, 0),
           (20, 60, 40, 22, 35)]
    high = [(28, 80, 60, 20, 4), (26, 97.4, 70, 30, 6), (20, 70, 45, 18, 0), (22, 85, 35, 26, 45)]
    k_low, t1 = _micro_trips(low)
    k_med, t2 = _micro_trips(med, t1)
    k_high, t3 = _micro_trips(high, t2)
    kx = [(0, 0), (30, 80), (60, 80), (100, 110), (150, 110), (170, 95), (200, 95), (240, 131.3),
          (265, 131.3), (285, 120), (323, 0)]
    kx = _shift(kx, t3)
    knots = k_low + k_med[1:] + k_high[1:] + kx[1:]
    t, v = _from_knots(knots)
    phases = {"Low": (0, t1), "Medium": (t1, t2), "High": (t2, t3), "Extra-high": (t3, kx[-1][0])}
    return DriveCycle("WLTP-class-3-like (synthetic)", t, v, phases)


def midc_like() -> DriveCycle:
    """Modified Indian Driving Cycle: 4 x ECE-15 urban units (195 s, max 50 km/h) followed by
    the extra-urban unit capped at 90 km/h (400 s), 1180 s total (AIS-137 Part 2 / MoRTH)."""
    ece = [(0, 0), (11, 0), (15, 15), (23, 15), (28, 0), (49, 0), (61, 32), (85, 32), (96, 0),
           (117, 0), (143, 50), (155, 50), (163, 35), (176, 35), (188, 0), (195, 0)]
    knots = []
    for i in range(4):
        seg = _shift(ece, 195 * i)
        knots += seg if i == 0 else seg[1:]
    t_u = 780.0
    eudc = [(0, 0), (20, 0), (61, 70), (111, 70), (119, 50), (188, 50), (201, 70), (251, 70),
            (286, 90), (316, 90), (336, 90), (346, 90), (380, 0), (400, 0)]
    knots += _shift(eudc, t_u)[1:]
    t, v = _from_knots(knots)
    return DriveCycle("Indian MIDC-like (synthetic)", t, v, {"Urban (4 x ECE-15)": (0, t_u), "Extra-urban (90 km/h cap)": (t_u, t_u + 400)})


CYCLES = {"WLTP": wltp_class3_like, "MIDC": midc_like}
