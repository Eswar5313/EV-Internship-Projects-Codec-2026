"""Battery pack: internal-resistance (Rint) model for the DC bus.

    V_t = V_oc(SOC) - I R_int         (I > 0 = discharge)
    P_dc = V_t I  ->  I = (V_oc - sqrt(V_oc^2 - 4 R P_dc)) / (2 R)
    P_loss = I^2 R

Pack: 96s2p, 40 kWh class (Nissan Leaf 2018 pack: 96s2p, 350 V nominal,
R_pack ~ 60-90 mOhm from ORNL/ANL testing; 80 mOhm ASSUMED here).
OCV-SOC: 4-point linear table for an NMC cell (3.4 V @ 0 %, 3.6 V @ 20 %,
3.75 V @ 60 %, 4.1 V @ 100 %) - representative, not measured.
Usable energy for range: 90 % of nominal (typical BMS window, assumed).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class BatteryParams:
    n_series: int = 96
    n_parallel: int = 2
    e_nominal_wh: float = 40e3
    r_pack: float = 0.080        # ohm
    usable_fraction: float = 0.90
    p_aux: float = 300.0         # W, 12 V loads (lights, ECU, pumps), assumed, HVAC off

    def ocv(self, soc: float) -> float:
        soc_pts = [0.0, 0.2, 0.6, 1.0]
        v_pts = [3.4, 3.6, 3.75, 4.1]
        return self.n_series * float(np.interp(soc, soc_pts, v_pts))


def terminal_current(p_dc: np.ndarray, v_oc: float, r: float) -> np.ndarray:
    """Current (A) delivering DC-bus power p_dc (W, + = discharge) from an Rint source."""
    p = np.asarray(p_dc, dtype=float)
    disc = np.maximum(v_oc ** 2 - 4 * r * p, 0.0)
    return (v_oc - np.sqrt(disc)) / (2 * r)


def pack_losses(p_dc: np.ndarray, v_oc: float, r: float):
    """Returns (I, V_terminal, P_loss) for DC bus power p_dc."""
    i = terminal_current(p_dc, v_oc, r)
    return i, v_oc - i * r, i ** 2 * r
