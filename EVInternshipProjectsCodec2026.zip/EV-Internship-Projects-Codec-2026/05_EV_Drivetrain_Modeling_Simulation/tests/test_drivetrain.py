"""pytest suite for the drivetrain model.  Run with:  pytest -q"""

import numpy as np
import pytest

from drivetrain import battery as bat
from drivetrain import gearbox as gbx
from drivetrain import inverter as inv
from drivetrain import motors as mot
from drivetrain import simulate as S
from drivetrain import vehicle as veh


# ----------------------------------------------------------------- energy conservation
def test_energy_conservation_per_sample(backward_results):
    """P_batt_chem must equal wheel power + every loss + aux at every time step."""
    for r in backward_results.values():
        tr = r["traces"]
        rhs = tr["p_wheel"] + tr["p_gb_loss"] + tr["p_motor_loss"] + tr["p_inv_loss"] + tr["p_aux"] + tr["p_batt_loss"]
        np.testing.assert_allclose(tr["p_batt_chem"], rhs, rtol=1e-9, atol=1e-6)
        assert abs(r["energy"]["balance_residual_Wh"]) < 1e-6


def test_motor_electrical_power_is_mech_plus_losses():
    for key, fn in mot.ALL_MOTORS.items():
        m = fn()
        t = np.linspace(-m.t_max, m.t_max, 25)
        w = np.linspace(0, m.omega_max, 25)
        T, W = np.meshgrid(t, w)
        p_el = mot.electrical_power(T, W, m)
        np.testing.assert_allclose(p_el, T * W + mot.total_loss(T, W, m))


def test_forward_simulation_conserves_energy(wltp):
    r = S.forward_simulate(wltp, S.build("PMSM"))
    assert abs(r["energy"]["balance_residual_Wh"]) < 1e-6
    assert r["energy"]["tracking_rmse_kmh"] < 1.0


# ----------------------------------------------------------------- efficiencies in (0, 1]
def test_losses_non_negative_and_efficiency_in_unit_interval():
    for key, fn in mot.ALL_MOTORS.items():
        m = fn()
        W, T, eta = mot.efficiency_map(m)
        ok = np.isfinite(eta)
        assert ok.any()
        assert np.all(eta[ok] > 0) and np.all(eta[ok] <= 1)
        for name, l in mot.losses(T, W, m).items():
            assert np.all(l >= 0), (key, name)
        assert 0 < mot.rated_point_efficiency(m) <= 1


def test_cycle_efficiencies_in_unit_interval(backward_results):
    for r in backward_results.values():
        e = r["energy"]
        assert 0 < e["motor_cycle_eff"] <= 1
        assert 0 < e["drivetrain_cycle_eff"] <= 1


def test_inverter_efficiency_range():
    for p in (inv.igbt_params(), inv.sic_params()):
        load, eta = inv.efficiency_vs_load(p)
        assert np.all((eta > 0.9) & (eta < 1.0))


def test_gearbox_loss_sign_aware():
    gb = gbx.GearboxParams(9.0, 0.97)
    assert gbx.gearbox_loss(100.0, 300.0, gb) == pytest.approx(100 * 300 * 0.03)
    assert gbx.gearbox_loss(-100.0, 300.0, gb) == pytest.approx(100 * 300 * (1 / 0.97 - 1))
    # round trip: wheel -> motor -> wheel
    tw = np.array([500.0, -500.0])
    np.testing.assert_allclose(gbx.wheel_torque_from_motor(gbx.motor_torque_from_wheel(tw, gb), gb), tw)


# ----------------------------------------------------------------- AC vs DC ordering
def test_pmsm_more_efficient_than_brushed_dc(backward_results):
    assert backward_results["PMSM"]["energy"]["motor_cycle_eff"] > backward_results["DC"]["energy"]["motor_cycle_eff"]
    assert backward_results["PMSM"]["energy"]["Wh_per_km"] < backward_results["DC"]["energy"]["Wh_per_km"]
    assert mot.rated_point_efficiency(mot.pmsm_params()) > mot.rated_point_efficiency(mot.dc_params())


def test_pmsm_at_least_as_efficient_as_induction(backward_results):
    assert backward_results["PMSM"]["energy"]["motor_cycle_eff"] >= backward_results["IM"]["energy"]["motor_cycle_eff"]


# ----------------------------------------------------------------- gear ratio trade-off
def test_higher_gear_ratio_faster_0_100_but_lower_top_speed():
    dt = S.build("PMSM")
    t_low, t_high = S.accel_time(dt, 5.0), S.accel_time(dt, 8.0)
    v_low, v_high = S.top_speed(dt, 8.0), S.top_speed(dt, 12.0)
    assert t_high < t_low
    assert v_high < v_low


def test_top_speed_limited_by_motor_speed_at_design_ratio():
    dt = S.build("PMSM")
    assert S.top_speed(dt) * 3.6 == pytest.approx(150.0, abs=1.0)


# ----------------------------------------------------------------- steady state
def test_tractive_force_at_least_resistive_at_steady_state(backward_results):
    """Wherever the cycle cruises (|a| ~ 0, v > 0) the motor-path force must cover the road load."""
    r = backward_results["PMSM"]
    tr = r["traces"]
    p = veh.VehicleParams()
    a = np.gradient(tr["v"], tr["t"])
    cruise = (np.abs(a) < 1e-3) & (tr["v"] > 1.0)
    assert cruise.sum() > 50
    f_motor = tr["p_wheel"][cruise] / tr["v"][cruise]
    assert np.all(f_motor >= veh.resistive_force(tr["v"][cruise], p) - 1e-6)


def test_no_envelope_violations_on_cycles(backward_results, midc):
    for r in backward_results.values():
        assert r["energy"]["envelope_violations"] == 0
    for k in ("PMSM", "IM", "DC"):
        assert S.backward_simulate(midc, S.build(k))["energy"]["envelope_violations"] == 0


# ----------------------------------------------------------------- battery
def test_rint_battery_current_reproduces_power():
    v_oc, r = 360.0, 0.08
    for p in (-30e3, 0.0, 10e3, 60e3):
        i, vt, pl = bat.pack_losses(p, v_oc, r)
        assert vt * i == pytest.approx(p, rel=1e-9)
        assert pl >= 0


def test_torque_envelope():
    m = mot.pmsm_params()
    assert mot.torque_limit(0.0, m) == m.t_max
    assert mot.torque_limit(m.omega_base * 2, m) == pytest.approx(m.t_max / 2)
    assert mot.torque_limit(m.omega_max * 1.01, m) == 0.0
