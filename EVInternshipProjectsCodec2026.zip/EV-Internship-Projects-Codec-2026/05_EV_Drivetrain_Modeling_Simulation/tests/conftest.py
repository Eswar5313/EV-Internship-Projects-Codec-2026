import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


@pytest.fixture(scope="session")
def wltp():
    from drivetrain.cycles import wltp_class3_like
    return wltp_class3_like()


@pytest.fixture(scope="session")
def midc():
    from drivetrain.cycles import midc_like
    return midc_like()


@pytest.fixture(scope="session")
def backward_results(wltp):
    from drivetrain import simulate as S
    return {k: S.backward_simulate(wltp, S.build(k)) for k in ("PMSM", "IM", "DC")}
