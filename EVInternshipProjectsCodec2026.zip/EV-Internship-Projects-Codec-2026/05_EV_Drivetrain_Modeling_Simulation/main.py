"""EV drivetrain modelling and simulation - single entry point.

    python main.py          # regenerates everything in results/

Outputs (results/):
    efficiency_maps.png, drive_cycles.png, cycle_traces_wltp_{pmsm,im,dc}.png,
    cycle_traces_midc_pmsm.png, energy_flow_{wltp,midc}.png, gear_ratio_sweep.png,
    motor_comparison.png, inverter_efficiency.png, forward_tracking.png,
    summary.json, comparison_table.csv, wltp_pmsm_timeseries.csv

Author: Eswar Mahalingam (EV internship, Codec Technologies India, Sept 2026)
"""

from __future__ import annotations

import json
import os
import time

import numpy as np
import pandas as pd

from drivetrain import cycles as C
from drivetrain import inverter as inv
from drivetrain import motors as mot
from drivetrain import plots
from drivetrain import simulate as S

RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
MOTOR_KEYS = ["PMSM", "IM", "DC"]


def main() -> dict:
    t0 = time.time()
    os.makedirs(RESULTS, exist_ok=True)
    cycles = {k: f() for k, f in C.CYCLES.items()}
    motors = {k: mot.ALL_MOTORS[k]() for k in MOTOR_KEYS}
    drivetrains = {k: S.build(k) for k in MOTOR_KEYS}
    summary = {"vehicle": vars(drivetrains["PMSM"].vehicle), "battery": vars(drivetrains["PMSM"].battery),
               "inverter": drivetrains["PMSM"].inverter.name, "cycles": {}, "motors": {}, "comparison": {}}

    for ck, c in cycles.items():
        summary["cycles"][ck] = {"name": c.name, "duration_s": c.duration_s, "distance_km": c.distance_m / 1000,
                                 "v_max_kmh": float(c.v.max() * 3.6), "a_max_ms2": float(c.accel.max())}

    # ---- backward-facing energy simulation, every motor x every cycle
    backward = {ck: {} for ck in cycles}
    for mk, dt in drivetrains.items():
        m = dt.motor
        summary["motors"][mk] = {
            "name": m.name, "p_max_kW": m.p_max / 1e3, "t_max_Nm": m.t_max, "omega_max_rpm": m.omega_max / mot.RPM,
            "base_speed_rpm": m.omega_base / mot.RPM, "gear_ratio": dt.gearbox.ratio,
            "rated_point_eff": mot.rated_point_efficiency(m), "mass_kg": m.mass_kg, "cost_note": m.cost_note,
            "rated_point_losses_W": {k: float(v) for k, v in mot.losses(m.t_max, m.omega_base, m).items()},
            "t_0_100_s": S.accel_time(dt), "v_top_kmh": S.top_speed(dt) * 3.6,
        }
        for ck, c in cycles.items():
            r = S.backward_simulate(c, dt)
            backward[ck][mk] = r
            summary["motors"][mk][f"backward_{ck}"] = r["energy"]
            print(f"[backward] {ck:4s} {mk:4s}: {r['energy']['Wh_per_km']:6.1f} Wh/km, motor cycle eff "
                  f"{r['energy']['motor_cycle_eff']:.3f}, range {r['energy']['range_km']:.0f} km, "
                  f"residual {r['energy']['balance_residual_Wh']:.2e} Wh")

    # ---- forward-facing PI driver, WLTP, every motor
    forward = {}
    for mk, dt in drivetrains.items():
        f = S.forward_simulate(cycles["WLTP"], dt)
        forward[mk] = f
        summary["motors"][mk]["forward_WLTP"] = f["energy"]
        print(f"[forward ] WLTP {mk:4s}: {f['energy']['Wh_per_km']:6.1f} Wh/km, tracking RMSE "
              f"{f['energy']['tracking_rmse_kmh']:.3f} km/h")

    # ---- SiC inverter variant (PMSM, WLTP)
    dt_sic = S.build("PMSM", "SIC")
    r_sic = S.backward_simulate(cycles["WLTP"], dt_sic)
    summary["sic_variant_WLTP_PMSM"] = {"inverter": dt_sic.inverter.name, "Wh_per_km": r_sic["energy"]["Wh_per_km"],
                                        "E_inv_loss_Wh": r_sic["energy"]["E_inv_loss_Wh"],
                                        "E_inv_loss_Wh_IGBT": backward["WLTP"]["PMSM"]["energy"]["E_inv_loss_Wh"]}

    # ---- gear ratio sweep (PMSM)
    sweep = S.gear_ratio_sweep(drivetrains["PMSM"])
    summary["gear_ratio_sweep"] = {k: [None if not np.isfinite(x) else float(x) for x in v] for k, v in sweep.items()}

    # ---- comparison table
    table = {}
    for mk in MOTOR_KEYS:
        sm = summary["motors"][mk]
        table[mk] = {
            "motor": sm["name"], "type": "AC" if mk != "DC" else "DC", "rated_point_eff": sm["rated_point_eff"],
            "motor_cycle_eff_WLTP": sm["backward_WLTP"]["motor_cycle_eff"],
            "motor_cycle_eff_MIDC": sm["backward_MIDC"]["motor_cycle_eff"],
            "drivetrain_eff_WLTP": sm["backward_WLTP"]["drivetrain_cycle_eff"],
            "Wh_per_km_WLTP": sm["backward_WLTP"]["Wh_per_km"], "Wh_per_km_MIDC": sm["backward_MIDC"]["Wh_per_km"],
            "range_km_WLTP": sm["backward_WLTP"]["range_km"], "range_km_MIDC": sm["backward_MIDC"]["range_km"],
            "t_0_100_s": sm["t_0_100_s"], "v_top_kmh": sm["v_top_kmh"], "gear_ratio": sm["gear_ratio"],
            "mass_kg": sm["mass_kg"], "cost": sm["cost_note"],
        }
    summary["comparison"] = table
    pd.DataFrame(table).T.to_csv(os.path.join(RESULTS, "comparison_table.csv"))

    # ---- plots
    plots.efficiency_maps(motors, RESULTS)
    plots.drive_cycles(cycles, RESULTS)
    for mk in MOTOR_KEYS:
        plots.cycle_traces(backward["WLTP"][mk], RESULTS, f"cycle_traces_wltp_{mk.lower()}.png")
    plots.cycle_traces(backward["MIDC"]["PMSM"], RESULTS, "cycle_traces_midc_pmsm.png")
    for ck in cycles:
        plots.energy_flow({mk: backward[ck][mk]["energy"] for mk in MOTOR_KEYS}, ck, RESULTS)
    plots.gear_sweep(sweep, drivetrains["PMSM"].gearbox.ratio, RESULTS)
    plots.motor_comparison(table, RESULTS)
    plots.inverter_efficiency({inv.igbt_params().name: inv.efficiency_vs_load(inv.igbt_params()),
                               inv.sic_params().name: inv.efficiency_vs_load(inv.sic_params())}, RESULTS)
    plots.forward_tracking(forward["PMSM"], RESULTS)

    # ---- time series CSV
    tr = backward["WLTP"]["PMSM"]["traces"]
    cols = ["t", "v", "omega", "t_motor", "p_wheel", "p_motor_mech", "p_motor_loss", "p_inv_loss", "p_gb_loss",
            "p_batt_loss", "p_batt_chem", "i_batt", "v_term", "soc"]
    pd.DataFrame({c: tr[c] for c in cols}).to_csv(os.path.join(RESULTS, "wltp_pmsm_timeseries.csv"), index=False)

    summary["runtime_s"] = time.time() - t0
    with open(os.path.join(RESULTS, "summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2, default=float)
    print(f"done in {summary['runtime_s']:.1f} s -> {RESULTS}")
    return summary


if __name__ == "__main__":
    main()
