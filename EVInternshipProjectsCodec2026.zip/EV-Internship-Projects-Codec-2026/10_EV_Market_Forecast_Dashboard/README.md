# EV Market Forecast Dashboard

**Project 10 — EV internship, Codec Technologies India**
Author: Eswar Mahalingam · September 2026

> Brief: *"EV Market Forecast Dashboard — interactive dashboard to predict EV market growth. Use Python (Pandas, Plotly, Dash). Analyze global trends, government policies, and adoption rates. Visualize data with graphs, maps, and growth models."*

## 1. Overview

I built an interactive Dash dashboard that (a) shows how electric-car adoption has evolved since 2010 in 70+ countries and regions, (b) fits several growth models (logistic S-curve, Bass diffusion, CAGR, exponential, linear) to the EV sales-share series of World, China, Europe, USA and India and forecasts them to 2035, (c) maps the latest EV share by country, and (d) puts 20 real government policy decisions on a timeline so the forecasts can be read against the policy context.

All historical numbers are **real IEA data** downloaded programmatically from the API behind the IEA *Global EV Data Explorer* (Global EV Outlook 2026 edition, historical years 2010–2025). Nothing in the modelling inputs was typed in by hand. The policy register was hand-compiled, but every row has an official or trade-press source URL.

Key parts:

| Path | What it is |
|---|---|
| `src/app.py` | Dash app: tabs Overview / Forecast / Map / Policies / Data & Sources; region dropdown, model selector, horizon slider, policy-scenario slider, saturation-ceiling slider |
| `src/models.py` | Growth models fitted with `scipy.optimize.curve_fit`; writes `results/forecast_table.csv` and `results/model_params.json` |
| `src/figures.py` | All Plotly figures (stacked bars, forecast + band, choropleth, S-curve fits, policy timeline, country ranking, model comparison) |
| `src/load_data.py` | Single place that reads `data/*.csv` |
| `src/prepare_data.py` | Rebuilds the tidy CSVs from the raw IEA download |
| `src/export_static.py` | Writes `results/dashboard_static.html` (self-contained, works offline) and PNG snapshots via kaleido |
| `data/` | Raw IEA extract, tidy tables, `policies.csv`, `sources.csv` |
| `results/` | Forecast table, fitted parameters, static HTML, PNGs, screenshots |
| `tests/test_project.py` | 40 pytest checks (data integrity, model bounds, monotonic forecasts, figures, app layout) |

## 2. Screenshots

Dash app (Playwright screenshots, `results/screenshots/`):

| Forecast tab | Map tab |
|---|---|
| ![](results/screenshots/dash_forecast.png) | ![](results/screenshots/dash_map.png) |

Static figures (kaleido PNGs, `results/png/`):

![](results/png/global_sales_by_region.png)
![](results/png/world_forecast.png)
![](results/png/s-curve_fits_fixed_100pct_ceiling.png)
![](results/png/policy_timeline.png)

Every figure is also in `results/dashboard_static.html` — open it in a browser without running anything.

## 3. Data provenance

| File | Content | Publisher / edition | How obtained | Licence |
|---|---|---|---|---|
| `data/iea_global_ev_data_explorer_2026.csv` (52 800 rows) | EV sales, sales share, stock, stock share, charging points, electricity demand, oil displacement, battery deployment, price percentiles; cars/buses/vans/trucks; Historical 2010–2025 + STEPS/CPS projections for 2035; 71 regions | IEA Global EV Data Explorer, GEO 2026 edition (explorer last updated 20 May 2026) | **Downloaded with curl from the public IEA API** `https://api.iea.org/evs?year=YYYY`, one call per year 2010–2035, on 2026-09-02; rows concatenated unchanged | CC BY 4.0 |
| `data/ev_cars_by_region.csv` (923 rows) | Cars only, region × year: EV/BEV/PHEV sales, sales share, stock, stock share, implied total car sales | Derived from the file above by `src/prepare_data.py` | — | CC BY 4.0 (derived) |
| `data/ev_share_by_country_latest.csv` (61 countries) | 2025 EV sales share per country + ISO3 for the choropleth | Derived | ISO3 mapping added by hand | CC BY 4.0 (derived) |
| `data/iea_projections_2035.csv` | IEA STEPS and CPS 2035 projections (used only as a benchmark) | IEA GEO 2026 | Filtered from the raw file | CC BY 4.0 |
| `data/policies.csv` (20 rows) | Government EV policy events 2001–2025 with country, year, type, direction, summary, source URL | PIB India, IRS, EU Council, EU Commission, gov.uk, gov.cn, Transport Canada, White House, electrive, ESG Today, ASEAN Briefing | **Hand-compiled** from the cited pages (verified by reading each page) | facts; URL per row |
| `data/sources.csv` | Registry of all of the above | — | — | — |
| `src/assets/world_110m.json` | World topojson used by the choropleth | plotly.js asset (cdn.plot.ly) | curl | MIT |

Cross-check against the IEA GEO 2026 executive summary: it says electric car sales "exceed 20 million in 2025" with "one-quarter of all new cars sold" electric, China "nearly 55%", Europe 28%, USA "just under 10%". The API series gives World 21.0 M / 25%, China 53%, Europe 28%, USA 10% — consistent (IEA rounds to two significant figures). This is checked automatically in `tests/test_project.py::test_headline_numbers_match_iea_geo2026_summary`.

Note on the IEA data: values are rounded to 2 significant figures by the IEA, `implied_total_car_sales = ev_sales / share` is my derived quantity, and a few small countries are missing early years — the five modelling regions have complete 2015–2025 series with no gaps.

## 4. Methodology — growth models

All models are fitted to the **EV share of new car sales** *s(t)* (%, BEV+PHEV) over 2015–2025 for each region. Working in share space rather than unit sales keeps the forecast bounded (0–100%) and separates adoption from the size of the car market. EV unit forecasts are then `share × total market`, where the total market is the 2025 implied total grown at that region's 2015–2025 average rate, capped to [−1%, +3%] per year.

| Model | Equation | Fitted parameters |
|---|---|---|
| Logistic S-curve, free saturation | s(t) = L / (1 + e^(−k (t − t₀))) | L, k, t₀ (curve_fit, bounds L ∈ [max s, 100]) |
| Logistic S-curve, fixed ceiling (default) | same, L fixed by the ceiling slider (default 100 %) | k, t₀ |
| Bass diffusion | s(t) = m · F(τ), F(τ) = (1 − e^(−(p+q)τ)) / (1 + (q/p) e^(−(p+q)τ)), τ = t − 2014 | m, p (innovation), q (imitation) |
| CAGR extrapolation | s(t) = s₂₀₂₅ (1 + g)^(t − 2025), g = 5-year CAGR of the share | g |
| Exponential | s(t) = a e^(b (t − 2015)) (least squares on log s) | a, b |
| Linear | s(t) = a + b (t − 2015) | a, b |

CAGR/exponential/linear outputs are clipped to 0–100 %. The **confidence band** (5–95 %) for the S-curve models is a parametric bootstrap: parameters are resampled from the `curve_fit` covariance (400 draws, standard errors damped ×0.5 because the parameters are strongly correlated) and the band is the 5th/95th percentile of the resulting curves. For the simpler models the band is ±1.645·RMSE·√(1 + horizon).

**Policy-scenario slider** (−1 … +1): scales the growth rate (k, or p and q, or g/b) by (1 + 0.3·f) and the saturation level by (1 + 0.1·f), re-anchoring the curve at the 2025 observation so only the future changes. It is a what-if lever, not a calibrated policy-elasticity — the size of the effect is illustrative.

**Model validation:** in-sample RMSE and R² on 2015–2025, plus a hold-out test (fit on 2015–2022, score on 2023–2025).

### Fitted parameters (`results/model_params.json`)

| Region | Logistic free (L, k, t₀) | Logistic fixed L=100 (k, t₀) | Bass (m, p, q) | 5-yr share CAGR |
|---|---|---|---|---|
| World | 27.7 %, 0.676, 2022.0 | 0.336, 2028.0 | 27.8 %, 0.0031, 0.667 | +41.6 %/yr |
| China | 58.5 %, 0.810, 2022.2 | 0.477, 2024.3 | 58.4 %, 0.0011, 0.811 | +56.2 %/yr |
| Europe | 28.0 %, 0.720, 2020.9 | 0.281, 2028.0 | 28.0 %, 0.0056, 0.703 | +22.9 %/yr |
| USA | 11.6 %, 0.649, 2021.3 | 0.245, 2033.2 | 11.5 %, 0.0053, 0.666 | +34.2 %/yr |
| India | 9.2 %, 0.580, 2025.6 | 0.464, 2031.9 | 10.2 %, 0.0007, 0.556 | +101.6 %/yr |

Goodness of fit (RMSE in percentage points, in-sample / hold-out 2023–25):

| Region | Logistic free | Logistic fixed | Bass | CAGR | Exponential | Linear |
|---|---|---|---|---|---|---|
| World | 0.73 / 16.8 | 1.64 / 16.8 | 0.75 / 16.3 | 2.85 / 24.1 | 3.27 / 14.1 | 2.74 / 7.0 |
| China | 1.51 / 17.6 | 2.93 / 17.6 | 1.53 / 17.7 | 8.26 / 32.9 | 6.78 / 19.1 | 7.01 / 20.3 |
| Europe | 1.83 / 2.9 | 3.21 / 23.5 | 1.83 / 2.9 | 3.59 / 42.6 | 5.96 / 38.1 | 2.88 / 2.0 |
| USA | 0.72 / 7.3 | 1.15 / 7.3 | 0.74 / 6.6 | 1.92 / 7.9 | 1.43 / 3.6 | 1.22 / 2.6 |
| India | 0.26 / 20.2 | 0.27 / 20.2 | 0.26 / 2.5 | 0.44 / 6.2 | 0.36 / 0.9 | 0.65 / 1.9 |

### Forecast summary — EV share of new car sales (%), `results/forecast_table.csv`

| Region | 2025 actual | Logistic fixed 2030 / 2035 | Logistic free 2030 / 2035 | Bass 2030 / 2035 | Linear 2030 / 2035 | IEA STEPS 2035 |
|---|---|---|---|---|---|---|
| World | 25 | 66.5 / 91.4 | 27.6 / 27.7 | 27.6 / 27.8 | 34.9 / 47.8 | 53 |
| China | 53 | 93.7 / 99.4 | 58.4 / 58.5 | 58.3 / 58.4 | 74.2 / 100 | 94 |
| Europe | 28 | 63.5 / 87.6 | 28.0 / 28.0 | 28.0 / 28.0 | 41.3 / 56.0 | 85 |
| USA | 10 | 31.3 / 60.8 | 11.6 / 11.6 | 11.4 / 11.5 | 15.7 / 21.2 | 20 |
| India | 4 | 29.5 / 81.0 | 8.5 / 9.1 | 9.3 / 10.2 | 4.3 / 6.1 | 24 |

## 5. Key insights

1. **The global market grew 40× in a decade.** Electric car sales went from 0.53 M (0.68 % share) in 2015 to 21 M (25 %) in 2025 — a 44 %/yr CAGR in units. 2025 sales were +24 % over 2024's 17 M. Global EV stock reached 75 M (5 % of cars on the road).
2. **China is the market.** 13 M of the 21 M electric cars sold in 2025 were sold in China (62 %), where 53 % of all new cars were electric. Europe sold 4.2 M (28 % share), the USA 1.5 M (10 %, flat since 2024), India 0.17 M (4 %).
3. **Adoption follows an S-curve, but the data cannot yet tell us where the ceiling is.** With 11 annual points the free-saturation logistic and Bass fits place the ceiling right at the current level for every region (World 27.7 %, Europe 28 %, USA 11.6 %) — they essentially say "2024's slowdown was the top". The fixed-ceiling logistic (L = 100 %) instead reaches 66 % by 2030 and 91 % by 2035 for the world. IEA's own STEPS scenario (53 % in 2035) sits between the two, which is why the dashboard shows both and lets the user set the ceiling.
4. **China is already well past the S-curve midpoint (t₀ = 2022 on the free fit, 2024 on the fixed fit) with k ≈ 0.5–0.8/yr**, the steepest of any region; even the fixed-ceiling fit puts China at 94 % in 2030, matching IEA STEPS 2035 (94 %).
5. **Europe's 2024 stall was policy-driven and visible in the data:** share was 22 % in 2023 and 21 % in 2024 (Germany ended the Umweltbonus on 17 Dec 2023) and then jumped to 28 % in 2025 when the EU 2025 CO₂ targets kicked in — even with the 3-year averaging flexibility adopted in May 2025. Linear extrapolation had the best hold-out score for Europe (RMSE 2.0 pp), reflecting the near-linear ~3 pp/yr climb.
6. **The USA is the outlier among large markets:** 10 % share, flat 2024→2025, midpoint on the fixed fit not until 2033. The termination of the 30D tax credit after 30 Sept 2025 and the revocation of California's ACC II waiver (June 2025) are both in the policy register and both point to slower growth than the 2015–2022 trend; the hold-out test shows 2015–2022 trends over-predicted 2023–25 by 7 pp for the USA and 17 pp for the world.
7. **India is early on its curve (4 % in 2025, doubling from 2.1 % in 2024).** Its share CAGR over five years is +102 %/yr, but from a low base: the Bass fit with a free ceiling saturates at only 10 % — because private e-cars get no purchase subsidy under PM E-DRIVE (the scheme targets 2W/3W/buses) and the fitted "imitation" coefficient q = 0.56 is the lowest of the five regions. The +1 policy scenario chart (`results/png/india_forecast_plus1_policy_scenario.png`) shows how much a stronger push moves the curve.
8. **Policy direction has flipped in the West since 2023:** of the 20 policies in the register, all 6 "weakening" events are in 2023–2025 (Germany, Canada, USA ×2, EU ×2 incl. the Dec 2025 proposal to ease the 2035 target to 90 %), and Norway is phasing out its VAT exemption by 2028, while China, India, Thailand and the UK kept adding support. This asymmetry is the main reason I would not trust a single global S-curve — regional curves with their own ceilings are the more honest model.

## 6. How to run

```bash
cd 10_EV_Market_Forecast_Dashboard
pip install -r requirements.txt

# interactive dashboard
python src/app.py            # then open http://127.0.0.1:8050

# refit models and write results/forecast_table.csv + model_params.json
python src/models.py

# rebuild the static HTML (+ PNGs if kaleido and a Chromium binary are available)
python src/export_static.py          # add --no-png to skip PNGs

# tests
pytest -q tests

# re-derive tidy CSVs from the raw IEA extract (only needed if you refresh the raw file)
python src/prepare_data.py
```

Set `PORT=8051 python src/app.py` to use another port. PNG export uses kaleido ≥ 1.0, which needs Chrome/Chromium; the script looks in `$BROWSER_PATH`, on `$PATH`, and in Playwright's browser cache. If none is found the PNG step is skipped and the HTML is still written.

## 7. Limitations

- **Short series for S-curve fitting.** Eleven annual observations cannot identify the saturation level; the free-fit ceilings should be read as "what the last two years imply", not as a prediction. I expose the ceiling as a slider instead of hiding this.
- **The policy-scenario slider is illustrative.** The ±30 % growth-rate / ±10 % saturation mapping is my own assumption, not estimated from data.
- **Total-market assumption.** EV unit forecasts assume the total car market grows at the region's 2015–2025 implied rate (capped at −1…+3 %/yr); a recession or a shift to shared mobility would change unit numbers even if the share path holds.
- **IEA rounding.** Values are given to 2 significant figures by the IEA, so year-on-year changes for small markets are coarse.
- **Europe definition.** IEA's "Europe" = EU27 + EFTA + UK + Türkiye/Balkans; "European Union" is also in the data if needed.
- **PNG of the choropleth.** In my sandbox kaleido's Chromium could not fetch plotly's topojson from cdn.plot.ly, so `results/png/` has 15 of 16 figures (no map PNG); the map renders fine in the Dash app and in the static HTML because I bundled the topojson (`src/assets/world_110m.json`). With normal internet access `python src/export_static.py` will write the map PNG too.
- **Policy register coverage.** 20 events chosen for relevance to the five modelled regions plus Norway/UK/Thailand/Canada/Germany; it is not an exhaustive database.
- No `statsmodels` dependency was needed; it is listed as optional in `requirements.txt` only because the brief mentioned it.

## 8. References

1. IEA (2026), *Global EV Data Explorer*, https://www.iea.org/data-and-statistics/data-tools/global-ev-data-explorer — CC BY 4.0. API: `https://api.iea.org/evs?year=YYYY`.
2. IEA (2026), *Global EV Outlook 2026 — Executive summary*, https://www.iea.org/reports/global-ev-outlook-2026/executive-summary
3. IEA (2025), *Global EV Outlook 2025*, https://www.iea.org/reports/global-ev-outlook-2025
4. PIB (2019), *Cabinet approves Scheme for FAME India Phase II*, https://www.pib.gov.in/Pressreleaseshare.aspx?PRID=1566758
5. PIB (2019), *GST rate on all Electric Vehicles reduced from 12% to 5%*, https://www.pib.gov.in/Pressreleaseshare.aspx?PRID=1580536
6. PIB (2024), *MHI announces Electric Mobility Promotion Scheme 2024*, https://www.pib.gov.in/PressReleaseIframePage.aspx?PRID=2014366
7. PIB (2024), *Cabinet approves PM E-DRIVE Scheme with an outlay of Rs 10,900 crore*, https://www.pib.gov.in/PressReleaseIframePage.aspx?PRID=2053959
8. Council of the EU (28 Mar 2023), *Fit for 55: Council adopts regulation on CO2 emissions for new cars and vans*, https://www.consilium.europa.eu/en/press/press-releases/2023/03/28/fit-for-55-council-adopts-regulation-on-co2-emissions-for-new-cars-and-vans/
9. Council of the EU (27 May 2025), *CO2 emissions in cars: Council gives final approval to additional flexibility for carmakers*, https://www.consilium.europa.eu/en/press/press-releases/2025/05/27/co2-emissions-in-cars-council-gives-final-approval-to-additional-flexibility-for-carmakers/
10. European Commission (5 Mar 2025), *Commission proposes flexibility to help manufacturers comply with 2025 CO2 targets*, https://ec.europa.eu/commission/presscorner/detail/en/ip_25_854
11. European Commission (2024), *Commission imposes definitive countervailing duties on BEV imports from China*, https://ec.europa.eu/commission/presscorner/detail/en/ip_24_5589
12. ESG Today (17 Dec 2025), *EU to scrap requirements for 100% emissions reduction from new cars by 2035*, https://www.esgtoday.com/eu-to-scrap-requirements-for-100-emissions-reduction-from-new-cars-by-2035/
13. IRS, *Credits for new clean vehicles purchased in 2023 or after*, https://www.irs.gov/credits-deductions/credits-for-new-clean-vehicles-purchased-in-2023-or-after
14. IRS, *FAQs for modification of sections 25C, 25D, 25E, 30C, 30D … under Public Law 119-21 (OBBB)*, https://www.irs.gov/newsroom/faqs-for-modification-of-sections-25c-25d-25e-30c-30d-45l-45w-and-179d-under-public-law-119-21-139-stat-72-july-4-2025-commonly-known-as-the-one-big-beautiful-bill-obbb
15. The White House (June 2025), *Statement by the President* (CRA resolutions on California vehicle waivers), https://www.whitehouse.gov/briefings-statements/2025/06/statement-by-the-president/
16. gov.cn (21 Jun 2023), *China extends preferential purchase tax policy for NEVs*, https://english.www.gov.cn/news/202306/21/content_WS64929394c6d0868f4e8dd11c.html
17. gov.cn (31 Dec 2025), *China renews auto trade-in subsidy program for 2026*, https://english.www.gov.cn/news/202512/31/content_WS6954b901c6d00ca5f9a08596.html
18. electrive (4 Dec 2025), *Norway to keep tax breaks for electric cars a little longer*, https://www.electrive.com/2025/12/04/norway-to-keep-tax-breaks-for-electric-cars-a-little-longer/
19. GOV.UK (3 Jan 2024), *Pathway for zero emission vehicle transition by 2035 becomes law*, https://www.gov.uk/government/news/pathway-for-zero-emission-vehicle-transition-by-2035-becomes-law
20. electrive (15 Jul 2025), *UK announces new EV subsidies*, https://www.electrive.com/2025/07/15/uk-announces-new-ev-subsidies/
21. electrive (18 Dec 2023), *Germany cuts the EV purchase premium Umweltbonus with immediate effect*, https://www.electrive.com/2023/12/18/germany-cuts-all-zero-emission-vehicle-subsidies-with-immediate-effect/
22. Transport Canada (Jan 2025), *Pause of the Incentives for Zero-Emission Vehicles Program*, https://www.canada.ca/en/transport-canada/news/2025/01/pause-of-the-incentives-for-zero-emission-vehicles-program.html
23. ASEAN Briefing (2024), *Thailand EV purchase subsidy scheme EV3.5*, https://www.aseanbriefing.com/news/thailand-ev-purchase-subsidy-scheme-2024-to-2027-boost-local-production/
24. Bass, F. M. (1969), "A New Product Growth for Model Consumer Durables", *Management Science* 15(5), 215–227.
