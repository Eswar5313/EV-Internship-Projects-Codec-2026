"""pytest suite: run `pytest -q` from the project root."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import load_data as LD  # noqa: E402
import models as M  # noqa: E402
import figures as F  # noqa: E402


# --------------------------------------------------------------------------- #
# Data
# --------------------------------------------------------------------------- #
def test_region_table_loads_without_nan_in_key_columns():
    df = LD.load_region_table()
    key = df[df["region"].isin(LD.FORECAST_REGIONS) & (df["year"] >= 2015)]
    assert len(key) == 5 * 11  # 5 regions x 2015-2025
    assert key[LD.KEY_COLUMNS].isna().sum().sum() == 0
    assert key["ev_sales_share_pct"].between(0, 100).all()
    assert (key["ev_sales"] > 0).all()


def test_country_map_table():
    df = LD.load_country_latest()
    assert df["iso3"].str.len().eq(3).all()
    assert df["iso3"].is_unique
    assert df["ev_sales_share_pct"].between(0, 100).all()
    assert len(df) >= 30
    assert df.loc[df["region"] == "Norway", "ev_sales_share_pct"].iloc[0] > 90


def test_headline_numbers_match_iea_geo2026_summary():
    """IEA GEO 2026 executive summary: >20 M electric cars in 2025, ~25% share."""
    w = LD.get_series("World").set_index("year")
    assert w.loc[2025, "ev_sales"] > 20e6
    assert 23 <= w.loc[2025, "ev_sales_share_pct"] <= 27
    cn = LD.get_series("China").set_index("year")
    assert 50 <= cn.loc[2025, "ev_sales_share_pct"] <= 58


def test_policies_have_sources_and_years():
    pol = LD.load_policies()
    assert len(pol) >= 20
    assert pol["source_url"].str.startswith("http").all()
    assert pol["year"].between(2000, 2026).all()
    assert (pol["end_year"] >= pol["year"]).all()
    assert set(pol["direction"]) <= {"Support", "Weakening", "Mixed"}


def test_sources_csv_covers_every_data_file():
    src = LD.load_sources()
    listed = set(src["dataset_file"])
    for f in LD.DATA_DIR.glob("*.csv"):
        if f.name != "sources.csv":
            assert f.name in listed, f"{f.name} missing from sources.csv"


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("region", LD.FORECAST_REGIONS)
@pytest.mark.parametrize("model", ["logistic", "logistic_fixed", "bass"])
def test_scurve_fit_share_within_0_100(region, model):
    tab, res = M.forecast(region, model, 2035)
    assert tab["share_pct"].between(0, 100).all()
    assert tab["share_lo"].between(0, 100).all() and tab["share_hi"].between(0, 100).all()
    assert (tab["share_lo"] <= tab["share_pct"] + 1e-9).all() and (tab["share_hi"] >= tab["share_pct"] - 1e-9).all()
    assert 0 < res.params.get("L", res.params.get("m")) <= 100
    assert res.r2_in_sample > 0.85


@pytest.mark.parametrize("region", LD.FORECAST_REGIONS)
@pytest.mark.parametrize("model", ["logistic", "logistic_fixed", "bass"])
def test_scurve_forecast_is_monotonic(region, model):
    tab, _ = M.forecast(region, model, 2035)
    fut = tab[tab["is_forecast"]]["share_pct"].to_numpy()
    assert np.all(np.diff(fut) >= -1e-9)


def test_policy_scenario_shifts_forecast_in_right_direction():
    base, _ = M.forecast("World", "logistic_fixed", 2035, 0.0)
    up, _ = M.forecast("World", "logistic_fixed", 2035, 1.0)
    down, _ = M.forecast("World", "logistic_fixed", 2035, -1.0)
    b, u, d = (t[t["year"] == 2030]["share_pct"].iloc[0] for t in (base, up, down))
    assert d < b < u
    # history is unchanged by the scenario
    assert np.allclose(base[~base["is_forecast"]]["share_pct"], up[~up["is_forecast"]]["share_pct"])


def test_cagr_and_simple_models_run_and_are_capped():
    for m in ["cagr", "exponential", "linear"]:
        tab, res = M.forecast("India", m, 2035)
        assert tab["share_pct"].between(0, 100).all()
        assert np.isfinite(res.rmse_in_sample)


def test_fit_all_writes_results(tmp_path):
    table, fits = M.fit_all(regions=["World"], horizon_end=2030)
    M.save_results(table, fits, tmp_path)
    assert (tmp_path / "forecast_table.csv").exists() and (tmp_path / "model_params.json").exists()
    assert set(table["model"]) == set(M.MODEL_NAMES)
    assert table["year"].max() == 2030


# --------------------------------------------------------------------------- #
# Figures and app
# --------------------------------------------------------------------------- #
def test_all_static_figures_build():
    for name, fn in F.ALL_STATIC_FIGURES.items():
        fig = fn()
        assert len(fig.data) > 0, name


def test_app_layout_builds():
    import app as A
    layout = A.app.layout
    assert layout is not None
    ids = str(layout)
    assert "tabs" in ids and "tab-content" in ids
    # tab renderers and forecast callback run without a server
    for tab in ["overview", "forecast", "map", "policies", "data"]:
        assert A.render_tab(tab) is not None
    out = A.update_forecast("India", "bass", 2032, 0.5, 80)
    assert len(out) == 5
