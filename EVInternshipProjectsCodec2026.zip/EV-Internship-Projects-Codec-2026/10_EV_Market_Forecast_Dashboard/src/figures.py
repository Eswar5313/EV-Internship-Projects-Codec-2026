"""
figures.py
----------
All Plotly figures used by the Dash app and the static export. Each function
returns a plotly.graph_objects.Figure and takes plain arguments so it can be
unit-tested without Dash.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

try:
    from load_data import (load_region_table, load_country_latest, load_policies,
                           load_projections, get_series, FORECAST_REGIONS)
    from models import forecast, MODEL_LABELS, logistic, bass, FIT_START_YEAR
except ImportError:  # pragma: no cover
    from src.load_data import (load_region_table, load_country_latest, load_policies,
                               load_projections, get_series, FORECAST_REGIONS)
    from src.models import forecast, MODEL_LABELS, logistic, bass, FIT_START_YEAR

TEMPLATE = "plotly_white"
REGION_COLORS = {
    "China": "#c0392b", "Europe": "#2874a6", "USA": "#1e8449", "India": "#d68910",
    "Rest of world": "#7f8c8d", "World": "#2c3e50",
}
FONT = dict(family="Inter, Segoe UI, Helvetica, Arial, sans-serif", size=13)


def _layout(fig: go.Figure, title: str, height: int = 460, **kw) -> go.Figure:
    base = dict(template=TEMPLATE, title=dict(text=title, x=0.01, y=0.97, yanchor="top", font=dict(size=16)),
                height=height, margin=dict(l=50, r=30, t=85, b=50), font=FONT,
                legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1, font=dict(size=11)))
    base.update(kw)
    fig.update_layout(**base)
    return fig


# --------------------------------------------------------------------------- #
# 1. Global sales stacked bar by region
# --------------------------------------------------------------------------- #
def fig_global_sales_stacked(start_year: int = 2015) -> go.Figure:
    df = load_region_table()
    regions = ["China", "Europe", "USA", "India"]
    piv = df[df["region"].isin(regions + ["World"]) & (df["year"] >= start_year)] \
        .pivot(index="year", columns="region", values="ev_sales")
    piv["Rest of world"] = (piv["World"] - piv[regions].sum(axis=1)).clip(lower=0)
    fig = go.Figure()
    for r in regions + ["Rest of world"]:
        fig.add_bar(x=piv.index, y=piv[r] / 1e6, name=r, marker_color=REGION_COLORS[r],
                    hovertemplate=f"{r}<br>%{{x}}: %{{y:.2f}} M<extra></extra>")
    fig.add_scatter(x=piv.index, y=piv["World"] / 1e6, mode="lines+markers+text", name="World total",
                    text=[f"{v:.1f}M" for v in piv["World"] / 1e6], textposition="top center",
                    line=dict(color=REGION_COLORS["World"], width=2), marker=dict(size=6))
    fig.update_layout(barmode="stack", yaxis_title="Electric car sales (millions, BEV+PHEV)",
                      xaxis=dict(dtick=1))
    return _layout(fig, "Global electric car sales by region (IEA, historical)")


# --------------------------------------------------------------------------- #
# 2. Share line chart with forecast + confidence band
# --------------------------------------------------------------------------- #
def fig_share_forecast(region: str = "World", model: str = "logistic_fixed", horizon_end: int = 2035,
                       policy_factor: float = 0.0, ceiling: float = 100.0,
                       show_iea: bool = True) -> go.Figure:
    tab, res = forecast(region, model, horizon_end, policy_factor, ceiling)
    obs = tab.dropna(subset=["share_observed"])
    fut = tab[tab["is_forecast"]]
    last = obs.iloc[-1]
    color = REGION_COLORS.get(region, "#2c3e50")

    fig = go.Figure()
    # band
    band_x = np.concatenate([[last["year"]], fut["year"].to_numpy(), fut["year"].to_numpy()[::-1], [last["year"]]])
    band_y = np.concatenate([[last["share_observed"]], fut["share_hi"].to_numpy(),
                             fut["share_lo"].to_numpy()[::-1], [last["share_observed"]]])
    fig.add_scatter(x=band_x, y=band_y, fill="toself", fillcolor="rgba(40,116,166,0.15)",
                    line=dict(width=0), name="5-95% band", hoverinfo="skip")
    fig.add_scatter(x=obs["year"], y=obs["share_observed"], mode="lines+markers", name="Observed (IEA)",
                    line=dict(color=color, width=3), marker=dict(size=7),
                    hovertemplate="%{x}: %{y:.1f}%<extra>observed</extra>")
    fig.add_scatter(x=obs["year"], y=obs["share_pct"], mode="lines", name="Model fit",
                    line=dict(color="#7f8c8d", width=1.5, dash="dot"), hovertemplate="%{x}: %{y:.1f}%<extra>fit</extra>")
    fig.add_scatter(x=np.concatenate([[last["year"]], fut["year"]]),
                    y=np.concatenate([[last["share_observed"]], fut["share_pct"]]),
                    mode="lines+markers", name=f"Forecast ({MODEL_LABELS[model]})",
                    line=dict(color="#2874a6", width=3, dash="dash"), marker=dict(size=5),
                    hovertemplate="%{x}: %{y:.1f}%<extra>forecast</extra>")
    if show_iea:
        proj = load_projections()
        p = proj[(proj["region"] == region) & (proj["parameter"] == "EV sales share")]
        for _, row in p.iterrows():
            if row["year"] <= horizon_end:
                fig.add_scatter(x=[row["year"]], y=[row["value"]], mode="markers",
                                name=f"IEA {row['scenario']} {int(row['year'])}",
                                marker=dict(symbol="diamond", size=12,
                                            color="#c0392b" if row["scenario"] == "STEPS" else "#d68910"),
                                hovertemplate=f"IEA {row['scenario']} {int(row['year'])}: %{{y:.0f}}%<extra></extra>")
    fig.add_vline(x=last["year"] + 0.5, line=dict(color="#999", dash="dot"))
    fig.add_annotation(x=last["year"] + 0.6, y=98, text="forecast →", showarrow=False, xanchor="left",
                       font=dict(color="#666", size=11))
    ptxt = ", ".join((f"{k}={v:.0f}" if k in ("t0", "t_last", "t_ref") else f"{k}={v:.3g}")
                     for k, v in res.params.items() if k not in ("t_start", "window_years"))
    scen = "" if policy_factor == 0 else f" | policy scenario {policy_factor:+.2f}"
    fig.update_layout(yaxis=dict(title="EV share of new car sales (%)", range=[0, 102]),
                      xaxis=dict(dtick=1, title="Year"))
    return _layout(fig, f"{region}: EV sales share, {MODEL_LABELS[model]} — {ptxt}{scen}", height=500)


# --------------------------------------------------------------------------- #
# 3. Choropleth world map of EV share by country
# --------------------------------------------------------------------------- #
def fig_choropleth() -> go.Figure:
    df = load_country_latest()
    fig = px.choropleth(df, locations="iso3", color="ev_sales_share_pct", hover_name="region",
                        hover_data={"iso3": False, "ev_sales_share_pct": ":.1f", "ev_sales": ":,.0f", "year": True},
                        color_continuous_scale="Viridis", range_color=(0, 100),
                        labels={"ev_sales_share_pct": "EV share of new car sales (%)", "ev_sales": "EV sales"})
    fig.update_geos(showcountries=True, countrycolor="#ccc", showframe=False, projection_type="natural earth",
                    landcolor="#f2f2f2", projection_rotation=dict(lon=10, lat=0), center=dict(lon=10, lat=15),
                    lataxis_range=[-58, 85])
    fig.update_layout(coloraxis_colorbar=dict(title="EV share %", len=0.7))
    yr = int(df["year"].max())
    return _layout(fig, f"EV share of new car sales by country, {yr} (IEA; {len(df)} countries)", height=560,
                   margin=dict(l=0, r=0, t=85, b=0))


# --------------------------------------------------------------------------- #
# 4. S-curve fit chart (all headline regions, logistic and Bass)
# --------------------------------------------------------------------------- #
def fig_scurve_fits(model: str = "logistic_fixed", regions=FORECAST_REGIONS, horizon_end: int = 2035,
                    ceiling: float = 100.0) -> go.Figure:
    fig = go.Figure()
    for r in regions:
        tab, res = forecast(r, model, horizon_end, 0.0, ceiling)
        obs = tab.dropna(subset=["share_observed"])
        c = REGION_COLORS.get(r, "#555")
        fig.add_scatter(x=obs["year"], y=obs["share_observed"], mode="markers", name=f"{r} observed",
                        marker=dict(color=c, size=8), legendgroup=r)
        fig.add_scatter(x=tab["year"], y=tab["share_pct"], mode="lines", name=f"{r} fit + forecast",
                        line=dict(color=c, width=2, dash="dash"), legendgroup=r,
                        hovertemplate=f"{r} %{{x}}: %{{y:.1f}}%<extra></extra>")
    fig.update_layout(yaxis=dict(title="EV share of new car sales (%)", range=[0, 102]),
                      xaxis=dict(dtick=1, title="Year"))
    return _layout(fig, f"S-curve fits by region — {MODEL_LABELS[model]}", height=520,
                   legend=dict(orientation="v", x=1.02, y=1, xanchor="left"))


# --------------------------------------------------------------------------- #
# 5. Policy timeline (Gantt-style scatter)
# --------------------------------------------------------------------------- #
def fig_policy_timeline() -> go.Figure:
    pol = load_policies().sort_values(["country", "year", "policy_id"]).reset_index(drop=True)
    colors = {"Support": "#1e8449", "Weakening": "#c0392b", "Mixed": "#d68910"}
    x_min = 2017
    fig = go.Figure()
    labels, seen = [], set()
    for i, r in pol.iterrows():
        col = colors.get(r["direction"], "#555")
        show = r["direction"] not in seen
        seen.add(r["direction"])
        short = r["policy"] if len(r["policy"]) <= 48 else r["policy"][:46] + "…"
        labels.append(f"{r['country']} · {short}")
        hover = (f"<b>{r['policy']}</b><br>{r['country']} · {r['year']}"
                 f"{'' if r['end_year'] == r['year'] + 1 else ' - ' + str(r['end_year'])} · {r['type']}<br>"
                 + "<br>".join(_wrap(r["summary"], 80)))
        x0 = max(r["year"], x_min)
        fig.add_scatter(x=[x0, r["end_year"]], y=[i, i], mode="lines", line=dict(color=col, width=10),
                        opacity=0.35, showlegend=False, hoverinfo="skip")
        if r["year"] < x_min:  # e.g. Norway VAT exemption since 2001
            fig.add_annotation(x=x_min, y=i, text=f"← since {r['year']}", showarrow=False, xanchor="left",
                               yshift=12, font=dict(size=10, color="#666"))
        fig.add_scatter(x=[max(r["year"], x_min)], y=[i], mode="markers",
                        marker=dict(color=col, size=13, symbol="diamond"),
                        name=r["direction"], legendgroup=r["direction"], showlegend=show,
                        hovertemplate=hover + "<extra></extra>")
    fig.update_layout(yaxis=dict(tickvals=list(range(len(labels))), ticktext=labels, autorange="reversed",
                                 tickfont=dict(size=11)),
                      xaxis=dict(title="Year", dtick=1, range=[x_min - 0.3, 2036]))
    return _layout(fig, "Government EV policy timeline (bar = stated duration; diamond = decision year; colour = direction)",
                   height=70 + 26 * len(labels), margin=dict(l=330, r=30, t=85, b=50))


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur); cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines


# --------------------------------------------------------------------------- #
# 6. Country ranking bar
# --------------------------------------------------------------------------- #
def fig_country_ranking(top_n: int = 25, metric: str = "ev_sales_share_pct") -> go.Figure:
    df = load_country_latest().sort_values(metric, ascending=False).head(top_n)
    label = {"ev_sales_share_pct": "EV share of new car sales (%)", "ev_sales": "EV sales (vehicles)"}[metric]
    fig = px.bar(df, x=metric, y="region", orientation="h", color=metric, color_continuous_scale="Viridis",
                 text=df[metric].map(lambda v: f"{v:.0f}%" if metric.endswith("pct") else f"{v/1e6:.2f}M" if v >= 1e6 else f"{v/1e3:.0f}k"),
                 labels={metric: label, "region": ""})
    fig.update_traces(textposition="outside", cliponaxis=False)
    fig.update_layout(yaxis=dict(autorange="reversed"), coloraxis_showscale=False)
    yr = int(df["year"].max())
    return _layout(fig, f"Top {top_n} countries by {label.lower()}, {yr}", height=620)


# --------------------------------------------------------------------------- #
# 7. Model comparison chart (all models, one region)
# --------------------------------------------------------------------------- #
def fig_model_comparison(region: str = "World", horizon_end: int = 2035, policy_factor: float = 0.0,
                         ceiling: float = 100.0) -> go.Figure:
    fig = go.Figure()
    palette = px.colors.qualitative.Safe
    first = True
    for i, m in enumerate(MODEL_LABELS):
        tab, res = forecast(region, m, horizon_end, policy_factor, ceiling)
        if first:
            obs = tab.dropna(subset=["share_observed"])
            fig.add_scatter(x=obs["year"], y=obs["share_observed"], mode="markers", name="Observed (IEA)",
                            marker=dict(color="#2c3e50", size=9))
            first = False
        fig.add_scatter(x=tab["year"], y=tab["share_pct"], mode="lines", name=MODEL_LABELS[m],
                        line=dict(color=palette[i % len(palette)], width=2),
                        hovertemplate=f"{MODEL_LABELS[m]} %{{x}}: %{{y:.1f}}%<extra></extra>")
    fig.update_layout(yaxis=dict(title="EV share of new car sales (%)", range=[0, 102]), xaxis=dict(dtick=1))
    return _layout(fig, f"{region}: growth-model comparison", height=480,
                   legend=dict(orientation="v", x=1.02, y=1, xanchor="left"))


# --------------------------------------------------------------------------- #
# 8. Forecast sales bars (observed + forecast) for one region
# --------------------------------------------------------------------------- #
def fig_sales_forecast(region: str = "World", model: str = "logistic_fixed", horizon_end: int = 2035,
                       policy_factor: float = 0.0, ceiling: float = 100.0) -> go.Figure:
    tab, _ = forecast(region, model, horizon_end, policy_factor, ceiling)
    obs = tab.dropna(subset=["ev_sales_observed"])
    fut = tab[tab["is_forecast"]]
    fig = go.Figure()
    fig.add_bar(x=obs["year"], y=obs["ev_sales_observed"] / 1e6, name="Observed EV sales",
                marker_color=REGION_COLORS.get(region, "#2c3e50"))
    fig.add_bar(x=fut["year"], y=fut["ev_sales_forecast"] / 1e6, name="Forecast EV sales",
                marker_color="rgba(40,116,166,0.55)")
    fig.add_scatter(x=tab["year"], y=tab["total_market_assumed"] / 1e6, mode="lines", name="Assumed total car market",
                    line=dict(color="#999", dash="dot"))
    fig.update_layout(barmode="overlay", yaxis_title="Cars (millions)", xaxis=dict(dtick=1))
    return _layout(fig, f"{region}: EV sales — observed and forecast ({MODEL_LABELS[model]})", height=420)


# --------------------------------------------------------------------------- #
# 9. BEV vs PHEV mix
# --------------------------------------------------------------------------- #
def fig_powertrain_mix(region: str = "World") -> go.Figure:
    s = get_series(region, FIT_START_YEAR)
    fig = go.Figure()
    fig.add_bar(x=s["year"], y=s["bev_sales"] / 1e6, name="BEV", marker_color="#1e8449")
    fig.add_bar(x=s["year"], y=s["phev_sales"] / 1e6, name="PHEV", marker_color="#82e0aa")
    fig.update_layout(barmode="stack", yaxis_title="Sales (millions)", xaxis=dict(dtick=1))
    return _layout(fig, f"{region}: BEV vs PHEV sales", height=380)


ALL_STATIC_FIGURES = {
    "global_sales_stacked": lambda: fig_global_sales_stacked(),
    "share_forecast_world": lambda: fig_share_forecast("World"),
    "share_forecast_india": lambda: fig_share_forecast("India"),
    "model_comparison_world": lambda: fig_model_comparison("World"),
    "scurve_fits": lambda: fig_scurve_fits(),
    "choropleth": lambda: fig_choropleth(),
    "country_ranking": lambda: fig_country_ranking(),
    "policy_timeline": lambda: fig_policy_timeline(),
    "sales_forecast_world": lambda: fig_sales_forecast("World"),
    "powertrain_mix_world": lambda: fig_powertrain_mix("World"),
}

if __name__ == "__main__":
    for name, fn in ALL_STATIC_FIGURES.items():
        f = fn()
        print(name, "traces:", len(f.data))
