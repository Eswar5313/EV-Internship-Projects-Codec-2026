"""
export_static.py
----------------
Writes results/dashboard_static.html: a single self-contained HTML page with all
figures (plotly.js embedded once) so the project can be viewed without running Dash.
Also tries to save PNG snapshots of every figure to results/png/ via kaleido; if
kaleido or a Chromium binary is unavailable the PNG step is skipped with a message.

Run:  python src/export_static.py [--no-png]
"""
from __future__ import annotations

import html as html_lib
import json
import sys
from pathlib import Path

import pandas as pd
import plotly.io as pio

sys.path.insert(0, str(Path(__file__).resolve().parent))

from load_data import RESULTS_DIR, load_region_table, load_sources, load_policies  # noqa: E402
from models import fit_all, save_results, MODEL_LABELS  # noqa: E402
import figures as F  # noqa: E402

CSS = """
body{font-family:Inter,'Segoe UI',Helvetica,Arial,sans-serif;background:#f4f6f8;margin:0;color:#2c3e50}
header{background:#2c3e50;color:#fff;padding:20px 32px}header h1{margin:0;font-size:26px}header p{margin:6px 0 0;color:#dfe6ec;font-size:13px}
main{max-width:1300px;margin:0 auto;padding:20px 24px}
.card{background:#fff;border-radius:10px;padding:14px 18px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:18px}
.kpis{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px}.kpi{flex:1;min-width:170px;background:#fff;border-radius:10px;padding:14px;box-shadow:0 1px 4px rgba(0,0,0,.08);text-align:center}
.kpi .l{font-size:12px;color:#666;text-transform:uppercase}.kpi .v{font-size:26px;font-weight:700}.kpi .s{font-size:12px;color:#888}
h2{font-size:20px;margin:26px 0 10px;border-bottom:2px solid #dfe6ec;padding-bottom:4px}
table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #e3e8ec;padding:6px 8px;text-align:left;vertical-align:top}th{background:#f0f3f5}
nav a{margin-right:14px;color:#2874a6;text-decoration:none;font-weight:600}
footer{color:#888;font-size:12px;text-align:center;padding:16px}
"""


def kpi_html() -> str:
    df = load_region_table()
    w = df[df["region"] == "World"].set_index("year")
    cn = df[df["region"] == "China"].set_index("year")
    ind = df[df["region"] == "India"].set_index("year")
    y = int(w.index.max())
    growth = (w.loc[y, "ev_sales"] / w.loc[y - 1, "ev_sales"] - 1) * 100
    items = [
        (f"Global EV car sales {y}", f"{w.loc[y, 'ev_sales'] / 1e6:.1f} M", f"{growth:+.0f}% vs {y - 1}"),
        (f"Global EV sales share {y}", f"{w.loc[y, 'ev_sales_share_pct']:.0f}%", f"{w.loc[y - 1, 'ev_sales_share_pct']:.0f}% in {y - 1}"),
        ("China share of global EV sales", f"{cn.loc[y, 'ev_sales'] / w.loc[y, 'ev_sales'] * 100:.0f}%", f"{cn.loc[y, 'ev_sales'] / 1e6:.1f} M cars"),
        (f"India EV share {y}", f"{ind.loc[y, 'ev_sales_share_pct']:.1f}%", f"{ind.loc[y, 'ev_sales']:,.0f} cars"),
        ("Global EV stock", f"{w.loc[y, 'ev_stock'] / 1e6:.0f} M", f"{w.loc[y, 'ev_stock_share_pct']:.1f}% of cars on the road"),
    ]
    return '<div class="kpis">' + "".join(
        f'<div class="kpi"><div class="l">{l}</div><div class="v">{v}</div><div class="s">{s}</div></div>' for l, v, s in items) + "</div>"


def df_html(df: pd.DataFrame, link_col: str | None = None) -> str:
    rows = []
    for _, r in df.iterrows():
        cells = []
        for c in df.columns:
            v = r[c]
            if link_col and c == link_col and isinstance(v, str) and v.startswith("http"):
                cells.append(f'<td><a href="{html_lib.escape(v)}" target="_blank">link</a></td>')
            else:
                cells.append(f"<td>{html_lib.escape(str(v))}</td>")
        rows.append("<tr>" + "".join(cells) + "</tr>")
    head = "".join(f"<th>{html_lib.escape(c)}</th>" for c in df.columns)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(rows)}</tbody></table>"


def build_figures() -> dict:
    figs = {
        "Global sales by region": F.fig_global_sales_stacked(),
        "S-curve fits (fixed 100% ceiling)": F.fig_scurve_fits("logistic_fixed"),
        "S-curve fits (free saturation)": F.fig_scurve_fits("logistic"),
        "World forecast": F.fig_share_forecast("World"),
        "World model comparison": F.fig_model_comparison("World"),
        "World sales forecast": F.fig_sales_forecast("World"),
        "China forecast": F.fig_share_forecast("China"),
        "Europe forecast": F.fig_share_forecast("Europe"),
        "USA forecast": F.fig_share_forecast("USA"),
        "India forecast": F.fig_share_forecast("India"),
        "India forecast, +1 policy scenario": F.fig_share_forecast("India", policy_factor=1.0),
        "World map": F.fig_choropleth(),
        "Country ranking (share)": F.fig_country_ranking(25, "ev_sales_share_pct"),
        "Country ranking (volume)": F.fig_country_ranking(25, "ev_sales"),
        "Policy timeline": F.fig_policy_timeline(),
        "World BEV vs PHEV": F.fig_powertrain_mix("World"),
    }
    return figs


def export_png(figs: dict, out_dir: Path) -> list[str]:
    """Try kaleido; return list of written files (empty if unavailable)."""
    try:
        import kaleido  # noqa: F401
    except ImportError:
        print("kaleido not installed - skipping PNG export")
        return []
    # kaleido>=1 needs a Chrome/Chromium binary; honour BROWSER_PATH or look in common spots
    import os, glob, shutil
    if not os.environ.get("BROWSER_PATH"):
        cands = [shutil.which("chromium"), shutil.which("chromium-browser"), shutil.which("google-chrome")]
        cands += sorted(glob.glob("/opt/pw-browsers/chromium-*/chrome-linux/chrome"))
        cands += sorted(glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium-*/chrome-linux/chrome")))
        for c in cands:
            if c and os.path.exists(c):
                os.environ["BROWSER_PATH"] = c
                break
    out_dir.mkdir(parents=True, exist_ok=True)
    written, failed = [], []
    items = [(name, fig, out_dir / (name.lower().replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")
                                    .replace("+", "plus").replace("%", "pct") + ".png")) for name, fig in figs.items()]
    # plotly>=6.1 can render a batch of figures with a single browser session (much faster)
    if hasattr(pio, "write_images"):
        try:
            pio.write_images([f for _, f, _ in items], [str(p) for _, _, p in items], width=1200, scale=2)
        except Exception as e:  # noqa: BLE001
            print(f"batch PNG export raised {type(e).__name__}: {e}; falling back to one-by-one")
    for name, fig, fname in items:
        if fname.exists() and fname.stat().st_size > 0:
            written.append(str(fname)); continue
        try:
            fig.write_image(str(fname), width=1200, height=fig.layout.height or 500, scale=2)
            written.append(str(fname))
        except Exception as e:  # noqa: BLE001
            failed.append(name)
            print(f"PNG export failed for {name}: {type(e).__name__}: {str(e)[:120]}")
    print(f"wrote {len(written)} PNGs to {out_dir}" + (f"; failed: {failed}" if failed else ""))
    return written


def main() -> None:
    RESULTS_DIR.mkdir(exist_ok=True)
    # 1. refresh model outputs
    table, fits = fit_all()
    save_results(table, fits)

    # 2. figures
    figs = build_figures()
    parts = []
    first = True
    # plotly.js normally downloads its world map topojson from cdn.plot.ly; embed the
    # bundled copy (src/assets/world_110m.json, a plotly.js MIT asset) so the map works offline.
    topo_path = Path(__file__).resolve().parent / "assets" / "world_110m.json"
    topo_script = ""
    if topo_path.exists():
        topo_script = ('<script>window.PlotlyGeoAssets = window.PlotlyGeoAssets || {topojson: {}};'
                       'window.PlotlyGeoAssets.topojson["world_110m"] = ' + topo_path.read_text() + ';</script>')
    for name, fig in figs.items():
        parts.append(f'<div class="card" id="{name.lower().replace(" ", "-")}">'
                     + (topo_script if name == "World map" else "")
                     + pio.to_html(fig, full_html=False, include_plotlyjs=first)
                     + "</div>")
        first = False

    # 3. parameter table
    rows = []
    for f in fits:
        rows.append({"region": f.region, "model": MODEL_LABELS[f.model],
                     "parameters": ", ".join(f"{k}={v:.4g}" for k, v in f.params.items()),
                     "RMSE in-sample (pp)": round(f.rmse_in_sample, 2), "R2": round(f.r2_in_sample, 3),
                     "RMSE hold-out 2023-25 (pp)": round(f.rmse_holdout, 2) if pd.notna(f.rmse_holdout) else "n/a",
                     "share 2030 (%)": round(float(table[(table.region == f.region) & (table.model == f.model) & (table.year == 2030)]["share_pct"].iloc[0]), 1),
                     "share 2035 (%)": round(float(table[(table.region == f.region) & (table.model == f.model) & (table.year == 2035)]["share_pct"].iloc[0]), 1)})
    params_df = pd.DataFrame(rows)

    pol = load_policies()[["policy_id", "country", "year", "type", "direction", "policy", "summary", "source_url"]]
    src = load_sources()

    html_doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>EV Market Forecast Dashboard (static export)</title><style>{CSS}</style></head><body>
<header><h1>EV Market Forecast Dashboard — static export</h1>
<p>Global electric-car adoption, government policy and growth-model forecasts to 2035 · Data: IEA Global EV Data Explorer
(Global EV Outlook 2026 edition, CC BY 4.0) · Eswar Mahalingam, Codec Technologies India internship, Sept 2026 ·
Interactive version: <code>python src/app.py</code></p></header>
<main>
<nav class="card"><a href="#overview">Overview</a><a href="#forecast">Forecast</a><a href="#map">Map</a>
<a href="#policies">Policies</a><a href="#params">Model parameters</a><a href="#sources">Data &amp; sources</a></nav>
<h2 id="overview">Overview</h2>{kpi_html()}{parts[0]}{parts[1]}{parts[2]}{parts[15]}
<h2 id="forecast">Forecast</h2>
<p>Default model: logistic S-curve with the ceiling fixed at 100% (every new car electric). Shaded band = 5-95% parametric
bootstrap from the fitted covariance. Diamonds = IEA Global EV Outlook 2026 scenario points (STEPS / CPS) for reference.</p>
{''.join(parts[3:11])}
<h2 id="map">Map</h2>{parts[11]}{parts[12]}{parts[13]}
<h2 id="policies">Policies</h2>{parts[14]}<div class="card">{df_html(pol, 'source_url')}</div>
<h2 id="params">Fitted model parameters and forecasts</h2><div class="card">{df_html(params_df)}</div>
<h2 id="sources">Data &amp; sources</h2><div class="card">{df_html(src, 'url')}</div>
</main><footer>Growth-model forecasts are illustrative and are not IEA projections. Generated by src/export_static.py.</footer>
</body></html>"""
    out = RESULTS_DIR / "dashboard_static.html"
    out.write_text(html_doc, encoding="utf-8")
    print(f"wrote {out} ({out.stat().st_size / 1e6:.1f} MB)")

    # 4. PNGs (optional; skip with `python src/export_static.py --no-png`)
    if "--no-png" in sys.argv:
        print("--no-png given: skipping PNG export"); return
    written = export_png(figs, RESULTS_DIR / "png")
    (RESULTS_DIR / "png_export_status.json").write_text(json.dumps({"png_files": written}, indent=2))


if __name__ == "__main__":
    main()
