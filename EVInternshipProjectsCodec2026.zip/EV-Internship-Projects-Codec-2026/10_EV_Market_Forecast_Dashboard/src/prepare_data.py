"""
prepare_data.py
---------------
Derives the tidy CSVs in data/ from the raw IEA Global EV Data Explorer download.

The raw file (data/iea_global_ev_data_explorer_2026.csv) was pulled from the
IEA's public EV data API (https://api.iea.org/evs?year=YYYY, one call per year,
2010-2035) on 2026-09-02. It is the same data that backs the IEA "Global EV Data
Explorer" (Global EV Outlook 2026 edition, last updated 20 May 2026, CC BY 4.0).

Outputs
- data/ev_cars_by_region.csv        : long tidy table (region x year) for cars
- data/ev_share_by_country_latest.csv: latest-year EV sales share per country + ISO3
- data/iea_projections_2035.csv     : IEA STEPS / CPS projections for 2035 (cars)

Run:  python src/prepare_data.py
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RAW = DATA / "iea_global_ev_data_explorer_2026.csv"

# IEA region name -> ISO-3166 alpha-3 (needed by the Plotly choropleth).
# Aggregates (World, Europe, EU, ...) are intentionally left out of the map.
ISO3 = {
    "Argentina": "ARG", "Australia": "AUS", "Austria": "AUT", "Belgium": "BEL",
    "Brazil": "BRA", "Bulgaria": "BGR", "Cambodia": "KHM", "Canada": "CAN",
    "Chile": "CHL", "China": "CHN", "Colombia": "COL", "Costa Rica": "CRI",
    "Croatia": "HRV", "Cyprus": "CYP", "Czech Republic": "CZE", "Denmark": "DNK",
    "Estonia": "EST", "Finland": "FIN", "France": "FRA", "Germany": "DEU",
    "Greece": "GRC", "Hungary": "HUN", "Iceland": "ISL", "India": "IND",
    "Indonesia": "IDN", "Ireland": "IRL", "Israel": "ISR", "Italy": "ITA",
    "Japan": "JPN", "Jordan": "JOR", "Korea": "KOR", "Lao PDR": "LAO",
    "Latvia": "LVA", "Lithuania": "LTU", "Luxembourg": "LUX", "Malaysia": "MYS",
    "Mexico": "MEX", "Nepal": "NPL", "Netherlands": "NLD", "New Zealand": "NZL",
    "Norway": "NOR", "Philippines": "PHL", "Poland": "POL", "Portugal": "PRT",
    "Romania": "ROU", "Russia": "RUS", "Seychelles": "SYC", "Singapore": "SGP",
    "Slovakia": "SVK", "Slovenia": "SVN", "South Africa": "ZAF", "Spain": "ESP",
    "Sweden": "SWE", "Switzerland": "CHE", "Thailand": "THA", "Turkiye": "TUR",
    "USA": "USA", "Ukraine": "UKR", "United Arab Emirates": "ARE",
    "United Kingdom": "GBR", "Uruguay": "URY", "Uzbekistan": "UZB", "Viet Nam": "VNM",
}

SOURCE_URL = "https://www.iea.org/data-and-statistics/data-tools/global-ev-data-explorer"


def load_raw() -> pd.DataFrame:
    df = pd.read_csv(RAW)
    df = df[df["region"].astype(str).str.strip() != ""]
    return df


def build_region_table(df: pd.DataFrame) -> pd.DataFrame:
    cars = df[(df["mode"] == "Cars") & (df["category"] == "Historical")]

    def series(param: str, powertrain: str, name: str) -> pd.DataFrame:
        s = cars[(cars["parameter"] == param) & (cars["powertrain"] == powertrain)]
        return s[["region", "year", "value"]].rename(columns={"value": name})

    out = series("EV sales", "EV", "ev_sales")
    for p, name in [("BEV", "bev_sales"), ("PHEV", "phev_sales")]:
        out = out.merge(series("EV sales", p, name), on=["region", "year"], how="left")
    out = out.merge(series("EV sales share", "EV", "ev_sales_share_pct"), on=["region", "year"], how="left")
    out = out.merge(series("EV stock", "EV", "ev_stock"), on=["region", "year"], how="left")
    out = out.merge(series("EV stock share", "EV", "ev_stock_share_pct"), on=["region", "year"], how="left")
    # Implied total car market = EV sales / share
    out["implied_total_car_sales"] = (out["ev_sales"] / (out["ev_sales_share_pct"] / 100.0)).round(0)
    out["iso3"] = out["region"].map(ISO3)
    out["source"] = SOURCE_URL
    out = out.sort_values(["region", "year"]).reset_index(drop=True)
    return out


def build_country_latest(region_table: pd.DataFrame) -> pd.DataFrame:
    t = region_table.dropna(subset=["iso3", "ev_sales_share_pct"])
    latest = t.sort_values("year").groupby("region").tail(1)
    cols = ["region", "iso3", "year", "ev_sales", "ev_sales_share_pct", "ev_stock", "ev_stock_share_pct", "source"]
    return latest[cols].sort_values("ev_sales_share_pct", ascending=False).reset_index(drop=True)


def build_projections(df: pd.DataFrame) -> pd.DataFrame:
    proj = df[(df["mode"] == "Cars") & (df["category"].str.startswith("Projection"))
              & (df["parameter"].isin(["EV sales", "EV sales share", "EV stock"]))
              & (df["powertrain"] == "EV")]
    proj = proj[["region", "category", "parameter", "year", "unit", "value"]].copy()
    proj["scenario"] = proj["category"].str.replace("Projection-", "", regex=False)
    proj["source"] = SOURCE_URL
    return proj.drop(columns="category").sort_values(["region", "scenario", "parameter"]).reset_index(drop=True)


def main() -> None:
    df = load_raw()
    region_table = build_region_table(df)
    region_table.to_csv(DATA / "ev_cars_by_region.csv", index=False)
    country_latest = build_country_latest(region_table)
    country_latest.to_csv(DATA / "ev_share_by_country_latest.csv", index=False)
    proj = build_projections(df)
    proj.to_csv(DATA / "iea_projections_2035.csv", index=False)
    print(f"regions: {region_table['region'].nunique()}, rows: {len(region_table)}, "
          f"years {region_table['year'].min()}-{region_table['year'].max()}")
    print(f"countries on map: {len(country_latest)}; projections rows: {len(proj)}")


if __name__ == "__main__":
    main()
