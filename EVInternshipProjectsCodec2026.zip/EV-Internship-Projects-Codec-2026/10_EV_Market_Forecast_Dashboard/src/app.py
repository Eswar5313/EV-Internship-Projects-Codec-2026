"""
app.py
------
EV Market Forecast Dashboard (Dash).

Run:  python src/app.py   then open http://127.0.0.1:8050

Tabs: Overview / Forecast / Map / Policies / Data & Sources
Controls (Forecast tab): region dropdown, model selector, forecast-horizon slider,
policy-scenario slider (shifts growth rate +-30% and saturation +-10%), and a
saturation-ceiling slider used by the fixed-ceiling logistic model.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
from dash import Dash, dcc, html, Input, Output, dash_table

sys.path.insert(0, str(Path(__file__).resolve().parent))

from load_data import (available_regions, load_country_latest, load_policies, load_sources,  # noqa: E402
                       load_region_table, FORECAST_REGIONS)
from models import MODEL_LABELS, forecast, holdout_rmse  # noqa: E402
import figures as F  # noqa: E402

app = Dash(__name__, title="EV Market Forecast Dashboard", suppress_callback_exceptions=True)
server = app.server

REGIONS = available_regions()
YEAR_MAX = int(load_region_table()["year"].max())

CARD = {"background": "#fff", "borderRadius": "10px", "padding": "14px 18px",
        "boxShadow": "0 1px 4px rgba(0,0,0,0.08)", "marginBottom": "16px"}
KPI = {"flex": "1", "minWidth": "170px", "background": "#fff", "borderRadius": "10px", "padding": "14px",
       "boxShadow": "0 1px 4px rgba(0,0,0,0.08)", "textAlign": "center"}


def kpi(label: str, value: str, sub: str = "") -> html.Div:
    return html.Div([html.Div(label, style={"fontSize": "12px", "color": "#666", "textTransform": "uppercase"}),
                     html.Div(value, style={"fontSize": "26px", "fontWeight": "700", "color": "#2c3e50"}),
                     html.Div(sub, style={"fontSize": "12px", "color": "#888"})], style=KPI)


def overview_kpis() -> html.Div:
    df = load_region_table()
    w = df[df["region"] == "World"].set_index("year")
    cn = df[df["region"] == "China"].set_index("year")
    ind = df[df["region"] == "India"].set_index("year")
    y = YEAR_MAX
    growth = (w.loc[y, "ev_sales"] / w.loc[y - 1, "ev_sales"] - 1) * 100
    return html.Div([
        kpi(f"Global EV car sales {y}", f"{w.loc[y, 'ev_sales'] / 1e6:.1f} M", f"{growth:+.0f}% vs {y - 1}"),
        kpi(f"Global EV sales share {y}", f"{w.loc[y, 'ev_sales_share_pct']:.0f}%", f"{w.loc[y - 1, 'ev_sales_share_pct']:.0f}% in {y - 1}"),
        kpi(f"China share of global EV sales", f"{cn.loc[y, 'ev_sales'] / w.loc[y, 'ev_sales'] * 100:.0f}%", f"{cn.loc[y, 'ev_sales'] / 1e6:.1f} M cars"),
        kpi(f"India EV share {y}", f"{ind.loc[y, 'ev_sales_share_pct']:.1f}%", f"{ind.loc[y, 'ev_sales']:,.0f} cars"),
        kpi("Global EV stock", f"{w.loc[y, 'ev_stock'] / 1e6:.0f} M", f"{w.loc[y, 'ev_stock_share_pct']:.1f}% of cars on the road"),
    ], style={"display": "flex", "gap": "12px", "flexWrap": "wrap", "marginBottom": "16px"})


# --------------------------------------------------------------------------- #
# Layout
# --------------------------------------------------------------------------- #
header = html.Div([
    html.H1("EV Market Forecast Dashboard", style={"margin": "0", "fontSize": "26px"}),
    html.Div("Global electric-car adoption, government policy and growth-model forecasts to 2035 · "
             "Data: IEA Global EV Data Explorer (GEO 2026 edition, CC BY 4.0) · "
             "Eswar Mahalingam, Codec Technologies India internship, Sept 2026",
             style={"color": "#dfe6ec", "fontSize": "13px", "marginTop": "4px"}),
], style={"background": "#2c3e50", "color": "#fff", "padding": "18px 28px"})

controls = html.Div([
    html.Div([html.Label("Region", style={"fontWeight": "600"}),
              dcc.Dropdown(id="region", options=[{"label": r, "value": r} for r in REGIONS], value="World",
                           clearable=False)], style={"flex": "1", "minWidth": "180px"}),
    html.Div([html.Label("Growth model", style={"fontWeight": "600"}),
              dcc.Dropdown(id="model", options=[{"label": v, "value": k} for k, v in MODEL_LABELS.items()],
                           value="logistic_fixed", clearable=False)], style={"flex": "1.4", "minWidth": "240px"}),
    html.Div([html.Label("Forecast horizon", style={"fontWeight": "600"}),
              dcc.Slider(id="horizon", min=YEAR_MAX + 1, max=2035, step=1, value=2035,
                         marks={y: str(y) for y in range(YEAR_MAX + 1, 2036, 2)})], style={"flex": "1.4", "minWidth": "240px"}),
    html.Div([html.Label("Policy scenario (−1 rollback … +1 strong support)", style={"fontWeight": "600"}),
              dcc.Slider(id="policy", min=-1, max=1, step=0.1, value=0,
                         marks={-1: "−1", -0.5: "−0.5", 0: "0", 0.5: "+0.5", 1: "+1"})], style={"flex": "1.4", "minWidth": "240px"}),
    html.Div([html.Label("Saturation ceiling % (fixed-ceiling logistic)", style={"fontWeight": "600"}),
              dcc.Slider(id="ceiling", min=30, max=100, step=5, value=100,
                         marks={30: "30", 50: "50", 70: "70", 85: "85", 100: "100"})], style={"flex": "1.2", "minWidth": "200px"}),
], style={**CARD, "display": "flex", "gap": "18px", "flexWrap": "wrap", "alignItems": "flex-end"})


def sources_table() -> html.Div:
    src = load_sources()
    src["url"] = src["url"].map(lambda u: f"[link]({u})")
    return dash_table.DataTable(
        data=src.to_dict("records"),
        columns=[{"name": c, "id": c, "presentation": "markdown"} if c == "url" else {"name": c, "id": c} for c in src.columns],
        style_cell={"textAlign": "left", "whiteSpace": "normal", "height": "auto", "fontSize": "12px",
                    "fontFamily": "inherit", "maxWidth": "420px"},
        style_header={"fontWeight": "700", "background": "#f0f3f5"}, page_size=10)


def policies_table() -> html.Div:
    pol = load_policies().copy()
    pol["source_url"] = pol["source_url"].map(lambda u: f"[source]({u})")
    cols = ["policy_id", "country", "year", "type", "direction", "policy", "summary", "source_url"]
    return dash_table.DataTable(
        data=pol[cols].to_dict("records"),
        columns=[{"name": c, "id": c, "presentation": "markdown"} if c == "source_url" else {"name": c, "id": c} for c in cols],
        style_cell={"textAlign": "left", "whiteSpace": "normal", "height": "auto", "fontSize": "12px", "fontFamily": "inherit"},
        style_header={"fontWeight": "700", "background": "#f0f3f5"},
        style_data_conditional=[{"if": {"filter_query": '{direction} = "Weakening"'}, "backgroundColor": "#fdecea"},
                                {"if": {"filter_query": '{direction} = "Support"'}, "backgroundColor": "#eafaf1"}],
        page_size=20, sort_action="native", filter_action="native")


def data_table() -> html.Div:
    df = load_region_table()
    df = df[df["region"].isin(FORECAST_REGIONS) & (df["year"] >= 2015)]
    cols = ["region", "year", "ev_sales", "bev_sales", "phev_sales", "ev_sales_share_pct", "ev_stock", "ev_stock_share_pct"]
    return dash_table.DataTable(data=df[cols].round(2).to_dict("records"), columns=[{"name": c, "id": c} for c in cols],
                                style_cell={"textAlign": "left", "fontSize": "12px", "fontFamily": "inherit"},
                                style_header={"fontWeight": "700", "background": "#f0f3f5"},
                                page_size=15, sort_action="native", filter_action="native", export_format="csv")


app.layout = html.Div([
    header,
    html.Div([
        dcc.Tabs(id="tabs", value="overview", children=[
            dcc.Tab(label="Overview", value="overview"),
            dcc.Tab(label="Forecast", value="forecast"),
            dcc.Tab(label="Map", value="map"),
            dcc.Tab(label="Policies", value="policies"),
            dcc.Tab(label="Data & Sources", value="data"),
        ], style={"marginBottom": "14px"}),
        html.Div(id="tab-content"),
    ], style={"padding": "18px 28px", "maxWidth": "1400px", "margin": "0 auto"}),
    html.Div("Growth models are fitted on IEA historical sales-share data (2015-" + str(YEAR_MAX) + "); forecasts are "
             "illustrative and not IEA projections. IEA STEPS/CPS 2035 points are shown as diamonds for comparison.",
             style={"color": "#888", "fontSize": "12px", "textAlign": "center", "padding": "10px 0 24px"}),
], style={"fontFamily": "Inter, Segoe UI, Helvetica, Arial, sans-serif", "background": "#f4f6f8", "minHeight": "100vh"})


# --------------------------------------------------------------------------- #
# Callbacks
# --------------------------------------------------------------------------- #
@app.callback(Output("tab-content", "children"), Input("tabs", "value"))
def render_tab(tab):
    if tab == "overview":
        return html.Div([
            overview_kpis(),
            html.Div(dcc.Graph(figure=F.fig_global_sales_stacked()), style=CARD),
            html.Div([html.Div(dcc.Graph(figure=F.fig_scurve_fits()), style={**CARD, "flex": "1.3", "minWidth": "420px"}),
                      html.Div(dcc.Graph(figure=F.fig_powertrain_mix("World")), style={**CARD, "flex": "1", "minWidth": "360px"})],
                     style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
        ])
    if tab == "forecast":
        return html.Div([
            controls,
            html.Div(dcc.Graph(id="fig-share"), style=CARD),
            html.Div(id="fit-summary", style={**CARD, "fontSize": "13px"}),
            html.Div([html.Div(dcc.Graph(id="fig-sales"), style={**CARD, "flex": "1", "minWidth": "400px"}),
                      html.Div(dcc.Graph(id="fig-compare"), style={**CARD, "flex": "1", "minWidth": "400px"})],
                     style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
            html.Div([html.H4("Forecast table", style={"margin": "0 0 8px"}), html.Div(id="forecast-table")], style=CARD),
        ])
    if tab == "map":
        return html.Div([
            html.Div(dcc.Graph(figure=F.fig_choropleth(), config={"topojsonURL": "/assets/"}), style=CARD),
            html.Div([html.Div(dcc.Graph(figure=F.fig_country_ranking(25, "ev_sales_share_pct")), style={**CARD, "flex": "1", "minWidth": "400px"}),
                      html.Div(dcc.Graph(figure=F.fig_country_ranking(25, "ev_sales")), style={**CARD, "flex": "1", "minWidth": "400px"})],
                     style={"display": "flex", "gap": "16px", "flexWrap": "wrap"}),
        ])
    if tab == "policies":
        return html.Div([
            html.Div(dcc.Graph(figure=F.fig_policy_timeline()), style=CARD),
            html.Div([html.H4("Policy register (20 sourced events)", style={"margin": "0 0 8px"}), policies_table()], style=CARD),
        ])
    return html.Div([
        html.Div([html.H4("Data provenance", style={"margin": "0 0 8px"}),
                  html.P("Every dataset in data/ is listed here with its publisher, edition, licence and how it was obtained. "
                         "The headline series come straight from the IEA Global EV Data Explorer API; nothing was estimated by hand."),
                  sources_table()], style=CARD),
        html.Div([html.H4("Historical series used for modelling (cars, BEV+PHEV)", style={"margin": "0 0 8px"}), data_table()], style=CARD),
    ])


@app.callback(
    Output("fig-share", "figure"), Output("fig-sales", "figure"), Output("fig-compare", "figure"),
    Output("fit-summary", "children"), Output("forecast-table", "children"),
    Input("region", "value"), Input("model", "value"), Input("horizon", "value"),
    Input("policy", "value"), Input("ceiling", "value"))
def update_forecast(region, model, horizon, policy, ceiling):
    fig_share = F.fig_share_forecast(region, model, horizon, policy, ceiling)
    fig_sales = F.fig_sales_forecast(region, model, horizon, policy, ceiling)
    fig_cmp = F.fig_model_comparison(region, horizon, policy, ceiling)
    tab, res = forecast(region, model, horizon, policy, ceiling)
    ho = holdout_rmse(region, model, ceiling=ceiling)
    params = ", ".join(f"{k} = {v:.4g}" for k, v in res.params.items())
    ses = ", ".join(f"±{v:.2g}" for v in res.param_se.values()) if res.param_se else "n/a"
    fut = tab[tab["is_forecast"]]
    end_share = float(fut["share_pct"].iloc[-1]); end_year = int(fut["year"].iloc[-1])
    summary = html.Div([
        html.B(f"{MODEL_LABELS[model]} — {region}"), html.Br(),
        f"Fitted parameters: {params}  (std. errors: {ses}). {res.notes}", html.Br(),
        f"In-sample RMSE {res.rmse_in_sample:.2f} pp, R² {res.r2_in_sample:.3f}; "
        f"hold-out RMSE (fit ≤2022, test 2023-{YEAR_MAX}) {ho:.2f} pp.", html.Br(),
        f"Forecast: EV share {end_share:.1f}% in {end_year} "
        f"(band {float(fut['share_lo'].iloc[-1]):.1f}–{float(fut['share_hi'].iloc[-1]):.1f}%), "
        f"≈ {float(fut['ev_sales_forecast'].iloc[-1]) / 1e6:.2f} M electric cars, assuming the total car market grows "
        f"{(tab['total_market_assumed'].iloc[-1] / tab['total_market_assumed'].iloc[-2] - 1) * 100:.1f}%/yr. "
        + (f"Policy scenario {policy:+.1f} applied (growth rate ×{1 + 0.3 * policy:.2f}, saturation ×{1 + 0.1 * policy:.2f})." if policy else ""),
    ])
    cols = ["year", "share_observed", "share_pct", "share_lo", "share_hi", "ev_sales_observed", "ev_sales_forecast"]
    table = dash_table.DataTable(data=tab[cols].round(2).to_dict("records"), columns=[{"name": c, "id": c} for c in cols],
                                 style_cell={"textAlign": "left", "fontSize": "12px", "fontFamily": "inherit"},
                                 style_header={"fontWeight": "700", "background": "#f0f3f5"}, page_size=25,
                                 export_format="csv")
    return fig_share, fig_sales, fig_cmp, summary, table


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8050))
    app.run(debug=False, host="127.0.0.1", port=port)
