"""
load_data.py
------------
Single entry point for reading the CSVs in data/. Every other module imports
from here so that paths and cleaning rules live in one place.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"

# Regions used for the forecast models (all have complete 2015-2025 series).
FORECAST_REGIONS = ["World", "China", "Europe", "USA", "India"]
KEY_COLUMNS = ["region", "year", "ev_sales", "ev_sales_share_pct"]


@lru_cache(maxsize=None)
def load_region_table() -> pd.DataFrame:
    """Car-only, region x year tidy table derived from the IEA explorer."""
    df = pd.read_csv(DATA_DIR / "ev_cars_by_region.csv")
    df["year"] = df["year"].astype(int)
    return df


def get_series(region: str, start_year: int = 2010) -> pd.DataFrame:
    df = load_region_table()
    s = df[(df["region"] == region) & (df["year"] >= start_year)].dropna(subset=KEY_COLUMNS)
    return s.sort_values("year").reset_index(drop=True)


@lru_cache(maxsize=None)
def load_country_latest() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "ev_share_by_country_latest.csv")
    return df.dropna(subset=["iso3", "ev_sales_share_pct"]).reset_index(drop=True)


@lru_cache(maxsize=None)
def load_projections() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "iea_projections_2035.csv")


@lru_cache(maxsize=None)
def load_policies() -> pd.DataFrame:
    df = pd.read_csv(DATA_DIR / "policies.csv")
    df["year"] = df["year"].astype(int)
    df["end_year"] = df["end_year"].fillna(df["year"] + 1).astype(int)
    return df


@lru_cache(maxsize=None)
def load_sources() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "sources.csv")


def available_regions() -> list[str]:
    df = load_region_table()
    counts = df.dropna(subset=KEY_COLUMNS).groupby("region")["year"].nunique()
    good = counts[counts >= 8].index.tolist()
    # Put the headline regions first, then the rest alphabetically
    rest = sorted(r for r in good if r not in FORECAST_REGIONS)
    return [r for r in FORECAST_REGIONS if r in good] + rest


if __name__ == "__main__":
    t = load_region_table()
    print(t.head())
    print("regions:", len(available_regions()))
    print(load_policies()[["country", "year", "policy"]])
