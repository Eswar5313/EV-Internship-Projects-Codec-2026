"""
models.py
---------
Growth models for the EV sales-share series (percentage of new car sales that
are BEV+PHEV) fitted with scipy.optimize.curve_fit.

Models
- logistic : s(t) = L / (1 + exp(-k (t - t0)))               (3 params L, k, t0, all free)
- logistic_fixed : same curve with L fixed to a ceiling (default 100% = every new car
             electric) so only k and t0 are fitted. With only 11 annual points the free
             fit tends to put L right at the latest observation, so both views are kept.
- bass     : s(t) = m * F(t),  F(t) = (1 - e^{-(p+q)tau}) / (1 + (q/p) e^{-(p+q)tau}),
             tau = t - t_start                                (3 params m, p, q)
             Interpreted as "share of the car-buying population that has switched
             to buying an EV" (m = eventual ceiling of that share).
- cagr     : s(t) = s_last * (1 + g)^(t - t_last), g = CAGR of last N years, capped 100%
- exponential: s(t) = a * exp(b t)   (least squares on log share), capped 100%
- linear   : s(t) = a + b t, clipped to [0, 100]

The `policy_factor` argument (-1 .. +1) is the dashboard's "policy scenario"
slider: it scales the fitted growth rate (k, or p+q) and the saturation level.

Run `python src/models.py` to fit every model for World/China/Europe/USA/India,
print the parameters and write results/forecast_table.csv + results/model_params.json.
"""
from __future__ import annotations

import json
import warnings
from dataclasses import dataclass, field, asdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit, OptimizeWarning

try:  # allow both `python src/models.py` and `from src import models`
    from load_data import get_series, FORECAST_REGIONS, RESULTS_DIR
except ImportError:  # pragma: no cover
    from src.load_data import get_series, FORECAST_REGIONS, RESULTS_DIR

MODEL_NAMES = ["logistic", "logistic_fixed", "bass", "cagr", "exponential", "linear"]
MODEL_LABELS = {
    "logistic": "Logistic S-curve (free saturation)",
    "logistic_fixed": "Logistic S-curve (fixed ceiling)",
    "bass": "Bass diffusion",
    "cagr": "CAGR extrapolation",
    "exponential": "Exponential",
    "linear": "Linear",
}
FIT_START_YEAR = 2015     # first year used to fit share models
CAGR_WINDOW = 5           # years used for the CAGR estimate
TOTAL_MARKET_GROWTH_CAP = (-0.01, 0.03)  # allowed annual growth of the total car market


# --------------------------------------------------------------------------- #
# Model functions
# --------------------------------------------------------------------------- #
def logistic(t, L, k, t0):
    return L / (1.0 + np.exp(-k * (t - t0)))


def bass_F(tau, p, q):
    e = np.exp(-(p + q) * tau)
    return (1.0 - e) / (1.0 + (q / p) * e)


def bass(t, m, p, q, t_start=FIT_START_YEAR - 1):
    return m * bass_F(t - t_start, p, q)


# --------------------------------------------------------------------------- #
# Results container
# --------------------------------------------------------------------------- #
@dataclass
class FitResult:
    region: str
    model: str
    params: dict = field(default_factory=dict)
    param_se: dict = field(default_factory=dict)
    rmse_in_sample: float = float("nan")
    r2_in_sample: float = float("nan")
    rmse_holdout: float = float("nan")      # train <= 2022, test 2023-2025
    fit_years: tuple = (FIT_START_YEAR, 2025)
    policy_factor: float = 0.0
    notes: str = ""

    def to_dict(self):
        d = asdict(self)
        d["fit_years"] = list(self.fit_years)
        return d


# --------------------------------------------------------------------------- #
# Fitting
# --------------------------------------------------------------------------- #
def _metrics(y, yhat):
    resid = np.asarray(y) - np.asarray(yhat)
    rmse = float(np.sqrt(np.mean(resid ** 2)))
    ss_tot = float(np.sum((np.asarray(y) - np.mean(y)) ** 2))
    r2 = 1.0 - float(np.sum(resid ** 2)) / ss_tot if ss_tot > 0 else float("nan")
    return rmse, r2


def _fit_logistic(t, y, L_fixed: float | None = None):
    if L_fixed is None:
        L0 = min(100.0, max(y.max() * 1.5, 5.0))
        p0 = [L0, 0.4, float(t[np.argmin(np.abs(y - y.max() / 2))])]
        lower = [max(y.max(), 1e-3), 0.01, t.min() - 10]
        upper = [100.0, 3.0, t.max() + 40]
        p0 = np.clip(p0, lower, upper)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", OptimizeWarning)
            popt, pcov = curve_fit(logistic, t, y, p0=p0, bounds=(lower, upper), maxfev=20000)
        return popt, pcov
    L = float(L_fixed)

    def f(tt, k, t0):
        return logistic(tt, L, k, t0)

    p0 = [0.4, float(t.max()) + 3]
    lower, upper = [0.01, t.min() - 10], [3.0, t.max() + 60]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", OptimizeWarning)
        popt, pcov = curve_fit(f, t, y, p0=p0, bounds=(lower, upper), maxfev=20000)
    popt = np.array([L, popt[0], popt[1]])
    full = np.full((3, 3), 0.0)
    full[1:, 1:] = pcov
    return popt, full


def _fit_bass(t, y):
    p0 = [min(100.0, max(y.max() * 1.5, 5.0)), 0.01, 0.5]
    lower = [max(y.max(), 1e-3), 1e-5, 1e-3]
    upper = [100.0, 0.5, 3.0]
    p0 = np.clip(p0, lower, upper)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", OptimizeWarning)
        popt, pcov = curve_fit(bass, t, y, p0=p0, bounds=(lower, upper), maxfev=20000)
    return popt, pcov


def fit_share_model(region: str, model: str, *, end_year: int | None = None,
                    ceiling: float = 100.0) -> tuple[FitResult, np.ndarray, np.ndarray]:
    """Fit `model` to the sales-share series. Returns (FitResult, t, y).
    `ceiling` is only used by logistic_fixed (saturation level in %)."""
    s = get_series(region, FIT_START_YEAR)
    if end_year is not None:
        s = s[s["year"] <= end_year]
    t = s["year"].to_numpy(dtype=float)
    y = s["ev_sales_share_pct"].to_numpy(dtype=float)
    res = FitResult(region=region, model=model, fit_years=(int(t.min()), int(t.max())))

    if model in ("logistic", "logistic_fixed"):
        L_fixed = None if model == "logistic" else max(float(ceiling), float(y.max()) + 1e-6)
        popt, pcov = _fit_logistic(t, y, L_fixed)
        se = np.sqrt(np.clip(np.diag(pcov), 0, None)) if np.all(np.isfinite(pcov)) else np.full(3, np.nan)
        res.params = {"L": float(popt[0]), "k": float(popt[1]), "t0": float(popt[2])}
        res.param_se = {"L": float(se[0]), "k": float(se[1]), "t0": float(se[2])}
        if model == "logistic_fixed":
            res.notes = f"L fixed at {L_fixed:.1f}% (not fitted)"
        yhat = logistic(t, *popt)
    elif model == "bass":
        popt, pcov = _fit_bass(t, y)
        se = np.sqrt(np.clip(np.diag(pcov), 0, None)) if np.all(np.isfinite(pcov)) else np.full(3, np.nan)
        res.params = {"m": float(popt[0]), "p": float(popt[1]), "q": float(popt[2]), "t_start": FIT_START_YEAR - 1}
        res.param_se = {"m": float(se[0]), "p": float(se[1]), "q": float(se[2])}
        yhat = bass(t, *popt)
    elif model == "cagr":
        n = min(CAGR_WINDOW, len(y) - 1)
        g = (y[-1] / y[-1 - n]) ** (1.0 / n) - 1.0
        res.params = {"g": float(g), "s_last": float(y[-1]), "t_last": float(t[-1]), "window_years": int(n)}
        yhat = y[-1] * (1 + g) ** (t - t[-1])
        res.notes = f"CAGR over {int(t[-1-n])}-{int(t[-1])}; extrapolation capped at 100%"
    elif model == "exponential":
        b, loga = np.polyfit(t - t[0], np.log(np.maximum(y, 1e-6)), 1)
        res.params = {"a": float(np.exp(loga)), "b": float(b), "t_ref": float(t[0])}
        yhat = np.exp(loga) * np.exp(b * (t - t[0]))
        res.notes = "least squares on log(share); capped at 100%"
    elif model == "linear":
        b, a = np.polyfit(t - t[0], y, 1)
        res.params = {"a": float(a), "b": float(b), "t_ref": float(t[0])}
        yhat = a + b * (t - t[0])
    else:
        raise ValueError(f"unknown model {model}")

    res.rmse_in_sample, res.r2_in_sample = _metrics(y, yhat)
    return res, t, y


def predict_share(res: FitResult, years: np.ndarray, policy_factor: float = 0.0) -> np.ndarray:
    """Evaluate a fitted model at `years`, applying the policy scenario factor."""
    years = np.asarray(years, dtype=float)
    p = res.params
    f = float(np.clip(policy_factor, -1, 1))
    growth_mult = 1.0 + 0.30 * f          # +-30% on growth rate at the slider extremes
    sat_mult = 1.0 + 0.10 * f             # +-10% on saturation level
    if res.model in ("logistic", "logistic_fixed"):
        if f == 0.0:
            out = logistic(years, p["L"], p["k"], p["t0"])
        else:
            L = min(100.0, p["L"] * sat_mult)
            k = p["k"] * growth_mult
            # Anchor the scenario curve at the last observed year so that only the
            # future changes: s(t_last) is preserved, and t0 is re-solved for the new (L, k).
            t_last = res.fit_years[1]
            s_last = min(logistic(t_last, p["L"], p["k"], p["t0"]), L * 0.999)
            t0 = t_last + np.log(L / s_last - 1.0) / k
            base = logistic(years, L, k, t0)
            hist = logistic(years, p["L"], p["k"], p["t0"])
            out = np.where(years <= t_last, hist, base)
    elif res.model == "bass":
        m = min(100.0, p["m"] * sat_mult)
        pp, q = p["p"] * growth_mult, p["q"] * growth_mult
        out = bass(years, m, pp, q, p["t_start"])
    elif res.model == "cagr":
        g = p["g"] * growth_mult
        out = p["s_last"] * (1 + g) ** (years - p["t_last"])
    elif res.model == "exponential":
        out = p["a"] * np.exp(p["b"] * growth_mult * (years - p["t_ref"]))
    elif res.model == "linear":
        out = p["a"] + p["b"] * growth_mult * (years - p["t_ref"])
    else:
        raise ValueError(res.model)
    return np.clip(out, 0.0, 100.0)


def confidence_band(res: FitResult, years: np.ndarray, policy_factor: float = 0.0,
                    n_draws: int = 400, seed: int = 42) -> tuple[np.ndarray, np.ndarray]:
    """5-95% band. For logistic/bass: parametric bootstrap from curve_fit's covariance
    (parameters resampled, then predicted). For the simpler models: a residual-based
    band that widens with the horizon."""
    rng = np.random.default_rng(seed)
    years = np.asarray(years, dtype=float)
    base = predict_share(res, years, policy_factor)
    if res.model in ("logistic", "logistic_fixed", "bass") and all(np.isfinite(v) for v in res.param_se.values()):
        draws = []
        keys = ["L", "k", "t0"] if res.model.startswith("logistic") else ["m", "p", "q"]
        for _ in range(n_draws):
            pr = dict(res.params)
            for kname in keys:
                se = res.param_se[kname]
                pr[kname] = res.params[kname] + rng.normal(0, se * 0.5)  # damped SE (fits are correlated)
            # keep parameters physically valid
            if res.model.startswith("logistic"):
                pr["L"] = float(np.clip(pr["L"], 1, 100)); pr["k"] = max(pr["k"], 0.01)
            else:
                pr["m"] = float(np.clip(pr["m"], 1, 100)); pr["p"] = max(pr["p"], 1e-5); pr["q"] = max(pr["q"], 1e-3)
            tmp = FitResult(res.region, res.model, params=pr, param_se=res.param_se, fit_years=res.fit_years)
            draws.append(predict_share(tmp, years, policy_factor))
        draws = np.vstack(draws)
        lo, hi = np.percentile(draws, 5, axis=0), np.percentile(draws, 95, axis=0)
        # never let the band exclude the central path
        return np.minimum(lo, base), np.maximum(hi, base)
    horizon = np.maximum(years - res.fit_years[1], 0)
    width = 1.645 * res.rmse_in_sample * np.sqrt(1 + horizon)
    return np.clip(base - width, 0, 100), np.clip(base + width, 0, 100)


def holdout_rmse(region: str, model: str, train_end: int = 2022, ceiling: float = 100.0) -> float:
    """Fit on years <= train_end and score on the later observed years."""
    try:
        res, _, _ = fit_share_model(region, model, end_year=train_end, ceiling=ceiling)
    except Exception:
        return float("nan")
    s = get_series(region, train_end + 1)
    if s.empty:
        return float("nan")
    pred = predict_share(res, s["year"].to_numpy())
    return float(np.sqrt(np.mean((s["ev_sales_share_pct"].to_numpy() - pred) ** 2)))


def total_market_growth(region: str) -> float:
    """Annual growth of the implied total car market over the last decade, capped."""
    s = get_series(region, FIT_START_YEAR)
    tot = s["implied_total_car_sales"].to_numpy(dtype=float)
    n = len(tot) - 1
    g = (tot[-1] / tot[0]) ** (1.0 / n) - 1.0 if n > 0 and tot[0] > 0 else 0.0
    return float(np.clip(g, *TOTAL_MARKET_GROWTH_CAP))


def forecast(region: str, model: str, horizon_end: int = 2035, policy_factor: float = 0.0,
             ceiling: float = 100.0) -> tuple[pd.DataFrame, FitResult]:
    """Full forecast table (history + future) for one region/model."""
    res, t, y = fit_share_model(region, model, ceiling=ceiling)
    hist = get_series(region, FIT_START_YEAR)
    last_year = int(t.max())
    future_years = np.arange(last_year + 1, horizon_end + 1)
    all_years = np.concatenate([t, future_years])
    share = predict_share(res, all_years, policy_factor)
    lo, hi = confidence_band(res, all_years, policy_factor)

    g_tot = total_market_growth(region)
    tot_last = float(hist["implied_total_car_sales"].iloc[-1])
    total = tot_last * (1 + g_tot) ** (all_years - last_year)
    ev_sales = share / 100.0 * total

    out = pd.DataFrame({
        "region": region, "model": model, "year": all_years.astype(int),
        "share_pct": share, "share_lo": lo, "share_hi": hi,
        "ev_sales_forecast": ev_sales, "total_market_assumed": total,
        "is_forecast": all_years > last_year,
    })
    obs = hist.set_index("year")
    out["share_observed"] = out["year"].map(obs["ev_sales_share_pct"])
    out["ev_sales_observed"] = out["year"].map(obs["ev_sales"])
    res.policy_factor = policy_factor
    return out, res


def fit_all(regions=FORECAST_REGIONS, horizon_end: int = 2035, policy_factor: float = 0.0) -> tuple[pd.DataFrame, list[FitResult]]:
    tables, fits = [], []
    for r in regions:
        for m in MODEL_NAMES:
            tab, res = forecast(r, m, horizon_end, policy_factor)
            res.rmse_holdout = holdout_rmse(r, m)
            tables.append(tab)
            fits.append(res)
    return pd.concat(tables, ignore_index=True), fits


def save_results(table: pd.DataFrame, fits: list[FitResult], results_dir: Path = RESULTS_DIR) -> None:
    results_dir.mkdir(parents=True, exist_ok=True)
    table.round(4).to_csv(results_dir / "forecast_table.csv", index=False)
    with open(results_dir / "model_params.json", "w") as fh:
        json.dump([f.to_dict() for f in fits], fh, indent=2)


def main() -> None:
    table, fits = fit_all()
    save_results(table, fits)
    pd.set_option("display.width", 160)
    for f in fits:
        p = ", ".join(f"{k}={v:.4g}" for k, v in f.params.items())
        print(f"{f.region:7s} {f.model:12s} RMSE={f.rmse_in_sample:5.2f} R2={f.r2_in_sample:5.3f} "
              f"holdout RMSE={f.rmse_holdout:5.2f} | {p}")
    piv = table[table["year"].isin([2025, 2030, 2035])].pivot_table(
        index=["region", "model"], columns="year", values="share_pct").round(1)
    print("\nEV sales share forecast (%):\n", piv)
    print(f"\nwritten {RESULTS_DIR/'forecast_table.csv'} and model_params.json")


if __name__ == "__main__":
    main()
