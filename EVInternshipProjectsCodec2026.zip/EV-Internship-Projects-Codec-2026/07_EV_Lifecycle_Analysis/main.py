"""
EV cradle-to-grave screening LCA.   Run:  python main.py   (regenerates results/ in ~3 s)
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import time
from dataclasses import asdict
from pathlib import Path

import pandas as pd

from src import config as C
from src.excel_report import build_workbook
from src.lca import break_even_km, materials_table, run_lca, sensitivity_tornado
from src.plots import plot_break_even, plot_energy, plot_stacked_phases, plot_tornado

PAIRS = [(C.NEXON_EV, C.NEXON_PETROL), (C.E_SCOOTER, C.PETROL_SCOOTER)]
VEHICLES = [v for pair in PAIRS for v in pair]


def recalc_check(xlsx: Path) -> dict:
    """Recalculate the workbook with LibreOffice headless (if installed) and scan for error cells."""
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return {"libreoffice_available": False}
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", td, str(xlsx)],
                       capture_output=True, timeout=120)
        out = Path(td) / xlsx.name
        if not out.exists():
            return {"libreoffice_available": True, "recalculated": False}
        from openpyxl import load_workbook
        wb = load_workbook(out, data_only=True)
        errors = [(ws.title, c.coordinate, c.value) for ws in wb for row in ws.iter_rows() for c in row
                  if isinstance(c.value, str) and c.value.startswith("#") and c.value.endswith(("!", "?", "A", "0!"))]
        res_ws = wb["Results"]
        totals = {res_ws.cell(1, j).value: res_ws.cell(7, j).value for j in range(2, 6)}
        be = res_ws["B13"].value
        return {"libreoffice_available": True, "recalculated": True, "error_cells": errors,
                "india_totals_kg_from_formulas": totals, "india_break_even_km_from_formula": be}


def main() -> dict:
    t0 = time.time()
    C.RESULTS_DIR.mkdir(exist_ok=True)

    # 1. phase results for every vehicle x scenario
    rows = []
    for sc in C.SCENARIOS:
        for v in VEHICLES:
            r = run_lca(v, sc)
            rows.append({"scenario": sc, "vehicle": v.name, "powertrain": v.powertrain, "segment": v.segment,
                         "lifetime_km": r.km, **{k: round(x, 1) for k, x in r.phases.items()},
                         "total_kg_co2e": round(r.total_kg, 1), "g_co2e_per_km": round(r.g_per_km, 1),
                         "final_energy_gj": round(r.energy_final_mj / 1000, 1),
                         "primary_energy_gj": round(r.energy_primary_mj / 1000, 1)})
    df = pd.DataFrame(rows)
    df.to_csv(C.RESULTS_DIR / "lca_results.csv", index=False)

    # 2. break-even and reductions
    be = {}
    for ev, ice in PAIRS:
        for sc in C.SCENARIOS:
            be[f"{ev.segment}|{sc}"] = round(break_even_km(ev, ice, sc), 0)
    reductions = {}
    for ev, ice in PAIRS:
        for sc in C.SCENARIOS:
            e, i = run_lca(ev, sc).total_kg, run_lca(ice, sc).total_kg
            reductions[f"{ev.segment}|{sc}"] = round(1 - e / i, 3)

    # 3. sensitivity + materials
    sens = sensitivity_tornado(C.NEXON_EV, C.NEXON_PETROL)
    pd.DataFrame(sens).to_csv(C.RESULTS_DIR / "sensitivity.csv", index=False)
    mats = {v.name: materials_table(v) for v in VEHICLES}
    mats["Tata Nexon EV (30.2 kWh) - LFP chemistry alt."] = materials_table(C.NEXON_EV, "LFP")
    pd.DataFrame(mats).fillna(0).to_csv(C.RESULTS_DIR / "materials_kg.csv")

    # 4. plots
    plot_stacked_phases(PAIRS)
    plot_break_even(C.NEXON_EV, C.NEXON_PETROL)
    plot_tornado(sens)
    plot_energy(PAIRS)

    # 5. workbook + recalculation check
    xlsx = C.RESULTS_DIR / "ev_lca.xlsx"
    build_workbook(xlsx, sens, {v.name: run_lca(v).total_kg for v in VEHICLES})
    check = recalc_check(xlsx)

    summary = {
        "project": "Cradle-to-grave screening LCA: Indian compact EV vs petrol, e-scooter vs petrol scooter",
        "author": "Eswar Mahalingam", "organisation": "Codec Technologies India", "date": "September 2026",
        "method_note": "Screening-level attributional GHG LCA (GWP100), transparent factors; NOT ISO 14040/14044, NOT SimaPro/ecoinvent",
        "functional_unit": {"car": "1 vehicle, 150,000 km, 12 years", "2W": "1 vehicle, 60,000 km, 10 years"},
        "scenarios_grid_g_per_kwh_at_plug": {sc: round(run_lca(C.NEXON_EV, sc).use_kg * 1000 / (150_000 * 0.159), 1) for sc in C.SCENARIOS},
        "vehicles": {v.name: asdict(v) for v in VEHICLES},
        "results_by_scenario": rows,
        "ev_reduction_vs_ice": reductions,
        "break_even_km": be,
        "sensitivity_tornado_india": sens,
        "materials_kg": mats,
        "battery_factor_kg_co2e_per_kwh": {"base": C.BATTERY_FACTOR_BASE, "range": C.BATTERY_FACTOR_RANGE, "all": C.BATTERY_KG_CO2E_PER_KWH},
        "workbook_check": check,
        "sources": [{"id": s[0], "description": s[1], "url": s[2]} for s in C.SOURCES],
        "assumptions": [{"assumption": a, "basis": b} for a, b in C.ASSUMPTIONS],
        "runtime_s": round(time.time() - t0, 1),
    }
    (C.RESULTS_DIR / "summary.json").write_text(json.dumps(summary, indent=2, default=float))

    for r in rows:
        if r["scenario"] == C.BASE_SCENARIO:
            print(f"[India] {r['vehicle'][:38]:38s} {r['total_kg_co2e']/1000:6.2f} t  {r['g_co2e_per_km']:6.1f} g/km")
    print("reductions:", reductions); print("break-even km:", be)
    print("workbook check:", {k: v for k, v in check.items() if k != 'india_totals_kg_from_formulas'})
    print(f"done in {summary['runtime_s']} s -> {C.RESULTS_DIR}")
    return summary


if __name__ == "__main__":
    main()
