"""pytest suite - `pytest -q` from the project folder."""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src import config as C  # noqa: E402
from src.excel_report import build_workbook  # noqa: E402
from src.lca import (break_even_km, grid_at_plug_g_per_kwh, materials_table,  # noqa: E402
                     run_lca, sensitivity_tornado)

INDIA, EU, RE = C.SCENARIOS


def test_phases_sum_to_total():
    for v in (C.NEXON_EV, C.NEXON_PETROL, C.E_SCOOTER, C.PETROL_SCOOTER):
        for sc in C.SCENARIOS:
            r = run_lca(v, sc)
            assert abs(sum(r.phases.values()) - r.total_kg) < 1e-9
            assert abs(r.g_per_km - r.total_kg * 1000 / r.km) < 1e-9


def test_break_even_positive_finite_india():
    be = break_even_km(C.NEXON_EV, C.NEXON_PETROL, INDIA)
    assert np.isfinite(be) and 0 < be < C.NEXON_EV.lifetime_km
    be2 = break_even_km(C.E_SCOOTER, C.PETROL_SCOOTER, INDIA)
    assert np.isfinite(be2) and 0 < be2 < C.E_SCOOTER.lifetime_km


def test_ev_below_ice_under_eu_and_india():
    for sc in (EU, INDIA, RE):
        assert run_lca(C.NEXON_EV, sc).total_kg < run_lca(C.NEXON_PETROL, sc).total_kg
        assert run_lca(C.E_SCOOTER, sc).total_kg < run_lca(C.PETROL_SCOOTER, sc).total_kg


def test_ice_independent_of_grid():
    a = run_lca(C.NEXON_PETROL, INDIA).total_kg
    b = run_lca(C.NEXON_PETROL, EU).total_kg
    assert a == b


def test_grid_ordering_and_plug_factor():
    assert run_lca(C.NEXON_EV, RE).total_kg < run_lca(C.NEXON_EV, EU).total_kg < run_lca(C.NEXON_EV, INDIA).total_kg
    assert abs(grid_at_plug_g_per_kwh(INDIA) - 727 * 1.10 / 0.81) < 1e-6


def test_break_even_matches_cumulative_curves():
    ev, ice = run_lca(C.NEXON_EV), run_lca(C.NEXON_PETROL)
    be = break_even_km(C.NEXON_EV, C.NEXON_PETROL)
    ev_at = ev.embodied_kg + ev.per_km_kg * be
    ice_at = ice.embodied_kg + ice.per_km_kg * be
    assert abs(ev_at - ice_at) < 1e-6


def test_battery_factor_monotonic():
    lo = run_lca(C.NEXON_EV, battery_factor=34).total_kg
    hi = run_lca(C.NEXON_EV, battery_factor=106).total_kg
    assert hi > lo
    assert abs((hi - lo) - 30.2 * (106 - 34) * (1 - C.EOL["battery_recycling_credit_fraction"])) < 1e-6


def test_sensitivity_sorted_and_grid_dominant():
    rows = sensitivity_tornado(C.NEXON_EV, C.NEXON_PETROL)
    swings = [r["swing_t"] for r in rows]
    assert swings == sorted(swings, reverse=True)
    assert rows[0]["parameter"].startswith("Grid")


def test_materials_mass_closes():
    m = materials_table(C.NEXON_EV)
    glider_mass = C.NEXON_EV.mass_kg - m["Battery pack (total mass)"]
    glider_sum = sum(m[k] for k in C.GLIDER_MATERIAL_SHARES) - C.BEV_EXTRA_COPPER_KG_PER_KWH * C.NEXON_EV.battery_kwh
    assert abs(glider_sum - glider_mass) < 1.0
    assert m["Lithium"] > 0 and m["Nickel"] > 0


def test_summary_json_consistent():
    p = C.RESULTS_DIR / "summary.json"
    if not p.exists():
        pytest.skip("run main.py first")
    s = json.loads(p.read_text())
    for r in s["results_by_scenario"]:
        phases = [r[k] for k in ["Glider & vehicle manufacturing", "Battery production",
                                 "Use phase (fuel/electricity)", "Maintenance", "End of life (net of recycling)"]]
        assert abs(sum(phases) - r["total_kg_co2e"]) < 0.5
    assert s["break_even_km"][f"car|{INDIA}"] > 0


@pytest.mark.skipif(not (shutil.which("soffice") or shutil.which("libreoffice")), reason="LibreOffice not installed")
def test_workbook_recalculates_without_errors():
    from openpyxl import load_workbook
    with tempfile.TemporaryDirectory() as td:
        xlsx = Path(td) / "ev_lca.xlsx"
        build_workbook(xlsx, sensitivity_tornado(C.NEXON_EV, C.NEXON_PETROL),
                       {v.name: run_lca(v).total_kg for v in (C.NEXON_EV, C.NEXON_PETROL, C.E_SCOOTER, C.PETROL_SCOOTER)})
        out = Path(td) / "out"; out.mkdir()
        subprocess.run([shutil.which("soffice") or shutil.which("libreoffice"), "--headless", "--convert-to", "xlsx",
                        "--outdir", str(out), str(xlsx)], capture_output=True, timeout=120)
        wb = load_workbook(out / "ev_lca.xlsx", data_only=True)
        bad = [(ws.title, c.coordinate, c.value) for ws in wb for row in ws.iter_rows() for c in row
               if isinstance(c.value, str) and c.value in ("#REF!", "#DIV/0!", "#NAME?", "#VALUE!", "#N/A")]
        assert bad == []
        # formula totals equal python totals (India block: row 7, cols B..E)
        res = wb["Results"]
        for j, v in enumerate((C.NEXON_EV, C.NEXON_PETROL, C.E_SCOOTER, C.PETROL_SCOOTER)):
            assert abs(res.cell(7, 2 + j).value - run_lca(v).total_kg) < 0.5
        assert abs(res["B13"].value - break_even_km(C.NEXON_EV, C.NEXON_PETROL)) < 1.0
