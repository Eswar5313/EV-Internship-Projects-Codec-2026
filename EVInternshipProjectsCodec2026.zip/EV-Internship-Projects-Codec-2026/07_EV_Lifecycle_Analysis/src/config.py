"""
All LCA inputs in one place.  Each value carries a source tag [Sx] (see SOURCES) or the
word ASSUMPTION.  These same tables are written to the Excel "Inputs" and "Sources"
sheets so the spreadsheet is self-documenting.

Screening-level LCA (GHG, CO2-equivalent, GWP100).  NOT an ISO 14040/14044 study and
NOT a SimaPro / ecoinvent model - see README "Limitations".
"""
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = ROOT / "results"

# ----------------------------------------------------------------- vehicles
@dataclass(frozen=True)
class Vehicle:
    name: str
    powertrain: str                 # "BEV" or "ICEV"
    segment: str                    # "car" or "2W"
    mass_kg: float                  # curb mass incl. battery
    battery_kwh: float              # 0 for ICEV
    battery_wh_per_kg: float        # pack specific energy (to split battery mass from glider)
    energy_use: float               # BEV: kWh/100 km at the plug (real-world); ICEV: L/100 km real-world
    glider_factor_t_per_t: float    # t CO2e per t of glider+powertrain mass (production+recycling)
    maintenance_g_per_km: float
    lifetime_km: float
    lifetime_years: float
    source_note: str = ""


# Indian compact SUV / hatchback-class comparison (same segment, ICCT "SUV" India numbers)
NEXON_EV = Vehicle(
    name="Tata Nexon EV (30.2 kWh)", powertrain="BEV", segment="car",
    mass_kg=1400.0,                 # ASSUMPTION: ~1,400 kg curb (ICCT India SUV-segment avg 1,377 kg [S1 A.1])
    battery_kwh=30.2,               # [S1] Table A.8 note: Nexon EV 30.2 kWh
    battery_wh_per_kg=148.0,        # [S2] Hill et al. 2020 pack specific energy used by ICCT
    energy_use=15.9,                # kWh/100 km real-world, India SUV-segment BEV [S1] Table A.8
    glider_factor_t_per_t=4.7,      # BEV glider+powertrain, t CO2e per t vehicle [S1] Table A.1
    maintenance_g_per_km=3.6,       # ICCT Indonesia, SUV BEV maintenance [S3] Table 5 (proxy)
    lifetime_km=150_000, lifetime_years=12,   # brief functional unit; ICCT India uses 15 yr / 165-188k km
    source_note="Brief: ~30 kWh Indian compact EV",
)
NEXON_PETROL = Vehicle(
    name="Petrol compact SUV (Nexon-class)", powertrain="ICEV", segment="car",
    mass_kg=1250.0,                 # ASSUMPTION: petrol sub-4 m SUV curb ~1,250 kg
    battery_kwh=0.0, battery_wh_per_kg=1.0,
    energy_use=8.2,                 # L/100 km real-world, India SUV gasoline [S1] Table A.8
    glider_factor_t_per_t=5.2,      # gasoline ICEV [S1] Table A.1
    maintenance_g_per_km=4.9,       # ICCT Indonesia, SUV gasoline maintenance [S3] Table 5 (proxy)
    lifetime_km=150_000, lifetime_years=12,
)
# Indian electric scooter vs 110 cc petrol scooter
E_SCOOTER = Vehicle(
    name="Electric scooter (3.7 kWh, Ather 450X-class)", powertrain="BEV", segment="2W",
    mass_kg=112.0,                  # ASSUMPTION: ~110 kg (Ather 450X spec ~111 kg)
    battery_kwh=3.7,                # Ather 450X 3.7 kWh pack (manufacturer spec) [S9]
    battery_wh_per_kg=148.0,
    energy_use=3.5,                 # kWh/100 km at plug - ASSUMPTION (35 Wh/km incl. charger losses; ICCT Indonesia Gesits: 6.2)
    glider_factor_t_per_t=4.0,      # ASSUMPTION: derived so that ~0.4 t for a 95 kg e-scooter [S3] Table 5 (Gesits G1 0.4 t)
    maintenance_g_per_km=1.0,       # [S3] Table 5, electric scooter
    lifetime_km=60_000, lifetime_years=10,    # ASSUMPTION (ICCT Indonesia: 8,300 km/yr x 12 yr = 99,600 km)
)
PETROL_SCOOTER = Vehicle(
    name="Petrol scooter 110 cc (Activa-class)", powertrain="ICEV", segment="2W",
    mass_kg=106.0,                  # ASSUMPTION: ~106 kg (Honda Activa 6G spec)
    battery_kwh=0.0, battery_wh_per_kg=1.0,
    energy_use=2.3,                 # L/100 km real-world, 110 cc scooter (Honda Beat) [S3] Table 7
    glider_factor_t_per_t=3.4,      # ASSUMPTION: derived so that ~0.3 t for an 89 kg scooter [S3] Table 5 (Honda Beat 0.3 t)
    maintenance_g_per_km=1.9,       # [S3] Table 5, gasoline scooter
    lifetime_km=60_000, lifetime_years=10,
)

# ------------------------------------------------------------ battery factors
BATTERY_KG_CO2E_PER_KWH = {
    "base_india_nmc622": 68.0,      # [S1] Table 2.3/2.4 - factor for batteries used in China & India (NMC622, 2021)
    "lfp_china": 56.0,              # [S3] LFP produced in China (GREET-based), used by ICCT 2023
    "low_lfp_europe": 34.0,         # [S1] Table 2.3 lower bound (LFP, Europe)
    "high_ivl2019": 106.0,          # [S4] IVL 2019 (Emilsson & Dahllof) upper bound 61-106
    "ivl2019_low": 61.0,            # [S4] IVL 2019 lower bound
    "greet_argonne_typical": 65.0,  # ASSUMPTION: GREET 2020-based NMC values cluster 55-75 [S1 Sec 2.4]
}
BATTERY_FACTOR_BASE = BATTERY_KG_CO2E_PER_KWH["base_india_nmc622"]
BATTERY_FACTOR_RANGE = (34.0, 106.0)

# ------------------------------------------------------------- grid factors
GRID_G_CO2_PER_KWH = {
    # generation-side factors; T&D losses applied separately
    "India (CEA v20, FY2023-24)": 727.0,      # [S5] CEA CO2 Baseline Database v20.0: 0.727 tCO2/MWh weighted avg
    "EU (2021 cars, ICCT STEPS)": 199.0,      # [S1] Table A.21 lifetime-average EU mix at the plug (already incl. T&D)
    "100 % renewables (solar+wind)": 35.0,    # [S1] Table A.21 India renewables mix life-cycle 35 g/kWh
}
T_AND_D_LOSS = {                              # fraction of output lost, [S1] p.78 (IEA 2021)
    "India (CEA v20, FY2023-24)": 0.19,
    "EU (2021 cars, ICCT STEPS)": 0.0,        # ICCT value already at the plug
    "100 % renewables (solar+wind)": 0.0,
}
# CEA factor is combustion CO2 only; add upstream fuel-cycle (coal mining/transport) - ASSUMPTION
INDIA_UPSTREAM_UPLIFT = 1.10                  # ASSUMPTION: +10 % for coal mining, methane & transport (ICCT life-cycle India ~561-746)
SCENARIOS = list(GRID_G_CO2_PER_KWH.keys())
BASE_SCENARIO = SCENARIOS[0]

# --------------------------------------------------------------- fuel factors
PETROL_WTT_KG_PER_L = 0.64      # [S1] Table A.9 India gasoline well-to-tank 2021
PETROL_TTW_KG_PER_L = 2.15      # [S1] Table A.9 India gasoline tank-to-wheel (5-20 % ethanol blend)
PETROL_WTW_KG_PER_L = PETROL_WTT_KG_PER_L + PETROL_TTW_KG_PER_L  # 2.79
PETROL_LHV_MJ_PER_L = 32.2      # ASSUMPTION: gasoline LHV ~32 MJ/L (GREET-typical)
PETROL_WTT_ENERGY_OVERHEAD = 0.20  # ASSUMPTION: 0.2 MJ upstream per MJ fuel (refining & distribution)
ELEC_PRIMARY_FACTOR = {          # MJ primary per MJ electricity delivered - ASSUMPTION
    "India (CEA v20, FY2023-24)": 2.8,        # coal-heavy grid ~36 % efficiency incl. T&D
    "EU (2021 cars, ICCT STEPS)": 2.0,
    "100 % renewables (solar+wind)": 1.0,
}

# ---------------------------------------------------------------- end of life
EOL = {
    "battery_recycling_credit_fraction": 0.20,   # ASSUMPTION: recycling avoids ~20 % of battery production GHG (range 10-30 %) [S6]
    "battery_recycling_process_kg_per_kwh": 4.0,  # ASSUMPTION: hydrometallurgical recycling burden ~4 kg CO2e/kWh
    "vehicle_shredding_kg_per_t": 30.0,           # ASSUMPTION: dismantling/shredding ~30 kg CO2e per t vehicle
    "material_recovery_rate_li": 0.50,            # [S7] EU Battery Regulation 2023/1542 target 50 % Li by 2027 (80 % by 2031)
    "material_recovery_rate_ni_co_cu": 0.90,      # [S7] 90 % Co/Cu/Ni by 2027 (95 % by 2031)
    "india_bwmr_recovery_target": 0.70,           # [S8] India Battery Waste Management Rules 2022: 70 % by 2024-25, 80 % from 2026-27
}
# Note: the ICCT glider factor [S1 Table A.1] already NETS OUT glider recycling (Hill et al. hybrid method),
# so the explicit EoL phase here contains only battery recycling and a small shredding burden.

# ------------------------------------------------------------------ materials
# kg per vehicle. Car body composition = ASSUMPTION based on typical GREET2 material shares.
GLIDER_MATERIAL_SHARES = {         # fraction of glider mass
    "Steel": 0.62, "Aluminium": 0.09, "Copper (wiring, motor)": 0.02, "Plastics/rubber": 0.18,
    "Glass": 0.03, "Other": 0.06,
}
BEV_EXTRA_COPPER_KG_PER_KWH = 0.41  # [S10] IEA: EV 53.2 kg Cu vs conventional car 22.3 kg, for 75 kWh -> (53.2-22.3)/75
BATTERY_MINERALS_KG_PER_KWH_NMC622 = {  # [S10] IEA Critical Minerals (2021) EV bars / 75 kWh NMC622
    "Lithium": 8.9 / 75, "Nickel": 39.9 / 75, "Cobalt": 13.3 / 75, "Manganese": 24.5 / 75, "Graphite": 66.3 / 75,
}
# LFP alternative from stoichiometry (LiFePO4 157.8 g/mol, 160 mAh/g, 3.2 V -> ~1.95 kg cathode/kWh) - CALCULATED
BATTERY_MINERALS_KG_PER_KWH_LFP = {"Lithium": 1.95 * 6.94 / 157.8, "Iron": 1.95 * 55.85 / 157.8,
                                   "Phosphorus": 1.95 * 30.97 / 157.8, "Graphite": 66.3 / 75}

# ------------------------------------------------------------- sensitivity
SENSITIVITY = {
    "Grid intensity (g CO2/kWh gen.)": (400.0, 727.0, 900.0),
    "Battery size (kWh)": (24.0, 30.2, 40.0),
    "Lifetime km": (100_000, 150_000, 200_000),
    "Battery production (kg CO2e/kWh)": (34.0, 68.0, 106.0),
    "EV consumption (kWh/100 km)": (13.0, 15.9, 19.0),
    "ICE consumption (L/100 km)": (6.4, 8.2, 9.5),
}
LIFETIME_KM_SWEEP = list(range(0, 300_001, 10_000))

SOURCES = [
    ("S1", "ICCT - Bieker, G. (2021) A global comparison of the life-cycle GHG emissions of combustion engine and electric passenger cars (Tables 2.3, 2.4, A.1, A.8, A.9, A.21)",
     "https://theicct.org/sites/default/files/publications/Global-LCA-passenger-cars-jul2021_0.pdf"),
    ("S2", "Hill, N. et al. (2020) Determining the environmental impacts of conventional and alternatively fuelled vehicles through LCA, Ricardo for European Commission",
     "https://op.europa.eu/en/publication-detail/-/publication/1f494180-bc0e-11ea-811c-01aa75ed71a1"),
    ("S3", "ICCT (2023) Comparison of the life-cycle GHG emissions of combustion engine and electric passenger cars and two-wheelers in Indonesia (Tables 5, 6, 7)",
     "https://theicct.org/wp-content/uploads/2023/09/ID-17-%E2%80%93-LCA-Indonesia_report_final2.pdf"),
    ("S4", "Emilsson & Dahllof (2019) IVL Lithium-Ion Vehicle Battery Production - 61-106 kg CO2e/kWh",
     "https://www.ivl.se/english/ivl/publications/publications/lithium-ion-vehicle-battery-production---status-2019-on-energy-use-co2-emissions-use-of-metals-products-environmental-footprint-and-recycling.html"),
    ("S5", "CEA CO2 Baseline Database for the Indian Power Sector, User Guide v20.0 (Jan 2025): weighted average 0.727 tCO2/MWh FY2023-24",
     "https://cea.nic.in/cdm-co2-baseline-database/"),
    ("S6", "Tankou, Bieker & Hall (2023) ICCT - Scaling up reuse and recycling of electric vehicle batteries",
     "https://theicct.org/publication/recycling-electric-vehicle-batteries-ecological-footprint-feb23/"),
    ("S7", "EU Regulation 2023/1542 on batteries - recycling efficiency and material recovery targets (Annex XII)",
     "https://eur-lex.europa.eu/eli/reg/2023/1542/oj"),
    ("S8", "India Battery Waste Management Rules 2022 (MoEFCC) - recovery targets 70 % (2024-25) to 80 % (2026-27+)",
     "https://cpcb.nic.in/uploads/hwmd/Battery_Waste_Management_Rules_2022.pdf"),
    ("S9", "Ather Energy 450X specifications (3.7 kWh pack)",
     "https://www.atherenergy.com/450X"),
    ("S10", "IEA (2021) The Role of Critical Minerals in Clean Energy Transitions - minerals per EV vs conventional car",
     "https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energy-transitions"),
    ("S11", "Argonne GREET model (battery & vehicle-cycle background data referenced by S1)",
     "https://greet.anl.gov/"),
]

ASSUMPTIONS = [
    ("Functional unit 150,000 km / 12 years (car), 60,000 km / 10 years (2-wheeler)", "Brief; ICCT India uses 165-188k km / 15 yr"),
    ("Vehicle curb masses: Nexon EV 1,400 kg, petrol SUV 1,250 kg, e-scooter 112 kg, petrol scooter 106 kg", "Approximate manufacturer specs"),
    ("India grid: CEA 727 g/kWh generation x 1.10 upstream uplift / (1 - 0.19 T&D loss) = 988 g/kWh at plug", "CEA is combustion-only; ICCT India life-cycle 561-746 g/kWh; my value is conservative (high) for the EV"),
    ("Battery production 68 kg CO2e/kWh base (range 34-106)", "ICCT 2021 India/China NMC622; LFP lower; IVL 2019 upper"),
    ("E-scooter 3.5 kWh/100 km at plug", "Typical Indian e-scooter 25-35 Wh/km + charger losses"),
    ("Two-wheeler glider factors 4.0 (BEV) / 3.4 (ICEV) t CO2e per t", "Back-calculated from ICCT Indonesia Table 5 (0.4 t / 0.3 t)"),
    ("EoL: battery recycling credit 20 % of production GHG; recycling process 4 kg/kWh; shredding 30 kg/t vehicle", "Literature range 10-30 %; screening-level"),
    ("Energy: petrol LHV 32.2 MJ/L + 20 % upstream; electricity primary energy factors 2.8 / 2.0 / 1.0", "GREET-typical; declared"),
    ("Car material shares: steel 62 %, Al 9 %, Cu 2 %, plastics 18 %, glass 3 %, other 6 % of glider mass", "GREET2-typical composition"),
    ("ICE and BEV maintenance factors taken from ICCT Indonesia SUV values", "No India-specific values in the sources"),
]
