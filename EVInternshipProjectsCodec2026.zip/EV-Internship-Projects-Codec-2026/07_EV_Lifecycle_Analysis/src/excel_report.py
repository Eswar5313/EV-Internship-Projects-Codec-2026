"""
results/ev_lca.xlsx - built with openpyxl, LIVE formulas throughout.

Inputs  -> Manufacturing -> Use_Phase -> End_of_Life -> Results (sums, g/km, break-even, chart)
Change any yellow cell on Inputs and every sheet recalculates.
"""
from __future__ import annotations

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import config as C
from .lca import materials_table, run_lca

HDR = Font(bold=True, color="FFFFFF")
HFILL = PatternFill("solid", fgColor="2A6F97")
INFILL = PatternFill("solid", fgColor="FFF2CC")
FORMFILL = PatternFill("solid", fgColor="E2EFDA")

VEHICLES = [C.NEXON_EV, C.NEXON_PETROL, C.E_SCOOTER, C.PETROL_SCOOTER]
VCOLS = ["B", "C", "D", "E"]           # vehicle columns on every sheet
PHASES = ["Glider & vehicle manufacturing", "Battery production", "Use phase (fuel/electricity)",
          "Maintenance", "End of life (net of recycling)"]


def _header(ws, row, cols, start_col=1):
    for j, c in enumerate(cols, start_col):
        cell = ws.cell(row=row, column=j, value=c)
        cell.font = HDR; cell.fill = HFILL; cell.alignment = Alignment(horizontal="center", wrap_text=True)


def _widths(ws, widths):
    for k, w in widths.items():
        ws.column_dimensions[k].width = w


def build_workbook(path, sens_rows, python_results: dict):
    wb = Workbook()

    # ------------------------------------------------------------------ Inputs
    ws = wb.active; ws.title = "Inputs"
    _header(ws, 1, ["Vehicle parameter"] + [v.name for v in VEHICLES] + ["Unit", "Source / note"])
    vrows = [
        ("Powertrain", [v.powertrain for v in VEHICLES], "-", "BEV / ICEV"),
        ("Curb mass", [v.mass_kg for v in VEHICLES], "kg", "ASSUMPTION (approx. manufacturer specs; ICCT India SUV avg 1,377 kg)"),
        ("Battery capacity", [v.battery_kwh for v in VEHICLES], "kWh", "S1 Table A.8 (Nexon 30.2); S9 Ather 450X 3.7"),
        ("Pack specific energy", [v.battery_wh_per_kg for v in VEHICLES], "Wh/kg", "S2 Hill et al. 2020 (148 Wh/kg)"),
        ("Energy use (BEV kWh/100 km at plug; ICEV L/100 km)", [v.energy_use for v in VEHICLES], "kWh or L /100 km", "S1 Table A.8 (car); S3 Table 7 (petrol scooter); ASSUMPTION (e-scooter)"),
        ("Glider+powertrain factor", [v.glider_factor_t_per_t for v in VEHICLES], "t CO2e / t", "S1 Table A.1 (cars); ASSUMPTION from S3 Table 5 (2W)"),
        ("Maintenance", [v.maintenance_g_per_km for v in VEHICLES], "g CO2e/km", "S3 Table 5"),
        ("Lifetime distance", [v.lifetime_km for v in VEHICLES], "km", "Brief (150,000 km car); ASSUMPTION 60,000 km 2W"),
        ("Lifetime", [v.lifetime_years for v in VEHICLES], "years", "Brief (12 yr); ASSUMPTION 10 yr 2W"),
    ]
    R = {}
    for i, (name, vals, unit, note) in enumerate(vrows, 2):
        ws.cell(row=i, column=1, value=name)
        for j, val in enumerate(vals):
            c = ws.cell(row=i, column=2 + j, value=val); c.fill = INFILL
        ws.cell(row=i, column=6, value=unit); ws.cell(row=i, column=7, value=note)
        R[name] = i
    r0 = len(vrows) + 3
    _header(ws, r0, ["Global parameter", "Value", "", "", "", "Unit", "Source / note"])
    gl = [
        ("Battery production factor", C.BATTERY_FACTOR_BASE, "kg CO2e/kWh", "S1 Table 2.3/2.4 (India/China NMC622 = 68); range 34 (LFP EU) - 106 (IVL 2019)"),
        ("Grid gen. factor - India", C.GRID_G_CO2_PER_KWH[C.SCENARIOS[0]], "g CO2/kWh", "S5 CEA v20.0 FY2023-24 weighted average 0.727 t/MWh"),
        ("Grid factor - EU (at plug)", C.GRID_G_CO2_PER_KWH[C.SCENARIOS[1]], "g CO2e/kWh", "S1 Table A.21 (EU STEPS 2021 cars, lifetime avg)"),
        ("Grid factor - 100 % renewables (at plug)", C.GRID_G_CO2_PER_KWH[C.SCENARIOS[2]], "g CO2e/kWh", "S1 Table A.21 (India solar+wind mix)"),
        ("India T&D loss", C.T_AND_D_LOSS[C.SCENARIOS[0]], "fraction", "S1 p.78 (IEA 2021: 19 %)"),
        ("India upstream fuel-cycle uplift", C.INDIA_UPSTREAM_UPLIFT, "factor", "ASSUMPTION (+10 % coal mining/transport/CH4)"),
        ("Petrol WTT", C.PETROL_WTT_KG_PER_L, "kg CO2e/L", "S1 Table A.9 India"),
        ("Petrol TTW", C.PETROL_TTW_KG_PER_L, "kg CO2e/L", "S1 Table A.9 India"),
        ("Petrol LHV", C.PETROL_LHV_MJ_PER_L, "MJ/L", "ASSUMPTION"),
        ("Petrol upstream energy overhead", C.PETROL_WTT_ENERGY_OVERHEAD, "MJ/MJ", "ASSUMPTION"),
        ("Electricity primary energy factor - India", C.ELEC_PRIMARY_FACTOR[C.SCENARIOS[0]], "MJ/MJ", "ASSUMPTION"),
        ("Electricity primary energy factor - EU", C.ELEC_PRIMARY_FACTOR[C.SCENARIOS[1]], "MJ/MJ", "ASSUMPTION"),
        ("Electricity primary energy factor - RE", C.ELEC_PRIMARY_FACTOR[C.SCENARIOS[2]], "MJ/MJ", "ASSUMPTION"),
        ("Battery recycling credit", C.EOL["battery_recycling_credit_fraction"], "fraction of battery production", "ASSUMPTION (10-30 %, S6)"),
        ("Battery recycling process burden", C.EOL["battery_recycling_process_kg_per_kwh"], "kg CO2e/kWh", "ASSUMPTION"),
        ("Vehicle shredding burden", C.EOL["vehicle_shredding_kg_per_t"], "kg CO2e/t", "ASSUMPTION"),
        ("Li recovery rate (EU 2027 target)", C.EOL["material_recovery_rate_li"], "fraction", "S7"),
        ("Ni/Co/Cu recovery rate (EU 2027 target)", C.EOL["material_recovery_rate_ni_co_cu"], "fraction", "S7"),
        ("India BWMR recovery target", C.EOL["india_bwmr_recovery_target"], "fraction", "S8"),
    ]
    G = {}
    for i, (name, val, unit, note) in enumerate(gl, r0 + 1):
        ws.cell(row=i, column=1, value=name)
        c = ws.cell(row=i, column=2, value=val); c.fill = INFILL
        ws.cell(row=i, column=6, value=unit); ws.cell(row=i, column=7, value=note)
        G[name] = f"Inputs!$B${i}"
    # derived plug factors (formulas)
    d0 = r0 + len(gl) + 2
    ws.cell(row=d0, column=1, value="Derived (formulas)").font = Font(bold=True)
    ws.cell(row=d0 + 1, column=1, value="India grid at plug (g CO2e/kWh)")
    ws.cell(row=d0 + 1, column=2, value=f"={G['Grid gen. factor - India']}*{G['India upstream fuel-cycle uplift']}/(1-{G['India T&D loss']})").fill = FORMFILL
    ws.cell(row=d0 + 2, column=1, value="EU grid at plug (g CO2e/kWh)"); ws.cell(row=d0 + 2, column=2, value=f"={G['Grid factor - EU (at plug)']}").fill = FORMFILL
    ws.cell(row=d0 + 3, column=1, value="RE grid at plug (g CO2e/kWh)"); ws.cell(row=d0 + 3, column=2, value=f"={G['Grid factor - 100 % renewables (at plug)']}").fill = FORMFILL
    ws.cell(row=d0 + 4, column=1, value="Petrol WTW (kg CO2e/L)"); ws.cell(row=d0 + 4, column=2, value=f"={G['Petrol WTT']}+{G['Petrol TTW']}").fill = FORMFILL
    PLUG = {C.SCENARIOS[0]: f"Inputs!$B${d0+1}", C.SCENARIOS[1]: f"Inputs!$B${d0+2}", C.SCENARIOS[2]: f"Inputs!$B${d0+3}"}
    WTW = f"Inputs!$B${d0+4}"
    ws.cell(row=d0 + 6, column=1, value="Yellow = input, green = formula. Screening-level LCA, not ISO 14040 / SimaPro.")
    _widths(ws, {"A": 46, "B": 20, "C": 20, "D": 22, "E": 22, "F": 20, "G": 70})

    def vin(name, col):  # reference to vehicle input
        return f"Inputs!{col}${R[name]}"

    # ----------------------------------------------------------- Manufacturing
    ws = wb.create_sheet("Manufacturing")
    _header(ws, 1, ["Item (kg CO2e unless stated)"] + [v.name for v in VEHICLES])
    lines = [
        ("Battery mass (kg)", lambda c: f"={vin('Battery capacity', c)}*1000/{vin('Pack specific energy', c)}"),
        ("Glider + powertrain mass (kg)", lambda c: f"={vin('Curb mass', c)}-{c}2"),
        ("Glider & vehicle manufacturing (kg CO2e)", lambda c: f"={c}3*{vin('Glider+powertrain factor', c)}"),
        ("Battery production (kg CO2e)", lambda c: f"={vin('Battery capacity', c)}*{G['Battery production factor']}"),
        ("Manufacturing total (kg CO2e)", lambda c: f"={c}4+{c}5"),
        ("Manufacturing per km (g CO2e/km)", lambda c: f"={c}6*1000/{vin('Lifetime distance', c)}"),
    ]
    for i, (name, f) in enumerate(lines, 2):
        ws.cell(row=i, column=1, value=name)
        for col in VCOLS:
            ws[f"{col}{i}"] = f(col); ws[f"{col}{i}"].fill = FORMFILL
    ws["A9"] = "Materials (kg per vehicle) - glider shares are ASSUMPTIONS (GREET2-typical); battery minerals from IEA S10 (NMC622 basis)"
    ws["A9"].font = Font(bold=True)
    mats = [materials_table(v) for v in VEHICLES]
    keys = []
    for m in mats:
        for k in m:
            if k not in keys:
                keys.append(k)
    _header(ws, 10, ["Material (kg)"] + [v.name for v in VEHICLES])
    MROW = {k: 11 + i for i, k in enumerate(keys)}
    for i, k in enumerate(keys, 11):
        ws.cell(row=i, column=1, value=k)
        for j, m in enumerate(mats):
            ws.cell(row=i, column=2 + j, value=m.get(k, 0.0))
    _widths(ws, {"A": 46, "B": 22, "C": 22, "D": 24, "E": 24})

    # --------------------------------------------------------------- Use_Phase
    ws = wb.create_sheet("Use_Phase")
    _header(ws, 1, ["Scenario / item"] + [v.name for v in VEHICLES])
    row = 2
    USE = {}
    for sc in C.SCENARIOS:
        ws.cell(row=row, column=1, value=sc).font = Font(bold=True)
        ws.cell(row=row + 1, column=1, value="Lifetime energy (kWh electricity or L petrol)")
        ws.cell(row=row + 2, column=1, value="Use-phase GHG (kg CO2e)")
        ws.cell(row=row + 3, column=1, value="Maintenance GHG (kg CO2e)")
        ws.cell(row=row + 4, column=1, value="Final energy (MJ)")
        ws.cell(row=row + 5, column=1, value="Primary energy (MJ)")
        pef = {C.SCENARIOS[0]: G['Electricity primary energy factor - India'],
               C.SCENARIOS[1]: G['Electricity primary energy factor - EU'],
               C.SCENARIOS[2]: G['Electricity primary energy factor - RE']}[sc]
        for col in VCOLS:
            pt = vin('Powertrain', col); km = vin('Lifetime distance', col); eu = vin('Energy use (BEV kWh/100 km at plug; ICEV L/100 km)', col)
            ws[f"{col}{row+1}"] = f"={km}*{eu}/100"
            ws[f"{col}{row+2}"] = f'=IF({pt}="BEV",{col}{row+1}*{PLUG[sc]}/1000,{col}{row+1}*{WTW})'
            ws[f"{col}{row+3}"] = f"={km}*{vin('Maintenance', col)}/1000"
            ws[f"{col}{row+4}"] = f'=IF({pt}="BEV",{col}{row+1}*3.6,{col}{row+1}*{G["Petrol LHV"]})'
            ws[f"{col}{row+5}"] = f'=IF({pt}="BEV",{col}{row+4}*{pef},{col}{row+4}*(1+{G["Petrol upstream energy overhead"]}))'
            for k in range(1, 6):
                ws[f"{col}{row+k}"].fill = FORMFILL
        USE[sc] = row
        row += 7
    _widths(ws, {"A": 46, "B": 22, "C": 22, "D": 24, "E": 24})

    # ------------------------------------------------------------- End_of_Life
    ws = wb.create_sheet("End_of_Life")
    _header(ws, 1, ["Item (kg CO2e)"] + [v.name for v in VEHICLES])
    eol_lines = [
        ("Vehicle dismantling & shredding", lambda c: f"={vin('Curb mass', c)}/1000*{G['Vehicle shredding burden']}"),
        ("Battery recycling process", lambda c: f"={vin('Battery capacity', c)}*{G['Battery recycling process burden']}"),
        ("Battery recycling credit (avoided virgin material)", lambda c: f"=-Manufacturing!{c}5*{G['Battery recycling credit']}"),
        ("End of life net (kg CO2e)", lambda c: f"=SUM({c}2:{c}4)"),
        ("Recovered lithium (kg, EU 2027 rate)", lambda c: f"=Manufacturing!{c}{MROW['Lithium']}*{G['Li recovery rate (EU 2027 target)']}"),
        ("Recovered Ni+Co (kg, EU 2027 rate)", lambda c: f"=(Manufacturing!{c}{MROW['Nickel']}+Manufacturing!{c}{MROW['Cobalt']})*{G['Ni/Co/Cu recovery rate (EU 2027 target)']}"),
    ]
    for i, (name, f) in enumerate(eol_lines, 2):
        ws.cell(row=i, column=1, value=name)
        for col in VCOLS:
            ws[f"{col}{i}"] = f(col); ws[f"{col}{i}"].fill = FORMFILL
    ws["A9"] = "Note: glider recycling is already netted inside the ICCT glider factor (Hill et al. 2020 hybrid method), so only battery recycling and shredding appear here."
    _widths(ws, {"A": 50, "B": 22, "C": 22, "D": 24, "E": 24})

    # ----------------------------------------------------------------- Results
    ws = wb.create_sheet("Results")
    row = 1
    RES = {}
    for sc in C.SCENARIOS:
        _header(ws, row, [f"Phase (kg CO2e) - {sc}"] + [v.name for v in VEHICLES])
        u = USE[sc]
        for col in VCOLS:
            ws[f"{col}{row+1}"] = f"=Manufacturing!{col}4"
            ws[f"{col}{row+2}"] = f"=Manufacturing!{col}5"
            ws[f"{col}{row+3}"] = f"=Use_Phase!{col}{u+2}"
            ws[f"{col}{row+4}"] = f"=Use_Phase!{col}{u+3}"
            ws[f"{col}{row+5}"] = f"=End_of_Life!{col}5"
            ws[f"{col}{row+6}"] = f"=SUM({col}{row+1}:{col}{row+5})"
            ws[f"{col}{row+7}"] = f"={col}{row+6}*1000/{vin('Lifetime distance', col)}"
            ws[f"{col}{row+8}"] = f"={col}{row+1}+{col}{row+2}+{col}{row+5}"
            ws[f"{col}{row+9}"] = f"=({col}{row+3}+{col}{row+4})/{vin('Lifetime distance', col)}"
            for k in range(1, 10):
                ws[f"{col}{row+k}"].fill = FORMFILL
        for k, name in enumerate(PHASES, 1):
            ws.cell(row=row + k, column=1, value=name)
        ws.cell(row=row + 6, column=1, value="TOTAL (kg CO2e)").font = Font(bold=True)
        ws.cell(row=row + 7, column=1, value="g CO2e per km")
        ws.cell(row=row + 8, column=1, value="Embodied (glider+battery+EoL)")
        ws.cell(row=row + 9, column=1, value="Per-km rate (use+maintenance) kg/km")
        ws.cell(row=row + 10, column=1, value="EV vs petrol reduction - car")
        ws[f"B{row+10}"] = f"=1-B{row+6}/C{row+6}"; ws[f"B{row+10}"].fill = FORMFILL; ws[f"B{row+10}"].number_format = "0.0%"
        ws.cell(row=row + 11, column=1, value="EV vs petrol reduction - 2W")
        ws[f"B{row+11}"] = f"=1-D{row+6}/E{row+6}"; ws[f"B{row+11}"].fill = FORMFILL; ws[f"B{row+11}"].number_format = "0.0%"
        ws.cell(row=row + 12, column=1, value="Break-even km - car (embodied diff / per-km diff)")
        ws[f"B{row+12}"] = f'=IF(C{row+9}>B{row+9},MAX(0,(B{row+8}-C{row+8})/(C{row+9}-B{row+9})),"never")'; ws[f"B{row+12}"].fill = FORMFILL
        ws.cell(row=row + 13, column=1, value="Break-even km - 2W")
        ws[f"B{row+13}"] = f'=IF(E{row+9}>D{row+9},MAX(0,(D{row+8}-E{row+8})/(E{row+9}-D{row+9})),"never")'; ws[f"B{row+13}"].fill = FORMFILL
        RES[sc] = row
        row += 16
    # cross-check vs python
    ws.cell(row=row, column=1, value="Python cross-check (India scenario totals, kg)").font = Font(bold=True)
    for j, v in enumerate(VEHICLES):
        ws.cell(row=row + 1, column=2 + j, value=round(python_results[v.name], 2))
        ws.cell(row=row + 2, column=2 + j, value=f"={VCOLS[j]}{RES[C.BASE_SCENARIO]+6}-{VCOLS[j]}{row+1}").fill = FORMFILL
    ws.cell(row=row + 1, column=1, value="Python total (India)")
    ws.cell(row=row + 2, column=1, value="Difference (formula - python)")
    # chart: India scenario stacked phases
    ch = BarChart(); ch.type = "col"; ch.grouping = "stacked"; ch.overlap = 100
    ch.title = f"Lifecycle GHG by phase - {C.BASE_SCENARIO}"; ch.y_axis.title = "kg CO2e"
    base = RES[C.BASE_SCENARIO]
    ch.add_data(Reference(ws, min_col=1, max_col=5, min_row=base + 1, max_row=base + 5), titles_from_data=True, from_rows=True)
    ch.set_categories(Reference(ws, min_col=2, max_col=5, min_row=base))
    ch.height, ch.width = 9, 18
    ws.add_chart(ch, "H2")
    ch2 = BarChart(); ch2.type = "col"; ch2.grouping = "stacked"; ch2.overlap = 100
    ch2.title = f"Lifecycle GHG by phase - {C.SCENARIOS[1]}"; ch2.y_axis.title = "kg CO2e"
    b2 = RES[C.SCENARIOS[1]]
    ch2.add_data(Reference(ws, min_col=1, max_col=5, min_row=b2 + 1, max_row=b2 + 5), titles_from_data=True, from_rows=True)
    ch2.set_categories(Reference(ws, min_col=2, max_col=5, min_row=b2))
    ch2.height, ch2.width = 9, 18
    ws.add_chart(ch2, "H22")
    _widths(ws, {"A": 50, "B": 22, "C": 22, "D": 24, "E": 24})

    # ------------------------------------------------------------- Sensitivity
    ws = wb.create_sheet("Sensitivity")
    _header(ws, 1, ["Parameter", "Low", "Base", "High", "EV-ICE diff at low (t)", "EV-ICE diff at high (t)", "Base diff (t)", "Swing (t, formula)"])
    for i, r in enumerate(sens_rows, 2):
        ws.cell(row=i, column=1, value=r["parameter"]); ws.cell(row=i, column=2, value=r["low_value"])
        ws.cell(row=i, column=3, value=r["base_value"]); ws.cell(row=i, column=4, value=r["high_value"])
        ws.cell(row=i, column=5, value=round(r["diff_at_low_t"], 3)); ws.cell(row=i, column=6, value=round(r["diff_at_high_t"], 3))
        ws.cell(row=i, column=7, value=round(r["base_diff_t"], 3))
        ws.cell(row=i, column=8, value=f"=ABS(F{i}-E{i})").fill = FORMFILL
    n = len(sens_rows) + 1
    ws.cell(row=n + 2, column=1, value="Live what-if: lifetime km sweep (India grid, car) - formulas").font = Font(bold=True)
    _header(ws, n + 3, ["km", "EV cumulative (kg)", "Petrol cumulative (kg)", "EV better?"])
    b = RES[C.BASE_SCENARIO]
    for i, km in enumerate(range(0, 300_001, 25_000)):
        r = n + 4 + i
        ws.cell(row=r, column=1, value=km)
        ws.cell(row=r, column=2, value=f"=Results!$B${b+8}+Results!$B${b+9}*A{r}").fill = FORMFILL
        ws.cell(row=r, column=3, value=f"=Results!$C${b+8}+Results!$C${b+9}*A{r}").fill = FORMFILL
        ws.cell(row=r, column=4, value=f'=IF(B{r}<C{r},"yes","no")').fill = FORMFILL
    _widths(ws, {"A": 40, "B": 18, "C": 20, "D": 14, "E": 22, "F": 22, "G": 14, "H": 16})

    # ------------------------------------------------------------------ Sources
    ws = wb.create_sheet("Sources")
    _header(ws, 1, ["ID", "Source", "URL"])
    for i, (sid, desc, url) in enumerate(C.SOURCES, 2):
        ws.cell(row=i, column=1, value=sid); ws.cell(row=i, column=2, value=desc); ws.cell(row=i, column=3, value=url)
    r = len(C.SOURCES) + 3
    _header(ws, r, ["#", "Assumption", "Basis"])
    for i, (a, bsis) in enumerate(C.ASSUMPTIONS, 1):
        ws.cell(row=r + i, column=1, value=i); ws.cell(row=r + i, column=2, value=a); ws.cell(row=r + i, column=3, value=bsis)
    _widths(ws, {"A": 6, "B": 110, "C": 90})

    wb.save(path)
    return path
