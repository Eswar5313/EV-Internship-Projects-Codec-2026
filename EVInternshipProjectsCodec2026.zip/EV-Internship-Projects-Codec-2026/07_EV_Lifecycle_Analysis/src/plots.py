"""Figures for the LCA project."""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from . import config as C
from .config import RESULTS_DIR
from .lca import break_even_km, cumulative_curve, run_lca

PHASE_COLORS = ["#6C757D", "#8E44AD", "#E8A317", "#2A9D8F", "#3FA34D"]


def plot_stacked_phases(pairs, path=RESULTS_DIR / "lifecycle_ghg_by_phase.png"):
    """pairs = [(ev, ice), ...]; one panel per pair, bars per scenario x powertrain."""
    fig, axes = plt.subplots(1, len(pairs), figsize=(7 * len(pairs), 6))
    axes = np.atleast_1d(axes)
    for ax, (ev, ice) in zip(axes, pairs):
        labels, stacks = [], []
        for sc in C.SCENARIOS:
            for v in (ev, ice):
                if v.powertrain == "ICEV" and sc != C.BASE_SCENARIO:
                    continue  # ICE does not depend on grid; show once
                r = run_lca(v, sc)
                short = sc.split(" (")[0]
                labels.append(f"{'EV' if v.powertrain == 'BEV' else 'Petrol'}\n{short if v.powertrain == 'BEV' else ''}")
                stacks.append([x / 1000.0 for x in r.phases.values()])
        stacks = np.array(stacks)
        x = np.arange(len(labels))
        pos = np.zeros(len(labels)); neg = np.zeros(len(labels))
        for j, name in enumerate(run_lca(ev).phases.keys()):
            vals = stacks[:, j]
            bottom = np.where(vals >= 0, pos, neg)
            ax.bar(x, vals, bottom=bottom, color=PHASE_COLORS[j], label=name, width=0.7)
            pos += np.where(vals >= 0, vals, 0); neg += np.where(vals < 0, vals, 0)
        for i in range(len(labels)):
            ax.text(x[i], pos[i] + 0.3, f"{stacks[i].sum():.1f} t", ha="center", fontsize=9, fontweight="bold")
        ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8)
        ax.set_ylabel("t CO2e per vehicle over lifetime")
        km = ev.lifetime_km
        ax.set_title(f"{ev.name}\nvs {ice.name}\n({km:,.0f} km)", fontsize=10)
        ax.axhline(0, color="k", lw=0.6); ax.grid(axis="y", alpha=0.3)
        ax.set_ylim(min(neg.min(), 0) * 1.5, pos.max() * 1.18)
    axes[0].legend(fontsize=8, loc="upper right")
    fig.suptitle("Cradle-to-grave GHG by life-cycle phase (screening-level LCA)", fontsize=12)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_break_even(ev, ice, path=RESULTS_DIR / "break_even_km.png"):
    kms = np.array(C.LIFETIME_KM_SWEEP)
    fig, ax = plt.subplots(figsize=(10, 6))
    ice_curve = cumulative_curve(ice, kms) / 1000.0
    ax.plot(kms / 1000, ice_curve, color="#C8102E", lw=2.5, label=f"{ice.name}")
    colors = ["#E8A317", "#2A6F97", "#3FA34D"]
    axins = ax.inset_axes([0.08, 0.45, 0.38, 0.4])
    axins.plot(kms / 1000, ice_curve, color="#C8102E", lw=2)
    for j, (sc, col) in enumerate(zip(C.SCENARIOS, colors)):
        cur = cumulative_curve(ev, kms, sc) / 1000.0
        be = break_even_km(ev, ice, sc)
        ax.plot(kms / 1000, cur, color=col, lw=2, label=f"EV - {sc}  (break-even {be/1000:.1f}k km)")
        axins.plot(kms / 1000, cur, color=col, lw=2)
        if np.isfinite(be):
            y_be = np.interp(be, kms, ice_curve)
            axins.plot(be / 1000, y_be, "o", color=col, ms=6, mec="k")
            axins.annotate(f"{be/1000:.1f}k", (be / 1000, y_be), xytext=(4, -12 - 6 * j), textcoords="offset points", fontsize=8, color=col)
    axins.set_xlim(0, 30); axins.set_ylim(5.5, 15); axins.grid(alpha=0.3)
    axins.set_title("zoom: first 30,000 km", fontsize=8); axins.tick_params(labelsize=7)
    ax.axvline(ev.lifetime_km / 1000, color="grey", ls="--", lw=1)
    ax.text(ev.lifetime_km / 1000 + 2, 2, "functional unit", fontsize=8, color="grey")
    ax.set_xlabel("Distance driven (thousand km)"); ax.set_ylabel("Cumulative GHG (t CO2e)")
    ax.set_title("Break-even distance: EV starts with a higher embodied footprint, then wins")
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(0.5, 0.42)); ax.grid(alpha=0.3); ax.set_ylim(0, None)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_tornado(rows, path=RESULTS_DIR / "sensitivity_tornado.png"):
    fig, ax = plt.subplots(figsize=(9, 5))
    base = rows[0]["base_diff_t"]
    y = np.arange(len(rows))[::-1]
    for yi, r in zip(y, rows):
        lo, hi = r["diff_at_low_t"], r["diff_at_high_t"]
        ax.barh(yi, lo - base, left=base, color="#2A6F97", height=0.6)
        ax.barh(yi, hi - base, left=base, color="#E8A317", height=0.6)
        ax.text(min(lo, hi) - 0.3, yi, f"{r['low_value']:g}", va="center", ha="right", fontsize=8)
        ax.text(max(lo, hi) + 0.3, yi, f"{r['high_value']:g}", va="center", ha="left", fontsize=8)
    ax.axvline(base, color="k", lw=1)
    ax.axvline(0, color="#C8102E", ls="--", lw=1)
    ax.text(0, len(rows) - 0.4, " EV = ICE", color="#C8102E", fontsize=8)
    ax.set_yticks(y); ax.set_yticklabels([r["parameter"] for r in rows], fontsize=9)
    ax.set_xlabel("Lifetime GHG: EV minus petrol (t CO2e)  -  negative = EV better")
    ax.set_title(f"One-at-a-time sensitivity, India grid (base = {base:.1f} t)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_energy(pairs, path=RESULTS_DIR / "energy_consumption_mj.png"):
    fig, axes = plt.subplots(1, len(pairs), figsize=(6 * len(pairs), 4.8))
    axes = np.atleast_1d(axes)
    for ax, (ev, ice) in zip(axes, pairs):
        labels, fin, prim = [], [], []
        for v in (ev, ice):
            for sc in (C.SCENARIOS if v.powertrain == "BEV" else [C.BASE_SCENARIO]):
                r = run_lca(v, sc)
                labels.append(("EV " + sc.split(" (")[0]) if v.powertrain == "BEV" else "Petrol")
                fin.append(r.energy_final_mj / 1000); prim.append(r.energy_primary_mj / 1000)
        x = np.arange(len(labels))
        ax.bar(x - 0.2, fin, 0.4, label="final energy (at plug / tank)", color="#2A6F97")
        ax.bar(x + 0.2, prim, 0.4, label="primary energy (assumed factors)", color="#9E9E9E")
        ax.set_xticks(x); ax.set_xticklabels(labels, fontsize=8, rotation=15)
        ax.set_ylabel("GJ over lifetime"); ax.set_title(f"Use-phase energy: {ev.segment}", fontsize=10)
        ax.grid(axis="y", alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
