"""
Transparent cradle-to-grave GHG + energy calculator.

Phases (kg CO2e per vehicle over the functional unit):
  glider_manufacturing = glider_mass_t * glider_factor
  battery_production   = battery_kWh * kgCO2e_per_kWh
  use_phase            = km * (kWh/km * grid_at_plug)   or   km * (L/km * WTW petrol)
  maintenance          = km * g/km / 1000
  end_of_life          = shredding + battery recycling process - battery recycling credit
Total = sum of phases.  Per-km = total / km.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np

from . import config as C
from .config import Vehicle


@dataclass
class LCAResult:
    vehicle: str
    powertrain: str
    scenario: str
    km: float
    glider_kg: float
    battery_kg: float
    use_kg: float
    maintenance_kg: float
    eol_kg: float
    energy_final_mj: float
    energy_primary_mj: float
    battery_mass_kg: float
    glider_mass_kg: float

    @property
    def phases(self) -> dict:
        return {"Glider & vehicle manufacturing": self.glider_kg, "Battery production": self.battery_kg,
                "Use phase (fuel/electricity)": self.use_kg, "Maintenance": self.maintenance_kg,
                "End of life (net of recycling)": self.eol_kg}

    @property
    def total_kg(self) -> float:
        return sum(self.phases.values())

    @property
    def g_per_km(self) -> float:
        return self.total_kg * 1000.0 / self.km

    @property
    def embodied_kg(self) -> float:
        """Emissions that do not scale with km (for break-even)."""
        return self.glider_kg + self.battery_kg + self.eol_kg

    @property
    def per_km_kg(self) -> float:
        return (self.use_kg + self.maintenance_kg) / self.km


def grid_at_plug_g_per_kwh(scenario: str, gen_factor: float | None = None) -> float:
    gen = C.GRID_G_CO2_PER_KWH[scenario] if gen_factor is None else gen_factor
    uplift = C.INDIA_UPSTREAM_UPLIFT if scenario.startswith("India") else 1.0
    return gen * uplift / (1.0 - C.T_AND_D_LOSS[scenario])


def battery_mass_kg(v: Vehicle) -> float:
    return v.battery_kwh * 1000.0 / v.battery_wh_per_kg if v.battery_kwh > 0 else 0.0


def run_lca(v: Vehicle, scenario: str = C.BASE_SCENARIO, battery_factor: float = C.BATTERY_FACTOR_BASE,
            grid_gen_factor: float | None = None, lifetime_km: float | None = None) -> LCAResult:
    km = v.lifetime_km if lifetime_km is None else lifetime_km
    b_mass = battery_mass_kg(v)
    g_mass = v.mass_kg - b_mass
    glider = g_mass / 1000.0 * v.glider_factor_t_per_t * 1000.0     # kg CO2e
    battery = v.battery_kwh * battery_factor
    if v.powertrain == "BEV":
        plug = grid_at_plug_g_per_kwh(scenario, grid_gen_factor)
        kwh = km * v.energy_use / 100.0
        use = kwh * plug / 1000.0
        e_final = kwh * 3.6
        e_primary = e_final * C.ELEC_PRIMARY_FACTOR[scenario]
    else:
        litres = km * v.energy_use / 100.0
        use = litres * C.PETROL_WTW_KG_PER_L
        e_final = litres * C.PETROL_LHV_MJ_PER_L
        e_primary = e_final * (1 + C.PETROL_WTT_ENERGY_OVERHEAD)
    maint = km * v.maintenance_g_per_km / 1000.0
    shred = v.mass_kg / 1000.0 * C.EOL["vehicle_shredding_kg_per_t"]
    recyc_proc = v.battery_kwh * C.EOL["battery_recycling_process_kg_per_kwh"]
    credit = battery * C.EOL["battery_recycling_credit_fraction"]
    eol = shred + recyc_proc - credit
    return LCAResult(v.name, v.powertrain, scenario, km, glider, battery, use, maint, eol,
                     e_final, e_primary, b_mass, g_mass)


def break_even_km(ev: Vehicle, ice: Vehicle, scenario: str = C.BASE_SCENARIO,
                  battery_factor: float = C.BATTERY_FACTOR_BASE, grid_gen_factor: float | None = None) -> float:
    """km at which cumulative EV emissions (embodied + per-km) drop below the ICE's."""
    a = run_lca(ev, scenario, battery_factor, grid_gen_factor)
    b = run_lca(ice, scenario, battery_factor, grid_gen_factor)
    delta_fixed = a.embodied_kg - b.embodied_kg
    delta_rate = b.per_km_kg - a.per_km_kg
    if delta_rate <= 0:
        return float("inf")
    return max(0.0, delta_fixed / delta_rate)


def cumulative_curve(v: Vehicle, kms, scenario=C.BASE_SCENARIO, battery_factor=C.BATTERY_FACTOR_BASE):
    r = run_lca(v, scenario, battery_factor)
    return np.array([r.embodied_kg + r.per_km_kg * k for k in kms])


def sensitivity_tornado(ev: Vehicle, ice: Vehicle) -> list[dict]:
    """One-at-a-time sensitivity of the EV-minus-ICE lifetime difference (t CO2e), India grid."""
    base_ev = run_lca(ev).total_kg
    base_ice = run_lca(ice).total_kg
    base_diff = (base_ev - base_ice) / 1000.0
    rows = []
    for name, (lo, mid, hi) in C.SENSITIVITY.items():
        outs = []
        for val in (lo, hi):
            ev2, ice2, kw = ev, ice, {}
            if name.startswith("Grid"):
                kw = {"grid_gen_factor": val}
            elif name.startswith("Battery size"):
                ev2 = replace(ev, battery_kwh=val)
            elif name.startswith("Lifetime"):
                kw = {"lifetime_km": val}
            elif name.startswith("Battery production"):
                kw = {"battery_factor": val}
            elif name.startswith("EV consumption"):
                ev2 = replace(ev, energy_use=val)
            elif name.startswith("ICE consumption"):
                ice2 = replace(ice, energy_use=val)
            e = run_lca(ev2, **kw).total_kg
            i = run_lca(ice2, **{k: v for k, v in kw.items() if k == "lifetime_km"}).total_kg
            outs.append((e - i) / 1000.0)
        rows.append({"parameter": name, "low_value": lo, "base_value": mid, "high_value": hi,
                     "diff_at_low_t": outs[0], "diff_at_high_t": outs[1], "base_diff_t": base_diff,
                     "swing_t": abs(outs[1] - outs[0])})
    rows.sort(key=lambda r: -r["swing_t"])
    return rows


def materials_table(v: Vehicle, chemistry: str = "NMC622") -> dict:
    """kg of key materials per vehicle."""
    g_mass = v.mass_kg - battery_mass_kg(v)
    mats = {k: g_mass * s for k, s in C.GLIDER_MATERIAL_SHARES.items()}
    if v.battery_kwh > 0:
        minerals = C.BATTERY_MINERALS_KG_PER_KWH_NMC622 if chemistry == "NMC622" else C.BATTERY_MINERALS_KG_PER_KWH_LFP
        for k, per_kwh in minerals.items():
            mats[k] = mats.get(k, 0.0) + per_kwh * v.battery_kwh
        mats["Copper (wiring, motor)"] += C.BEV_EXTRA_COPPER_KG_PER_KWH * v.battery_kwh
        mats["Battery pack (total mass)"] = battery_mass_kg(v)
    return {k: round(val, 1) for k, val in mats.items()}
