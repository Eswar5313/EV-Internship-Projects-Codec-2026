# EV Cradle-to-Grave Lifecycle Analysis (screening-level LCA)

**Project 07 - EV Internship, Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026
**Stack:** Python 3, NumPy, pandas, matplotlib, openpyxl (+ LibreOffice headless for verification)

> ## Scope statement - read this first
> * This is a **screening-level, attributional greenhouse-gas LCA (GWP100)** built from
>   published, cited emission factors. It is **not an ISO 14040/14044 study**, it was
>   **not done in SimaPro/GaBi/openLCA**, and it uses **no ecoinvent inventory**. It
>   answers "roughly how much, and what drives it", not "exactly how much".
> * **No data in this project is measured by me.** Every factor is either cited to a
>   public source (S1-S11) or declared as an assumption - in §7 here, in `src/config.py`,
>   and in the workbook's `Inputs` and `Sources` sheets.
> * Where I could not find an India-specific value I say so and use the closest
>   published proxy (mostly ICCT's 2021 global study and its 2023 Indonesia study).

---

## 1. Overview

Brief: *"Perform a full cradle-to-grave sustainability analysis of an EV. Use Excel or
specialized tools (SimaPro). Include materials, energy consumption, recycling impact.
Compare with ICE vehicle."*

I built a transparent LCA calculator in Python and mirrored every equation as live
formulas in an Excel workbook, for two India-relevant comparisons:

| Pair | EV | ICE | Functional unit |
|---|---|---|---|
| Car | Tata Nexon EV, 30.2 kWh [S1], 15.9 kWh/100 km real-world at plug [S1] | Petrol compact SUV of the same segment, 8.2 L/100 km real-world [S1] | 1 vehicle, **150,000 km / 12 yr** |
| Two-wheeler | Electric scooter, 3.7 kWh (Ather 450X-class) [S9], 3.5 kWh/100 km (assumption) | 110 cc petrol scooter (Activa-class), 2.3 L/100 km [S3] | 1 vehicle, **60,000 km / 10 yr** |

Three electricity scenarios: **India grid** (CEA FY2023-24 [S5]), **EU grid** (ICCT 2021
lifetime average [S1]) and **100 % renewables** (solar + wind life-cycle factor [S1]).

`python main.py` regenerates everything in `results/` in about 3 s (including a
LibreOffice recalculation check of the workbook).

## 2. Method and equations

Five phases, all in kg CO2e per vehicle over the functional unit:

```
Glider & vehicle manufacturing = (curb mass − battery mass) × glider factor      [t CO2e per t, S1 Table A.1: 4.7 BEV / 5.2 ICEV]
Battery production             = battery kWh × 68 kg CO2e/kWh                  [S1 Table 2.3-2.4, India/China NMC622; range 34-106]
Use phase - BEV                = km × kWh/km × grid-at-plug
       grid-at-plug (India)    = 727 g/kWh [S5] × 1.10 upstream uplift (assumption) / (1 − 0.19 T&D loss [S1]) = 987 g/kWh
Use phase - ICEV               = km × L/km × (0.64 WTT + 2.15 TTW) kg CO2e/L   [S1 Table A.9, India petrol]
Maintenance                    = km × g/km                                        [S3 Table 5]
End of life                    = shredding (30 kg/t, assumption) + battery recycling process (4 kg/kWh, assumption)
                                 − recycling credit (20 % of battery production GHG, assumption; range 10-30 %, S6)
Total = Σ phases ;  g/km = Total / km
Break-even km = (EV embodied − ICE embodied) / (ICE kg/km − EV kg/km)
```

Battery mass is split from the glider with 148 Wh/kg pack specific energy [S2]. The ICCT
glider factor already nets out glider recycling (Hill et al. hybrid method), so the
explicit EoL phase only carries the battery and shredding terms - I say this in the
workbook too, to avoid double counting.

Energy: final energy = kWh × 3.6 MJ or L × 32.2 MJ; primary energy uses declared
factors (electricity 2.8 India / 2.0 EU / 1.0 RE MJ/MJ; petrol +20 % upstream).

Materials: glider mass split by GREET2-typical shares (assumption); battery minerals
per kWh scaled from IEA's 75 kWh NMC622 reference EV [S10]; an LFP alternative is
computed from LiFePO4 stoichiometry (1.95 kg cathode/kWh at 160 mAh/g, 3.2 V).

## 3. How to run

```bash
pip install -r requirements.txt
python main.py        # ~3 s -> results/
pytest -q             # 11 tests (one uses LibreOffice if present)
```

## 4. Results (actual numbers from `results/summary.json`)

### 4.1 Lifecycle GHG by phase (t CO2e per vehicle)

| Vehicle / scenario | Glider | Battery | Use | Maint. | EoL (net) | **Total** | **g/km** |
|---|---|---|---|---|---|---|---|
| Nexon EV - India grid | 5.62 | 2.05 | 23.55 | 0.54 | −0.25 | **31.5** | **210** |
| Nexon EV - EU grid | 5.62 | 2.05 | 4.75 | 0.54 | −0.25 | **12.7** | **85** |
| Nexon EV - 100 % RE | 5.62 | 2.05 | 0.83 | 0.54 | −0.25 | **8.8** | **59** |
| Petrol compact SUV | 6.50 | 0 | 34.32 | 0.74 | +0.04 | **41.6** | **277** |
| E-scooter - India grid | 0.35 | 0.25 | 2.07 | 0.06 | −0.03 | **2.70** | **45** |
| E-scooter - EU grid | 0.35 | 0.25 | 0.42 | 0.06 | −0.03 | **1.05** | **17** |
| E-scooter - 100 % RE | 0.35 | 0.25 | 0.07 | 0.06 | −0.03 | **0.70** | **12** |
| Petrol scooter 110 cc | 0.36 | 0 | 3.85 | 0.11 | +0.003 | **4.33** | **72** |

**EV reduction vs petrol:** car **24 %** (India) / 69 % (EU) / 79 % (RE);
scooter **38 %** (India) / 76 % (EU) / 84 % (RE).

For comparison, ICCT's own India result for 2021 cars is 19-38 % lower life-cycle GHG
for BEVs (STEPS) [S1] - my 24 % sits inside that range, which is the sanity check I
wanted. My India grid factor (987 g/kWh at plug) is deliberately on the high side
(CEA measured 2023-24, no future decarbonisation), so the 24 % is conservative.

![Phases](results/lifecycle_ghg_by_phase.png)

### 4.2 Break-even distance

| Scenario | Car break-even km | Scooter break-even km |
|---|---|---|
| India grid | **12,163** | **6,681** |
| EU grid | 4,481 | 3,508 |
| 100 % renewables | 3,960 | 3,193 |

The EV starts ~0.9 t CO2e "in debt" (battery + slightly heavier body, minus its cheaper
glider factor) and repays it within the first year of typical Indian driving even on
today's coal-heavy grid.

![Break-even](results/break_even_km.png)

### 4.3 Sensitivity (car, India grid; EV-minus-ICE lifetime difference, base −10.1 t)

| Parameter (low / base / high) | Diff at low | Diff at high | Swing |
|---|---|---|---|
| Grid intensity 400 / 727 / 900 g/kWh | −20.7 t | −4.5 t | **16.2 t** |
| ICE consumption 6.4 / 8.2 / 9.5 L/100 km | −2.5 t | −15.5 t | 13.0 t |
| EV consumption 13 / 15.9 / 19 kWh/100 km | −14.4 t | −5.5 t | 8.9 t |
| Lifetime 100k / 150k / 200k km | −6.4 t | −13.7 t | 7.3 t |
| Battery production 34 / 68 / 106 kg/kWh | −10.9 t | −9.2 t | 1.7 t |
| Battery size 24 / 30.2 / 40 kWh | −10.2 t | −9.8 t | 0.4 t |

The EV remains better than petrol in **every** one-at-a-time case. Grid intensity and
the real-world consumption of both vehicles dominate; battery manufacturing - the
factor most people argue about - moves the answer by less than 2 t over 150,000 km.

![Tornado](results/sensitivity_tornado.png)

### 4.4 Energy consumption (use phase, lifetime)

| Vehicle | Final energy | Primary energy (assumed factors) |
|---|---|---|
| Nexon EV (any grid) | 86 GJ | 240 GJ India / 172 GJ EU / 86 GJ RE |
| Petrol compact SUV | 396 GJ | 475 GJ |
| E-scooter | 7.6 GJ | 21 / 15 / 7.6 GJ |
| Petrol scooter | 44 GJ | 53 GJ |

![Energy](results/energy_consumption_mj.png)

### 4.5 Materials (kg per vehicle)

| Material | Nexon EV (NMC622 basis) | Nexon EV (LFP alt.) | Petrol SUV | E-scooter | Petrol scooter |
|---|---|---|---|---|---|
| Steel | 742 | 742 | 775 | 54 | 66 |
| Aluminium | 108 | 108 | 113 | 8 | 10 |
| Copper | 36 | 36 | 25 | 3.3 | 2.1 |
| Plastics/rubber | 215 | 215 | 225 | 16 | 19 |
| Lithium | 3.6 | 2.6 | 0 | 0.4 | 0 |
| Nickel | 16.1 | 0 | 0 | 2.0 | 0 |
| Cobalt | 5.4 | 0 | 0 | 0.7 | 0 |
| Manganese | 9.9 | 0 | 0 | 1.2 | 0 |
| Iron (cathode) / Phosphorus | - | 20.8 / 11.6 | - | - | - |
| Graphite | 27 | 27 | 0 | 3.3 | 0 |
| Battery pack mass | 204 | 204 | 0 | 25 | 0 |

Recycling: at EU-2027 recovery targets (Li 50 %, Ni/Co/Cu 90 % [S7]) the Nexon EV pack
returns ~1.8 kg Li and ~19 kg Ni+Co at end of life; India's BWMR 2022 requires 70-80 %
overall recovery [S8]. These are computed live in the `End_of_Life` sheet.

## 5. Excel workbook (`results/ev_lca.xlsx`)

| Sheet | Content |
|---|---|
| `Inputs` | every vehicle and global parameter (yellow), source column, derived plug factors (formulas) |
| `Manufacturing` | battery mass, glider mass, glider and battery GHG - formulas; materials table |
| `Use_Phase` | per scenario: lifetime kWh/L, GHG, maintenance, final and primary energy - formulas with `IF(powertrain="BEV",...)` |
| `End_of_Life` | shredding, recycling process, recycling credit, recovered Li / Ni+Co - formulas |
| `Results` | per scenario: 5 phases → total → g/km → embodied/per-km → % reduction → break-even km; two stacked-bar charts; Python cross-check row |
| `Sensitivity` | tornado table + a live km-sweep (`EV better?` column recalculates from `Results`) |
| `Sources` | S1-S11 with URLs, then the assumptions table |

Verification: `main.py` recalculates the workbook with LibreOffice headless and scans
every cell - **0 error cells**; formula totals equal the Python totals (India: 31,513 /
41,590 / 2,701 / 4,328 kg) and the formula break-even (12,162.8 km) equals Python's.

## 6. Tests (`pytest -q` → 11 passed)

phases sum to totals (all vehicles × scenarios) · break-even positive and finite under
India grid (car and scooter) · EV < ICE under EU, India and RE · ICE independent of grid
· RE < EU < India ordering and India plug factor = 727×1.10/0.81 · break-even point
equalises the cumulative curves · battery factor monotonic with the exact expected slope
· tornado sorted and grid-dominated · glider material masses close · summary.json
phases sum · workbook recalculates in LibreOffice with no `#REF!/#DIV/0!/#NAME?/#VALUE!`
and matches Python.

## 7. Limitations (honest list)

* **Screening-level only.** No process inventories, no ecoinvent, no ISO critical
  review, GHG only (no acidification, toxicity, water, particulates).
* **Proxy factors.** Glider factors are European (Ricardo/ICCT); maintenance and
  two-wheeler factors are from ICCT's Indonesia study; India-specific manufacturing
  data was not available to me.
* **Static grid.** I use the FY2023-24 CEA factor for all 12 years. ICCT's projected
  lifetime average for India (561-746 g/kWh) would improve the EV by several tonnes -
  the tornado shows the effect.
* **Upstream uplift (+10 %) for Indian coal** and the recycling credit (20 %) are my
  assumptions; both are single cells in `Inputs`.
* **Battery chemistry:** the base factor is NMC622 (ICCT India); Tata actually uses LFP,
  which would be ~56 kg/kWh [S3] - i.e. slightly better for the EV.
* Battery replacement within 150,000 km is not assumed (typical warranties cover
  8 yr / 160,000 km); vehicle masses are approximate manufacturer figures.
* Real-world consumption values are 2019-20 fleet averages, not measurements of a
  specific car.

## 8. Sources

| ID | Source | URL |
|---|---|---|
| S1 | Bieker, G. (2021) *A global comparison of the life-cycle GHG emissions of combustion engine and electric passenger cars*, ICCT - Tables 2.3, 2.4, A.1, A.8, A.9, A.21, p.78 | https://theicct.org/sites/default/files/publications/Global-LCA-passenger-cars-jul2021_0.pdf |
| S2 | Hill, N. et al. (2020) *Determining the environmental impacts of conventional and alternatively fuelled vehicles through LCA*, Ricardo for EC DG Climate Action | https://op.europa.eu/en/publication-detail/-/publication/1f494180-bc0e-11ea-811c-01aa75ed71a1 |
| S3 | ICCT (2023) *Comparison of the life-cycle GHG emissions of combustion engine and electric passenger cars and two-wheelers in Indonesia* - Tables 5, 6, 7 | https://theicct.org/wp-content/uploads/2023/09/ID-17-%E2%80%93-LCA-Indonesia_report_final2.pdf |
| S4 | Emilsson, E. & Dahllöf, L. (2019) *Lithium-Ion Vehicle Battery Production*, IVL - 61-106 kg CO2e/kWh | https://www.ivl.se/english/ivl/publications/publications/lithium-ion-vehicle-battery-production---status-2019-on-energy-use-co2-emissions-use-of-metals-products-environmental-footprint-and-recycling.html |
| S5 | CEA, *CO2 Baseline Database for the Indian Power Sector*, User Guide v20.0 (Jan 2025) - weighted average 0.727 tCO2/MWh, FY2023-24 | https://cea.nic.in/cdm-co2-baseline-database/ |
| S6 | Tankou, Bieker & Hall (2023) *Scaling up reuse and recycling of electric vehicle batteries*, ICCT | https://theicct.org/publication/recycling-electric-vehicle-batteries-ecological-footprint-feb23/ |
| S7 | Regulation (EU) 2023/1542 on batteries - Annex XII recovery targets | https://eur-lex.europa.eu/eli/reg/2023/1542/oj |
| S8 | MoEFCC, *Battery Waste Management Rules 2022* - recovery targets 70 % (2024-25) → 80 % (2026-27) | https://cpcb.nic.in/uploads/hwmd/Battery_Waste_Management_Rules_2022.pdf |
| S9 | Ather Energy 450X specifications (3.7 kWh) | https://www.atherenergy.com/450X |
| S10 | IEA (2021) *The Role of Critical Minerals in Clean Energy Transitions* - minerals per EV vs conventional car | https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energy-transitions |
| S11 | Argonne National Laboratory, GREET model | https://greet.anl.gov/ |

### Declared assumptions (also in the workbook `Sources` sheet)

| # | Assumption | Basis |
|---|---|---|
| 1 | Functional unit 150,000 km / 12 yr (car), 60,000 km / 10 yr (2W) | brief; ICCT India uses 165-188k km / 15 yr |
| 2 | Curb masses 1,400 / 1,250 / 112 / 106 kg | approximate manufacturer specs |
| 3 | India plug factor = 727 × 1.10 / (1 − 0.19) = 987 g/kWh | CEA is combustion-only; uplift is my estimate |
| 4 | Battery production 68 kg CO2e/kWh (range 34-106) | ICCT NMC622 India/China; LFP lower, IVL 2019 upper |
| 5 | E-scooter 3.5 kWh/100 km at plug | typical 25-35 Wh/km + charger losses |
| 6 | 2W glider factors 4.0 (BEV) / 3.4 (ICEV) t/t | back-calculated from ICCT Indonesia Table 5 |
| 7 | EoL: 20 % battery recycling credit, 4 kg/kWh process, 30 kg/t shredding | literature range; screening level |
| 8 | Petrol LHV 32.2 MJ/L, +20 % upstream energy; electricity primary factors 2.8 / 2.0 / 1.0 | GREET-typical |
| 9 | Glider composition: steel 62 %, Al 9 %, Cu 2 %, plastics 18 %, glass 3 %, other 6 % | GREET2-typical |
| 10 | Maintenance factors from ICCT Indonesia SUV/scooter values | no India values found |

## 9. File tree

```
07_EV_Lifecycle_Analysis/
├── README.md, requirements.txt, main.py
├── src/
│   ├── config.py        # vehicles, factors, SOURCES, ASSUMPTIONS
│   ├── lca.py           # phase calculator, break-even, sensitivity, materials
│   ├── plots.py         # 4 figures
│   └── excel_report.py  # openpyxl workbook with live formulas + charts
├── tests/test_lca.py
└── results/
    ├── summary.json, lca_results.csv, sensitivity.csv, materials_kg.csv
    ├── lifecycle_ghg_by_phase.png, break_even_km.png, sensitivity_tornado.png, energy_consumption_mj.png
    └── ev_lca.xlsx
```
