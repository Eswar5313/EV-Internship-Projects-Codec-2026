"""BMS Simulation package.

Battery Management System simulation for an EV internship project
(Codec Technologies India, Sept 2026). All data produced by this package
is synthetic / simulated.

Author: Eswar Mahalingam
"""

__version__ = "1.0.0"
__author__ = "Eswar Mahalingam"
