"""Matplotlib figures for the BMS simulation results.

All figures use a fixed, colour-blind-friendly palette (Okabe-Ito) and
stacked panels with a shared x-axis instead of dual y-axes.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

# Okabe-Ito palette: fixed assignment by role
C_TRUE = "#000000"
C_CC = "#E69F00"  # orange
C_EKF = "#0072B2"  # blue
C_TEMP = "#D55E00"  # vermillion
C_FLOW = "#009E73"  # green
C_HEAT = "#CC79A7"  # purple
C_VOLT = "#0072B2"
C_CURR = "#D55E00"
C_LIMIT = "#999999"
C_SOH_C = "#0072B2"
C_SOH_R = "#E69F00"

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 130, "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False, "lines.linewidth": 1.4, "font.size": 9.5,
    "axes.titlesize": 10.5, "axes.titleweight": "bold", "legend.frameon": False, "legend.fontsize": 8.5,
})


def _finish(fig, path, title):
    fig.suptitle(title + "   (synthetic simulation data)", fontsize=12, fontweight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(path)
    plt.close(fig)
    return path


def plot_voltage_current(drive: dict, path: str):
    t = drive["t"] / 60
    fig, ax = plt.subplots(4, 1, figsize=(10, 9.5), sharex=True)
    ax[0].plot(t, drive["speed_kmh"], color="#555555")
    ax[0].set_ylabel("Speed [km/h]")
    ax[0].set_title("Synthetic urban + highway speed profile")
    ax[1].plot(t, drive["i_pack"], color=C_CURR, lw=1.0, label="Pack current (true)")
    ax[1].plot(t, drive["i_meas"], color=C_CURR, lw=0.5, alpha=0.35, label="Sensor (noise + 2 A bias)")
    ax[1].axhline(0, color="k", lw=0.6)
    ax[1].set_ylabel("Current [A]\n(+ discharge)")
    ax[1].set_title("Pack current demand from the vehicle model")
    ax[1].legend(loc="upper left", ncol=2)
    ax[2].plot(t, drive["v_pack"], color=C_VOLT, label="Pack terminal voltage")
    ax[2].set_ylabel("Pack voltage [V]")
    ax[2].set_title("Pack voltage (96s2p)")
    ax[2].legend(loc="upper right")
    ax[3].plot(t, drive["v_cell_max"], color=C_TEMP, label="Max cell")
    ax[3].plot(t, drive["v_cell_min"], color=C_FLOW, label="Min cell")
    ax[3].axhline(4.25, color=C_LIMIT, ls="--", lw=1, label="OV / UV limits")
    ax[3].axhline(2.80, color=C_LIMIT, ls="--", lw=1)
    ax[3].set_ylabel("Cell voltage [V]")
    ax[3].set_xlabel("Time [min]")
    ax[3].set_title("Cell voltage envelope with safety limits")
    ax[3].legend(loc="lower left", ncol=3)
    return _finish(fig, path, "Drive cycle: speed, current and voltage")


def plot_soc_estimation(drive: dict, path: str):
    t = drive["t"] / 60
    fig, ax = plt.subplots(2, 1, figsize=(10, 7), sharex=True, gridspec_kw={"height_ratios": [1.4, 1]})
    ax[0].plot(t, drive["soc_true"] * 100, color=C_TRUE, lw=2, label="True SOC (pack model)")
    ax[0].plot(t, drive["soc_cc"] * 100, color=C_CC, ls="--", label="Coulomb counting")
    ax[0].plot(t, drive["soc_ekf"] * 100, color=C_EKF, label="EKF (2-RC model)")
    ax[0].set_ylabel("SOC [%]")
    ax[0].set_title("SOC estimation: Coulomb counting vs Extended Kalman Filter")
    ax[0].legend(loc="upper right")
    err_cc = (drive["soc_cc"] - drive["soc_true"]) * 100
    err_ekf = (drive["soc_ekf"] - drive["soc_true"]) * 100
    ax[1].plot(t, err_cc, color=C_CC, ls="--", label=f"CC error (final {drive['cc_final_err_pct']:+.1f} %)")
    ax[1].plot(t, err_ekf, color=C_EKF, label=f"EKF error (RMSE {drive['ekf_rmse_pct']:.2f} % after settling)")
    ax[1].axhspan(-2, 2, color=C_EKF, alpha=0.08, lw=0)
    ax[1].text(t[-1], 2.2, "+/-2 % band", ha="right", va="bottom", fontsize=8, color="#555")
    ax[1].axhline(0, color="k", lw=0.6)
    ax[1].set_ylabel("Estimation error [% SOC]")
    ax[1].set_xlabel("Time [min]")
    ax[1].set_ylim(-8, 3.5)
    ax[1].set_title("Estimation error (EKF started 15 % low, CC started 5 % low + 2 A sensor bias)")
    ax[1].legend(loc="lower right")
    return _finish(fig, path, "SOC estimation accuracy")


def plot_thermal(drive_on: dict, drive_off: dict, fc_on: dict, fc_off: dict, cold: dict, path: str):
    fig, ax = plt.subplots(3, 2, figsize=(12, 10), gridspec_kw={"height_ratios": [1.3, 1, 1]})
    limit = drive_on["temp_limit_c"]
    # --- column 0: drive cycle
    t = drive_on["t"] / 60
    ax[0, 0].plot(t, drive_off["temp"], color=C_TEMP, ls="--", label="No thermal management")
    ax[0, 0].plot(t, drive_on["temp"], color=C_TEMP, label="Thermal management ON")
    ax[0, 0].axhline(limit, color=C_LIMIT, ls=":", label=f"Design limit {limit:.0f} degC")
    ax[0, 0].set_ylabel("Pack temperature [degC]")
    ax[0, 0].set_title("Drive cycle, 40 degC ambient, heat-soaked pack")
    ax[0, 0].set_ylim(top=49)
    ax[0, 0].legend(loc="upper left")
    ax[1, 0].plot(t, drive_on["flow"], color=C_FLOW, label="Coolant flow (PI + hysteresis)")
    ax[1, 0].set_ylabel("Coolant flow [L/min]")
    ax[1, 0].legend(loc="upper right")
    ax[2, 0].plot(t, drive_on["q_gen"], color="#555555", lw=0.8, label="Heat generation (I2R + entropic)")
    ax[2, 0].set_ylabel("Heat [W]")
    ax[2, 0].set_xlabel("Time [min]")
    ax[2, 0].legend(loc="upper right")
    # --- column 1: fast charge (top two rows), cold start (bottom)
    t_off, t_on = fc_off["t"] / 60, fc_on["t"] / 60
    ax[0, 1].plot(t_off, fc_off["temp"], color=C_TEMP, ls="--", label=f"Uncooled (peak {fc_off['peak_temp_c']:.1f} degC)")
    ax[0, 1].plot(t_on, fc_on["temp"], color=C_TEMP, label=f"Cooled (peak {fc_on['peak_temp_c']:.1f} degC)")
    ax[0, 1].axhline(limit, color=C_LIMIT, ls=":", label=f"Design limit {limit:.0f} degC")
    ax[0, 1].set_ylabel("Pack temperature [degC]")
    ax[0, 1].set_title(f"DC fast charge {fc_on['c_rate']:.1f}C, 20 -> 100 % SOC")
    ax[0, 1].legend(loc="upper left")
    ax[1, 1].plot(t_on, fc_on["flow"], color=C_FLOW, label="Coolant flow, cooled case")
    ax[1, 1].set_ylabel("Coolant flow [L/min]")
    ax[1, 1].set_xlabel("Time [min]")
    ax[1, 1].legend(loc="lower right")
    tc = cold["t"] / 60
    ax[2, 1].plot(tc, cold["temp"], color=C_TEMP, label="Pack temperature")
    on = cold["heater"] > 0
    if on.any():
        ax[2, 1].axvspan(tc[on].min(), tc[on].max(), color=C_HEAT, alpha=0.15, lw=0,
                         label=f"Heater ON ({cold['heater'][0]/1000:.1f} kW)")
    ax[2, 1].axhline(5, color=C_LIMIT, ls=":", label="Heater ON < 5 degC, OFF > 10 degC")
    ax[2, 1].axhline(10, color=C_LIMIT, ls=":")
    ax[2, 1].set_ylabel("Pack temperature [degC]")
    ax[2, 1].set_xlabel("Time [min]")
    ax[2, 1].set_title("Cold start at -8 degC: heater hysteresis")
    ax[2, 1].legend(loc="lower right")
    return _finish(fig, path, "Thermal management")


def plot_soh(age: dict, path: str, n_report: int = 500):
    c = age["cycle"]
    fig, ax = plt.subplots(3, 1, figsize=(10, 9), sharex=True, gridspec_kw={"height_ratios": [1.8, 1, 1]})
    ax[0].plot(c[::10], age["soh_capacity_measured"][::10] * 100, ".", color=C_SOH_C, alpha=0.35, ms=4,
               label="Capacity SOH, 'measured' (every 10th cycle, +/-0.3 % noise)")
    ax[0].plot(c, age["soh_capacity"] * 100, color=C_SOH_C, lw=2, label="Capacity SOH (model)")
    ax[0].plot(c, age["soh_resistance"] * 100, color=C_SOH_R, lw=2, label="Resistance SOH (model)")
    ax[0].axhline(80, color=C_LIMIT, ls="--", label="80 % end-of-life threshold")
    ax[0].set_ylabel("SOH [%]")
    ax[0].set_ylim(75, 102)
    ax[0].set_title(f"Accelerated ageing: {n_report} cycles, 80 % DoD, 35 degC, 1C")
    ax[0].annotate(f"{age['soh_capacity'][-1]*100:.1f} %", (c[-1], age["soh_capacity"][-1] * 100),
                   xytext=(-40, -14), textcoords="offset points", color=C_SOH_C, fontsize=9)
    ax[0].annotate(f"{age['soh_resistance'][-1]*100:.1f} %", (c[-1], age["soh_resistance"][-1] * 100),
                   xytext=(-40, 8), textcoords="offset points", color=C_SOH_R, fontsize=9)
    ax[0].legend(loc="lower left")
    ax[1].plot(c, age["capacity_ah"], color=C_SOH_C)
    ax[1].set_ylabel("Cell capacity [Ah]")
    ax[1].set_title("Capacity fade (cyclic Ah-throughput power law + calendar sqrt(t))")
    ax[2].plot(c, age["resistance_ohm"] * 1e3, color=C_SOH_R)
    ax[2].set_ylabel("Cell R0 [milli-ohm]")
    ax[2].set_xlabel("Cycle number")
    ax[2].set_title("Internal resistance growth")
    return _finish(fig, path, "State of health")


def plot_balancing(bal: dict, path: str):
    t = bal["t"] / 3600
    fig, ax = plt.subplots(3, 1, figsize=(10, 8.5), sharex=True)
    ax[0].plot(t, bal["soc_cells"] * 100, color=C_EKF, lw=0.4, alpha=0.35)
    ax[0].plot([], [], color=C_EKF, label="Individual cell SOC (192 cells)")
    ax[0].set_ylabel("Cell SOC [%]")
    ax[0].set_title("Passive balancing at rest: every cell converges to the weakest cell")
    ax[0].legend(loc="upper right")
    ax[1].plot(t, bal["spread_mv"], color=C_TEMP, label="Max - min cell voltage [mV]")
    ax[1].axhline(40, color=C_LIMIT, ls="--", label="IMBALANCE flag threshold (40 mV)")
    ax[1].set_ylabel("Spread [mV]")
    ax[1].legend(loc="upper right")
    ax[2].plot(t, bal["n_active"], color=C_FLOW, label="Cells with bleed resistor ON")
    ax[2].set_ylabel("Cells bleeding")
    ax[2].set_xlabel("Time [h]")
    ax[2].legend(loc="upper right")
    return _finish(fig, path, "Cell balancing")


def plot_charge(ch: dict, path: str):
    t = ch["t"] / 60
    fig, ax = plt.subplots(3, 1, figsize=(10, 8.5), sharex=True)
    ax[0].plot(t, ch["v_pack"], color=C_VOLT, label="Pack voltage")
    ax[0].axhline(4.2 * 96, color=C_LIMIT, ls="--", label="CV target (4.20 V x 96)")
    ax[0].set_ylabel("Pack voltage [V]")
    ax[0].set_title(f"CC-CV charge at {ch['c_rate']:.1f}C: CV phase starts at {ch['cv_start_time_min']:.0f} min")
    ax[0].legend(loc="lower right")
    ax[1].plot(t, ch["i_pack"], color=C_CURR, label="Charge current")
    ax[1].set_ylabel("Current [A]\n(- = charging)")
    ax[1].legend(loc="lower right")
    ax[2].plot(t, ch["soc_true"] * 100, color=C_TRUE, lw=2, label="True SOC")
    ax[2].plot(t, ch["soc_ekf"] * 100, color=C_EKF, label="EKF SOC (started 10 % low)")
    seg = (ch["soc_ekf"] > 0.35) & (ch["soc_ekf"] < 0.75)
    if seg.any():
        ax[2].axvspan(t[seg].min(), t[seg].max(), color=C_FLOW, alpha=0.12, lw=0,
                      label=f"LS capacity fit window -> Q = {ch['q_est_ah']:.2f} Ah ({ch['q_est_err_pct']:+.1f} %)")
    ax[2].set_ylabel("SOC [%]")
    ax[2].set_xlabel("Time [min]")
    ax[2].legend(loc="lower right")
    return _finish(fig, path, "Charging and capacity estimation")


def plot_faults(fi: dict, path: str):
    t = fi["t"] / 60
    fig, ax = plt.subplots(3, 1, figsize=(10, 8.5), sharex=True)
    ax[0].plot(t, fi["current"], color=C_CURR, label="Injected abuse current")
    ax[0].axhline(300, color=C_LIMIT, ls="--", label="Over-current limits")
    ax[0].axhline(-150, color=C_LIMIT, ls="--")
    ax[0].set_ylabel("Current [A]")
    ax[0].set_title("Fault injection: over-charge, current pulse, 3C discharge without cooling")
    ax[0].legend(loc="upper left")
    ax[1].plot(t, fi["v_cell_max"], color=C_TEMP, label="Max cell voltage")
    ax[1].plot(t, fi["v_cell_min"], color=C_FLOW, label="Min cell voltage")
    ax[1].axhline(4.25, color=C_LIMIT, ls="--", label="OV / UV limits")
    ax[1].axhline(2.80, color=C_LIMIT, ls="--")
    ax[1].set_ylabel("Cell voltage [V]")
    ax[1].legend(loc="lower left")
    ax[2].plot(t, fi["temp"], color=C_TEMP, label="Pack temperature")
    ax[2].axhline(55, color=C_LIMIT, ls="--", label="Over-temperature limit 55 degC")
    ax[2].set_ylabel("Temperature [degC]")
    ax[2].set_xlabel("Time [min]")
    ax[2].legend(loc="upper left")
    row = {"OVER_VOLTAGE": 1, "UNDER_VOLTAGE": 1, "OVER_CURRENT": 0, "OVER_TEMP": 2, "IMBALANCE": 1}
    for ev in fi["fault_events"]:
        a = ax[row.get(ev["fault"], 0)]
        a.axvline(ev["time_s"] / 60, color="#CC0000", lw=0.8, alpha=0.7)
        a.text(ev["time_s"] / 60 + 0.3, a.get_ylim()[1], ev["fault"], color="#CC0000", fontsize=7, va="top", rotation=90)
    return _finish(fig, path, "Safety monitor fault flags")
