"""State-of-health estimation and a semi-empirical ageing model.

Two SOH definitions are tracked:

* Capacity SOH:    SOH_C = Q_actual / Q_nominal
* Resistance SOH:  SOH_R = 1 - (R/R_0 - 1) / (R_EOL/R_0 - 1)
                   (1.0 when fresh, 0.0 when resistance has doubled)

Capacity fade model (Wang et al. 2011 style, "Ah-throughput" model with
Arrhenius temperature dependence and a DoD stress factor):

    Q_loss[%] = B * exp(-Ea / (Rg * T)) * f(DoD) * Ah^z     (z ~ 0.55)

Calendar ageing adds a sqrt(time) term. Resistance growth is modelled as
linear in Ah throughput with the same temperature stress. All coefficients
are synthetic and tuned so that a cell reaches ~85-90 % SOH after 500
cycles at 35 degC / 80 % DoD - typical of an EV cell.

Cycle counting: a simple half-cycle (turning-point) counter on the SOC
signal gives a list of depths of discharge, and Ah throughput / (2*Q)
gives the number of equivalent full cycles (EFC).

Capacity estimation from a partial charge: fit Ah(t) = Q * soc(t) + c by
linear least squares, where soc(t) comes from the EKF / OCV inversion.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_R_GAS = 8.314


@dataclass
class AgeingParams:
    b_cyc: float = 750.0  # pre-exponential factor for cyclic fade [%]
    ea_cyc: float = 26_000.0  # activation energy [J/mol]
    z: float = 0.55  # Ah-throughput exponent
    b_cal: float = 1.2e5  # calendar fade pre-factor [% / sqrt(day)]
    ea_cal: float = 35_000.0
    dod_ref: float = 0.8
    dod_exp: float = 0.5  # stress grows with DoD^dod_exp
    k_res: float = 0.10  # resistance growth per (Ah * stress * Arrhenius) unit
    r_eol_ratio: float = 2.0  # end-of-life when R has doubled


class AgeingModel:
    """Tracks true capacity and resistance of a cell as it is cycled."""

    def __init__(self, q_nominal_ah: float, r0_nominal: float, params: AgeingParams | None = None):
        self.p = params or AgeingParams()
        self.q_nom = q_nominal_ah
        self.r0_nom = r0_nominal
        self.ah_total = 0.0
        self.days = 0.0
        self.q_loss_cyc_pct = 0.0
        self.q_loss_cal_pct = 0.0
        self.r_growth = 0.0

    # -- stress factors -------------------------------------------------
    def _arrhenius(self, ea: float, temp_c: float) -> float:
        return float(np.exp(-ea / (_R_GAS * (temp_c + 273.15))))

    def _dod_stress(self, dod: float) -> float:
        return float((max(dod, 1e-3) / self.p.dod_ref) ** self.p.dod_exp)

    # -- update after one cycle ---------------------------------------------
    def cycle(self, dod: float, temp_c: float, c_rate: float = 1.0, rest_days: float = 0.0):
        """Apply one charge/discharge cycle of depth `dod` at `temp_c`."""
        ah = 2.0 * dod * self.q_nom  # charge + discharge throughput
        stress = self._dod_stress(dod) * (1 + 0.1 * max(c_rate - 1.0, 0.0))
        # "effective" Ah throughput weighted by stress so the power law is
        # applied to a single accumulated quantity (keeps fade monotonic)
        self.ah_total += ah * stress
        self.q_loss_cyc_pct = self.p.b_cyc * self._arrhenius(self.p.ea_cyc, temp_c) * self.ah_total**self.p.z
        self.days += rest_days + (2 * dod / max(c_rate, 1e-3)) / 24.0
        self.q_loss_cal_pct = self.p.b_cal * self._arrhenius(self.p.ea_cal, temp_c) * np.sqrt(self.days)
        self.r_growth += self.p.k_res * ah * stress * self._arrhenius(self.p.ea_cyc, temp_c)

    # -- outputs -----------------------------------------------------------
    @property
    def capacity_ah(self) -> float:
        return self.q_nom * (1 - (self.q_loss_cyc_pct + self.q_loss_cal_pct) / 100.0)

    @property
    def resistance(self) -> float:
        return self.r0_nom * (1 + self.r_growth)

    @property
    def soh_capacity(self) -> float:
        return self.capacity_ah / self.q_nom

    @property
    def soh_resistance(self) -> float:
        return soh_from_resistance(self.resistance, self.r0_nom, self.p.r_eol_ratio)

    @property
    def soh(self) -> float:
        return min(self.soh_capacity, self.soh_resistance)


def soh_from_capacity(q_actual: float, q_nominal: float) -> float:
    return float(q_actual / q_nominal)


def soh_from_resistance(r_actual: float, r_nominal: float, r_eol_ratio: float = 2.0) -> float:
    growth = r_actual / r_nominal - 1.0
    return float(np.clip(1.0 - growth / (r_eol_ratio - 1.0), 0.0, 1.0))


def run_accelerated_ageing(n_cycles: int = 500, q_nominal_ah: float = 30.0, r0_nominal: float = 2.0e-3,
                           dod: float = 0.8, temp_c: float = 35.0, c_rate: float = 1.0,
                           rest_days_per_cycle: float = 0.5, params: AgeingParams | None = None,
                           noise_std_pct: float = 0.3, seed: int = 7):
    """Cycle a cell n_cycles times; return a dict of arrays (true + noisy 'measured')."""
    model = AgeingModel(q_nominal_ah, r0_nominal, params)
    rng = np.random.default_rng(seed)
    cycles = np.arange(0, n_cycles + 1)
    soh_c = np.empty(n_cycles + 1)
    soh_r = np.empty(n_cycles + 1)
    cap = np.empty(n_cycles + 1)
    res = np.empty(n_cycles + 1)
    soh_c[0], soh_r[0], cap[0], res[0] = 1.0, 1.0, q_nominal_ah, r0_nominal
    for k in range(1, n_cycles + 1):
        model.cycle(dod, temp_c, c_rate, rest_days_per_cycle)
        soh_c[k], soh_r[k], cap[k], res[k] = model.soh_capacity, model.soh_resistance, model.capacity_ah, model.resistance
    measured_soh_c = soh_c + rng.normal(0, noise_std_pct / 100, soh_c.shape)
    return {
        "cycle": cycles,
        "soh_capacity": soh_c,
        "soh_resistance": soh_r,
        "capacity_ah": cap,
        "resistance_ohm": res,
        "soh_capacity_measured": measured_soh_c,
        "ah_throughput": cycles * 2 * dod * q_nominal_ah,
    }


# ---------------------------------------------------------------------------
# Cycle counting
# ---------------------------------------------------------------------------
def equivalent_full_cycles(current_a, dt: float, capacity_ah: float) -> float:
    """EFC = total |Ah| throughput / (2 * capacity)."""
    ah = np.sum(np.abs(np.asarray(current_a))) * dt / 3600.0
    return float(ah / (2.0 * capacity_ah))


def count_half_cycles(soc, min_dod: float = 0.005):
    """Turning-point half-cycle counter: returns the DoD of every monotone
    SOC swing larger than min_dod (a simplified rainflow)."""
    s = np.asarray(soc, dtype=float)
    if s.size < 2:
        return np.array([])
    d = np.diff(s)
    turning = [0]
    for k in range(1, len(d)):
        if np.sign(d[k]) != np.sign(d[k - 1]) and d[k] != 0:
            turning.append(k)
    turning.append(len(s) - 1)
    pts = s[turning]
    dods = np.abs(np.diff(pts))
    return dods[dods >= min_dod]


# ---------------------------------------------------------------------------
# Capacity estimate from a partial charge segment (least squares)
# ---------------------------------------------------------------------------
def estimate_capacity_least_squares(soc_est, current_a, dt: float):
    """Fit Ah(t) = Q * soc(t) + c over a segment. Returns (Q_est, r2).

    soc_est: SOC estimate along the segment (e.g. from the EKF, or OCV at
    rest points); current_a: measured current (discharge positive).
    Ah(t) is the *charge put into* the cell, so Ah = -cumsum(i)*dt/3600.
    """
    soc_est = np.asarray(soc_est, dtype=float)
    ah = -np.cumsum(np.asarray(current_a, dtype=float)) * dt / 3600.0
    X = np.column_stack([soc_est, np.ones_like(soc_est)])
    coef, *_ = np.linalg.lstsq(X, ah, rcond=None)
    pred = X @ coef
    ss_res = np.sum((ah - pred) ** 2)
    ss_tot = np.sum((ah - ah.mean()) ** 2) + 1e-12
    return float(coef[0]), float(1 - ss_res / ss_tot)
