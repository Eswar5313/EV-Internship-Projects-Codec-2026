"""Synthetic drive cycle and charge profile generation.

IMPORTANT: the speed profile below is SYNTHETIC. It is built from a
sequence of accelerate / cruise / brake / idle phases meant to *resemble*
an urban segment followed by a highway segment. It is not a standard
cycle (WLTP, FTP-75, IDC, ...) and no real vehicle data is used.

Longitudinal vehicle model (per time step):

    F_trac = m*a + 0.5*rho*Cd*A*v^2 + Crr*m*g          [N]
    P_batt = F_trac*v / eta            (traction, P > 0)
           = F_trac*v * eta_regen      (braking, P < 0, limited)
    I_pack = P_batt / V_nominal        (discharge positive)

A CC-CV charge profile is also provided (constant current until the pack
reaches its CV voltage, then the current tapers).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class VehicleParams:
    mass_kg: float = 1400.0
    cd: float = 0.29
    frontal_area_m2: float = 2.25
    crr: float = 0.010
    eta_drive: float = 0.90  # battery -> wheel efficiency
    eta_regen: float = 0.60  # wheel -> battery efficiency during braking
    p_regen_max_w: float = 40_000.0
    p_aux_w: float = 600.0  # HVAC/12V auxiliaries
    rho_air: float = 1.20
    g: float = 9.81


def _phase(v0_kmh, v1_kmh, duration_s, dt):
    """Linear ramp (or hold) from v0 to v1 over duration_s."""
    n = max(int(round(duration_s / dt)), 1)
    return np.linspace(v0_kmh, v1_kmh, n, endpoint=False)


def synthetic_speed_profile(dt: float = 1.0, seed: int = 3) -> tuple[np.ndarray, np.ndarray]:
    """Return (t [s], speed [km/h]) for ~30 min: urban stop-go then highway."""
    rng = np.random.default_rng(seed)
    segs = []
    # ---- urban: 15 min of stop-and-go (0-50 km/h)
    v = 0.0
    t_used = 0.0
    while t_used < 900:
        v_target = float(rng.uniform(25, 50))
        acc = float(rng.uniform(8, 14))
        cruise = float(rng.uniform(15, 45))
        brake = float(rng.uniform(6, 10))
        idle = float(rng.uniform(5, 20))
        segs += [_phase(v, v_target, acc, dt), _phase(v_target, v_target, cruise, dt),
                 _phase(v_target, 0.0, brake, dt), _phase(0.0, 0.0, idle, dt)]
        v = 0.0
        t_used += acc + cruise + brake + idle
    # ---- highway: ramp to 100-120 km/h with speed variations, then exit
    segs.append(_phase(0.0, 100.0, 25, dt))
    v = 100.0
    t_used = 0.0
    while t_used < 720:
        v_target = float(rng.uniform(95, 120))
        ramp = float(rng.uniform(10, 20))
        hold = float(rng.uniform(40, 90))
        segs += [_phase(v, v_target, ramp, dt), _phase(v_target, v_target, hold, dt)]
        v = v_target
        t_used += ramp + hold
    segs += [_phase(v, 40.0, 25, dt), _phase(40.0, 40.0, 20, dt), _phase(40.0, 0.0, 10, dt),
             _phase(0.0, 0.0, 30, dt)]
    speed = np.concatenate(segs)
    # light smoothing so accelerations are not perfectly piecewise-linear
    k = np.ones(3) / 3
    speed = np.convolve(speed, k, mode="same")
    speed[:2] = 0.0
    speed[-2:] = 0.0
    t = np.arange(len(speed)) * dt
    return t, np.clip(speed, 0.0, None)


def current_from_speed(t: np.ndarray, speed_kmh: np.ndarray, v_nominal: float,
                       veh: VehicleParams | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Convert a speed profile into (power [W], pack current [A]) demand."""
    veh = veh or VehicleParams()
    v = speed_kmh / 3.6
    dt = float(np.mean(np.diff(t)))
    a = np.gradient(v, dt)
    f_aero = 0.5 * veh.rho_air * veh.cd * veh.frontal_area_m2 * v**2
    f_roll = veh.crr * veh.mass_kg * veh.g * (v > 0.1)
    f_trac = veh.mass_kg * a + f_aero + f_roll
    p_wheel = f_trac * v
    p_batt = np.where(p_wheel >= 0, p_wheel / veh.eta_drive, p_wheel * veh.eta_regen)
    p_batt = np.maximum(p_batt, -veh.p_regen_max_w) + veh.p_aux_w
    current = p_batt / v_nominal
    return p_batt, current


def cc_cv_charge_profile(pack_capacity_ah: float, n_series: int, c_rate: float = 0.5,
                         v_cv_cell: float = 4.20, dt: float = 1.0, max_hours: float = 2.5):
    """Return a *controller* for CC-CV charging.

    Usage in a loop: I = controller(pack_voltage) -> negative (charging) current.
    CC: I = -c_rate * Q.  CV: current tapers so that V_pack stays at V_cv
    (simple proportional taper), ends when |I| < 0.05 C.
    """
    i_cc = -c_rate * pack_capacity_ah
    v_cv = v_cv_cell * n_series
    i_cut = -0.05 * pack_capacity_ah
    state = {"cv": False, "i": i_cc, "done": False, "t": 0.0}

    def controller(v_pack: float) -> float:
        state["t"] += dt
        if state["done"] or state["t"] > max_hours * 3600:
            state["done"] = True
            return 0.0
        if not state["cv"] and v_pack >= v_cv:
            state["cv"] = True
        if state["cv"]:
            # proportional taper: reduce |I| when voltage is above the CV target
            gain = 0.3 * pack_capacity_ah  # A per V
            i_new = state["i"] + gain * (v_pack - v_cv)  # v > v_cv -> less negative
            state["i"] = float(np.clip(i_new, i_cc, 0.0))
            if state["i"] > i_cut:
                state["done"] = True
                return 0.0
        return state["i"]

    controller.state = state
    return controller
