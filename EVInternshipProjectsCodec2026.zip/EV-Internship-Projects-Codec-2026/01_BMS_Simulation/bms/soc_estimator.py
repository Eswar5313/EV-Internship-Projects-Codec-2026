"""State-of-charge estimators.

1. CoulombCounter  - integrates measured current. Simple, but any initial
   error and current-sensor bias accumulate (drift).
2. ExtendedKalmanFilter - EKF on the 2-RC cell model, corrected by the
   measured terminal voltage through the OCV(SOC) relation. Both are
   run on the average cell (pack voltage / Ns, pack current / Np).

EKF equations (Plett, "Battery Management Systems Vol. II", ch. 3):
    Prediction:   x^- = A x + B u,           P^- = A P A' + Q
    Jacobian:     C   = [dOCV/dSOC, -1, -1]
    Innovation:   y   = V_meas - (OCV(soc^-) - v1^- - v2^- - R0(T) u)
    Gain:         K   = P^- C' / (C P^- C' + R)
    Update:       x   = x^- + K y,           P = (I - K C) P^-
"""

from __future__ import annotations

import numpy as np

from .cell_model import CellParams, discrete_matrices, docv_dsoc, ocv


class CoulombCounter:
    """SOC by current integration (Ah counting)."""

    def __init__(self, capacity_ah: float, soc0: float):
        self.capacity_ah = capacity_ah
        self.soc = float(soc0)

    def step(self, current_a: float, dt: float) -> float:
        self.soc = float(np.clip(self.soc - current_a * dt / (3600.0 * self.capacity_ah), 0.0, 1.0))
        return self.soc


class ExtendedKalmanFilter:
    """EKF for the 2-RC model, state x = [soc, v1, v2]."""

    def __init__(self, params: CellParams, dt: float, soc0: float,
                 q_diag=(1e-8, 1e-6, 1e-6), r_meas: float = 5e-3**2,
                 p0_diag=(0.02, 1e-4, 1e-4)):
        self.p = params
        self.dt = dt
        self.A, self.B = discrete_matrices(params, dt)
        self.x = np.array([soc0, 0.0, 0.0])
        self.P = np.diag(p0_diag)
        self.Q = np.diag(q_diag)
        self.R = r_meas
        self.last_innovation = 0.0

    @property
    def soc(self) -> float:
        return float(self.x[0])

    def step(self, current_a: float, voltage_meas: float, temp_c: float) -> float:
        """One predict/update cycle. current_a = discharge-positive cell current."""
        # --- predict
        x = self.A @ self.x + self.B * current_a
        x[0] = np.clip(x[0], 0.0, 1.0)
        P = self.A @ self.P @ self.A.T + self.Q

        # --- measurement model and Jacobian
        r0 = float(self.p.r0(temp_c))
        v_pred = float(ocv(x[0]) - x[1] - x[2] - r0 * current_a)
        C = np.array([float(docv_dsoc(x[0])), -1.0, -1.0])

        # --- update
        s = float(C @ P @ C.T + self.R)
        K = (P @ C.T) / s
        innov = voltage_meas - v_pred
        x = x + K * innov
        x[0] = np.clip(x[0], 0.0, 1.0)
        I_KC = np.eye(3) - np.outer(K, C)
        # Joseph form for numerical robustness
        P = I_KC @ P @ I_KC.T + np.outer(K, K) * self.R

        self.x, self.P, self.last_innovation = x, P, innov
        return self.soc


def rmse_pct(estimate, truth) -> float:
    e = np.asarray(estimate) - np.asarray(truth)
    return float(np.sqrt(np.mean(e**2)) * 100.0)


def max_abs_err_pct(estimate, truth) -> float:
    return float(np.max(np.abs(np.asarray(estimate) - np.asarray(truth))) * 100.0)
