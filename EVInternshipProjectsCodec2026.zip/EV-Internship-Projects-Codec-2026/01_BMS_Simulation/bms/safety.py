"""Safety monitoring (fault flags) and passive cell balancing.

Fault checks performed every step:
    OVER_VOLTAGE   any cell voltage  > v_cell_max
    UNDER_VOLTAGE  any cell voltage  < v_cell_min
    OVER_TEMP      pack temperature  > t_max
    UNDER_TEMP     pack temperature  < t_min (charging not allowed)
    OVER_CURRENT   |I| > limit (separate discharge / charge limits)
    IMBALANCE      max(V_cell) - min(V_cell) > imbalance_mv  -> request balancing

Each new fault is logged as an event (time, flag, value). Flags with
`latching=True` remain set until `reset()` is called (as a real BMS would
open the contactors and require a service reset).

Passive balancing: each cell has a bleed resistor switched by the BMS.
Cells whose voltage (a proxy for SOC at rest) is more than `threshold_mv`
above the weakest cell are bled with `bleed_current_a`. The balancer
returns an (Ns, Np) array of extra discharge current for the pack model.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np


class Fault(str, Enum):
    OVER_VOLTAGE = "OVER_VOLTAGE"
    UNDER_VOLTAGE = "UNDER_VOLTAGE"
    OVER_TEMP = "OVER_TEMP"
    UNDER_TEMP = "UNDER_TEMP"
    OVER_CURRENT = "OVER_CURRENT"
    IMBALANCE = "IMBALANCE"


@dataclass
class SafetyLimits:
    v_cell_max: float = 4.25
    v_cell_min: float = 2.80
    t_max_c: float = 55.0
    t_min_c: float = 0.0
    i_discharge_max_a: float = 300.0
    i_charge_max_a: float = 150.0
    imbalance_mv: float = 40.0


@dataclass
class FaultEvent:
    time_s: float
    fault: Fault
    value: float
    scenario: str = ""

    def as_dict(self):
        return {"time_s": round(self.time_s, 1), "fault": self.fault.value,
                "value": round(float(self.value), 4), "scenario": self.scenario}


@dataclass
class SafetyMonitor:
    limits: SafetyLimits = field(default_factory=SafetyLimits)
    scenario: str = ""
    latching: bool = True
    active: set = field(default_factory=set)
    latched: set = field(default_factory=set)
    events: list = field(default_factory=list)

    def reset(self):
        self.active.clear()
        self.latched.clear()

    def check(self, t: float, cell_voltages: np.ndarray, temp_c: float, current_a: float) -> set:
        """Evaluate all limits; return the set of currently active faults."""
        L = self.limits
        v = np.asarray(cell_voltages)
        vmax, vmin = float(v.max()), float(v.min())
        now = {}
        if vmax > L.v_cell_max:
            now[Fault.OVER_VOLTAGE] = vmax
        if vmin < L.v_cell_min:
            now[Fault.UNDER_VOLTAGE] = vmin
        if temp_c > L.t_max_c:
            now[Fault.OVER_TEMP] = temp_c
        if temp_c < L.t_min_c:
            now[Fault.UNDER_TEMP] = temp_c
        if current_a > L.i_discharge_max_a or -current_a > L.i_charge_max_a:
            now[Fault.OVER_CURRENT] = current_a
        if (vmax - vmin) * 1e3 > L.imbalance_mv:
            now[Fault.IMBALANCE] = (vmax - vmin) * 1e3

        for f, val in now.items():
            if f not in self.active:  # rising edge -> log an event
                self.events.append(FaultEvent(t, f, val, self.scenario))
        self.active = set(now)
        if self.latching:
            self.latched |= {f for f in now if f is not Fault.IMBALANCE}
        return self.active

    @property
    def contactor_open(self) -> bool:
        """True when a latched hard fault requires the main contactor open."""
        return bool(self.latched)

    def event_counts(self) -> dict:
        counts = {f.value: 0 for f in Fault}
        for e in self.events:
            counts[e.fault.value] += 1
        return counts


@dataclass
class PassiveBalancer:
    """Bleed-resistor balancing decided from cell voltages."""

    bleed_current_a: float = 0.15  # typical 100-200 mA bleed
    threshold_mv: float = 5.0  # start bleeding when > min cell + threshold
    allow_when_current_above_a: float = 5.0  # only balance at rest / low current
    n_active: int = 0

    def command(self, cell_voltages: np.ndarray, pack_current_a: float) -> np.ndarray:
        v = np.asarray(cell_voltages)
        if abs(pack_current_a) > self.allow_when_current_above_a:
            self.n_active = 0
            return np.zeros_like(v)
        mask = (v - v.min()) * 1e3 > self.threshold_mv
        self.n_active = int(mask.sum())
        return mask.astype(float) * self.bleed_current_a
