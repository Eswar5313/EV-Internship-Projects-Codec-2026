"""Battery pack aggregation (default 96s2p) built from the 2-RC cell model.

The pack is simulated with NumPy arrays of shape (n_series, n_parallel) so
that all cells are advanced at once. Cell-to-cell variation (capacity and
resistance) is drawn from a seeded random generator so runs are reproducible.

Simplifications:
* Cells in a parallel group share current in proportion to their capacity
  (a good approximation when the cells have similar impedance).
* Group voltage = mean of the parallel cells' terminal voltages.
* A single lumped pack temperature is used for all cells (see thermal.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .cell_model import CellParams, entropic_coeff, ocv


@dataclass
class PackConfig:
    n_series: int = 96
    n_parallel: int = 2
    capacity_std_pct: float = 1.5  # std-dev of capacity variation [%]
    r0_std_pct: float = 4.0  # std-dev of R0 variation [%]
    soc_std_pct: float = 0.0  # initial SOC spread [% points]
    seed: int = 42
    r_interconnect_ohm: float = 0.25e-3  # busbar/weld resistance per series group [ohm]
    r0_age_scale: float = 1.0  # >1 for an aged pack (resistance growth)
    cell: CellParams = field(default_factory=CellParams)


class BatteryPack:
    """Vectorised Ns x Np pack of 2-RC cells."""

    def __init__(self, config: PackConfig | None = None, soc0: float = 0.9):
        self.cfg = config or PackConfig()
        p = self.cfg.cell
        rng = np.random.default_rng(self.cfg.seed)
        shape = (self.cfg.n_series, self.cfg.n_parallel)

        self.capacity = p.capacity_ah * (1 + rng.normal(0, self.cfg.capacity_std_pct / 100, shape))
        self.r0_scale = (1 + rng.normal(0, self.cfg.r0_std_pct / 100, shape)) * self.cfg.r0_age_scale
        self.soc = np.clip(soc0 + rng.normal(0, self.cfg.soc_std_pct / 100, shape), 0, 1)
        self.v1 = np.zeros(shape)
        self.v2 = np.zeros(shape)
        self.cell_current = np.zeros(shape)
        self.cell_voltage = ocv(self.soc)
        self.ah_throughput = 0.0

    # ------------------------------------------------------------------
    @property
    def n_cells(self) -> int:
        return self.cfg.n_series * self.cfg.n_parallel

    @property
    def nominal_capacity_ah(self) -> float:
        return self.cfg.cell.capacity_ah * self.cfg.n_parallel

    @property
    def nominal_voltage(self) -> float:
        return float(ocv(0.5) * self.cfg.n_series)

    @property
    def pack_soc(self) -> float:
        """Capacity-weighted mean SOC of all cells (the 'true' pack SOC)."""
        return float(np.sum(self.soc * self.capacity) / np.sum(self.capacity))

    @property
    def pack_voltage(self) -> float:
        """Terminal voltage incl. interconnect drop (pack_current sign: discharge +)."""
        return float(np.sum(self.cell_voltage.mean(axis=1))
                     - self.cfg.n_series * self.cfg.r_interconnect_ohm * self.cell_current.sum(axis=1).mean())

    @property
    def min_cell_voltage(self) -> float:
        return float(self.cell_voltage.min())

    @property
    def max_cell_voltage(self) -> float:
        return float(self.cell_voltage.max())

    # ------------------------------------------------------------------
    def split_current(self, pack_current_a: float) -> np.ndarray:
        """Distribute pack current among parallel cells (capacity weighted)."""
        w = self.capacity / self.capacity.sum(axis=1, keepdims=True)
        return pack_current_a * w

    def step(self, pack_current_a: float, dt: float, temp_c: float,
             bleed_current: np.ndarray | None = None) -> float:
        """Advance all cells by dt. Returns pack terminal voltage [V].

        bleed_current: optional (Ns, Np) array of additional discharge current
        drawn by passive balancing resistors.
        """
        p = self.cfg.cell
        i = self.split_current(pack_current_a)
        if bleed_current is not None:
            i = i + bleed_current
        a1 = np.exp(-dt / p.tau1)
        a2 = np.exp(-dt / p.tau2)
        self.v1 = a1 * self.v1 + p.r1 * (1 - a1) * i
        self.v2 = a2 * self.v2 + p.r2 * (1 - a2) * i
        self.soc = np.clip(self.soc - i * dt / (3600.0 * self.capacity), 0.0, 1.0)
        r0 = p.r0(temp_c) * self.r0_scale
        self.cell_voltage = ocv(self.soc) - i * r0 - self.v1 - self.v2
        self.cell_current = i
        self.ah_throughput += abs(pack_current_a) * dt / 3600.0
        return self.pack_voltage

    def heat_w(self, temp_c: float) -> float:
        """Total heat generation of the pack [W] (Joule + entropic)."""
        p = self.cfg.cell
        r0 = p.r0(temp_c) * self.r0_scale
        i = self.cell_current
        q_irr = i**2 * r0 + self.v1**2 / p.r1 + self.v2**2 / p.r2
        q_rev = -i * (temp_c + 273.15) * entropic_coeff(self.soc)
        i_pack = float(i.sum(axis=1).mean())
        q_interconnect = self.cfg.n_series * self.cfg.r_interconnect_ohm * i_pack**2
        return float(np.sum(q_irr + q_rev) + q_interconnect)

    def internal_resistance(self, temp_c: float) -> float:
        """Approximate pack DC resistance [ohm] (R0 only)."""
        r0 = self.cfg.cell.r0(temp_c) * self.r0_scale
        # parallel cells: 1/sum(1/R); series groups add; plus interconnects
        return float(np.sum(1.0 / np.sum(1.0 / r0, axis=1)) + self.cfg.n_series * self.cfg.r_interconnect_ohm)
