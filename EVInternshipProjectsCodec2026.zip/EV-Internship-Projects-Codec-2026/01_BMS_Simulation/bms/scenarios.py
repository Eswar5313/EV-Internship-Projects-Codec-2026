"""Closed-loop simulation scenarios that tie all BMS blocks together.

Each function returns a plain dict of NumPy arrays / scalars so that
main.py can plot and summarise them, and tests can assert on them.
"""

from __future__ import annotations

import numpy as np

from .drive_cycle import cc_cv_charge_profile, current_from_speed, synthetic_speed_profile
from .pack import BatteryPack, PackConfig
from .safety import PassiveBalancer, SafetyLimits, SafetyMonitor
from .soc_estimator import CoulombCounter, ExtendedKalmanFilter, max_abs_err_pct, rmse_pct
from .soh_estimator import count_half_cycles, equivalent_full_cycles, estimate_capacity_least_squares
from .thermal import ThermalManager, ThermalManagerConfig, ThermalModel, ThermalParams


class Sensors:
    """Adds realistic sensor imperfections (noise + current bias)."""

    def __init__(self, seed: int, v_noise_cell: float = 3e-3, i_noise_a: float = 1.0, i_bias_a: float = 2.0):
        self.rng = np.random.default_rng(seed)
        self.v_noise_cell = v_noise_cell
        self.i_noise_a = i_noise_a
        self.i_bias_a = i_bias_a

    def measure(self, v_pack: float, i_pack: float, n_series: int):
        v_meas = v_pack + self.rng.normal(0, self.v_noise_cell * np.sqrt(n_series))
        i_meas = i_pack + self.i_bias_a + self.rng.normal(0, self.i_noise_a)
        return v_meas, i_meas


def simulate_drive(thermal_enabled: bool = True, soc0: float = 0.90, temp0_c: float = 36.0,
                   t_ambient_c: float = 40.0, dt: float = 1.0, cc_soc0_error: float = -0.05,
                   ekf_soc0_error: float = -0.15, seed: int = 42, scenario_name: str = "drive") -> dict:
    """Drive cycle with pack, thermal management, safety and SOC estimators."""
    pack = BatteryPack(PackConfig(seed=seed), soc0=soc0)
    cell = pack.cfg.cell
    ns, npar = pack.cfg.n_series, pack.cfg.n_parallel

    t, speed = synthetic_speed_profile(dt=dt)
    power, current = current_from_speed(t, speed, pack.nominal_voltage)

    thermal = ThermalModel(ThermalParams(), temp0_c=temp0_c, t_ambient_c=t_ambient_c)
    manager = ThermalManager(ThermalManagerConfig(enabled=thermal_enabled))
    safety = SafetyMonitor(SafetyLimits(), scenario=scenario_name)
    sensors = Sensors(seed=seed + 1)

    cc = CoulombCounter(cell.capacity_ah, soc0 + cc_soc0_error)
    ekf = ExtendedKalmanFilter(cell, dt, soc0 + ekf_soc0_error)

    n = len(t)
    log = {k: np.zeros(n) for k in ("v_pack", "i_pack", "v_meas", "i_meas", "soc_true", "soc_cc", "soc_ekf",
                                     "temp", "flow", "heater", "q_gen", "v_cell_min", "v_cell_max", "n_faults")}
    for k in range(n):
        i_pack = float(current[k])
        v_pack = pack.step(i_pack, dt, thermal.temp_c)
        q_gen = pack.heat_w(thermal.temp_c)
        flow, heater = manager.update(thermal.temp_c, dt)
        temp = thermal.step(q_gen, flow, heater, dt)
        faults = safety.check(t[k], pack.cell_voltage, temp, i_pack)

        v_meas, i_meas = sensors.measure(v_pack, i_pack, ns)
        cc.step(i_meas / npar, dt)
        ekf.step(i_meas / npar, v_meas / ns, temp)

        log["v_pack"][k], log["i_pack"][k] = v_pack, i_pack
        log["v_meas"][k], log["i_meas"][k] = v_meas, i_meas
        log["soc_true"][k], log["soc_cc"][k], log["soc_ekf"][k] = pack.pack_soc, cc.soc, ekf.soc
        log["temp"][k], log["flow"][k], log["heater"][k], log["q_gen"][k] = temp, flow, heater, q_gen
        log["v_cell_min"][k], log["v_cell_max"][k] = pack.min_cell_voltage, pack.max_cell_voltage
        log["n_faults"][k] = len(faults)

    # ignore the first 5 minutes of EKF convergence when computing RMSE
    settle = int(300 / dt)
    dods = count_half_cycles(log["soc_true"])
    return {
        "t": t, "speed_kmh": speed, "power_w": power, **log,
        "ekf_rmse_pct": rmse_pct(log["soc_ekf"][settle:], log["soc_true"][settle:]),
        "ekf_rmse_full_pct": rmse_pct(log["soc_ekf"], log["soc_true"]),
        "ekf_max_err_pct": max_abs_err_pct(log["soc_ekf"][settle:], log["soc_true"][settle:]),
        "cc_rmse_pct": rmse_pct(log["soc_cc"], log["soc_true"]),
        "cc_final_err_pct": float((log["soc_cc"][-1] - log["soc_true"][-1]) * 100),
        "ekf_final_err_pct": float((log["soc_ekf"][-1] - log["soc_true"][-1]) * 100),
        "peak_temp_c": float(log["temp"].max()),
        "temp_limit_c": manager.cfg.t_limit_c,
        "energy_kwh": float(np.sum(power * dt) / 3.6e6),
        "distance_km": float(np.sum(speed / 3.6 * dt) / 1000),
        "ah_throughput": pack.ah_throughput,
        "equivalent_full_cycles": equivalent_full_cycles(current, dt, pack.nominal_capacity_ah),
        "half_cycles": len(dods), "max_dod_pct": float(dods.max() * 100) if len(dods) else 0.0,
        "peak_discharge_a": float(current.max()), "peak_regen_a": float(current.min()),
        "fault_events": [e.as_dict() for e in safety.events],
        "fault_counts": safety.event_counts(),
        "thermal_enabled": thermal_enabled,
        "pack": pack,
    }


def simulate_cold_start(dt: float = 1.0, temp0_c: float = -8.0, t_ambient_c: float = -8.0, duration_s: float = 1500) -> dict:
    """Pack idle at -8 degC with the heater enabled: shows heater hysteresis."""
    thermal = ThermalModel(ThermalParams(), temp0_c=temp0_c, t_ambient_c=t_ambient_c)
    manager = ThermalManager(ThermalManagerConfig())
    safety = SafetyMonitor(SafetyLimits(), scenario="cold_start", latching=False)
    pack = BatteryPack(PackConfig(), soc0=0.5)
    n = int(duration_s / dt)
    t = np.arange(n) * dt
    temp = np.zeros(n)
    heater = np.zeros(n)
    under_temp = np.zeros(n, dtype=bool)
    for k in range(n):
        flow, p_heat = manager.update(thermal.temp_c, dt)
        temp[k] = thermal.step(0.0, flow, p_heat, dt)
        heater[k] = p_heat
        under_temp[k] = "UNDER_TEMP" in {f.value for f in safety.check(t[k], pack.cell_voltage, temp[k], 0.0)}
    return {"t": t, "temp": temp, "heater": heater, "under_temp_flag": under_temp,
            "min_temp_c": float(temp.min()), "final_temp_c": float(temp[-1]),
            "charge_inhibit_min": float(under_temp.sum() * dt / 60),
            "heater_energy_kwh": float(np.sum(heater) * dt / 3.6e6),
            "fault_events": [e.as_dict() for e in safety.events], "fault_counts": safety.event_counts()}


def simulate_charge(soc0: float = 0.25, c_rate: float = 0.5, temp0_c: float = 28.0, dt: float = 1.0, seed: int = 42,
                    thermal_enabled: bool = True, scenario_name: str = "charge") -> dict:
    """CC-CV charge with EKF tracking and least-squares capacity estimation.

    c_rate = 0.5 -> AC charging; c_rate = 1.5 with thermal_enabled=False
    -> DC fast charge without cooling (thermal stress case).
    """
    pack = BatteryPack(PackConfig(seed=seed), soc0=soc0)
    cell = pack.cfg.cell
    ns, npar = pack.cfg.n_series, pack.cfg.n_parallel
    ctrl = cc_cv_charge_profile(pack.nominal_capacity_ah, ns, c_rate=c_rate, dt=dt)
    thermal = ThermalModel(ThermalParams(), temp0_c=temp0_c, t_ambient_c=temp0_c)
    manager = ThermalManager(ThermalManagerConfig(enabled=thermal_enabled))
    safety = SafetyMonitor(SafetyLimits(), scenario=scenario_name)
    sensors = Sensors(seed=seed + 2, i_bias_a=0.5)
    ekf = ExtendedKalmanFilter(cell, dt, soc0 - 0.10)

    keys = ("t", "v_pack", "i_pack", "soc_true", "soc_ekf", "temp", "v_cell_max", "flow")
    log = {k: [] for k in keys}
    t = 0.0
    v_pack = pack.pack_voltage
    while True:
        i_pack = ctrl(v_pack)
        if ctrl.state["done"]:
            break
        v_pack = pack.step(i_pack, dt, thermal.temp_c)
        flow, heater = manager.update(thermal.temp_c, dt)
        temp = thermal.step(pack.heat_w(thermal.temp_c), flow, heater, dt)
        safety.check(t, pack.cell_voltage, temp, i_pack)
        v_meas, i_meas = sensors.measure(v_pack, i_pack, ns)
        ekf.step(i_meas / npar, v_meas / ns, temp)
        for k, val in zip(keys, (t, v_pack, i_pack, pack.pack_soc, ekf.soc, temp, pack.max_cell_voltage, flow)):
            log[k].append(val)
        t += dt
    log = {k: np.asarray(v) for k, v in log.items()}

    # least-squares capacity estimate on a partial CC segment (SOC 35 % -> 75 %)
    seg = (log["soc_ekf"] > 0.35) & (log["soc_ekf"] < 0.75) & (log["i_pack"] < -0.4 * c_rate * pack.nominal_capacity_ah)
    q_est_cell, r2 = estimate_capacity_least_squares(log["soc_ekf"][seg], log["i_pack"][seg] / npar, dt)
    q_true_cell = float(pack.capacity.mean())
    # two-point OCV method as a cross-check: OCV at start and end of charge is not available
    # under load, so use the model-inverted SOC of the average cell at the segment ends
    return {
        **log, "charge_time_min": float(t / 60), "soc_final": float(pack.pack_soc),
        "cv_start_time_min": float(log["t"][np.argmax(log["i_pack"] > log["i_pack"].min() + 0.5)] / 60),
        "q_est_ah": q_est_cell, "q_true_ah": q_true_cell, "q_nominal_ah": cell.capacity_ah,
        "q_est_err_pct": float((q_est_cell - q_true_cell) / q_true_cell * 100), "ls_r2": r2,
        "ekf_rmse_pct": rmse_pct(log["soc_ekf"][300:], log["soc_true"][300:]),
        "peak_temp_c": float(log["temp"].max()), "temp_limit_c": manager.cfg.t_limit_c,
        "thermal_enabled": thermal_enabled, "c_rate": c_rate,
        "fault_events": [e.as_dict() for e in safety.events], "fault_counts": safety.event_counts(),
    }


def simulate_fast_charge(thermal_enabled: bool = True, c_rate: float = 1.5, soc0: float = 0.20,
                         temp0_c: float = 34.0, seed: int = 42) -> dict:
    """DC fast charge (default 1.5C) on a warm pack - the thermal stress case."""
    return simulate_charge(soc0=soc0, c_rate=c_rate, temp0_c=temp0_c, seed=seed, thermal_enabled=thermal_enabled,
                           scenario_name=f"fast_charge_{'cooled' if thermal_enabled else 'uncooled'}")


def simulate_balancing(soc_std_pct: float = 1.0, hours: float = 9.0, dt: float = 20.0, seed: int = 42) -> dict:
    """Pack at rest with an initial SOC spread; passive balancing bleeds high cells."""
    pack = BatteryPack(PackConfig(seed=seed, soc_std_pct=soc_std_pct), soc0=0.80)
    balancer = PassiveBalancer(bleed_current_a=0.2)
    safety = SafetyMonitor(SafetyLimits(), scenario="balancing", latching=False)
    n = int(hours * 3600 / dt)
    t = np.arange(n) * dt
    spread_mv = np.zeros(n)
    soc_spread = np.zeros(n)
    n_active = np.zeros(n)
    soc_cells = np.zeros((n, pack.n_cells))
    imbalance_flag = np.zeros(n, dtype=bool)
    for k in range(n):
        bleed = balancer.command(pack.cell_voltage, 0.0)
        pack.step(0.0, dt, 25.0, bleed_current=bleed)
        faults = safety.check(t[k], pack.cell_voltage, 25.0, 0.0)
        spread_mv[k] = (pack.max_cell_voltage - pack.min_cell_voltage) * 1e3
        soc_spread[k] = (pack.soc.max() - pack.soc.min()) * 100
        n_active[k] = balancer.n_active
        soc_cells[k] = pack.soc.ravel()
        imbalance_flag[k] = "IMBALANCE" in {f.value for f in faults}
    return {"t": t, "spread_mv": spread_mv, "soc_spread_pct": soc_spread, "n_active": n_active,
            "soc_cells": soc_cells, "imbalance_flag": imbalance_flag,
            "initial_spread_mv": float(spread_mv[0]), "final_spread_mv": float(spread_mv[-1]),
            "initial_soc_spread_pct": float(soc_spread[0]), "final_soc_spread_pct": float(soc_spread[-1]),
            "time_to_balance_h": float(t[np.argmax(~imbalance_flag)] / 3600) if (~imbalance_flag).any() else float("nan"),
            "energy_bled_wh": float(np.sum(n_active) * balancer.bleed_current_a * 3.7 * dt / 3600)}


def simulate_fault_injection(dt: float = 1.0, seed: int = 42) -> dict:
    """Deliberately abuse a small pack to exercise every fault flag."""
    pack = BatteryPack(PackConfig(seed=seed), soc0=0.97)
    safety = SafetyMonitor(SafetyLimits(), scenario="fault_injection")
    thermal = ThermalModel(ThermalParams(ua_amb=2.0), temp0_c=40.0, t_ambient_c=40.0)
    manager = ThermalManager(ThermalManagerConfig(enabled=False))  # cooling disabled on purpose
    n = 2100
    t = np.arange(n) * dt
    current = np.zeros(n)
    current[100:400] = -100.0  # hard charge at 97 % SOC -> over-voltage
    current[500:520] = 320.0  # 20 s over-current pulse
    current[600:2000] = 180.0  # sustained 3C discharge without cooling -> over-temp then under-voltage
    temp = np.zeros(n)
    vmin = np.zeros(n)
    vmax = np.zeros(n)
    for k in range(n):
        pack.step(current[k], dt, thermal.temp_c)
        flow, heater = manager.update(thermal.temp_c, dt)
        temp[k] = thermal.step(pack.heat_w(thermal.temp_c), flow, heater, dt)
        vmin[k], vmax[k] = pack.min_cell_voltage, pack.max_cell_voltage
        safety.check(t[k], pack.cell_voltage, temp[k], current[k])
    return {"t": t, "current": current, "temp": temp, "v_cell_min": vmin, "v_cell_max": vmax,
            "fault_events": [e.as_dict() for e in safety.events], "fault_counts": safety.event_counts(),
            "contactor_open": safety.contactor_open,
            "flags_raised": sorted({e["fault"] for e in [ev.as_dict() for ev in safety.events]})}
