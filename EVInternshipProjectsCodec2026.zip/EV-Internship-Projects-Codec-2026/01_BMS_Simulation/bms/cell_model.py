"""Second-order (2-RC) equivalent-circuit model of a Li-ion (NMC-like) cell.

Circuit (discharge current i > 0 flows out of the cell):

        +--R1--+     +--R2--+
   OCV --| R0 |--|      |--|      |---o  V_terminal
        +--C1--+     +--C2--+

    V = OCV(soc) - i*R0(T) - v1 - v2

State vector per cell: [soc, v1, v2]
    d(soc)/dt = -i / (3600 * Q)                     (Q in Ah)
    d(v1)/dt  = -v1/(R1*C1) + i/C1
    d(v2)/dt  = -v2/(R2*C2) + i/C2

R0 is temperature dependent via an Arrhenius law:
    R0(T) = R0_ref * exp( Ea/Rg * (1/T - 1/T_ref) )

The OCV-SOC curve is a lookup table shaped like a typical NMC/graphite cell
(3.0 V at 0 % SOC, ~3.7 V at 50 %, 4.2 V at 100 %). The values are
synthetic: they are NOT measured from a real cell.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# ---------------------------------------------------------------------------
# OCV-SOC lookup table (synthetic NMC-like curve)
# ---------------------------------------------------------------------------
OCV_SOC_TABLE = np.array(
    [0.00, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 0.95, 1.00]
)
OCV_V_TABLE = np.array(
    [3.00, 3.35, 3.48, 3.56, 3.62, 3.66, 3.71, 3.78, 3.87, 3.96, 4.06, 4.12, 4.20]
)

# Entropic coefficient dU/dT [V/K] vs SOC (synthetic, order of magnitude of
# literature values for NMC: a few tenths of a mV/K)
DUDT_TABLE = np.array(
    [-0.30, -0.20, -0.10, 0.00, 0.05, 0.10, 0.05, 0.00, -0.10, -0.15, -0.20, -0.25, -0.30]
) * 1e-3

_R_GAS = 8.314  # J/(mol K)


def ocv(soc):
    """Open-circuit voltage [V] from SOC (0..1). Vectorised, clipped."""
    return np.interp(np.clip(soc, 0.0, 1.0), OCV_SOC_TABLE, OCV_V_TABLE)


def docv_dsoc(soc, eps: float = 1e-3):
    """Numerical slope dOCV/dSOC [V per unit SOC] used by the EKF Jacobian."""
    s = np.clip(soc, eps, 1.0 - eps)
    return (ocv(s + eps) - ocv(s - eps)) / (2 * eps)


def soc_from_ocv(v):
    """Inverse lookup: SOC from OCV (table is monotonic so this is safe)."""
    return np.interp(v, OCV_V_TABLE, OCV_SOC_TABLE)


def entropic_coeff(soc):
    """dU/dT [V/K] as a function of SOC."""
    return np.interp(np.clip(soc, 0.0, 1.0), OCV_SOC_TABLE, DUDT_TABLE)


@dataclass
class CellParams:
    """Parameters of a 30 Ah prismatic NMC-like cell (synthetic values).

    96s2p of these cells gives a ~21 kWh / 355 V pack, similar in size to a
    compact city EV pack.
    """

    capacity_ah: float = 30.0  # nominal capacity [Ah]
    r0_ref: float = 2.0e-3  # ohmic resistance at T_ref [ohm]
    r1: float = 1.2e-3  # first RC branch [ohm]
    c1: float = 16_667.0  # [F]  -> tau1 = 20 s
    r2: float = 0.8e-3  # second RC branch [ohm]
    c2: float = 125_000.0  # [F]  -> tau2 = 100 s
    t_ref_k: float = 298.15  # reference temperature [K]
    ea_r0: float = 20_000.0  # activation energy for R0 [J/mol]
    v_max: float = 4.20  # charge cut-off [V]
    v_min: float = 2.80  # discharge cut-off [V]
    mass_kg: float = 0.65
    cp_j_per_kgk: float = 1000.0

    @property
    def tau1(self) -> float:
        return self.r1 * self.c1

    @property
    def tau2(self) -> float:
        return self.r2 * self.c2

    def r0(self, temp_c):
        """Temperature-dependent ohmic resistance [ohm] (Arrhenius)."""
        t_k = np.asarray(temp_c, dtype=float) + 273.15
        return self.r0_ref * np.exp(self.ea_r0 / _R_GAS * (1.0 / t_k - 1.0 / self.t_ref_k))


@dataclass
class Cell:
    """A single cell with 2-RC dynamics. Positive current = discharge."""

    params: CellParams = field(default_factory=CellParams)
    soc: float = 0.9
    v1: float = 0.0
    v2: float = 0.0
    capacity_ah: float | None = None  # actual capacity (may differ from nominal)
    r0_scale: float = 1.0  # cell-to-cell resistance variation / ageing

    def __post_init__(self):
        if self.capacity_ah is None:
            self.capacity_ah = self.params.capacity_ah

    def terminal_voltage(self, current_a: float, temp_c: float) -> float:
        r0 = self.params.r0(temp_c) * self.r0_scale
        return float(ocv(self.soc) - current_a * r0 - self.v1 - self.v2)

    def step(self, current_a: float, dt: float, temp_c: float) -> float:
        """Advance the state by dt seconds and return the terminal voltage."""
        p = self.params
        a1 = np.exp(-dt / p.tau1)
        a2 = np.exp(-dt / p.tau2)
        self.v1 = a1 * self.v1 + p.r1 * (1 - a1) * current_a
        self.v2 = a2 * self.v2 + p.r2 * (1 - a2) * current_a
        self.soc = float(np.clip(self.soc - current_a * dt / (3600.0 * self.capacity_ah), 0.0, 1.0))
        return self.terminal_voltage(current_a, temp_c)

    def heat_w(self, current_a: float, temp_c: float) -> float:
        """Irreversible (Joule) + reversible (entropic) heat generation [W]."""
        p = self.params
        r0 = p.r0(temp_c) * self.r0_scale
        q_irr = current_a**2 * r0 + self.v1**2 / p.r1 + self.v2**2 / p.r2
        # Bernardi reversible term; with discharge-positive current:
        q_rev = -current_a * (temp_c + 273.15) * entropic_coeff(self.soc)
        return float(q_irr + q_rev)


def discrete_matrices(params: CellParams, dt: float):
    """State-transition matrix A and input vector B of the 2-RC model.

    x = [soc, v1, v2], u = current (discharge positive):
        x[k+1] = A x[k] + B u[k]
    Capacity used is the nominal one (the estimator does not know the true
    capacity of each cell).
    """
    a1 = np.exp(-dt / params.tau1)
    a2 = np.exp(-dt / params.tau2)
    A = np.diag([1.0, a1, a2])
    B = np.array([-dt / (3600.0 * params.capacity_ah), params.r1 * (1 - a1), params.r2 * (1 - a2)])
    return A, B
