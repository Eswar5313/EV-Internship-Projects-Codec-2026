"""Lumped-parameter thermal model of the pack and a simple thermal manager.

Energy balance (single thermal mass for the whole pack):

    m_pack * cp * dT/dt = Q_gen + P_heater - UA_cool(flow) * (T - T_coolant)
                                          - UA_amb * (T - T_ambient)

    Q_gen  = sum over cells of ( I^2 R0 + v1^2/R1 + v2^2/R2  - I T dU/dT )
             (Joule/irreversible + entropic/reversible heat, computed by
              BatteryPack.heat_w)
    UA_cool(flow) = ua_cool_min + ua_cool_gain * flow   [W/K], flow in L/min

Thermal manager:
* Cooling: hysteresis switches the coolant pump ON above T_on and OFF
  below T_off. While ON, a PI controller sets the flow rate to drive the
  pack temperature towards T_target (with anti-windup clamping).
* Heating: a resistive heater (P_heater) is enabled below T_heat_on and
  disabled above T_heat_off (cold-start, e.g. winter).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ThermalParams:
    mass_kg: float = 125.0  # 192 cells x 0.65 kg (cell mass only, synthetic)
    cp: float = 1000.0  # J/(kg K)
    ua_amb: float = 12.0  # passive loss to ambient [W/K]
    ua_cool_min: float = 0.0  # conductance to coolant with pump off
    ua_cool_gain: float = 45.0  # W/K per L/min of coolant flow
    flow_max_lpm: float = 12.0
    flow_min_lpm: float = 1.0
    t_coolant_c: float = 22.0  # chiller outlet temperature
    p_heater_w: float = 2500.0


@dataclass
class ThermalManagerConfig:
    enabled: bool = True
    t_target_c: float = 30.0
    t_on_c: float = 33.0  # hysteresis: pump ON above this
    t_off_c: float = 29.0  # pump OFF below this
    kp: float = 3.0  # L/min per K
    ki: float = 0.01  # L/min per (K s)
    t_heat_on_c: float = 5.0  # heater ON below this
    t_heat_off_c: float = 10.0  # heater OFF above this
    t_limit_c: float = 45.0  # design limit used for reporting / tests


@dataclass
class ThermalManager:
    cfg: ThermalManagerConfig = field(default_factory=ThermalManagerConfig)
    params: ThermalParams = field(default_factory=ThermalParams)
    pump_on: bool = False
    heater_on: bool = False
    _integral: float = 0.0

    def update(self, temp_c: float, dt: float) -> tuple[float, float]:
        """Return (coolant_flow_lpm, heater_power_w) for the current step."""
        if not self.cfg.enabled:
            return 0.0, 0.0
        c, p = self.cfg, self.params

        # --- hysteresis pump on/off
        if temp_c > c.t_on_c:
            self.pump_on = True
        elif temp_c < c.t_off_c:
            self.pump_on = False

        flow = 0.0
        if self.pump_on:
            err = temp_c - c.t_target_c
            self._integral += err * dt
            flow = c.kp * err + c.ki * self._integral
            if flow > p.flow_max_lpm:  # anti-windup
                flow = p.flow_max_lpm
                self._integral -= err * dt
            flow = max(flow, p.flow_min_lpm)
        else:
            self._integral = 0.0

        # --- heater hysteresis
        if temp_c < c.t_heat_on_c:
            self.heater_on = True
        elif temp_c > c.t_heat_off_c:
            self.heater_on = False
        heater = p.p_heater_w if self.heater_on else 0.0
        return flow, heater


class ThermalModel:
    """Lumped pack thermal mass."""

    def __init__(self, params: ThermalParams | None = None, temp0_c: float = 30.0, t_ambient_c: float = 35.0):
        self.p = params or ThermalParams()
        self.temp_c = float(temp0_c)
        self.t_ambient_c = float(t_ambient_c)
        self.last_q_cool_w = 0.0

    def step(self, q_gen_w: float, flow_lpm: float, heater_w: float, dt: float) -> float:
        p = self.p
        ua_cool = p.ua_cool_min + p.ua_cool_gain * flow_lpm
        q_cool = ua_cool * (self.temp_c - p.t_coolant_c)
        q_amb = p.ua_amb * (self.temp_c - self.t_ambient_c)
        self.last_q_cool_w = q_cool
        dT = (q_gen_w + heater_w - q_cool - q_amb) / (p.mass_kg * p.cp) * dt
        self.temp_c += dT
        return self.temp_c
