"""pytest suite for the BMS simulation (run with `pytest` from the project root)."""

import numpy as np
import pytest

from bms.cell_model import OCV_SOC_TABLE, OCV_V_TABLE, Cell, CellParams, docv_dsoc, ocv, soc_from_ocv
from bms.drive_cycle import current_from_speed, synthetic_speed_profile
from bms.pack import BatteryPack, PackConfig
from bms.safety import Fault, PassiveBalancer, SafetyLimits, SafetyMonitor
from bms.scenarios import simulate_balancing, simulate_charge, simulate_cold_start, simulate_fault_injection
from bms.soc_estimator import CoulombCounter, ExtendedKalmanFilter, rmse_pct
from bms.soh_estimator import (AgeingModel, count_half_cycles, equivalent_full_cycles,
                               estimate_capacity_least_squares, run_accelerated_ageing)
from bms.thermal import ThermalManager, ThermalManagerConfig, ThermalModel


# ---------------------------------------------------------------- cell model
def test_ocv_table_monotonic():
    assert np.all(np.diff(OCV_SOC_TABLE) > 0)
    assert np.all(np.diff(OCV_V_TABLE) > 0)
    soc = np.linspace(0, 1, 1001)
    assert np.all(np.diff(ocv(soc)) >= 0)
    assert np.all(docv_dsoc(soc) > 0)
    assert np.allclose(soc_from_ocv(ocv(soc)), soc, atol=1e-6)


def test_r0_increases_when_cold():
    p = CellParams()
    assert p.r0(-10) > p.r0(25) > p.r0(45)
    assert np.isclose(p.r0(25), p.r0_ref, rtol=1e-3)


def test_cell_discharge_lowers_soc_and_voltage():
    c = Cell(soc=0.8)
    v0 = c.terminal_voltage(0.0, 25.0)
    v = c.step(30.0, 60.0, 25.0)  # 1C for 1 minute
    assert c.soc == pytest.approx(0.8 - 60 / 3600, abs=1e-9)
    assert v < v0


# ---------------------------------------------------------------- pack
def test_pack_aggregation_and_reproducibility():
    a = BatteryPack(PackConfig(seed=1), soc0=0.6)
    b = BatteryPack(PackConfig(seed=1), soc0=0.6)
    assert a.capacity.shape == (96, 2)
    assert np.array_equal(a.capacity, b.capacity)
    assert a.pack_voltage == pytest.approx(96 * ocv(0.6), rel=1e-6)
    # current split sums to the pack current in every series group
    i = a.split_current(50.0)
    assert np.allclose(i.sum(axis=1), 50.0)
    assert a.nominal_capacity_ah == 60.0


# ---------------------------------------------------------------- SOC estimation
def test_ekf_rmse_below_2pct(drive_managed):
    assert drive_managed["ekf_rmse_pct"] < 2.0
    assert drive_managed["ekf_max_err_pct"] < 3.0
    # EKF must beat Coulomb counting, which drifts with bias + wrong initial SOC
    assert drive_managed["ekf_rmse_pct"] < drive_managed["cc_rmse_pct"]
    assert abs(drive_managed["cc_final_err_pct"]) > 3.0


def test_ekf_converges_from_wrong_initial_soc():
    cell = Cell(soc=0.7)
    ekf = ExtendedKalmanFilter(CellParams(), dt=1.0, soc0=0.4)
    rng = np.random.default_rng(0)
    for k in range(600):
        i = 15.0 + 10.0 * np.sin(k / 30)
        v = cell.step(i, 1.0, 25.0)
        ekf.step(i + rng.normal(0, 0.2), v + rng.normal(0, 3e-3), 25.0)
    assert abs(ekf.soc - cell.soc) < 0.02


def test_coulomb_counter_integrates():
    cc = CoulombCounter(30.0, 0.5)
    for _ in range(3600):
        cc.step(15.0, 1.0)  # 0.5C for one hour = -50 % SOC
    assert cc.soc == pytest.approx(0.0, abs=1e-9)


# ---------------------------------------------------------------- thermal
def test_thermal_limit_respected_only_with_management(fast_charge_pair):
    cooled, uncooled = fast_charge_pair
    limit = cooled["temp_limit_c"]
    assert cooled["peak_temp_c"] <= limit
    assert uncooled["peak_temp_c"] > limit
    assert cooled["flow"].max() > 0 and uncooled["flow"].max() == 0


def test_drive_temperature_lower_with_management(drive_managed):
    from bms.scenarios import simulate_drive
    off = simulate_drive(thermal_enabled=False)
    assert drive_managed["peak_temp_c"] <= drive_managed["temp_limit_c"]
    assert drive_managed["peak_temp_c"] < off["peak_temp_c"]


def test_heater_engages_below_5c():
    cold = simulate_cold_start()
    assert cold["heater"][0] > 0
    assert cold["final_temp_c"] > 5.0
    assert cold["fault_counts"]["UNDER_TEMP"] == 1


def test_thermal_manager_hysteresis():
    m = ThermalManager(ThermalManagerConfig())
    assert m.update(31.0, 1.0)[0] == 0.0  # below t_on: pump stays off
    assert m.update(34.0, 1.0)[0] > 0.0  # above t_on: pump on
    assert m.update(31.0, 1.0)[0] > 0.0  # between t_off and t_on: stays on
    assert m.update(28.0, 1.0)[0] == 0.0  # below t_off: off


def test_thermal_energy_balance_cools_towards_coolant():
    th = ThermalModel(temp0_c=40.0, t_ambient_c=40.0)
    for _ in range(3600):
        th.step(0.0, 10.0, 0.0, 1.0)
    assert th.p.t_coolant_c < th.temp_c < 40.0


# ---------------------------------------------------------------- SOH
def test_soh_monotonic_non_increasing():
    age = run_accelerated_ageing(n_cycles=500)
    assert np.all(np.diff(age["soh_capacity"]) <= 1e-12)
    assert np.all(np.diff(age["soh_resistance"]) <= 1e-12)
    assert np.all(np.diff(age["capacity_ah"]) <= 1e-12)
    assert np.all(np.diff(age["resistance_ohm"]) >= -1e-12)
    assert 0.80 < age["soh_capacity"][-1] < 0.95


def test_ageing_is_faster_when_hot():
    hot = run_accelerated_ageing(n_cycles=200, temp_c=45.0)
    cool = run_accelerated_ageing(n_cycles=200, temp_c=25.0)
    assert hot["soh_capacity"][-1] < cool["soh_capacity"][-1]


def test_least_squares_capacity_estimate_within_3pct():
    ch = simulate_charge()
    assert abs(ch["q_est_err_pct"]) < 3.0
    assert ch["ls_r2"] > 0.999


def test_least_squares_recovers_exact_capacity_on_ideal_data():
    dt, q = 1.0, 30.0
    i = -15.0 * np.ones(3600)  # 0.5C charge
    soc = 0.3 - np.cumsum(i) * dt / (3600 * q)
    q_est, r2 = estimate_capacity_least_squares(soc, i, dt)
    assert q_est == pytest.approx(q, rel=1e-9)
    assert r2 == pytest.approx(1.0)


def test_cycle_counting():
    assert equivalent_full_cycles(np.full(3600, 60.0), 1.0, 60.0) == pytest.approx(0.5)
    soc = np.array([0.9, 0.5, 0.8, 0.2, 0.2, 0.7])
    dods = count_half_cycles(soc)
    assert np.allclose(dods, [0.4, 0.3, 0.6, 0.5])


# ---------------------------------------------------------------- safety / balancing
def test_safety_flags_raised_and_latched():
    m = SafetyMonitor(SafetyLimits())
    v = np.full((96, 2), 3.7)
    assert m.check(0.0, v, 30.0, 50.0) == set()
    v[3, 1] = 4.30
    assert m.check(1.0, v, 30.0, 50.0) == {Fault.OVER_VOLTAGE, Fault.IMBALANCE}
    v[3, 1] = 3.7
    assert m.check(2.0, v, 60.0, 400.0) == {Fault.OVER_TEMP, Fault.OVER_CURRENT}
    assert m.contactor_open
    assert m.event_counts()["OVER_VOLTAGE"] == 1
    m.reset()
    assert not m.contactor_open


def test_fault_injection_raises_every_hard_fault():
    fi = simulate_fault_injection()
    for f in ("OVER_VOLTAGE", "UNDER_VOLTAGE", "OVER_TEMP", "OVER_CURRENT"):
        assert f in fi["flags_raised"]
    assert fi["contactor_open"]


def test_no_faults_during_normal_drive(drive_managed):
    assert drive_managed["fault_counts"]["OVER_VOLTAGE"] == 0
    assert drive_managed["fault_counts"]["UNDER_VOLTAGE"] == 0
    assert drive_managed["fault_counts"]["OVER_TEMP"] == 0
    assert drive_managed["fault_counts"]["OVER_CURRENT"] == 0


def test_passive_balancing_reduces_spread():
    bal = simulate_balancing(hours=8.0)
    assert bal["final_spread_mv"] < bal["initial_spread_mv"] / 4
    assert bal["final_soc_spread_pct"] < 1.0
    assert bal["time_to_balance_h"] < 4.0


def test_balancer_only_at_rest():
    b = PassiveBalancer()
    v = np.array([[3.70, 3.72], [3.75, 3.70]])
    assert b.command(v, 100.0).sum() == 0.0
    cmd = b.command(v, 0.0)
    assert cmd[1, 0] == b.bleed_current_a and cmd[0, 0] == 0.0


# ---------------------------------------------------------------- drive cycle
def test_drive_cycle_is_physical():
    t, v = synthetic_speed_profile()
    assert v.min() >= 0 and 90 < v.max() < 130
    assert 1500 < len(t) < 2400
    p, i = current_from_speed(t, v, 355.0)
    assert i.max() > 50 and i.min() < 0  # traction and regen present
    assert abs(i.min()) * 355 <= 40_000 + 1000  # regen limit respected (+ aux)
