import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


@pytest.fixture(scope="session")
def drive_managed():
    from bms.scenarios import simulate_drive
    return simulate_drive(thermal_enabled=True)


@pytest.fixture(scope="session")
def fast_charge_pair():
    from bms.scenarios import simulate_fast_charge
    return simulate_fast_charge(thermal_enabled=True), simulate_fast_charge(thermal_enabled=False)
