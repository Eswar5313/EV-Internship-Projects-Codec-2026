# Battery Management System (BMS) Simulation

**EV Internship Project 01 - Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026

> **All data in this project is synthetic.** Every voltage, current, temperature
> and ageing curve is produced by the models in the `bms/` package. No real
> cell, vehicle or fleet measurements were used. Parameter values are chosen
> to be *representative* of an NMC/graphite cell and a compact city EV, not
> to reproduce any specific product.

---

## 1. Overview

For this project I built a pure-Python simulation of the core functions of an
EV battery management system:

| Function | What I implemented |
|---|---|
| **Cell model** | 2-RC equivalent circuit, synthetic NMC-like OCV-SOC lookup table, Arrhenius temperature-dependent ohmic resistance, entropic coefficient |
| **Pack** | 96s2p aggregation (30 Ah cells, 356 V, 21.4 kWh), seeded cell-to-cell capacity/resistance variation, capacity-weighted current sharing, busbar resistance |
| **SOC estimation** | Coulomb counting **and** an Extended Kalman Filter on the 2-RC model, compared against the true pack SOC |
| **SOH estimation** | Capacity-fade SOH from cycle / Ah-throughput ageing, internal-resistance-growth SOH, 500-cycle accelerated ageing loop, least-squares capacity estimate from a partial charge |
| **Thermal** | Lumped-parameter thermal model (I^2R + entropic heat, convection to coolant, ambient loss); thermal manager with hysteresis pump switching + PI flow control; heater below 5 degC |
| **Safety** | Fault flags (over/under-voltage, over/under-temperature, over-current, imbalance) with latching + event log; passive bleed-resistor balancing |
| **Drive cycle** | Synthetic urban + highway speed profile -> longitudinal vehicle model -> pack current; CC-CV charge controller |

`python main.py` runs seven scenarios in about 10 s and writes all plots and a
metrics summary to `results/`.

## 2. Block diagram

```
                     +-------------------------------------------------------------+
                     |                       PLANT (simulated truth)               |
  speed profile      |  +---------------+   I_pack   +---------------------------+ |
  (synthetic) -----> |  | Vehicle model | ---------> |  Battery pack 96s2p       | |
  drive_cycle.py     |  | F = ma + aero |            |  192 x 2-RC cells         | |
                     |  |   + rolling   |            |  OCV(SOC), R0(T), R1C1,   | |
  CC-CV charger ---> |  +---------------+            |  R2C2, capacity spread    | |
                     |                               +------------+--------------+ |
                     |            Q_gen = I^2R + entropic         | V_pack, V_cells|
                     |                    v                       v                |
                     |  +----------------------------+     (sensor noise + bias)   |
                     |  | Lumped thermal model       |            |                |
                     |  | m cp dT/dt = Q - UA(flow)  |            |                |
                     |  |   (T - T_cool) - UA_amb..  |            |                |
                     |  +-------------+--------------+            |                |
                     +----------------|---------------------------|----------------+
                                      | T_pack                    | V_meas, I_meas
   +----------------------------------|---------------------------|--------------------+
   |  BMS (bms/ package)              v                           v                    |
   |  +------------------+   +------------------+   +-----------------------------+   |
   |  | Thermal manager  |   | Safety monitor   |   | SOC estimators              |   |
   |  | hysteresis + PI  |   | OV UV OT UT OC   |   |  - Coulomb counter          |   |
   |  | -> coolant flow  |   | imbalance, latch |   |  - EKF on 2-RC model        |   |
   |  | -> heater < 5 C  |   | -> contactor     |   +-----------------------------+   |
   |  +------------------+   +------------------+   +-----------------------------+   |
   |                         | Passive balancer |   | SOH estimator               |   |
   |                         | bleed resistors  |   |  - Ah-throughput ageing     |   |
   |                         +------------------+   |  - R growth, LS capacity    |   |
   |                                                +-----------------------------+   |
   +----------------------------------------------------------------------------------+
```

## 3. Models and equations

### 3.1 Cell: 2-RC equivalent circuit (`bms/cell_model.py`)

```
V  = OCV(SOC) - i*R0(T) - v1 - v2                 (i > 0 = discharge)
dSOC/dt = -i / (3600 Q)
dv1/dt  = -v1/(R1 C1) + i/C1        tau1 = 20 s
dv2/dt  = -v2/(R2 C2) + i/C2        tau2 = 100 s
R0(T)   = R0_ref * exp( Ea/Rg * (1/T - 1/T_ref) )      (Ea = 20 kJ/mol -> R0 doubles from 25 to 0 degC)
```

Discretised exactly for a step `dt`: `v1[k+1] = a1 v1[k] + R1(1-a1) i[k]`, `a1 = exp(-dt/tau1)`.
The OCV-SOC table is a 13-point synthetic NMC-like curve (3.00 V at 0 %, 3.71 V at 50 %, 4.20 V at 100 %).

### 3.2 Pack (`bms/pack.py`)

Cells are stored as `(96, 2)` NumPy arrays and stepped together. Capacity varies
with 1.5 % std-dev and R0 with 4 % std-dev (`numpy.random.default_rng(42)`).
Parallel cells share current in proportion to capacity; the pack voltage is the
sum of group voltages minus a 0.25 mOhm/group busbar drop. The "true" pack SOC is
the capacity-weighted mean cell SOC.

### 3.3 SOC estimation (`bms/soc_estimator.py`)

*Coulomb counting:* `SOC[k+1] = SOC[k] - I_meas dt / (3600 Q)`. Any initial
error and current-sensor bias accumulate.

*Extended Kalman Filter* on `x = [SOC, v1, v2]` (Plett, Vol. II, ch. 3):

```
Predict:  x- = A x + B u            P- = A P A' + Q
Output:   y^ = OCV(SOC-) - v1- - v2- - R0(T) u
Jacobian: C  = [ dOCV/dSOC , -1 , -1 ]
Gain:     K  = P- C' / (C P- C' + R)
Update:   x  = x- + K (V_meas - y^)     P = (I-KC) P- (I-KC)' + K R K'   (Joseph form)
```

The EKF runs on the *average cell* (V_pack/96, I_pack/2) with nominal
datasheet parameters: it does not know the true capacity of each cell, the
busbar resistance, or the current-sensor bias.

### 3.4 SOH and ageing (`bms/soh_estimator.py`)

```
Q_loss_cyc [%] = B_cyc * exp(-Ea_cyc/(Rg T)) * (sum Ah * stress(DoD, C-rate))^0.55
Q_loss_cal [%] = B_cal * exp(-Ea_cal/(Rg T)) * sqrt(t_days)
R0(N)          = R0 * (1 + k_res * sum Ah * stress * exp(-Ea_cyc/(Rg T)))

SOH_capacity   = Q / Q_nominal
SOH_resistance = 1 - (R/R0 - 1) / (R_EOL/R0 - 1)        (R_EOL = 2 R0)
```

Cycle counting: equivalent full cycles = Ah-throughput / (2 Q) and a turning-point
half-cycle counter that lists depths of discharge. Capacity from a partial charge:
least-squares fit of `Ah_in(t) = Q * SOC_EKF(t) + c` over the 35-75 % SOC window
of a 0.5C charge.

### 3.5 Thermal (`bms/thermal.py`)

```
m cp dT/dt = Q_gen + P_heater - UA_cool(flow) (T - T_coolant) - UA_amb (T - T_ambient)
Q_gen      = sum_cells [ i^2 R0 + v1^2/R1 + v2^2/R2 - i T dU/dT ] + busbar losses
UA_cool    = 45 W/K per L/min of coolant (max 12 L/min), T_coolant = 22 degC
```

Manager: pump ON above 33 degC / OFF below 29 degC; while ON the flow is
`Kp e + Ki integral(e)` towards a 30 degC target with anti-windup. Heater
(2.5 kW) ON below 5 degC, OFF above 10 degC.

### 3.6 Drive cycle (`bms/drive_cycle.py`)

The ~30 min speed trace is **synthetic**: 15 min of random stop-and-go
(25-50 km/h) followed by a highway section (95-120 km/h). Pack current comes
from `F = m a + 0.5 rho Cd A v^2 + Crr m g`, `P = F v / eta` (regen limited to
40 kW at 60 % efficiency, 600 W auxiliaries), `I = P / V_nominal`. It is not a
standard cycle (WLTP / IDC / FTP-75).

## 4. How to run

```bash
cd 01_BMS_Simulation
pip install -r requirements.txt      # numpy, scipy, matplotlib, pandas, pytest
python main.py                       # ~10 s, writes results/*.png, summary.json, summary.csv
pytest                               # 23 tests, ~5 s
```

Everything is deterministic (fixed seeds), so the numbers below are reproduced
exactly on every run.

## 5. Results

Metrics below are copied from `results/summary.json` produced by `python main.py`.

### 5.1 Key metrics

| Metric | Value | Comment |
|---|---|---|
| EKF SOC RMSE (after 5 min settling) | **0.63 %** | EKF started 15 % too low, converged in < 1 min |
| EKF max abs error after settling | 1.15 % | bias from un-modelled busbar drop at high current |
| EKF SOC RMSE during CC-CV charge | 0.97 % | |
| Coulomb-counting RMSE / final drift | 5.84 % / **-6.64 %** | started 5 % low, 2 A sensor bias accumulates |
| Drive peak pack temperature, managed / unmanaged | **35.9 / 40.9 degC** | 40 degC ambient, heat-soaked pack, 145 Wh/km |
| 1.5C fast-charge peak temperature, cooled / uncooled | **34.0 / 50.9 degC** | design limit 45 degC exceeded only without cooling |
| Cold start -8 degC: heater time / charge-inhibit time | 15.7 min / 6.8 min | 0.65 kWh heater energy |
| SOH after 500 cycles (80 % DoD, 35 degC, 1C) | **90.1 % capacity / 90.6 % resistance** | R0 grew 9.4 % |
| Least-squares capacity estimate | 30.35 Ah vs 29.99 Ah true (**+1.2 %**) | R^2 = 0.99995 |
| Passive balancing (192 cells, 200 mA bleed) | 52 mV -> 5 mV spread in ~7.5 h | IMBALANCE flag cleared after 1.7 h |
| Fault events in normal operation | 2 (both IMBALANCE requests near 100 % SOC) | no hard faults |
| Fault events in fault-injection scenario | 6 -> OV, OC, OT, UV, IMBALANCE | contactor latched open |
| Total runtime of `main.py` | ~10 s | |

### 5.2 Figures (all in `results/`)

| File | Content |
|---|---|
| `drive_voltage_current.png` | speed profile, pack current (true + noisy sensor), pack voltage, cell voltage envelope with OV/UV limits |
| `soc_estimation.png` | true vs Coulomb-counting vs EKF SOC, and error traces with a +/-2 % band |
| `thermal_management.png` | drive-cycle temperature with/without management, coolant flow, heat generation; 1.5C fast charge cooled vs uncooled; cold-start heater hysteresis |
| `soh_fade.png` | capacity and resistance SOH over 500 cycles, underlying Ah and mOhm curves |
| `cell_balancing.png` | 192 cell SOCs converging, voltage spread vs the 40 mV flag, number of bleeding cells |
| `charge_capacity_estimation.png` | CC-CV charge voltage/current, EKF SOC, least-squares fit window |
| `fault_injection.png` | abuse current, cell voltage envelope, temperature, with every fault event marked |

![SOC](results/soc_estimation.png)
![Thermal](results/thermal_management.png)
![SOH](results/soh_fade.png)
![Balancing](results/cell_balancing.png)

### 5.3 What I learned from the numbers

* The EKF removes the initial-SOC problem completely and is insensitive to the
  2 A current-sensor bias, because the voltage measurement continuously pulls
  the SOC back to the OCV curve. Its residual ~1 % bias at high current is a
  *model-mismatch* error (the estimator does not know the 24 mOhm of busbars),
  which is exactly the kind of error a real BMS calibrates out.
* Coulomb counting alone is unusable without periodic OCV re-calibration: after
  only 30 min it has drifted to -6.6 %.
* A 30 min mixed drive does not overheat a 21 kWh pack even at 40 degC ambient
  (peak 40.9 degC without cooling). DC fast charging is the thermally critical
  case: at 1.5C the uncooled pack passes 45 degC after ~14 min and peaks at
  50.9 degC, while 5-6 L/min of coolant holds it at 30 degC.
* Passive balancing is slow (hours) and dissipative (0.5 kWh bled here); it is
  only practical at rest / end of charge, which is why the balancer is inhibited
  above 5 A.

## 6. Project structure

```
01_BMS_Simulation/
|-- README.md
|-- requirements.txt
|-- main.py                  # single entry point -> results/
|-- bms/
|   |-- __init__.py
|   |-- cell_model.py        # 2-RC cell, OCV-SOC table, R0(T), entropic coefficient
|   |-- pack.py              # 96s2p vectorised pack with cell-to-cell variation
|   |-- soc_estimator.py     # Coulomb counter + EKF
|   |-- soh_estimator.py     # ageing model, SOH definitions, cycle counting, LS capacity
|   |-- thermal.py           # lumped thermal model + hysteresis/PI thermal manager + heater
|   |-- safety.py            # fault flags, event log, passive balancer
|   |-- drive_cycle.py       # synthetic speed profile, vehicle model, CC-CV controller
|   |-- scenarios.py         # closed-loop scenarios used by main.py and the tests
|   `-- plots.py             # matplotlib figures
|-- tests/
|   |-- conftest.py
|   `-- test_bms.py          # 23 pytest tests
`-- results/                 # generated by main.py
    |-- *.png, summary.json, summary.csv, drive_timeseries.csv
```

## 7. Tests (`pytest`)

| Test | Checks |
|---|---|
| `test_ocv_table_monotonic` | OCV table and its interpolation are strictly increasing, inverse lookup is exact |
| `test_ekf_rmse_below_2pct` | EKF RMSE < 2 %, max error < 3 %, beats Coulomb counting |
| `test_thermal_limit_respected_only_with_management` | fast-charge peak <= 45 degC with cooling, > 45 degC without |
| `test_drive_temperature_lower_with_management` | drive-cycle peak below limit and below the unmanaged case |
| `test_soh_monotonic_non_increasing` | both SOH curves, capacity and resistance are monotone over 500 cycles |
| `test_least_squares_capacity_estimate_within_3pct` | capacity estimate error < 3 %, R^2 > 0.999 |
| `test_safety_flags_raised_and_latched`, `test_fault_injection_raises_every_hard_fault` | every flag fires, latches, opens the contactor, resets |
| `test_passive_balancing_reduces_spread` | spread reduced by > 4x, flag cleared within 4 h |
| plus cell, pack, heater, hysteresis, cycle-counting and drive-cycle sanity tests | |

## 8. Limitations

* **Synthetic everything**: OCV table, RC parameters, ageing coefficients and
  the drive cycle are plausible but invented; nothing is validated against
  measurements.
* **Lumped thermal model**: one temperature for the whole pack. Real packs have
  cell-to-cell and in-cell gradients; hot-spot cells age faster and are the
  ones that trigger faults.
* **Current sharing** between parallel cells is capacity-weighted rather than
  solved from the Kirchhoff node equations, so impedance-driven imbalance is
  not captured.
* **EKF on the average cell**: a production BMS runs per-cell (or per-group)
  estimators, often with a "bar-delta" structure, and would include the busbar
  resistance and a current-bias state.
* **Ageing model is applied per cycle**, not inside the time-domain loop, and
  the calendar term is only a sqrt(t) law at fixed temperature.
* The fault-injection scenario keeps abusing the pack after the contactor
  "opens" so that every flag can be exercised in one run; a real BMS would cut
  current at the first latched fault.
* No SOP (state of power) or derating strategy, no cell-level sensor faults,
  no CAN/communication layer.

## 9. Future work

* **MATLAB/Simulink equivalence**: the plant (pack + thermal) maps naturally to
  Simscape Battery / Simulink blocks and the BMS logic to Stateflow. The same
  scenarios could be re-run there to cross-check the Python results and to
  generate embedded C code for the estimator via Embedded Coder. Keeping the
  models in this repository small and explicit was a deliberate step towards
  that port.
* Per-cell (bar-delta) EKF and a sigma-point / unscented KF for comparison.
* Kirchhoff-solved parallel-cell current sharing and a multi-node thermal model.
* Online parameter estimation (recursive least squares for R0, Q) feeding the
  SOH estimator, and a proper rainflow cycle counter.
* Standard drive cycles (IDC / WLTC / FTP-75) from published tables, SOP
  estimation and charge/discharge derating maps.
* Hardware-in-the-loop: replace the plant with a real cell on a cycler and run
  the BMS package against it.

## 10. References

1. G. L. Plett, *Battery Management Systems, Volume I: Battery Modeling*, Artech House, 2015.
2. G. L. Plett, *Battery Management Systems, Volume II: Equivalent-Circuit Methods*, Artech House, 2015 (EKF/SPKF SOC estimation, chapters 3-4).
3. G. L. Plett, "Extended Kalman filtering for battery management systems of LiPB-based HEV battery packs, Parts 1-3", *J. Power Sources*, 134, 2004.
4. J. Wang et al., "Cycle-life model for graphite-LiFePO4 cells", *J. Power Sources*, 196, 2011 (Ah-throughput ageing law with Arrhenius dependence).
5. D. Bernardi, E. Pawlikowski, J. Newman, "A general energy balance for battery systems", *J. Electrochem. Soc.*, 132, 1985 (heat-generation equation).
6. R. Xiong et al., "Critical review on the battery state of charge estimation methods for electric vehicles", *IEEE Access*, 6, 2018.
7. M. Ecker et al., "Calendar and cycle life study of Li(NiMnCo)O2-based 18650 lithium-ion batteries", *J. Power Sources*, 248, 2014.
8. L. Lu et al., "A review on the key issues for lithium-ion battery management in electric vehicles", *J. Power Sources*, 226, 2013.
9. H. Rahimi-Eichi et al., "Battery Management System: An Overview of Its Application in the Smart Grid and Electric Vehicles", *IEEE Industrial Electronics Magazine*, 2013.
