import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


@pytest.fixture(scope="session")
def coils():
    from wpt.coils import SpiralCoil
    return (SpiralCoil("primary", 20, 0.100, 0.300), SpiralCoil("secondary", 20, 0.085, 0.225))
