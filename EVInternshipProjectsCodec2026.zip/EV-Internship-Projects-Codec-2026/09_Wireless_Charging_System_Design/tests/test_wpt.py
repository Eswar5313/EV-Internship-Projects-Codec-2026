"""pytest suite for the wireless-charging model.  Run with:  pytest -q"""

import numpy as np
import pytest

from wpt import circuit as X
from wpt import coils as C
from wpt import compensation as K
from wpt import fields as F

F0 = 85e3


# ----------------------------------------------------------------- inductance formulas
def test_mohan_matches_wheeler_published_formulas(coils):
    """Two independently published spiral formulas (Mohan 1999, Wheeler 1928) agree to < 10 %."""
    for c in coils:
        assert abs(c.inductance_mohan() - c.inductance_wheeler()) / c.inductance_wheeler() < 0.10


def test_mohan_matches_filament_method_within_10pct(coils):
    for c in coils:
        l_num = C.self_inductance_filament(c)
        assert abs(c.inductance_mohan() - l_num) / l_num < 0.10


def test_mohan_against_published_example():
    """Mohan et al. 1999 report < 3 % typical error for planar spirals; check against the
    exact Maxwell-summation for a 10-turn air-core spiral (r_in 50 mm, r_out 100 mm)."""
    c = C.SpiralCoil("ex", 10, 0.05, 0.10, ferrite=False, n_strands=100, d_strand=1e-4)
    l_num = C.self_inductance_filament(c)
    assert abs(c.inductance_mohan() - l_num) / l_num < 0.10


def test_neumann_matches_maxwell_exact():
    a, b = 0.20, 0.15
    l1, l2 = C.SpiralCoil("a", 1, a, a), C.SpiralCoil("b", 1, b, b)
    for z in (0.02, 0.10, 0.30):
        m_num = C.mutual_inductance(l1, l2, z, ferrite=False)
        m_ref = C.maxwell_mutual(a, b, z)
        assert abs(m_num - m_ref) / m_ref < 0.01


def test_single_loop_self_inductance_textbook_value():
    # Grover: loop a = 0.1 m, wire radius 1 mm -> 0.589 uH
    assert C.loop_self_inductance(0.1, 1e-3) == pytest.approx(0.589e-6, rel=0.01)


# ----------------------------------------------------------------- coupling behaviour
def test_mutual_inductance_decreases_with_gap(coils):
    c1, c2 = coils
    gaps = [0.10, 0.15, 0.20, 0.25]
    m = [C.mutual_inductance(c1, c2, g) for g in gaps]
    assert all(m[i] > m[i + 1] > 0 for i in range(len(m) - 1))


def test_mutual_inductance_decreases_with_misalignment(coils):
    c1, c2 = coils
    m = [C.mutual_inductance(c1, c2, 0.175, dx) for dx in (0.0, 0.05, 0.10, 0.15)]
    assert all(m[i] > m[i + 1] for i in range(len(m) - 1))


def test_k_in_unit_interval(coils):
    c1, c2 = coils
    for g in (0.05, 0.10, 0.175, 0.25):
        for dx in (0.0, 0.1):
            k = C.coupling(c1, c2, g, dx)
            assert 0.0 < k < 1.0


# ----------------------------------------------------------------- compensation
def test_ss_resonance_condition(coils):
    c1, c2 = coils
    d = K.design_ss(c1.inductance(), c2.inductance(), F0)
    assert d.w0 ** 2 * d.L1 * d.C1 == pytest.approx(1.0, rel=1e-12)
    assert d.w0 ** 2 * d.L2 * d.C2 == pytest.approx(1.0, rel=1e-12)


def test_lccs_resonance_conditions(coils):
    c1, c2 = coils
    d = K.design_lccs(c1.inductance(), c2.inductance(), 16.0, 360.0, F0)
    assert d.w0 ** 2 * d.Lf1 * d.Cf1 == pytest.approx(1.0, rel=1e-12)
    assert d.w0 ** 2 * (d.L1 - d.Lf1) * d.C1 == pytest.approx(1.0, rel=1e-12)
    assert d.w0 ** 2 * d.L2 * d.C2 == pytest.approx(1.0, rel=1e-12)
    # LCC primary behaves as a current source: |I1| = V1/(w0 Lf1), independent of load
    link = X.LinkParams(0.2, 0.2, 40e-6, d, R_f=0.0, esr=False)
    i_a = abs(X.solve(link, 360.0, 5.0)["I1"])
    i_b = abs(X.solve(link, 360.0, 50.0)["I1"])
    assert i_a == pytest.approx(360.0 / (d.w0 * d.Lf1), rel=0.02)
    assert i_b == pytest.approx(i_a, rel=0.02)


# ----------------------------------------------------------------- efficiency
def test_link_efficiency_in_unit_interval_and_increases_with_kQ(coils):
    c1, c2 = coils
    L1, L2 = c1.inductance(), c2.inductance()
    R1, R2 = c1.r_ac(F0), c2.r_ac(F0)
    k_vals = np.linspace(0.02, 0.5, 30)
    eta = X.efficiency_vs_k(k_vals, L1, L2, R1, R2, K.load_resistance(400, 7700))
    assert np.all((eta > 0) & (eta < 1))
    assert np.all(np.diff(eta) > 0)                       # monotone in k at fixed load
    # analytical eta_max(kQ) also monotone and bounded
    q1, q2 = K.W0 * L1 / R1, K.W0 * L2 / R2
    em = K.eta_max(k_vals, q1, q2)
    assert np.all((em > 0) & (em < 1)) and np.all(np.diff(em) > 0)
    # numerical optimum load matches the analytical optimum
    d = K.design_ss(L1, L2, F0)
    M = 0.2 * np.sqrt(L1 * L2)
    r_opt = K.optimal_load(R2, 0.2, q1, q2)
    link = X.LinkParams(R1, R2, M, d, esr=False)
    eta_opt = X.solve(link, 100.0, r_opt)["eta_link"]
    assert eta_opt == pytest.approx(float(K.eta_max(0.2, q1, q2)), rel=1e-6)
    assert eta_opt >= X.solve(link, 100.0, r_opt * 2)["eta_link"]
    assert eta_opt >= X.solve(link, 100.0, r_opt / 2)["eta_link"]


def test_energy_balance_pin_equals_pout_plus_losses(coils):
    c1, c2 = coils
    L1, L2 = c1.inductance(), c2.inductance()
    R1, R2 = c1.r_ac(F0), c2.r_ac(F0)
    M = C.mutual_inductance(c1, c2, 0.175)
    cp = X.ConverterParams()
    for d, rf in ((K.design_ss(L1, L2, F0), 0.0), (K.design_lccs(L1, L2, 16.0, 360.0, F0), 0.05)):
        link = X.LinkParams(R1, R2, M, d, R_f=rf)
        res = X.solve(link, 360.0, 16.8)
        assert res["P_in"] == pytest.approx(res["P_out"] + res["P_coil1"] + res["P_coil2"] + res["P_Lf1"], rel=1e-9)
        sp = X.system_point(link, 500.0, 400.0, 7700.0, cp)
        assert abs(sp["balance_residual_W"]) < 1e-6
        assert 0 < sp["eta_system"] < 1


def test_vdc_solver_hits_target_power(coils):
    c1, c2 = coils
    L1, L2 = c1.inductance(), c2.inductance()
    link = X.LinkParams(c1.r_ac(F0), c2.r_ac(F0), C.mutual_inductance(c1, c2, 0.175), K.design_ss(L1, L2, F0))
    cp = X.ConverterParams()
    vdc = X.v_dc_for_power(link, 400.0, 7700.0, cp)
    assert X.system_point(link, vdc, 400.0, 7700.0, cp)["P_bat"] == pytest.approx(7700.0, rel=1e-6)


# ----------------------------------------------------------------- fields
def test_biot_savart_matches_on_axis_loop_formula():
    loop = C.SpiralCoil("loop", 1, 0.2, 0.2)
    p, dl = loop.filaments(90)
    for z in (0.0, 0.1, 0.3):
        b_num = abs(F.b_field(np.array([[0.0, 0.0, z]]), p, dl, 10.0)[0, 2])
        assert b_num == pytest.approx(F.b_on_axis_single_loop(0.2, z, 10.0), rel=0.01)


def test_field_decays_with_distance(coils):
    c1, c2 = coils
    pts = np.array([[0.5, 0, 0.1], [0.8, 0, 0.1], [1.2, 0, 0.1]])
    b = F.field_at_points(pts, c1, c2, 0.175, 16.0, 21.0j)
    assert b[0] > b[1] > b[2] > 0
