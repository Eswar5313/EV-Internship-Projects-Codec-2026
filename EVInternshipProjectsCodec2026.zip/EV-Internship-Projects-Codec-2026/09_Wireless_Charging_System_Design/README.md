# Wireless (Inductive) EV Charging System Design

**EV Internship Project 09 - Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026

> **Brief:** "Model an inductive charging system for EVs. Use COMSOL or ANSYS Maxwell
> for electromagnetic simulation. Design primary and secondary coils. Analyze power
> transfer efficiency and losses."
>
> I did not have access to COMSOL or ANSYS Maxwell, so I replaced the finite-element
> step with an **analytical + numerical Python model**: published closed-form
> inductance formulas, a vectorised Neumann-integral (filament) solver for mutual
> inductance, a Biot-Savart field solver on a cut plane ("FEM-lite"), and a phasor
> circuit model of the resonant link and converters. Section 8 explains exactly what
> the FEM tool would add. `python main.py` regenerates `results/` in about 20 s.

---

## 1. Overview and design case

| Item | Value | Source |
|---|---|---|
| Power class | **WPT2, 7.7 kW** to the battery | SAE J2954 |
| Battery | 400 V nominal | assumed |
| Frequency | **85 kHz** (81.38-90 kHz band) | SAE J2954 |
| Gap class | **Z2 = 140-210 mm**, nominal 175 mm | SAE J2954 |
| Misalignment | X offset **+/-75 mm** (Y +/-100 mm) | SAE J2954 |
| Exposure limit | **27 uT** rms (general public, 3 kHz-10 MHz) | ICNIRP 2010; used by J2954 |

| Module (`wpt/`) | What I implemented |
|---|---|
| `coils.py` | Circular planar spiral geometry (turns, inner/outer radius, pitch, litz), self-inductance by **Mohan** and **Wheeler** formulas, independent filament-method self-inductance, **Neumann-formula mutual inductance** for coaxial and laterally misaligned coils, coupling k vs gap and misalignment, litz AC resistance (skin depth + proximity factor), ferrite backing as a declared factor |
| `compensation.py` | **Series-series (SS)** and **LCC-S** compensation at 85 kHz: capacitor values, capacitor ESR, load referred through the rectifier, optimum load, analytical eta_max(kQ) |
| `circuit.py` | Phasor mesh analysis of the two-port resonant link (SS: 2 x 2, LCC-S: 3 x 3), efficiency eta(k, Q1, Q2, R_L), output power vs input voltage, DC-bus solver for the target power, inverter (SiC, ZVS) and rectifier (SiC Schottky) losses, energy balance |
| `fields.py` | Biot-Savart |B| on the x-z cut plane from all filament segments with the solved coil currents; bystander check against ICNIRP |
| `plots.py`, `main.py` | Figures, `summary.json`, `cases.csv`, `k_sweeps.csv` |

## 2. Block diagram

```
   grid  +-----------+  V_dc   +--------------+  V1 (85 kHz)  +----------+          +----------+
   ----->| PFC (not  |-------->| full-bridge  |-------------->| C1 (SS)  |          |          |
         | modelled) |         | SiC inverter |   I_in        | or       |  I1      |  L1      |
         +-----------+         | ZVS, R_ds,   |               | Lf1/Cf1/ |--------->|  primary |=====\
                               | E_off        |               | C1 (LCC) |          |  coil    |     |
                               +--------------+               +----------+          +----------+     |  M(gap, dx)
                                                                                                     |  k = M/sqrt(L1 L2)
         +-----------+  P_bat  +--------------+  I2 (AC)      +----------+          +----------+     |
         | battery   |<--------| full-bridge  |<--------------| C2       |<---------|  L2      |=====/
         | 400 V     |         | SiC Schottky |   R_L=8V^2/   | (series) |          | secondary|
         +-----------+         | rectifier    |     (pi^2 P)  +----------+          |  coil    |
                               +--------------+                                     +----------+

   Loss chain: P_dc_in = P_bat + P_inverter + P_coil1(+ESR C1) + P_Lf1 + P_coil2(+ESR C2) + P_rectifier
   Field check: Biot-Savart |B|(x,z) from I1, I2  ->  compare with ICNIRP 27 uT at bystander points
```

## 3. Equations

### 3.1 Coils (`coils.py`)

Self-inductance of a circular planar spiral (Mohan et al. 1999, current-sheet
expression, c1 = 1.00, c2 = 2.46, c3 = 0, c4 = 0.20):

```
L = mu0 N^2 d_avg c1 / 2 [ ln(c2/rho) + c3 rho + c4 rho^2 ],  d_avg = (d_out+d_in)/2,  rho = (d_out-d_in)/(d_out+d_in)
```

Wheeler (1928) flat spiral in SI: `L = 31.33 mu0 N^2 a^2 / (8a + 11c)`.

Mutual inductance by the Neumann formula, each turn discretised into 72 straight
segments and evaluated with one matrix product for all segment pairs:

```
M = mu0/(4 pi) sum_i sum_j (dl_i . dl_j) / |r_i - r_j|
```

Validation inside the tests: against Maxwell's exact elliptic-integral formula
for two coaxial loops (< 1 % error) and Grover's loop self-inductance.

Litz AC resistance at 85 kHz: skin depth `delta = sqrt(2 rho / (omega mu0)) = 0.224 mm`,
strands of 0.1 mm (< delta) so per-strand skin effect is negligible; proximity
factor `F_R = 1 + (d_s/delta)^4 N sqrt(n_s) / 24` (simplified Sullivan-type term, **assumed**
calibration, gives F_R = 1.63 here); `R_ac = F_R rho_cu l / (n_s pi d_s^2 / 4)`.

Ferrite backing (**declared assumption**): air-core results are multiplied by
`f_L = 1.30` (L) and `f_M = 1.40` (M), inside the range reported for circular
pads with ferrite bars by Budhia, Covic & Boys (2011). Air-core values are also
reported so the effect is visible.

### 3.2 Compensation (`compensation.py`)

```
SS:      C1 = 1/(w0^2 L1),  C2 = 1/(w0^2 L2)
         Z_r = w0^2 M^2 / (R2 + R_L)  (reflected, resistive at w0)
         eta = Z_r/(R1 + Z_r) * R_L/(R2 + R_L)
         R_L,opt = R2 sqrt(1 + k^2 Q1 Q2),   eta_max = k^2 Q1 Q2 / (1 + sqrt(1 + k^2 Q1 Q2))^2
LCC-S:   w0^2 Lf1 Cf1 = 1,  C1 = 1/(w0^2 (L1 - Lf1)),  C2 = 1/(w0^2 L2)
         |I1| = |V1| / (w0 Lf1)  (load-independent primary current)
Load:    R_L = (8/pi^2) V_bat^2 / P_bat ;  V1,rms = (2 sqrt2 / pi) V_dc ;  ESR_C = tan(delta)/(w0 C), tan(delta) = 5e-4
```

### 3.3 Circuit (`circuit.py`)

Mesh phasor equations solved with `numpy.linalg.solve`:

```
SS:    [R1 + j(wL1 - 1/wC1)      -jwM              ] [I1]   [V1]
       [-jwM                     R2 + R_L + j(wL2 - 1/wC2)] [I2] = [0 ]
LCC-S: three meshes (inverter/Lf1/Cf1, Cf1/C1/L1, secondary) - see module docstring
P_in = Re(V1 I_in*),  P_out = |I2|^2 R_L,  P_coil1 = |I1|^2 R1,  P_coil2 = |I2|^2 R2
```

Converters (device data **declared**): SiC MOSFET full bridge (C3M0021120K-class,
R_ds(on) 32 mOhm hot, ZVS so only turn-off energy 0.15 mJ @ 40 A / 800 V scaled with
current and voltage, 25 W control), SiC Schottky bridge rectifier (C4D40120D-class,
V_f0 0.9 V, r_d 20 mOhm). The DC-bus voltage that delivers exactly 7.7 kW is found by
bisection for every case, i.e. the primary-side controller re-regulates V_dc.

### 3.4 Fields (`fields.py`)

`B(r) = mu0/(4 pi) sum I dl x (r - r') / |r - r'|^3` over all segments of both coils
with the solved rms current phasors; |B|_rms = sqrt(sum |B_c|^2). Validated against
the on-axis loop formula (0.07 % error). Air core only - no ferrite, no aluminium
shield, so the leakage field is an over-estimate of a real pad.

## 4. How to run

```bash
pip install -r requirements.txt
python main.py      # ~20 s -> results/
pytest -q           # 15 tests, ~3 s
```

## 5. Results (`results/summary.json`, `results/cases.csv`)

### 5.1 Coil design (assumed geometry, 400 x 0.1 mm litz = 3.14 mm^2)

| | Primary (ground assembly) | Secondary (vehicle assembly) |
|---|---|---|
| Turns / r_in / r_out / pitch | 20 / 100 mm / 300 mm / 10.5 mm | 20 / 85 mm / 225 mm / 7.4 mm |
| Wire length | 25.1 m | 19.5 m |
| L air core (Mohan) | 165.2 uH | 135.3 uH |
| **L with ferrite factor (design value)** | **214.8 uH** | **175.8 uH** |
| L check: Wheeler / filament method | 215.5 / 210.8 uH (+0.3 % / -1.9 %) | 176.9 / 170.7 uH (+0.6 % / -2.9 %) |
| R_dc / R_ac (85 kHz) | 138 / 225 mOhm | 107 / 174 mOhm |
| R incl. capacitor ESR | 282 mOhm | 221 mOhm |
| Q (with ESR) | 406 | 424 |

### 5.2 Coupling

| Gap (mm) | 100 | 130 | 140 (Z2 min) | 160 | **175 (nominal)** | 190 | 210 (Z2 max) | 220 | 250 |
|---|---|---|---|---|---|---|---|---|---|
| k (with ferrite factor) | 0.389 | 0.308 | 0.286 | 0.246 | **0.221** | 0.199 | 0.173 | 0.162 | 0.133 |

| Lateral offset at 175 mm (mm) | 0 | 50 | **75** | 100 | 150 | 200 |
|---|---|---|---|---|---|---|
| k | 0.221 | 0.213 | **0.203** | 0.189 | 0.155 | 0.115 |

Nominal: **M = 42.9 uH, k = 0.221, k sqrt(Q1 Q2) = 92**, analytical eta_max = 97.8 %.

### 5.3 Compensation at 85 kHz

| | SS | LCC-S (designed for a 400 V bus) |
|---|---|---|
| C1 | **16.32 nF** (ESR 57 mOhm) | 20.35 nF |
| C2 | **19.94 nF** (ESR 47 mOhm) | 19.94 nF |
| L_f1 / C_f1 | - | 42.5 uH / 82.5 nF |
| Resonance check w0^2 L C | 1.000 / 1.000 | 1.000 / 1.000 / 1.000 |
| R_L (400 V, 7.7 kW) vs R_L,opt | 16.8 ohm vs 20.3 ohm (near-optimal by design) | - |

### 5.4 Operating cases, 7.7 kW delivered to the battery in every case

| Case | k | V_dc needed | I1 / I2 (A rms) | P_inv | P_coil1 | P_Lf1 | P_coil2 | P_rect | Link eta | **System eta (DC-DC)** |
|---|---|---|---|---|---|---|---|---|---|---|
| SS nominal (175 mm, aligned) | 0.221 | 551 V | 16.0 / 21.4 | 61 W | 72 W | - | 102 W | 44 W | 97.8 % | **96.5 %** |
| SS +75 mm offset | 0.203 | 506 V | 17.4 / 21.4 | 64 W | 86 W | - | 102 W | 44 W | 97.6 % | **96.3 %** |
| SS Z2 min (140 mm) | 0.286 | 710 V | 12.3 / 21.4 | 55 W | 43 W | - | 102 W | 44 W | 98.2 % | 96.9 % |
| SS Z2 max (210 mm) | 0.173 | 434 V | 20.4 / 21.4 | 72 W | 117 W | - | 102 W | 44 W | 97.2 % | 95.8 % |
| LCC-S nominal | 0.221 | 404 V | 16.0 / 21.4 | 75 W | 69 W | 24 W | 102 W | 44 W | 97.5 % | **96.1 %** |
| LCC-S +75 mm offset | 0.203 | 440 V | 17.4 / 21.4 | 71 W | 82 W | 20 W | 102 W | 44 W | 97.4 % | **96.0 %** |
| LCC-S Z2 min (140 mm) | 0.286 | 313 V | 12.3 / 21.4 | 96 W | 41 W | 40 W | 102 W | 44 W | 97.7 % | 96.0 % |
| LCC-S Z2 max (210 mm) | 0.173 | 515 V | 20.4 / 21.4 | 64 W | 113 W | 15 W | 102 W | 44 W | 97.1 % | 95.8 % |

Energy-balance residual `P_dc_in - (P_bat + all losses)` = 0.0 W in every case (tested to 1e-6 W).

Observations:
* The total loss budget at 7.7 kW is about 280-320 W; the secondary coil + C2 is the
  largest single item (102 W, fixed by the 21.4 A load current), then the primary coil,
  inverter and rectifier.
* SS needs the DC bus to **rise** with k (710 V at 140 mm) because its input impedance
  grows as w0^2 M^2/R_L; with a fixed 400-800 V PFC output the SS design covers the
  whole Z2 range. LCC-S needs the bus to **fall** with k (P ~ M^2 at fixed V_dc) and
  gives a load-independent primary current - the reason J2954 reference designs use it.
* +/-75 mm misalignment costs only 0.2 % efficiency because k drops just 8 %; the
  controller absorbs it through V_dc.
* SiC vs coil loss: converters (105-120 W) and coils (170-200 W) are the same order,
  so coil Q is as important as the semiconductor choice.

### 5.5 Field exposure (air-core Biot-Savart, SS nominal currents)

| Point (x, z) | Aligned | +75 mm offset | ICNIRP 2010 (27 uT) | ICNIRP 1998 (6.25 uT) |
|---|---|---|---|---|
| Centre of the gap (0, 87 mm) | 1 343 uT | - | (inside the pad, not an exposure point) | |
| Vehicle sill (0.80 m, 0.10 m) | **11.9 uT** | **14.2 uT** | pass | fail |
| Person beside car (1.00 m, 0.50 m) | **5.4 uT** | **6.3 uT** | pass | marginal |

The 27 uT contour sits at about x = 0.65 m from the pad centre. A real pad with
ferrite + aluminium backplates would shrink these numbers substantially; this is
the conservative unshielded case.

### 5.6 Figures (`results/`)

`coil_geometry.png`, `k_vs_gap.png` (Z-classes shaded, air vs ferrite), `k_vs_misalignment.png`,
`efficiency_vs_k_and_load.png`, `power_vs_vdc.png`, `power_vs_k.png` (SS vs LCC-S
open-loop sensitivity), `b_field_map.png`, `b_field_map_misaligned.png`, `loss_breakdown.png`.

## 6. Tests (`tests/test_wpt.py`, 15 tests)

* Mohan formula vs Wheeler formula (two published expressions) within 10 %; Mohan vs
  filament-method summation within 10 % for the design coils and a 10-turn example;
  Grover single-loop textbook value 0.589 uH
* Neumann filament M vs Maxwell's exact elliptic-integral M within 1 % at three spacings
* M decreases monotonically with gap and with lateral misalignment; 0 < k < 1
* SS and LCC-S resonance conditions `w0^2 L C = 1` to 1e-12; LCC-S primary current is
  load independent and equals V1/(w0 Lf1)
* eta in (0, 1), monotone in k at fixed load and in kQ (analytical); numerical optimum
  load reproduces the analytical eta_max
* `P_in = P_out + losses` for the link (1e-9 rel.) and for the whole system (1e-6 W)
* V_dc solver hits the 7.7 kW target; Biot-Savart vs on-axis loop formula within 1 %;
  field decays with distance

## 7. Limitations

* Ferrite and aluminium shielding are represented only by declared scalar factors on
  L and M, and not at all in the field map - a true FEM model is needed for those.
* Fundamental-harmonic approximation for the inverter and rectifier (square-wave
  harmonics, dead time and diode conduction angle neglected); ZVS assumed.
* The proximity-loss factor for the litz wire is a simplified calibration, not a
  measured or Dowell/Sullivan full solution; capacitor tan(delta) assumed.
* No thermal model of the pads, no foreign-object detection, no PFC stage loss,
  no bifurcation / frequency-splitting analysis at high k.
* Coil geometry is assumed (circular pads); J2954 GA/VA reference pads are rectangular
  or DD-type with different misalignment tolerance.

## 8. How this would be done in COMSOL / ANSYS Maxwell

| This package | FEM equivalent |
|---|---|
| Mohan / Wheeler + filament L, Neumann M | Maxwell 3-D **eddy-current solver** at 85 kHz with the litz-wire conductor model, ferrite tiles (e.g. TDK PC95 B-H curve) and aluminium shield; L1, L2, M read from the **inductance matrix** output; parametric sweep of gap and offset via Optimetrics |
| Litz R_ac approximation | Maxwell litz "stranded" winding model (AC resistance including proximity) or COMSOL *Coil* feature with homogenised multi-turn litz |
| `fields.py` Biot-Savart cut plane | Field overlay / *mf.normB* plots on the same cut plane, plus a human body phantom for ICNIRP compliance |
| `circuit.py` phasor link | Maxwell **Circuit Editor** / Simplorer (Twin Builder) co-simulation, or COMSOL *Electrical Circuit* interface coupled to the coil model |
| Ferrite factors 1.30 / 1.40 | not needed - the material is meshed and solved |

Everything else (compensation design, DC-bus regulation, loss budget, figures) would
sit on top of the FEM inductance matrix exactly as it sits on the analytical one here.

## 9. References

1. SAE J2954 (2020/2022), *Wireless Power Transfer for Light-Duty Plug-in/Electric Vehicles and Alignment Methodology* - WPT classes, 85 kHz band, Z-classes, misalignment, field limits.
2. ICNIRP, *Guidelines for limiting exposure to time-varying electric and magnetic fields (1 Hz-100 kHz)*, Health Physics 99(6), 2010 - 27 uT general-public reference level; ICNIRP 1998 - 6.25 uT.
3. Mohan, S. S., Hershenson, M., Boyd, S. P., Lee, T. H., "Simple accurate expressions for planar spiral inductances", IEEE J. Solid-State Circuits 34(10), 1999.
4. Wheeler, H. A., "Simple inductance formulas for radio coils", Proc. IRE 16(10), 1928.
5. Grover, F. W., *Inductance Calculations: Working Formulas and Tables*, Dover, 1946 (Maxwell coaxial-loop formula, single-loop inductance).
6. Wang, C.-S., Stielau, O. H., Covic, G. A., "Design considerations for a contactless electric vehicle battery charger", IEEE Trans. Ind. Electron. 52(5), 2005 - SS compensation and efficiency.
7. Li, S., Li, W., Deng, J., Nguyen, T. D., Mi, C., "A double-sided LCC compensation network and its tuning method for wireless power transfer", IEEE Trans. Veh. Technol. 64(6), 2015.
8. Budhia, M., Covic, G. A., Boys, J. T., "Design and optimization of circular magnetic structures for lumped inductive power transfer systems", IEEE Trans. Power Electron. 26(11), 2011 - ferrite effect on coupling.
9. Sullivan, C. R., "Optimal choice for number of strands in a litz-wire transformer winding", IEEE Trans. Power Electron. 14(2), 1999 - proximity loss in litz.
10. Hui, S. Y. R., Zhong, W., Lee, C. K., "A critical review of recent progress in mid-range wireless power transfer", IEEE Trans. Power Electron. 29(9), 2014 - eta_max(kQ).
11. Wolfspeed datasheets: C3M0021120K SiC MOSFET, C4D40120D SiC Schottky diode.
12. CRC Handbook of Chemistry and Physics - copper resistivity 1.72e-8 ohm m.
