"""Planar spiral coil geometry, self-inductance, AC resistance and mutual
inductance (filament method / Neumann formula).

Self-inductance - Mohan's modified-Wheeler / current-sheet expression for a
circular planar spiral (Mohan, Hershenson, Boyd, Lee, IEEE JSSC 34(10), 1999,
eq. 4, circular coefficients c1 = 1.00, c2 = 2.46, c3 = 0.00, c4 = 0.20):

    L = mu0 N^2 d_avg c1 / 2 * [ ln(c2 / rho) + c3 rho + c4 rho^2 ]
    d_avg = (d_out + d_in) / 2,   rho = (d_out - d_in) / (d_out + d_in)

Wheeler's original flat-spiral formula (Wheeler, Proc. IRE 1928) in SI units:

    L = 31.33 mu0 N^2 a^2 / (8 a + 11 c)      a = mean radius, c = winding width

Mutual inductance - Neumann formula between filament loops:

    M = mu0 / (4 pi) * sum_i sum_j  (dl_i . dl_j) / |r_i - r_j|

evaluated with every turn discretised into n_phi straight segments (vectorised
numpy).  It is validated in the tests against Maxwell's exact elliptic-integral
formula for two coaxial circular loops (Grover, "Inductance Calculations", 1946):

    M = mu0 sqrt(a b) [ (2/kk - kk) K(kk) - (2/kk) E(kk) ],  kk^2 = 4ab / ((a+b)^2 + z^2)

Litz-wire AC resistance (85 kHz):
    skin depth delta = sqrt(2 rho_cu / (omega mu0)) = 0.224 mm at 85 kHz
    strand diameter 0.1 mm < delta  -> skin effect negligible per strand
    proximity factor (simplified Sullivan form, ASSUMED calibration):
        F_R = 1 + (d_s / delta)^4 * N_turns * sqrt(n_strands) / 24
    R_ac = F_R * rho_cu * length / (n_strands * pi d_s^2 / 4)

Ferrite backing: an air-core model under-predicts inductance and coupling of
real pads.  Ferrite is represented by ASSUMED multiplicative factors
(f_L = 1.30 on L, f_M = 1.40 on M), inside the range reported by Budhia,
Covic & Boys (IEEE Trans. Power Electron. 2011) for circular pads with
ferrite bars.  Set ferrite=False to see the pure air-core numbers.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.special import ellipe, ellipk

MU0 = 4e-7 * np.pi
RHO_CU = 1.72e-8  # ohm m at 20 degC (CRC Handbook)

FERRITE_F_L = 1.30   # assumed
FERRITE_F_M = 1.40   # assumed


@dataclass
class SpiralCoil:
    name: str
    n_turns: int
    r_in: float            # m, inner radius
    r_out: float           # m, outer radius
    z: float = 0.0         # m, axial position of the coil plane
    n_strands: int = 400   # litz strands
    d_strand: float = 1e-4  # m, strand diameter (AWG 38)
    ferrite: bool = True

    @property
    def pitch(self) -> float:
        return (self.r_out - self.r_in) / max(self.n_turns - 1, 1)

    @property
    def turn_radii(self) -> np.ndarray:
        return np.linspace(self.r_in, self.r_out, self.n_turns)

    @property
    def wire_length(self) -> float:
        return float(2 * np.pi * self.turn_radii.sum())

    @property
    def d_avg(self) -> float:
        return self.r_in + self.r_out

    @property
    def rho_fill(self) -> float:
        return (self.r_out - self.r_in) / (self.r_out + self.r_in)

    # ---- self inductance
    def inductance_mohan(self) -> float:
        c1, c2, c3, c4 = 1.00, 2.46, 0.00, 0.20
        rho = self.rho_fill
        l_air = MU0 * self.n_turns ** 2 * self.d_avg * c1 / 2 * (np.log(c2 / rho) + c3 * rho + c4 * rho ** 2)
        return l_air * (FERRITE_F_L if self.ferrite else 1.0)

    def inductance_wheeler(self) -> float:
        a = (self.r_in + self.r_out) / 2
        c = self.r_out - self.r_in
        l_air = 31.33 * MU0 * self.n_turns ** 2 * a ** 2 / (8 * a + 11 * c)
        return l_air * (FERRITE_F_L if self.ferrite else 1.0)

    def inductance(self) -> float:
        return self.inductance_mohan()

    # ---- resistance
    def r_dc(self) -> float:
        area = self.n_strands * np.pi * self.d_strand ** 2 / 4
        return RHO_CU * self.wire_length / area

    def r_ac(self, f: float) -> float:
        return self.r_dc() * proximity_factor(self, f)

    # ---- filament discretisation
    def filaments(self, n_phi: int = 72, dx: float = 0.0, dy: float = 0.0):
        """Segment midpoints (N,3) and segment vectors (N,3) of every turn, shifted
        laterally by (dx, dy) and located at z = self.z."""
        phi = np.linspace(0, 2 * np.pi, n_phi + 1)
        pts, dls = [], []
        for r in self.turn_radii:
            x, y = r * np.cos(phi), r * np.sin(phi)
            p = np.stack([x, y, np.full_like(x, self.z)], axis=1)
            dl = p[1:] - p[:-1]
            mid = 0.5 * (p[1:] + p[:-1])
            mid[:, 0] += dx
            mid[:, 1] += dy
            pts.append(mid)
            dls.append(dl)
        return np.vstack(pts), np.vstack(dls)


def skin_depth(f: float) -> float:
    return float(np.sqrt(2 * RHO_CU / (2 * np.pi * f * MU0)))


def proximity_factor(coil: SpiralCoil, f: float) -> float:
    return 1.0 + (coil.d_strand / skin_depth(f)) ** 4 * coil.n_turns * np.sqrt(coil.n_strands) / 24.0


def loop_self_inductance(a: float, r_wire: float) -> float:
    """Single circular loop of radius a and wire radius r_wire (Grover / Ramo-Whinnery)."""
    return MU0 * a * (np.log(8 * a / r_wire) - 2.0)


def maxwell_mutual(a: float, b: float, z: float) -> float:
    """Exact M between two coaxial circular loops of radii a, b separated by z."""
    kk2 = 4 * a * b / ((a + b) ** 2 + z ** 2)
    kk = np.sqrt(kk2)
    return MU0 * np.sqrt(a * b) * ((2 / kk - kk) * ellipk(kk2) - (2 / kk) * ellipe(kk2))


def neumann_mutual(p1: np.ndarray, dl1: np.ndarray, p2: np.ndarray, dl2: np.ndarray) -> float:
    """M = mu0/(4pi) sum_ij (dl_i . dl_j)/|r_i - r_j|, fully vectorised."""
    # |r_i - r_j|^2 = |r_i|^2 + |r_j|^2 - 2 r_i.r_j  (one matmul instead of a (N1,N2,3) array)
    d2 = np.sum(p1 ** 2, axis=1)[:, None] + np.sum(p2 ** 2, axis=1)[None, :] - 2.0 * (p1 @ p2.T)
    dist = np.sqrt(np.maximum(d2, 1e-18))
    dots = dl1 @ dl2.T
    return float(MU0 / (4 * np.pi) * np.sum(dots / dist))


def mutual_inductance(c1: SpiralCoil, c2: SpiralCoil, gap: float, dx: float = 0.0, dy: float = 0.0,
                      n_phi: int = 72, ferrite: bool | None = None) -> float:
    """Mutual inductance for vertical gap `gap` (m) and lateral offset (dx, dy) of coil 2."""
    p1, dl1 = c1.filaments(n_phi)
    c2s = SpiralCoil(c2.name, c2.n_turns, c2.r_in, c2.r_out, z=c1.z + gap, n_strands=c2.n_strands,
                     d_strand=c2.d_strand, ferrite=c2.ferrite)
    p2, dl2 = c2s.filaments(n_phi, dx=dx, dy=dy)
    m_air = neumann_mutual(p1, dl1, p2, dl2)
    use_ferrite = (c1.ferrite and c2.ferrite) if ferrite is None else ferrite
    return m_air * (FERRITE_F_M if use_ferrite else 1.0)


def coupling(c1: SpiralCoil, c2: SpiralCoil, gap: float, dx: float = 0.0, dy: float = 0.0, n_phi: int = 72) -> float:
    return mutual_inductance(c1, c2, gap, dx, dy, n_phi) / np.sqrt(c1.inductance() * c2.inductance())


def self_inductance_filament(c: SpiralCoil, n_phi: int = 72) -> float:
    """Independent numerical self-inductance: sum of turn self terms (Grover loop
    formula with the litz bundle radius) + Neumann mutual terms between turns."""
    r_bundle = np.sqrt(c.n_strands) * c.d_strand * 0.6   # ~ packing factor, bundle radius
    radii = c.turn_radii
    total = sum(loop_self_inductance(r, r_bundle) for r in radii)
    for i in range(c.n_turns):
        for j in range(c.n_turns):
            if i != j:
                total += maxwell_mutual(radii[i], radii[j], 0.0)
    return float(total) * (FERRITE_F_L if c.ferrite else 1.0)
