"""Inductive (wireless) EV charging design package - analytical + numerical
replacement for a COMSOL / ANSYS Maxwell study.

Author: Eswar Mahalingam (EV internship, Codec Technologies India, Sept 2026)
"""

from . import circuit, coils, compensation, fields  # noqa: F401

__all__ = ["circuit", "coils", "compensation", "fields"]
