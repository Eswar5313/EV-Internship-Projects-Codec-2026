"""Biot-Savart magnetic flux density of the two coils ("FEM-lite").

    B(r) = mu0 / (4 pi) * sum_segments  I dl x (r - r') / |r - r'|^3

Every turn is a polygon of straight segments; the field of a segment is
approximated by the midpoint rule (accurate when the segment length is small
compared with the distance - fine for n_phi = 90 and observation points more
than a few mm from the wire).  Currents are rms phasors, so |B| is an rms
value; the two coil currents have different phases and are combined
component-wise as complex numbers before taking the magnitude.

Air-core only: no ferrite or aluminium shielding is modelled, so the leakage
field outside the pads is an OVER-estimate of a real shielded pad.

Exposure reference: ICNIRP 2010 guideline reference level for general public
exposure, 3 kHz - 10 MHz: B = 27 uT (rms).  SAE J2954 uses this limit for its
protection regions (region 2/3, outside the vehicle perimeter). ICNIRP 1998
gave 6.25 uT - both are reported.
"""

from __future__ import annotations

import numpy as np

from .coils import MU0, SpiralCoil

ICNIRP_2010_UT = 27.0
ICNIRP_1998_UT = 6.25


def b_field(points: np.ndarray, p_seg: np.ndarray, dl_seg: np.ndarray, current: complex, chunk: int = 2000):
    """Complex B (n_points, 3) from segments (midpoints p_seg, vectors dl_seg) carrying `current`."""
    out = np.zeros((len(points), 3), dtype=complex)
    for s in range(0, len(points), chunk):
        r = points[s:s + chunk, None, :] - p_seg[None, :, :]          # (c, S, 3)
        d3 = np.sum(r ** 2, axis=2) ** 1.5
        d3 = np.maximum(d3, 1e-9)
        cross = np.cross(dl_seg[None, :, :], r)                        # (c, S, 3)
        out[s:s + chunk] = MU0 / (4 * np.pi) * current * np.sum(cross / d3[:, :, None], axis=1)
    return out


def field_map_xz(c1: SpiralCoil, c2: SpiralCoil, gap: float, i1: complex, i2: complex, dx2: float = 0.0,
                 x_lim: float = 1.1, z_lim=(-0.3, 0.6), n: int = 91, n_phi: int = 90):
    """|B|_rms (tesla) on the y = 0 cut plane."""
    xs = np.linspace(-x_lim, x_lim, n)
    zs = np.linspace(z_lim[0], z_lim[1], n)
    X, Z = np.meshgrid(xs, zs)
    pts = np.stack([X.ravel(), np.zeros(X.size), Z.ravel()], axis=1)
    p1, dl1 = c1.filaments(n_phi)
    c2s = SpiralCoil(c2.name, c2.n_turns, c2.r_in, c2.r_out, z=c1.z + gap, ferrite=c2.ferrite)
    p2, dl2 = c2s.filaments(n_phi, dx=dx2)
    b = b_field(pts, p1, dl1, i1) + b_field(pts, p2, dl2, i2)
    b_rms = np.sqrt(np.sum(np.abs(b) ** 2, axis=1)).reshape(X.shape)
    return xs, zs, b_rms


def field_at_points(points: np.ndarray, c1: SpiralCoil, c2: SpiralCoil, gap: float, i1: complex, i2: complex,
                    dx2: float = 0.0, n_phi: int = 90) -> np.ndarray:
    p1, dl1 = c1.filaments(n_phi)
    c2s = SpiralCoil(c2.name, c2.n_turns, c2.r_in, c2.r_out, z=c1.z + gap, ferrite=c2.ferrite)
    p2, dl2 = c2s.filaments(n_phi, dx=dx2)
    b = b_field(points, p1, dl1, i1) + b_field(points, p2, dl2, i2)
    return np.sqrt(np.sum(np.abs(b) ** 2, axis=1))


def b_on_axis_single_loop(a: float, z: float, i: float) -> float:
    """Analytical on-axis field of one circular loop (for validating b_field)."""
    return MU0 * i * a ** 2 / (2 * (a ** 2 + z ** 2) ** 1.5)
