"""Phasor (frequency-domain) analysis of the resonant inductive link and the
power-conversion stages.

Mesh equations (phasors at frequency w, I2 defined into the load):

  SS:      [ R1 + j(wL1 - 1/(wC1))        -jwM                     ] [I1]   [V1]
           [ -jwM                          R2 + R_L + j(wL2 - 1/(wC2)) ] [I2] = [0 ]

  LCC-S:   mesh a (inverter loop: L_f1, C_f1), mesh 1 (C_f1, C1, L1), mesh 2 (secondary)
           V1 = jwL_f1 Ia + (Ia - I1)/(jwC_f1)
           0  = (I1 - Ia)/(jwC_f1) + I1 (R1 + jwL1 + 1/(jwC1)) - jwM I2
           0  = -jwM I1 + I2 (R2 + R_L + jwL2 + 1/(jwC2))

Powers:  P_in = Re(V1 conj(I_in)),  P_out = |I2|^2 R_L,  P_coil1 = |I1|^2 R1,
         P_coil2 = |I2|^2 R2 (R1, R2 include capacitor ESR), P_Lf1 = |Ia|^2 R_f
Energy balance P_in = P_out + losses holds to machine precision (tested).

Converter losses (declared device data):
  * Inverter: full-bridge SiC MOSFET (Wolfspeed C3M0021120K-class, 1200 V,
    R_ds(on) = 21 mOhm @ 25 C -> 32 mOhm hot ASSUMED), ZVS assumed so only
    turn-off energy counts: E_off = 0.15 mJ @ 40 A, 800 V (datasheet order of
    magnitude), scaled linearly with current and DC voltage; two devices conduct.
  * Rectifier: full bridge, two SiC Schottky diodes in series (Wolfspeed
    C4D40120D-class): V_f0 = 0.9 V, r_d = 20 mOhm.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np

from .compensation import LCCSDesign, SSDesign, capacitor_esr


@dataclass
class LinkParams:
    R1_coil: float
    R2_coil: float
    M: float
    design: SSDesign | LCCSDesign
    R_f: float = 0.0            # ESR of L_f1 (LCC-S only)
    esr: bool = True

    @property
    def R1(self):
        d = self.design
        r = self.R1_coil
        if self.esr:
            r += capacitor_esr(d.C1, d.f0)
        return r

    @property
    def R2(self):
        r = self.R2_coil
        if self.esr:
            r += capacitor_esr(self.design.C2, self.design.f0)
        return r


@dataclass
class ConverterParams:
    r_ds_on: float = 0.032
    e_off: float = 0.15e-3
    i_ref: float = 40.0
    v_ref: float = 800.0
    v_f0: float = 0.9
    r_d: float = 0.020
    p_ctrl: float = 25.0        # W, gate drives + control (assumed)


def solve(link: LinkParams, v1: complex, r_load: float, f: float | None = None) -> Dict[str, float]:
    """Solve the phasor network for source fundamental v1 (V rms, phasor) and AC load r_load."""
    d = link.design
    w = 2 * np.pi * (f if f is not None else d.f0)
    M = link.M
    z1 = link.R1 + 1j * (w * d.L1 - 1 / (w * d.C1))
    z2 = link.R2 + r_load + 1j * (w * d.L2 - 1 / (w * d.C2))
    if isinstance(d, SSDesign):
        A = np.array([[z1, -1j * w * M], [-1j * w * M, z2]])
        i1, i2 = np.linalg.solve(A, np.array([v1, 0.0]))
        i_in = i1
        p_lf = 0.0
    else:
        zf = 1 / (1j * w * d.Cf1)
        A = np.array([[1j * w * d.Lf1 + link.R_f + zf, -zf, 0.0],
                      [-zf, zf + z1, -1j * w * M],
                      [0.0, -1j * w * M, z2]])
        ia, i1, i2 = np.linalg.solve(A, np.array([v1, 0.0, 0.0]))
        i_in = ia
        p_lf = abs(ia) ** 2 * link.R_f
    p_in = float(np.real(v1 * np.conj(i_in)))
    p_out = float(abs(i2) ** 2 * r_load)
    p1, p2 = float(abs(i1) ** 2 * link.R1), float(abs(i2) ** 2 * link.R2)
    return {"I_in": i_in, "I1": i1, "I2": i2, "P_in": p_in, "P_out": p_out, "P_coil1": p1, "P_coil2": p2,
            "P_Lf1": float(p_lf), "eta_link": p_out / p_in if p_in > 0 else 0.0,
            "V2_oc": abs(w * M * i1), "Z_in": v1 / i_in if abs(i_in) > 0 else np.inf}


def converter_losses(res: Dict[str, float], v_dc: float, v_bat: float, cp: ConverterParams) -> Dict[str, float]:
    """Inverter + rectifier losses for a solved operating point."""
    i_inv = abs(res["I_in"])                      # rms current through the bridge
    p_inv_cond = 2 * cp.r_ds_on * i_inv ** 2
    i_pk = np.sqrt(2) * i_inv
    f0 = 85e3
    # four switches each turn off once per period; turn-off current taken as the peak (conservative)
    p_inv_sw = 4 * f0 * cp.e_off * (i_pk / cp.i_ref) * (v_dc / cp.v_ref)
    i2 = abs(res["I2"])
    i_dc = res["P_out"] / v_bat if v_bat > 0 else 0.0
    p_rect = 2 * (cp.v_f0 * i_dc + cp.r_d * i2 ** 2 / 2)
    return {"P_inverter": p_inv_cond + p_inv_sw + cp.p_ctrl, "P_rectifier": p_rect,
            "P_inv_cond": p_inv_cond, "P_inv_sw": p_inv_sw}


def system_point(link: LinkParams, v_dc: float, v_bat: float, p_target: float, cp: ConverterParams,
                 f: float | None = None) -> Dict[str, float]:
    """Full operating point: inverter -> link -> rectifier -> battery.
    The AC load is referred from the battery at the target power (R_L = 8/pi^2 V^2/P);
    the achieved DC output is P_out - rectifier loss."""
    from .compensation import inverter_fundamental_rms, load_resistance
    r_l = load_resistance(v_bat, p_target)
    res = solve(link, inverter_fundamental_rms(v_dc), r_l, f)
    cl = converter_losses(res, v_dc, v_bat, cp)
    p_dc_in = res["P_in"] + cl["P_inverter"]
    p_bat = res["P_out"] - cl["P_rectifier"]
    out = {**res, **cl, "R_L": r_l, "P_dc_in": p_dc_in, "P_bat": p_bat,
           "eta_system": p_bat / p_dc_in if p_dc_in > 0 else 0.0, "V_dc": v_dc}
    out["balance_residual_W"] = p_dc_in - (p_bat + cl["P_inverter"] + res["P_coil1"] + res["P_coil2"]
                                          + res["P_Lf1"] + cl["P_rectifier"])
    return out


def v_dc_for_power(link: LinkParams, v_bat: float, p_target: float, cp: ConverterParams,
                   v_max: float = 1000.0) -> float:
    """DC-bus voltage that delivers p_target to the battery (bisection: P_bat is monotone in V_dc)."""
    lo, hi = 1.0, v_max
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if system_point(link, mid, v_bat, p_target, cp)["P_bat"] < p_target:
            lo = mid
        else:
            hi = mid
    return hi


def efficiency_vs_k(k_values, L1, L2, R1, R2, r_load, f0=85e3):
    """SS link efficiency (analytical, at resonance) as a function of k for a fixed load."""
    from .compensation import design_ss
    d = design_ss(L1, L2, f0)
    out = []
    for k in k_values:
        link = LinkParams(R1, R2, k * np.sqrt(L1 * L2), d, esr=False)
        out.append(solve(link, 100.0, r_load)["eta_link"])
    return np.array(out)


def efficiency_vs_load(r_loads, L1, L2, R1, R2, M, f0=85e3):
    from .compensation import design_ss
    d = design_ss(L1, L2, f0)
    link = LinkParams(R1, R2, M, d, esr=False)
    return np.array([solve(link, 100.0, r)["eta_link"] for r in r_loads])
