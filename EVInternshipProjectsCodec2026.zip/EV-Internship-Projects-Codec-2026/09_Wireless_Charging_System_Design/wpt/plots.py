"""Figures for the wireless charging study."""

from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.colors import LogNorm  # noqa: E402

plt.rcParams.update({"font.size": 9, "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 110})


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return path


def coil_geometry(c1, c2, gap, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    ax = axes[0]
    for c, col in ((c1, "C0"), (c2, "C3")):
        th = np.linspace(0, 2 * np.pi * c.n_turns, 200 * c.n_turns)
        r = c.r_in + (c.r_out - c.r_in) * th / th[-1]
        ax.plot(r * np.cos(th), r * np.sin(th), color=col, lw=0.8,
                label=f"{c.name}: N={c.n_turns}, r_in={c.r_in*1e3:.0f} mm, r_out={c.r_out*1e3:.0f} mm, pitch={c.pitch*1e3:.1f} mm")
    ax.set(aspect="equal", xlabel="x (m)", ylabel="y (m)", title="Plan view (both coils, coaxial)")
    ax.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.12))
    ax = axes[1]
    for c, z, col in ((c1, 0.0, "C0"), (c2, gap, "C3")):
        for r in c.turn_radii:
            ax.plot([-r, r], [z, z], "o", color=col, ms=2)
        ax.add_patch(plt.Rectangle((-c.r_out * 1.1, z - (0.012 if c is c1 else -0.004)), 2.2 * c.r_out, 0.008,
                                   color="gray", alpha=0.5))
    ax.annotate("", xy=(0.36, gap), xytext=(0.36, 0), arrowprops=dict(arrowstyle="<->"))
    ax.text(0.37, gap / 2, f"gap {gap*1e3:.0f} mm", va="center")
    ax.set(aspect="equal", xlabel="x (m)", ylabel="z (m)", title="Side view (dots = litz turns, grey = ferrite backing, modelled as a factor)",
           xlim=(-0.45, 0.45), ylim=(-0.06, gap + 0.06))
    return _save(fig, os.path.join(out_dir, "coil_geometry.png"))


def k_vs_gap(gaps, k_air, k_fer, z_classes, out_dir):
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(gaps * 1e3, k_fer, "o-", label="with ferrite factor (design)")
    ax.plot(gaps * 1e3, k_air, "s--", label="air core (Neumann only)")
    for i, (name, (lo, hi)) in enumerate(z_classes.items()):
        ax.axvspan(lo, hi, alpha=0.08, color=f"C{i+2}")
        ax.text((lo + hi) / 2, max(k_fer) * 0.97, name, ha="center", fontsize=8)
    ax.set(xlabel="coil-to-coil gap (mm)", ylabel="coupling coefficient k", title="k vs gap (SAE J2954 Z-classes shaded)")
    ax.legend()
    return _save(fig, os.path.join(out_dir, "k_vs_gap.png"))


def k_vs_misalignment(dx, k_dx, gap, out_dir):
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(dx * 1e3, k_dx, "o-")
    ax.axvline(75, color="r", ls="--", lw=0.8)
    ax.text(76, max(k_dx) * 0.98, "J2954 X offset +/-75 mm", color="r", fontsize=8)
    ax.set(xlabel="lateral misalignment (mm)", ylabel="coupling coefficient k",
           title=f"k vs lateral misalignment at {gap*1e3:.0f} mm gap")
    return _save(fig, os.path.join(out_dir, "k_vs_misalignment.png"))


def efficiency_curves(k_vals, eta_k, r_vals, eta_r, r_opt, r_l_nom, k_nom, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for lab, eta in eta_k.items():
        axes[0].plot(k_vals, eta * 100, label=lab)
    axes[0].axvline(k_nom, color="k", ls="--", lw=0.8)
    axes[0].text(k_nom * 1.02, 30, f"design k = {k_nom:.3f}", fontsize=8)
    axes[0].set(xlabel="coupling coefficient k", ylabel="link efficiency (%)", title="SS link efficiency vs k", ylim=(0, 100))
    axes[0].legend(fontsize=8)
    axes[1].semilogx(r_vals, eta_r * 100)
    axes[1].axvline(r_opt, color="g", ls="--", lw=0.8, label=f"R_L,opt = {r_opt:.1f} ohm")
    axes[1].axvline(r_l_nom, color="r", ls="--", lw=0.8, label=f"R_L (400 V, 7.7 kW) = {r_l_nom:.1f} ohm")
    axes[1].set(xlabel="AC load resistance (ohm)", ylabel="link efficiency (%)", title=f"SS link efficiency vs load at k = {k_nom:.3f}")
    axes[1].legend(fontsize=8)
    return _save(fig, os.path.join(out_dir, "efficiency_vs_k_and_load.png"))


def power_vs_vdc(vdc, p_ss, p_lcc, target, out_dir):
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(vdc, p_ss / 1e3, label="SS (P ~ V_dc)")
    ax.plot(vdc, p_lcc / 1e3, label="LCC-S")
    ax.axhline(target / 1e3, color="k", ls="--", lw=0.8, label=f"target {target/1e3:.1f} kW")
    ax.set(xlabel="inverter DC-bus voltage (V)", ylabel="battery power (kW)", title="Output power vs input voltage (nominal gap, aligned)")
    ax.legend()
    return _save(fig, os.path.join(out_dir, "power_vs_vdc.png"))


def b_field_map(xs, zs, b, c1, c2, gap, bystander, out_dir, fname="b_field_map.png", title_extra=""):
    fig, ax = plt.subplots(figsize=(9, 5.5))
    b_ut = np.maximum(b * 1e6, 0.1)
    pc = ax.pcolormesh(xs, zs, b_ut, norm=LogNorm(vmin=1, vmax=min(b_ut.max(), 1e5)), cmap="inferno", shading="auto")
    cs = ax.contour(xs, zs, b_ut, levels=[6.25, 27], colors=["cyan", "lime"], linewidths=1.2)
    ax.clabel(cs, fmt={6.25: "6.25 uT (ICNIRP 1998)", 27: "27 uT (ICNIRP 2010)"}, fontsize=7)
    for c, z, col in ((c1, 0.0, "w"), (c2, gap, "w")):
        ax.plot([-c.r_out, -c.r_in], [z, z], color=col, lw=3)
        ax.plot([c.r_in, c.r_out], [z, z], color=col, lw=3)
    for (x, z, val) in bystander:
        ax.plot(x, z, "o", color="cyan", ms=7, mec="k")
        ax.text(x, z + 0.035, f"{val*1e6:.1f} uT", color="cyan", ha="center", fontsize=8, fontweight="bold")
    ax.set(xlabel="x (m)", ylabel="z (m)", aspect="equal", title=f"|B| rms on the y = 0 plane (Biot-Savart, air core){title_extra}")
    fig.colorbar(pc, ax=ax, label="|B| (uT, log scale)")
    return _save(fig, os.path.join(out_dir, fname))


def loss_breakdown(cases, out_dir):
    names = list(cases.keys())
    keys = [("P_inverter", "inverter"), ("P_coil1", "primary coil + C1"), ("P_Lf1", "L_f1 (LCC)"),
            ("P_coil2", "secondary coil + C2"), ("P_rectifier", "rectifier")]
    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(len(names))
    bottom = np.zeros(len(names))
    for i, (k, lab) in enumerate(keys):
        vals = np.array([cases[n][k] for n in names])
        ax.bar(x, vals, bottom=bottom, label=lab, color=f"C{i}")
        bottom += vals
    for xi, n in zip(x, names):
        ax.text(xi, bottom[xi] * 1.02, f"eta_sys {cases[n]['eta_system']*100:.1f} %\nV_dc {cases[n]['V_dc']:.0f} V",
                ha="center", fontsize=8)
    ax.set(xticks=x, xticklabels=names, ylabel="loss (W) at 7.7 kW battery power", title="Loss breakdown per operating case")
    ax.legend(fontsize=8)
    ax.set_ylim(0, bottom.max() * 1.25)
    return _save(fig, os.path.join(out_dir, "loss_breakdown.png"))
