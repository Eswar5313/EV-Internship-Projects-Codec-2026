"""Resonant compensation networks at the SAE J2954 frequency (85 kHz, band
79-90 kHz).

Series-series (SS):
    C1 = 1 / (w0^2 L1),   C2 = 1 / (w0^2 L2)
    At w0 the reflected impedance of the secondary is Z_r = w0^2 M^2 / (R2 + R_L)
    (purely resistive), the primary current is I1 = V1 / (R1 + Z_r) and the
    link efficiency is
        eta = Z_r / (R1 + Z_r) * R_L / (R2 + R_L)
    Optimal load  R_L,opt = R2 sqrt(1 + k^2 Q1 Q2)
    Maximum eta   eta_max = k^2 Q1 Q2 / (1 + sqrt(1 + k^2 Q1 Q2))^2
    (Wang, Stielau, Covic, IEEE Trans. Ind. Electron. 2005; Hui et al. 2014)

LCC-S (double-sided LCC reduced to LCC primary + series secondary, the
topology preferred in J2954 reference designs, Li et al., IEEE TVT 2015):
    primary:  L_f1 in series with the inverter, C_f1 in parallel, C1 in series with L1
        w0^2 L_f1 C_f1 = 1,   C1 = 1 / (w0^2 (L1 - L_f1))
        -> the coil current is load independent: |I1| = |V1| / (w0 L_f1)
    secondary: C2 = 1 / (w0^2 L2)  (series)

Load referred to the AC side of a full-bridge diode rectifier with a
capacitive filter feeding a battery (fundamental-harmonic approximation):
    R_L = (8 / pi^2) V_bat / I_bat = (8 / pi^2) V_bat^2 / P_bat
Full-bridge inverter fundamental (square wave, DC bus V_dc):
    V1,rms = (2 sqrt(2) / pi) V_dc
Capacitor ESR from dissipation factor: R_ESR = tan(delta) / (w0 C), tan(delta)
= 0.0005 (film capacitor, ASSUMED - typical polypropylene at 100 kHz).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

F0 = 85e3
W0 = 2 * np.pi * F0
TAN_DELTA = 0.0005


@dataclass
class SSDesign:
    L1: float
    L2: float
    C1: float
    C2: float
    f0: float = F0

    @property
    def w0(self):
        return 2 * np.pi * self.f0


@dataclass
class LCCSDesign:
    L1: float
    L2: float
    Lf1: float
    Cf1: float
    C1: float
    C2: float
    f0: float = F0

    @property
    def w0(self):
        return 2 * np.pi * self.f0


def design_ss(L1: float, L2: float, f0: float = F0) -> SSDesign:
    w = 2 * np.pi * f0
    return SSDesign(L1, L2, 1 / (w ** 2 * L1), 1 / (w ** 2 * L2), f0)


def design_lccs(L1: float, L2: float, i1_target: float, v1_rms: float, f0: float = F0) -> LCCSDesign:
    """Choose L_f1 so that the primary coil current equals i1_target (A rms) for the
    given inverter fundamental voltage."""
    w = 2 * np.pi * f0
    lf1 = v1_rms / (w * i1_target)
    if lf1 >= L1:
        raise ValueError("L_f1 must be smaller than L1; raise the target coil current")
    return LCCSDesign(L1, L2, lf1, 1 / (w ** 2 * lf1), 1 / (w ** 2 * (L1 - lf1)), 1 / (w ** 2 * L2), f0)


def capacitor_esr(c: float, f0: float = F0, tan_delta: float = TAN_DELTA) -> float:
    return tan_delta / (2 * np.pi * f0 * c)


def load_resistance(v_bat: float, p_bat: float) -> float:
    return 8 / np.pi ** 2 * v_bat ** 2 / p_bat


def inverter_fundamental_rms(v_dc: float) -> float:
    return 2 * np.sqrt(2) / np.pi * v_dc


def optimal_load(r2: float, k: float, q1: float, q2: float) -> float:
    return r2 * np.sqrt(1 + k ** 2 * q1 * q2)


def eta_max(k, q1, q2):
    x = np.asarray(k) ** 2 * q1 * q2
    return x / (1 + np.sqrt(1 + x)) ** 2
