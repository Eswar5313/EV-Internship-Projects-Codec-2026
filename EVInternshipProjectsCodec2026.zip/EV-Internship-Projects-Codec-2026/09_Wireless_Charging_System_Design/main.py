"""Inductive EV charging system design - single entry point.

    python main.py          # regenerates everything in results/

Outputs (results/):
    coil_geometry.png, k_vs_gap.png, k_vs_misalignment.png, efficiency_vs_k_and_load.png,
    power_vs_vdc.png, power_vs_k.png, b_field_map.png, b_field_map_misaligned.png,
    loss_breakdown.png, summary.json, cases.csv, k_sweeps.csv

Author: Eswar Mahalingam (EV internship, Codec Technologies India, Sept 2026)
"""

from __future__ import annotations

import json
import os
import time

import numpy as np
import pandas as pd

from wpt import circuit as X
from wpt import coils as C
from wpt import compensation as K
from wpt import fields as F
from wpt import plots

RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")

# ---------------------------------------------------------------- design inputs
P_TARGET = 7.7e3          # W, SAE J2954 WPT2 power class (7.7 kVA input rating)
V_BAT = 400.0             # V, nominal battery voltage
GAP_NOM = 0.175           # m, centre of J2954 Z2 class (140-210 mm)
Z_CLASSES = {"Z1": (100, 150), "Z2": (140, 210), "Z3": (170, 250)}   # mm, SAE J2954
MISALIGN = 0.075          # m, J2954 X-offset requirement +/-75 mm
BYSTANDER_POINTS = np.array([[0.80, 0.0, 0.10], [1.00, 0.0, 0.50]])   # m (x, y, z): vehicle sill / person beside car (assumed)

# Coils (ASSUMED geometry, sized so that ~30 turns-worth of L gives V_dc in the 400-600 V range):
PRIMARY = C.SpiralCoil("primary (ground assembly)", n_turns=20, r_in=0.100, r_out=0.300)
SECONDARY = C.SpiralCoil("secondary (vehicle assembly)", n_turns=20, r_in=0.085, r_out=0.225)


def main() -> dict:
    t0 = time.time()
    os.makedirs(RESULTS, exist_ok=True)
    c1, c2 = PRIMARY, SECONDARY
    f0 = K.F0
    cp = X.ConverterParams()

    # ---- coils
    L1, L2 = c1.inductance(), c2.inductance()
    R1c, R2c = c1.r_ac(f0), c2.r_ac(f0)
    M_nom = C.mutual_inductance(c1, c2, GAP_NOM)
    k_nom = M_nom / np.sqrt(L1 * L2)
    coil_info = {}
    for c, L, R in ((c1, L1, R1c), (c2, L2, R2c)):
        coil_info[c.name] = {
            "n_turns": c.n_turns, "r_in_mm": c.r_in * 1e3, "r_out_mm": c.r_out * 1e3, "pitch_mm": c.pitch * 1e3,
            "wire_length_m": c.wire_length, "litz": f"{c.n_strands} x {c.d_strand*1e3:.2f} mm (AWG38), {c.n_strands*np.pi*c.d_strand**2/4*1e6:.2f} mm2",
            "L_mohan_uH": L * 1e6, "L_wheeler_uH": c.inductance_wheeler() * 1e6,
            "L_filament_uH": C.self_inductance_filament(c) * 1e6, "L_air_core_uH": L / C.FERRITE_F_L * 1e6,
            "R_dc_mOhm": c.r_dc() * 1e3, "R_ac_mOhm": R * 1e3, "proximity_factor": C.proximity_factor(c, f0),
            "Q_coil": 2 * np.pi * f0 * L / R,
        }
        print(f"{c.name}: L = {L*1e6:.1f} uH, R_ac = {R*1e3:.0f} mOhm, Q = {2*np.pi*f0*L/R:.0f}")
    print(f"nominal gap {GAP_NOM*1e3:.0f} mm: M = {M_nom*1e6:.1f} uH, k = {k_nom:.3f}")

    # ---- k sweeps
    gaps = np.linspace(0.10, 0.25, 16)
    k_gap_fer = np.array([C.coupling(c1, c2, g) for g in gaps])
    k_gap_air = k_gap_fer / C.FERRITE_F_M * C.FERRITE_F_L      # k_air = M_air / sqrt(L_air L_air)
    dxs = np.linspace(0.0, 0.20, 21)
    k_dx = np.array([C.coupling(c1, c2, GAP_NOM, dx) for dx in dxs])
    pd.DataFrame({"gap_mm": gaps * 1e3, "k_ferrite": k_gap_fer, "k_air": k_gap_air}).to_csv(
        os.path.join(RESULTS, "k_sweeps.csv"), index=False)

    # ---- compensation
    ss = K.design_ss(L1, L2, f0)
    v1_lcc = K.inverter_fundamental_rms(400.0)            # LCC-S designed for a 400 V DC bus
    r_l_nom = K.load_resistance(V_BAT, P_TARGET)
    i1_lcc = np.sqrt(P_TARGET * 1.02 * r_l_nom) / (K.W0 * M_nom)   # coil current for the target power (+2 % rectifier)
    lcc = K.design_lccs(L1, L2, i1_lcc, v1_lcc, f0)
    r_f = 0.05   # ohm, ESR of L_f1 (assumed, ferrite-core choke)
    link_ss = X.LinkParams(R1c, R2c, M_nom, ss)
    link_lcc = X.LinkParams(R1c, R2c, M_nom, lcc, R_f=r_f)
    q1, q2 = K.W0 * L1 / link_ss.R1, K.W0 * L2 / link_ss.R2
    comp = {
        "SS": {"C1_nF": ss.C1 * 1e9, "C2_nF": ss.C2 * 1e9, "ESR_C1_mOhm": K.capacitor_esr(ss.C1) * 1e3,
               "ESR_C2_mOhm": K.capacitor_esr(ss.C2) * 1e3, "w0^2_L1_C1": K.W0 ** 2 * L1 * ss.C1,
               "w0^2_L2_C2": K.W0 ** 2 * L2 * ss.C2},
        "LCC-S": {"Lf1_uH": lcc.Lf1 * 1e6, "Cf1_nF": lcc.Cf1 * 1e9, "C1_nF": lcc.C1 * 1e9, "C2_nF": lcc.C2 * 1e9,
                  "I1_design_A": i1_lcc, "w0^2_Lf1_Cf1": K.W0 ** 2 * lcc.Lf1 * lcc.Cf1,
                  "w0^2_(L1-Lf1)_C1": K.W0 ** 2 * (L1 - lcc.Lf1) * lcc.C1},
        "R1_total_mOhm": link_ss.R1 * 1e3, "R2_total_mOhm": link_ss.R2 * 1e3, "Q1": q1, "Q2": q2,
        "k_nom": k_nom, "kQ_sqrtQ1Q2": k_nom * np.sqrt(q1 * q2), "R_L_nominal_ohm": r_l_nom,
        "R_L_optimal_ohm": K.optimal_load(link_ss.R2, k_nom, q1, q2), "eta_max_analytical": float(K.eta_max(k_nom, q1, q2)),
    }

    # ---- operating cases (V_dc re-regulated to deliver 7.7 kW in every case)
    cases = {}
    for topo, base in (("SS", ss), ("LCC-S", lcc)):
        for label, gap, dx in (("nominal", GAP_NOM, 0.0), ("+75 mm offset", GAP_NOM, MISALIGN),
                               ("Z2 min 140 mm", 0.140, 0.0), ("Z2 max 210 mm", 0.210, 0.0)):
            M = C.mutual_inductance(c1, c2, gap, dx)
            link = X.LinkParams(R1c, R2c, M, base, R_f=r_f if topo == "LCC-S" else 0.0)
            vdc = X.v_dc_for_power(link, V_BAT, P_TARGET, cp)
            sp = X.system_point(link, vdc, V_BAT, P_TARGET, cp)
            name = f"{topo} {label}"
            cases[name] = {"topology": topo, "gap_mm": gap * 1e3, "dx_mm": dx * 1e3, "M_uH": M * 1e6,
                           "k": M / np.sqrt(L1 * L2), "V_dc": vdc, "I1_A": abs(sp["I1"]), "I2_A": abs(sp["I2"]),
                           "I_inverter_A": abs(sp["I_in"]), "P_dc_in": sp["P_dc_in"], "P_bat": sp["P_bat"],
                           "P_inverter": sp["P_inverter"], "P_coil1": sp["P_coil1"], "P_Lf1": sp["P_Lf1"],
                           "P_coil2": sp["P_coil2"], "P_rectifier": sp["P_rectifier"],
                           "eta_link": sp["eta_link"], "eta_system": sp["eta_system"],
                           "balance_residual_W": sp["balance_residual_W"],
                           "Z_in_ohm": [float(np.real(sp["Z_in"])), float(np.imag(sp["Z_in"]))]}
            print(f"{name:22s}: k={cases[name]['k']:.3f} V_dc={vdc:6.1f} V I1={abs(sp['I1']):5.1f} A "
                  f"eta_link={sp['eta_link']*100:5.2f} % eta_sys={sp['eta_system']*100:5.2f} %")
    pd.DataFrame(cases).T.to_csv(os.path.join(RESULTS, "cases.csv"))

    # ---- efficiency curves
    k_vals = np.linspace(0.02, 0.6, 120)
    eta_k = {f"R_L = {r_l_nom:.1f} ohm (7.7 kW @ 400 V)": X.efficiency_vs_k(k_vals, L1, L2, link_ss.R1, link_ss.R2, r_l_nom),
             "R_L = 5 ohm": X.efficiency_vs_k(k_vals, L1, L2, link_ss.R1, link_ss.R2, 5.0),
             "R_L = 50 ohm": X.efficiency_vs_k(k_vals, L1, L2, link_ss.R1, link_ss.R2, 50.0),
             "analytical eta_max(kQ)": K.eta_max(k_vals, q1, q2)}
    r_vals = np.logspace(-0.5, 2.5, 120)
    eta_r = X.efficiency_vs_load(r_vals, L1, L2, link_ss.R1, link_ss.R2, M_nom)

    # ---- power vs V_dc and vs k at fixed V_dc
    vdcs = np.linspace(50, 800, 60)
    p_ss = np.array([X.system_point(link_ss, v, V_BAT, P_TARGET, cp)["P_bat"] for v in vdcs])
    p_lcc = np.array([X.system_point(link_lcc, v, V_BAT, P_TARGET, cp)["P_bat"] for v in vdcs])
    vdc_ss_nom, vdc_lcc_nom = cases["SS nominal"]["V_dc"], cases["LCC-S nominal"]["V_dc"]
    p_ss_k = np.array([X.system_point(X.LinkParams(R1c, R2c, k * np.sqrt(L1 * L2), ss), vdc_ss_nom, V_BAT, P_TARGET, cp)["P_bat"]
                       for k in k_vals])
    p_lcc_k = np.array([X.system_point(X.LinkParams(R1c, R2c, k * np.sqrt(L1 * L2), lcc, R_f=r_f), vdc_lcc_nom, V_BAT, P_TARGET, cp)["P_bat"]
                        for k in k_vals])

    # ---- fields (SS nominal currents)
    sp_nom = X.system_point(link_ss, vdc_ss_nom, V_BAT, P_TARGET, cp)
    i1, i2 = sp_nom["I1"], sp_nom["I2"]   # at resonance I2 is in quadrature with I1, so |B| is sign-independent
    xs, zs, b = F.field_map_xz(c1, c2, GAP_NOM, i1, i2)
    b_byst = F.field_at_points(BYSTANDER_POINTS, c1, c2, GAP_NOM, i1, i2)
    sp_mis = X.system_point(X.LinkParams(R1c, R2c, C.mutual_inductance(c1, c2, GAP_NOM, MISALIGN), ss),
                            cases["SS +75 mm offset"]["V_dc"], V_BAT, P_TARGET, cp)
    xs_m, zs_m, b_m = F.field_map_xz(c1, c2, GAP_NOM, sp_mis["I1"], sp_mis["I2"], dx2=MISALIGN)
    b_byst_m = F.field_at_points(BYSTANDER_POINTS, c1, c2, GAP_NOM, sp_mis["I1"], sp_mis["I2"], dx2=MISALIGN)
    # single-loop validation of the Biot-Savart routine
    loop = C.SpiralCoil("loop", 1, 0.2, 0.2)
    pl, dll = loop.filaments(90)
    b_num = abs(F.b_field(np.array([[0.0, 0.0, 0.1]]), pl, dll, 10.0)[0, 2])
    b_ana = F.b_on_axis_single_loop(0.2, 0.1, 10.0)
    b_gap_centre = float(F.field_at_points(np.array([[0.0, 0.0, GAP_NOM / 2]]), c1, c2, GAP_NOM, i1, i2)[0])
    fields_info = {
        "I1_rms_A": abs(i1), "I2_rms_A": abs(i2), "B_centre_of_gap_uT": b_gap_centre * 1e6,
        "bystander_points_m": BYSTANDER_POINTS.tolist(),
        "B_bystander_uT_aligned": (b_byst * 1e6).tolist(), "B_bystander_uT_misaligned": (b_byst_m * 1e6).tolist(),
        "ICNIRP_2010_reference_uT": F.ICNIRP_2010_UT, "ICNIRP_1998_reference_uT": F.ICNIRP_1998_UT,
        "compliant_ICNIRP_2010_aligned": bool(np.all(b_byst * 1e6 < F.ICNIRP_2010_UT)),
        "compliant_ICNIRP_2010_misaligned": bool(np.all(b_byst_m * 1e6 < F.ICNIRP_2010_UT)),
        "biot_savart_check_single_loop": {"numeric_T": b_num, "analytic_T": b_ana, "rel_err": abs(b_num - b_ana) / b_ana},
        "note": "air-core model, no ferrite/aluminium shielding -> leakage field is an over-estimate",
    }
    for lab, bb in (("aligned", b_byst), ("misaligned", b_byst_m)):
        print(f"B at bystander points ({lab}): {np.array2string(bb*1e6, precision=2)} uT vs ICNIRP 2010 27 uT")

    # ---- plots
    plots.coil_geometry(c1, c2, GAP_NOM, RESULTS)
    plots.k_vs_gap(gaps, k_gap_air, k_gap_fer, Z_CLASSES, RESULTS)
    plots.k_vs_misalignment(dxs, k_dx, GAP_NOM, RESULTS)
    plots.efficiency_curves(k_vals, eta_k, r_vals, eta_r, comp["R_L_optimal_ohm"], r_l_nom, k_nom, RESULTS)
    plots.power_vs_vdc(vdcs, p_ss, p_lcc, P_TARGET, RESULTS)
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(k_vals, p_ss_k / 1e3, label=f"SS at V_dc = {vdc_ss_nom:.0f} V (P ~ 1/M^2)")
    ax.plot(k_vals, p_lcc_k / 1e3, label=f"LCC-S at V_dc = {vdc_lcc_nom:.0f} V (P ~ M^2)")
    ax.axvline(k_nom, color="k", ls="--", lw=0.8)
    ax.set(xlabel="coupling coefficient k", ylabel="battery power (kW)", ylim=(0, 30),
           title="Output power vs k at fixed DC-bus voltage (open-loop sensitivity)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(RESULTS, "power_vs_k.png"), dpi=130)
    plt.close(fig)
    plots.b_field_map(xs, zs, b, c1, c2, GAP_NOM, [(p[0], p[2], v) for p, v in zip(BYSTANDER_POINTS, b_byst)], RESULTS)
    plots.b_field_map(xs_m, zs_m, b_m, c1, c2, GAP_NOM, [(p[0], p[2], v) for p, v in zip(BYSTANDER_POINTS, b_byst_m)],
                      RESULTS, "b_field_map_misaligned.png", ", secondary offset +75 mm")
    plots.loss_breakdown({k: v for k, v in cases.items() if "Z2" not in k}, RESULTS)

    summary = {
        "design": {"power_class": "SAE J2954 WPT2 (7.7 kW)", "P_target_W": P_TARGET, "V_bat_V": V_BAT, "f0_Hz": f0,
                   "gap_nominal_mm": GAP_NOM * 1e3, "z_classes_mm": Z_CLASSES, "misalignment_mm": MISALIGN * 1e3,
                   "ferrite_factors": {"f_L": C.FERRITE_F_L, "f_M": C.FERRITE_F_M}},
        "coils": coil_info,
        "coupling": {"M_nominal_uH": M_nom * 1e6, "k_nominal": k_nom,
                     "k_vs_gap": {"gap_mm": (gaps * 1e3).tolist(), "k_ferrite": k_gap_fer.tolist(), "k_air": k_gap_air.tolist()},
                     "k_vs_misalignment": {"dx_mm": (dxs * 1e3).tolist(), "k": k_dx.tolist()}},
        "compensation": comp, "cases": cases, "fields": fields_info,
        "converter_params": vars(cp), "runtime_s": time.time() - t0,
    }
    with open(os.path.join(RESULTS, "summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2, default=float)
    print(f"done in {summary['runtime_s']:.1f} s -> {RESULTS}")
    return summary


if __name__ == "__main__":
    main()
