#!/usr/bin/env python3
"""AI-Powered Driving Efficiency Optimizer - full pipeline.

    python main.py            # 2,000 synthetic trips, full run (~1 min)
    python main.py --trips 300  # quick run

Steps: simulate SYNTHETIC trips -> features -> train/compare models -> evaluate
-> driver-style classifier -> counterfactual tips -> write everything to results/.

Author: Eswar Mahalingam - Codec Technologies India EV internship, Sept 2026.
"""
from __future__ import annotations

import argparse
import time

import joblib
import numpy as np
import pandas as pd

from src import config as C
from src.data_generator import generate_dataset
from src.evaluate import (
    dataset_summary,
    recommendation_summary,
    write_metrics,
    write_sample_recommendations,
)
from src.features import FEATURE_COLUMNS, build_feature_table
from src.models import compare_regressors, feature_importance, split_data, train_style_classifier
from src.plots import (
    plot_confusion,
    plot_counterfactual_savings,
    plot_energy_by_group,
    plot_energy_vs_speed,
    plot_example_trip,
    plot_feature_importance,
    plot_pred_vs_actual,
)
from src.recommender import Recommender, savings_table

BANNER = """
=====================================================================
  AI-Powered Driving Efficiency Optimizer
  Codec Technologies India - EV internship - Eswar Mahalingam
  NOTE: all driving data is SYNTHETIC (physics-based simulator)
=====================================================================
"""


def main(n_trips: int = C.N_TRIPS, seed: int = C.RANDOM_SEED, n_raw_samples: int = 5):
    t0 = time.time()
    print(BANNER)
    out = C.RESULTS_DIR
    out.mkdir(parents=True, exist_ok=True)

    # 1. simulate --------------------------------------------------------------
    print(f"[1/6] Simulating {n_trips} synthetic trips (seed={seed}) ...")
    metas, raw, energies = generate_dataset(n_trips, seed)

    # 2. features -------------------------------------------------------------
    print("[2/6] Engineering per-trip features ...")
    trips = build_feature_table(metas, raw, energies)
    trips.to_csv(out / "trips_dataset.csv", index=False)
    sample_ids = [m.trip_id for m in metas[:n_raw_samples]]
    pd.concat([raw[i] for i in sample_ids]).to_csv(out / "raw_1hz_sample.csv", index=False, float_format="%.4f")
    summ = dataset_summary(trips)
    print(f"      {len(trips)} trips, {summ['total_distance_km']:.0f} km, {summ['total_hours']:.0f} h of driving")
    for s, d in summ["by_driver_style"].items():
        print(f"      {s:>10}: {d['mean']:.1f} ± {d['std']:.1f} Wh/km  (n={int(d['count'])})")

    # 3. regression -----------------------------------------------------------
    print("[3/6] Training and comparing regressors (5-fold CV + held-out test) ...")
    train_df, test_df = split_data(trips, seed)
    comparison, fitted, best_name = compare_regressors(train_df, test_df, seed)
    comparison.to_csv(out / "model_comparison.csv", index=False)
    print(comparison.round(3).to_string(index=False))
    best = fitted[best_name]
    print(f"      best model: {best_name}")
    joblib.dump(best, out / "best_regressor.joblib")

    imp = feature_importance(best, test_df, seed)
    imp.to_csv(out / "feature_importance.csv", index=False)

    # 4. classification -------------------------------------------------------
    print("[4/6] Training driver-style classifier ...")
    clf, clf_metrics = train_style_classifier(train_df, test_df, seed)
    print(f"      accuracy={clf_metrics['accuracy']:.3f}  macro-F1={clf_metrics['macro_f1']:.3f}")
    joblib.dump(clf, out / "style_classifier.joblib")

    # 5. recommendations ------------------------------------------------------
    print("[5/6] Generating counterfactual driving tips for the test trips ...")
    rec = Recommender(best, clf)
    recs = rec.recommend_many(test_df)
    sav = savings_table(recs)
    sav.to_csv(out / "counterfactual_savings.csv", index=False)
    rec_summary = recommendation_summary(recs)
    rec_summary["mean_combined_saving_pct_by_style"] = {
        s: float(np.mean([r.combined.saving_pct for r, st in zip(recs, test_df.driver_style)
                          if st == s and r.combined is not None] or [0.0]))
        for s in ["eco", "normal", "aggressive"]
    }
    # three example trips: one per driver style, biggest predicted saving
    examples = []
    for s in ["aggressive", "normal", "eco"]:
        cands = [r for r, st in zip(recs, test_df.driver_style) if st == s and r.tips]
        cands.sort(key=lambda r: r.combined.saving_pct if r.combined else 0, reverse=True)
        examples.append(cands[len(cands) // 4] if cands else recs[0])  # upper-quartile, not the extreme
    write_sample_recommendations(out / "sample_recommendations.md", examples, trips, best_name)
    for r in examples:
        top = r.tips[0] if r.tips else None
        print(f"      trip {r.trip_id:4d} ({r.predicted_style:>10}): {r.predicted_wh_per_km:.0f} Wh/km -> "
              + (f"top tip '{top.title}' saves {top.saving_pct:.1f} %" if top else "no tips"))

    # 6. plots + metrics ------------------------------------------------------
    print("[6/6] Writing plots and metrics ...")
    preds = {name: m.predict(test_df[FEATURE_COLUMNS]) for name, m in fitted.items()}
    plot_pred_vs_actual(test_df, preds, out / "predicted_vs_actual.png")
    plot_feature_importance(imp, out / "feature_importance.png")
    plot_energy_by_group(trips, out / "energy_by_style_and_road.png")
    plot_energy_vs_speed(trips, out / "energy_vs_speed.png")
    plot_counterfactual_savings(sav, out / "counterfactual_savings.png")
    plot_confusion(clf_metrics["confusion_matrix"], clf_metrics["labels"], out / "style_confusion_matrix.png")
    ex_id = examples[0].trip_id
    plot_example_trip(raw[ex_id], metas[ex_id], out / "example_trip_trace.png")

    metrics = write_metrics(
        out / "metrics.json",
        dataset=summ,
        regression={
            "best_model": best_name,
            "n_train": int(len(train_df)), "n_test": int(len(test_df)),
            "features": list(imp.feature),
            "models": comparison.to_dict(orient="records"),
            "permutation_importance_top10": imp.head(10).to_dict(orient="records"),
        },
        classification={k: v for k, v in clf_metrics.items() if k != "report"} | {
            "per_class_f1": {s: clf_metrics["report"][s]["f1-score"] for s in clf_metrics["labels"]}
        },
        recommendations=rec_summary,
        example_trips=[r.trip_id for r in examples],
        runtime_s=round(time.time() - t0, 1),
    )
    print(f"\nDone in {metrics['runtime_s']} s. Results written to {out}/")
    return metrics


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trips", type=int, default=C.N_TRIPS, help="number of synthetic trips to simulate")
    ap.add_argument("--seed", type=int, default=C.RANDOM_SEED)
    args = ap.parse_args()
    main(args.trips, args.seed)
