"""Driving-tip recommender: rule-based triggers + model-driven counterfactuals.

For a given trip the recommender

1. checks a set of *rules* (e.g. "harsh braking events present", "HVAC on")
   to decide which tips are applicable;
2. builds a *counterfactual* feature vector for each applicable tip (what the
   trip would have looked like if the driver had followed the tip);
3. re-predicts Wh/km with the trained regression model and reports the
   predicted saving in % relative to the trip's predicted baseline;
4. ranks the tips by predicted saving and adds a "do everything" scenario.

The counterfactual edits are simple, explainable and conservative. They act on
the same features a coaching app could compute from real OBD/GPS data.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .features import BEHAVIOUR_FEATURES, FEATURE_COLUMNS

SPEED_CAP_KMH = {"highway": 100.0, "hilly": 70.0, "urban": 50.0}


@dataclass
class Tip:
    key: str
    title: str
    advice: str
    trigger: str                      # human-readable rule that fired
    baseline_wh_per_km: float
    counterfactual_wh_per_km: float
    saving_pct: float
    saving_wh_per_km: float
    changes: dict = field(default_factory=dict)


@dataclass
class Recommendation:
    trip_id: int
    predicted_wh_per_km: float
    actual_wh_per_km: float | None
    predicted_style: str | None
    style_probabilities: dict
    tips: list[Tip]
    combined: Tip | None
    not_applicable: list[str]

    def to_markdown(self) -> str:
        lines = [f"### Trip {self.trip_id}"]
        if self.actual_wh_per_km is not None:
            lines.append(f"- Actual energy use: **{self.actual_wh_per_km:.1f} Wh/km**")
        lines.append(f"- Model prediction: **{self.predicted_wh_per_km:.1f} Wh/km**")
        if self.predicted_style:
            probs = ", ".join(f"{k}: {v:.0%}" for k, v in self.style_probabilities.items())
            lines.append(f"- Detected driving style: **{self.predicted_style}** ({probs})")
        lines.append("")
        if not self.tips:
            lines.append("No tip is predicted to save energy on this trip - already efficient driving.")
        else:
            lines.append("| # | Tip | Why it fired | Predicted Wh/km | Saving |")
            lines.append("|---|-----|--------------|-----------------|--------|")
            for i, t in enumerate(self.tips, 1):
                lines.append(
                    f"| {i} | **{t.title}** - {t.advice} | {t.trigger} | "
                    f"{t.counterfactual_wh_per_km:.1f} | {t.saving_pct:.1f} % |"
                )
        if self.combined is not None:
            lines.append("")
            lines.append(
                f"**All tips together:** {self.combined.counterfactual_wh_per_km:.1f} Wh/km "
                f"(-{self.combined.saving_pct:.1f} %, {self.combined.saving_wh_per_km:.1f} Wh/km saved)"
            )
        if self.not_applicable:
            lines.append("")
            lines.append("Not applicable to this trip: " + ", ".join(self.not_applicable))
        return "\n".join(lines)


# ----------------------------------------------------------------------------
# Counterfactual definitions
# ----------------------------------------------------------------------------
def _cf_smooth_accel(x: pd.Series) -> tuple[bool, str, dict]:
    ok = x["harsh_accel_per10km"] > 0.5 or x["mean_pos_accel_ms2"] > 0.7
    trig = f"{x['harsh_accel_per10km']:.1f} harsh accelerations / 10 km"
    ch = {
        "harsh_accel_per10km": 0.0,
        "mean_pos_accel_ms2": min(x["mean_pos_accel_ms2"], 0.6),
        "accel_std_ms2": x["accel_std_ms2"] * 0.75,
        "speed_std_kmh": x["speed_std_kmh"] * 0.92,
    }
    return ok, trig, ch


def _cf_gentle_braking(x: pd.Series) -> tuple[bool, str, dict]:
    ok = x["harsh_brake_per10km"] > 0.5
    trig = f"{x['harsh_brake_per10km']:.1f} harsh braking events / 10 km"
    ch = {
        "harsh_brake_per10km": 0.0,
        "accel_std_ms2": x["accel_std_ms2"] * 0.85,
        # gentler braking stays inside the regen envelope -> more recovery
        "regen_share": min(x["regen_share"] * 1.25, 0.8),
    }
    return ok, trig, ch


def _cf_cap_speed(x: pd.Series) -> tuple[bool, str, dict]:
    road = "highway" if x["road_highway"] else ("hilly" if x["road_hilly"] else "urban")
    cap = SPEED_CAP_KMH[road]
    ok = x["p95_speed_kmh"] > cap * 1.05
    ratio = cap / max(x["p95_speed_kmh"], 1e-6)
    trig = f"95th-pct speed {x['p95_speed_kmh']:.0f} km/h vs {cap:.0f} km/h cap ({road})"
    ch = {
        "p95_speed_kmh": cap,
        "mean_speed_kmh": x["mean_speed_kmh"] * (0.5 + 0.5 * ratio),
        "speed_std_kmh": x["speed_std_kmh"] * (0.6 + 0.4 * ratio),
    }
    return ok, trig, ch


def _cf_reduce_hvac(x: pd.Series) -> tuple[bool, str, dict]:
    ok = x["hvac_kw"] > 0.4
    trig = f"HVAC drawing {x['hvac_kw']:.1f} kW at {x['ambient_temp_c']:.0f} C"
    ch = {"hvac_kw": x["hvac_kw"] * 0.5}
    return ok, trig, ch


def _cf_reduce_idling(x: pd.Series) -> tuple[bool, str, dict]:
    ok = x["idle_share"] > 0.10
    trig = f"{x['idle_share']:.0%} of trip time stationary"
    removed = x["idle_share"] * 0.5
    ch = {
        "idle_share": x["idle_share"] - removed,
        # less time stopped -> mean speed rises for the same distance
        "mean_speed_kmh": x["mean_speed_kmh"] / max(1e-6, 1.0 - removed),
    }
    return ok, trig, ch


def _cf_lighten_load(x: pd.Series) -> tuple[bool, str, dict]:
    ok = x["payload_kg"] > 180
    trig = f"payload {x['payload_kg']:.0f} kg"
    ch = {"payload_kg": x["payload_kg"] - 60}
    return ok, trig, ch


TIP_LIBRARY = [
    ("smooth_accel", "Accelerate smoothly",
     "Ease onto the accelerator; aim for < 1.5 m/s^2 and let the car build speed gradually.",
     _cf_smooth_accel),
    ("gentle_braking", "Anticipate and brake gently",
     "Look further ahead, lift off early and let regenerative braking slow the car instead of the friction brakes.",
     _cf_gentle_braking),
    ("cap_speed", "Lower your cruising speed",
     "Aerodynamic drag grows with the square of speed - keep to the posted limit or slightly below.",
     _cf_cap_speed),
    ("reduce_hvac", "Use climate control sparingly",
     "Pre-condition the cabin while plugged in, use seat heating/ventilation and an eco climate mode.",
     _cf_reduce_hvac),
    ("reduce_idling", "Cut stationary time",
     "Plan routes to avoid congested junctions; power down or use the lowest climate setting when parked.",
     _cf_reduce_idling),
    ("lighten_load", "Remove unnecessary weight",
     "Every 60 kg of extra load costs energy on every acceleration and hill.",
     _cf_lighten_load),
]


class Recommender:
    """Wraps a fitted regression model (and optional style classifier)."""

    def __init__(self, regressor, classifier=None, min_saving_pct: float = 0.0):
        self.regressor = regressor
        self.classifier = classifier
        self.min_saving_pct = min_saving_pct

    def _predict(self, feats: pd.Series | dict) -> float:
        X = pd.DataFrame([feats])[FEATURE_COLUMNS]
        return float(self.regressor.predict(X)[0])

    def _style(self, feats: pd.Series):
        if self.classifier is None:
            return None, {}
        X = pd.DataFrame([feats])[BEHAVIOUR_FEATURES]
        probs = self.classifier.predict_proba(X)[0]
        classes = list(self.classifier.classes_)
        pred = classes[int(np.argmax(probs))]
        return pred, {c: float(p) for c, p in zip(classes, probs)}

    def recommend(self, trip: pd.Series, actual_wh_per_km: float | None = None) -> Recommendation:
        base_feats = trip[FEATURE_COLUMNS].astype(float)
        base_pred = self._predict(base_feats)
        style, probs = self._style(base_feats)

        tips, not_app, all_changes = [], [], {}
        for key, title, advice, fn in TIP_LIBRARY:
            ok, trig, changes = fn(base_feats)
            if not ok:
                not_app.append(title)
                continue
            cf = base_feats.copy()
            for k, v in changes.items():
                cf[k] = v
            cf_pred = self._predict(cf)
            saving = base_pred - cf_pred
            saving_pct = saving / base_pred * 100 if base_pred > 0 else 0.0
            if saving_pct < self.min_saving_pct:
                not_app.append(f"{title} (no predicted saving)")
                continue
            tips.append(Tip(key, title, advice, trig, base_pred, cf_pred, saving_pct, saving, changes))
            for k, v in changes.items():
                # combined scenario: keep the strongest edit per feature
                # (regen_share goes *up* with better driving, everything else goes down)
                if k not in all_changes:
                    all_changes[k] = v
                elif k == "regen_share":
                    all_changes[k] = max(all_changes[k], v)
                else:
                    all_changes[k] = min(all_changes[k], v)

        tips.sort(key=lambda t: t.saving_pct, reverse=True)

        combined = None
        if tips:
            cf = base_feats.copy()
            for k, v in all_changes.items():
                cf[k] = v
            cf_pred = self._predict(cf)
            saving = max(base_pred - cf_pred, max(t.saving_wh_per_km for t in tips))
            combined = Tip(
                "combined", "All tips together", "", "", base_pred, base_pred - saving,
                saving / base_pred * 100, saving, all_changes,
            )
        return Recommendation(
            trip_id=int(trip["trip_id"]), predicted_wh_per_km=base_pred,
            actual_wh_per_km=actual_wh_per_km, predicted_style=style,
            style_probabilities=probs, tips=tips, combined=combined, not_applicable=not_app,
        )

    def recommend_many(self, df: pd.DataFrame) -> list[Recommendation]:
        return [self.recommend(row, row.get("wh_per_km")) for _, row in df.iterrows()]


def savings_table(recs: list[Recommendation]) -> pd.DataFrame:
    """Long table of (trip, tip, saving) for plotting and aggregate statistics."""
    rows = []
    for r in recs:
        for t in r.tips:
            rows.append({
                "trip_id": r.trip_id, "tip": t.title, "key": t.key,
                "baseline_wh_per_km": t.baseline_wh_per_km,
                "counterfactual_wh_per_km": t.counterfactual_wh_per_km,
                "saving_pct": t.saving_pct, "saving_wh_per_km": t.saving_wh_per_km,
            })
    return pd.DataFrame(rows)
