"""AI-Powered Driving Efficiency Optimizer (Codec Technologies India EV internship, Sept 2026).

Author: Eswar Mahalingam

All driving data in this package is SYNTHETIC — produced by ``src.data_generator``
from a physics-based trip simulator. Nothing here comes from real vehicle telemetry.
"""

__version__ = "1.0.0"
__author__ = "Eswar Mahalingam"
