"""Per-trip feature engineering from 1 Hz driving traces.

The features are deliberately the kind of thing an OBD-II / CAN logger or a
smartphone app could compute on a real vehicle: they only need speed, time,
road gradient (from GPS altitude), cabin-climate state and ambient temperature.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as C

# Feature columns used by the regression / classification models. Kept in one
# place so every module (models, recommender, notebook) agrees on the order.
BEHAVIOUR_FEATURES = [
    "mean_speed_kmh",
    "p95_speed_kmh",
    "speed_std_kmh",
    "mean_pos_accel_ms2",
    "accel_std_ms2",
    "harsh_accel_per10km",
    "harsh_brake_per10km",
    "idle_share",
    "stops_per10km",
    "regen_share",
]
ENVIRONMENT_FEATURES = [
    "mean_abs_gradient_pct",
    "net_climb_m_per_km",
    "hvac_kw",
    "ambient_temp_c",
    "rain",
    "payload_kg",
    "road_urban",
    "road_highway",
    "road_hilly",
]
FEATURE_COLUMNS = BEHAVIOUR_FEATURES + ENVIRONMENT_FEATURES
TARGET = "wh_per_km"


def count_events(mask: np.ndarray, min_gap: int = C.EVENT_MIN_GAP_S) -> int:
    """Count separate events in a boolean mask, merging samples closer than ``min_gap``."""
    idx = np.flatnonzero(mask)
    if idx.size == 0:
        return 0
    gaps = np.diff(idx)
    return int(1 + np.sum(gaps > min_gap))


def trip_features(df: pd.DataFrame, meta, energy: dict) -> dict:
    """Compute the feature vector for one trip.

    Parameters
    ----------
    df : 1 Hz trace with columns speed_kmh, accel_ms2, grade (+ power columns)
    meta : TripMeta (driver_style, road_type, weather, HVAC ...)
    energy : summary dict from ``data_generator.energy_model``
    """
    v = df["speed_kmh"].to_numpy()
    a = df["accel_ms2"].to_numpy()
    g = df["grade"].to_numpy()
    dist_km = max(energy["distance_km"], 1e-3)
    moving = v > C.IDLE_SPEED_KMH

    # stops: transitions from moving to stopped
    stopped = ~moving
    n_stops = int(np.sum(stopped[1:] & ~stopped[:-1]))

    # energy recovered relative to energy spent on traction
    regen_share = energy["regen_wh"] / max(energy["traction_wh"], 1e-6)

    # net elevation gain per km: integrate grade * distance
    ds = df["speed_kmh"].to_numpy() / 3.6 * C.DT  # metres per sample
    net_climb_m = float(np.sum(g * ds))

    feats = {
        "trip_id": meta.trip_id,
        "driver_style": meta.driver_style,
        "road_type": meta.road_type,
        "duration_s": meta.duration_s,
        "distance_km": dist_km,
        # --- behaviour --------------------------------------------------
        "mean_speed_kmh": float(v.mean()),
        "p95_speed_kmh": float(np.percentile(v, 95)),
        "speed_std_kmh": float(v.std()),
        "mean_pos_accel_ms2": float(a[a > 0].mean()) if np.any(a > 0) else 0.0,
        "accel_std_ms2": float(a.std()),
        "harsh_accel_count": count_events(a > C.HARSH_ACCEL_MS2),
        "harsh_brake_count": count_events(a < C.HARSH_BRAKE_MS2),
        "idle_share": float(np.mean(~moving)),
        "n_stops": n_stops,
        "regen_share": float(regen_share),
        # --- environment ------------------------------------------------
        "mean_abs_gradient_pct": float(np.mean(np.abs(g)) * 100),
        "net_climb_m_per_km": net_climb_m / dist_km,
        "hvac_on": int(meta.hvac_on),
        "hvac_kw": float(meta.hvac_kw),
        "ambient_temp_c": float(meta.ambient_temp_c),
        "rain": int(meta.rain),
        "payload_kg": float(meta.payload_kg),
        "road_urban": int(meta.road_type == "urban"),
        "road_highway": int(meta.road_type == "highway"),
        "road_hilly": int(meta.road_type == "hilly"),
        # --- energy (target + breakdown) -----------------------------------
        "energy_wh": energy["energy_wh"],
        "traction_wh_per_km": energy["traction_wh"] / dist_km,
        "regen_wh_per_km": energy["regen_wh"] / dist_km,
        "friction_loss_wh_per_km": energy["friction_loss_wh"] / dist_km,
        "aux_wh_per_km": energy["aux_wh"] / dist_km,
        TARGET: energy["wh_per_km"],
    }
    feats["harsh_accel_per10km"] = feats["harsh_accel_count"] / dist_km * 10
    feats["harsh_brake_per10km"] = feats["harsh_brake_count"] / dist_km * 10
    feats["stops_per10km"] = n_stops / dist_km * 10
    return feats


def build_feature_table(metas, raw: dict, energies: dict) -> pd.DataFrame:
    """Build the trip-level dataset (one row per trip)."""
    rows = [trip_features(raw[m.trip_id], m, energies[m.trip_id]) for m in metas]
    df = pd.DataFrame(rows)
    # tidy column order: ids, labels, features, breakdown, target
    lead = ["trip_id", "driver_style", "road_type", "duration_s", "distance_km"]
    rest = [c for c in df.columns if c not in lead]
    return df[lead + rest]


def split_xy(df: pd.DataFrame):
    """Return (X, y) for the Wh/km regression."""
    return df[FEATURE_COLUMNS].copy(), df[TARGET].copy()
