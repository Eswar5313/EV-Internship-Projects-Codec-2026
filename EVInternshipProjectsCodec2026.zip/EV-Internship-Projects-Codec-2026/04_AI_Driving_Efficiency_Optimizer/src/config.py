"""Central configuration: simulator constants, driver archetypes, road types, paths.

Everything in this file describes a SIMULATED vehicle and SIMULATED drivers.
The numbers are plausible mid-size EV values (roughly a 1.6-1.8 t hatchback/SUV
with a ~110 kW motor), chosen from public engineering references (see README).
"""
from __future__ import annotations

from pathlib import Path

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"

# ----------------------------------------------------------------------------
# Reproducibility / dataset size
# ----------------------------------------------------------------------------
RANDOM_SEED = 42
N_TRIPS = 2000
SAMPLE_RATE_HZ = 1.0  # one sample per second
DT = 1.0 / SAMPLE_RATE_HZ

# ----------------------------------------------------------------------------
# Vehicle / physics constants (simulated mid-size EV)
# ----------------------------------------------------------------------------
VEHICLE = {
    "mass_kg": 1650.0,          # curb mass
    "rot_inertia_factor": 1.05,  # equivalent mass factor for rotating parts
    "crr": 0.010,               # rolling-resistance coefficient (dry, warm tyres)
    "cda_m2": 0.62,             # drag area Cd*A
    "motor_peak_kw": 110.0,     # peak motor power
    "eta_peak": 0.94,           # peak motor+inverter efficiency
    "eta_lowload_drop": 0.18,   # efficiency loss at very low load
    "eta_lowload_p0_kw": 6.0,   # low-load characteristic power
    "eta_highload_drop": 0.08,  # efficiency loss at peak load (I^2 R style)
    "regen_max_kw": 40.0,       # maximum regenerative braking power
    "regen_max_decel": 1.5,     # m/s^2 that regen alone can deliver
    "regen_fade_speed_ms": 3.0,  # below this speed regen fades to zero
    "eta_battery": 0.96,        # one-way battery/wiring efficiency
    "aux_base_kw": 0.25,        # always-on auxiliaries (12 V loads, electronics)
    "hvac_max_kw": 3.5,
}
G = 9.81
RHO_AIR_REF = 1.225  # kg/m^3 at 15 C

# ----------------------------------------------------------------------------
# Driver archetypes
# ----------------------------------------------------------------------------
# gain: how aggressively the driver closes the gap to the target speed (1/s)
# accel_max / decel_max: comfort limits (m/s^2)
# speed_factor: multiplier on the posted limit
# lookahead_s: how many seconds ahead the driver anticipates stops (coasting)
# jitter: random accelerator noise (m/s^2) - "pumping" the pedal
DRIVER_STYLES = {
    "eco": {
        "gain": 0.16, "accel_max": 1.2, "decel_max": 1.3, "speed_factor": 0.92,
        "lookahead_s": 14, "jitter": 0.10, "hvac_prob_scale": 0.7,
    },
    "normal": {
        "gain": 0.25, "accel_max": 1.8, "decel_max": 2.2, "speed_factor": 1.00,
        "lookahead_s": 6, "jitter": 0.25, "hvac_prob_scale": 1.0,
    },
    "aggressive": {
        "gain": 0.50, "accel_max": 3.2, "decel_max": 3.8, "speed_factor": 1.12,
        "lookahead_s": 2, "jitter": 0.55, "hvac_prob_scale": 1.2,
    },
}
DRIVER_STYLE_PROBS = {"eco": 0.32, "normal": 0.40, "aggressive": 0.28}
# log-normal sigma applied per trip to gain / accel / decel / jitter / look-ahead
DRIVER_VARIABILITY = 0.25

# ----------------------------------------------------------------------------
# Road types
# ----------------------------------------------------------------------------
# limits are km/h; stop_rate is stops per second (Poisson); grade_amp is the
# typical gradient amplitude (fraction, 0.05 = 5 %).
ROAD_TYPES = {
    "urban": {
        "limits_kmh": [30, 40, 50, 60], "duration_s": (600, 1500),
        "stop_rate": 1 / 110.0, "slowdown_rate": 1 / 300.0,
        "grade_amp": 0.02, "grade_wavelength_s": (60, 200),
    },
    "highway": {
        "limits_kmh": [80, 100, 110, 120], "duration_s": (900, 2400),
        "stop_rate": 1 / 1500.0, "slowdown_rate": 1 / 600.0,
        "grade_amp": 0.025, "grade_wavelength_s": (120, 400),
    },
    "hilly": {
        "limits_kmh": [50, 60, 70, 80], "duration_s": (900, 1800),
        "stop_rate": 1 / 450.0, "slowdown_rate": 1 / 400.0,
        "grade_amp": 0.06, "grade_wavelength_s": (90, 300),
    },
}
ROAD_TYPE_PROBS = {"urban": 0.45, "highway": 0.30, "hilly": 0.25}

# ----------------------------------------------------------------------------
# Weather
# ----------------------------------------------------------------------------
AMBIENT_TEMP_MEAN_C = 27.0   # Indian climate mix (hot summers, cool winter mornings)
AMBIENT_TEMP_STD_C = 7.0
RAIN_PROB = 0.18
HVAC_COMFORT_C = 22.0

# ----------------------------------------------------------------------------
# Feature engineering thresholds
# ----------------------------------------------------------------------------
HARSH_ACCEL_MS2 = 1.5      # > this = harsh acceleration event
HARSH_BRAKE_MS2 = -2.0     # < this = harsh braking event
IDLE_SPEED_KMH = 1.0       # below this = idling / stopped
EVENT_MIN_GAP_S = 3        # merge consecutive samples into one event

# ----------------------------------------------------------------------------
# Modelling
# ----------------------------------------------------------------------------
TEST_SIZE = 0.2
CV_FOLDS = 5
