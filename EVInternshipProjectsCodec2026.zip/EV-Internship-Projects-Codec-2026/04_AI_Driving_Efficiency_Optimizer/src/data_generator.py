"""SYNTHETIC driving-data simulator.

*** IMPORTANT: every trip produced here is SIMULATED. ***
No real vehicle, driver, or telemetry was used. The generator exists so the ML
pipeline can be developed and tested end-to-end without access to a fleet.

Each trip is built in three layers:

1. **Route / environment layer** - road type (urban / highway / hilly) sets the
   posted speed limits, stop frequency and the terrain gradient profile
   (a sum of random sinusoids). Weather sets ambient temperature, rain
   (higher rolling resistance) and the HVAC load.
2. **Driver layer** - a driver archetype (eco / normal / aggressive) turns the
   target-speed profile into an actual 1 Hz speed trace using a simple
   proportional speed-tracking controller with archetype-specific gain,
   acceleration/braking limits, stop anticipation (look-ahead coasting) and
   pedal jitter.
3. **Energy layer** - a longitudinal vehicle model integrates the tractive
   power needed for the speed/gradient trace:

       F_trac = m_eq * a + m g Crr cos(theta) + 0.5 rho CdA v^2 + m g sin(theta)
       P_wheel = F_trac * v

   Positive wheel power is divided by a motor/inverter efficiency map;
   negative wheel power is recovered through regenerative braking subject to
   power and deceleration limits (the remainder goes to friction brakes and is
   lost). Auxiliary + HVAC loads are added, battery losses applied, and the
   result is integrated to Wh and divided by distance -> Wh/km.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import config as C

KMH = 1 / 3.6  # km/h -> m/s


# ----------------------------------------------------------------------------
# Energy model
# ----------------------------------------------------------------------------
def motor_efficiency(p_abs_w: np.ndarray) -> np.ndarray:
    """Approximate motor + inverter efficiency as a function of |power| (W).

    Efficiency is poor at very low load (fixed losses dominate), peaks around
    20-60 % load and drops slightly at peak power (I^2 R losses)::

        eta(P) = eta_peak - d_low * exp(-|P| / P0) - d_high * (|P| / P_max)^2
    """
    v = C.VEHICLE
    p_kw = np.asarray(p_abs_w, dtype=float) / 1000.0
    eta = (
        v["eta_peak"]
        - v["eta_lowload_drop"] * np.exp(-p_kw / v["eta_lowload_p0_kw"])
        - v["eta_highload_drop"] * (p_kw / v["motor_peak_kw"]) ** 2
    )
    return np.clip(eta, 0.55, 0.96)


def air_density(temp_c: float) -> float:
    """Ideal-gas scaling of air density with temperature."""
    return C.RHO_AIR_REF * (288.15 / (temp_c + 273.15))


def rolling_coefficient(temp_c: float, rain: bool) -> float:
    """Rolling resistance rises on wet roads and with cold tyres."""
    crr = C.VEHICLE["crr"]
    if rain:
        crr *= 1.15
    if temp_c < 20:
        crr *= 1.0 + 0.004 * (20 - temp_c)  # cold tyres / stiffer rubber
    return crr


def hvac_power_kw(temp_c: float, hvac_on: bool, rng: np.random.Generator | None = None) -> float:
    """HVAC load grows with the gap between ambient and comfort temperature.

    Heating (cold ambient) is penalised more than cooling because a resistive
    heater is assumed (no heat pump).
    """
    if not hvac_on:
        return 0.0
    delta = abs(temp_c - C.HVAC_COMFORT_C)
    p = 0.30 + 0.10 * delta
    if temp_c < 15:
        p *= 1.3
    if rng is not None:
        p *= rng.uniform(0.85, 1.15)
    return float(min(p, C.VEHICLE["hvac_max_kw"]))


def energy_model(
    v_ms: np.ndarray,
    grade: np.ndarray,
    payload_kg: float = 100.0,
    temp_c: float = 25.0,
    rain: bool = False,
    hvac_kw: float = 0.0,
    dt: float = C.DT,
) -> dict:
    """Integrate the longitudinal energy model along a speed/gradient trace.

    Parameters
    ----------
    v_ms : speed trace [m/s]
    grade : road gradient as a fraction (rise/run) for every sample
    payload_kg, temp_c, rain, hvac_kw : trip-level conditions

    Returns a dict with per-sample battery power [W] and trip totals.
    """
    veh = C.VEHICLE
    m = veh["mass_kg"] + payload_kg
    m_eq = m * veh["rot_inertia_factor"]
    crr = rolling_coefficient(temp_c, rain)
    rho = air_density(temp_c)
    theta = np.arctan(grade)

    a = np.gradient(v_ms, dt)
    f_roll = m * C.G * crr * np.cos(theta) * (v_ms > 0.05)
    f_aero = 0.5 * rho * veh["cda_m2"] * v_ms**2
    f_grade = m * C.G * np.sin(theta)
    f_inertia = m_eq * a
    f_trac = f_inertia + f_roll + f_aero + f_grade
    p_wheel = f_trac * v_ms  # W, positive = traction, negative = braking

    # --- traction ---------------------------------------------------------
    p_trac = np.clip(p_wheel, 0, None)
    p_trac = np.minimum(p_trac, veh["motor_peak_kw"] * 1000)  # motor limit
    eta_m = motor_efficiency(p_trac)
    p_batt_trac = p_trac / eta_m / veh["eta_battery"]

    # --- regenerative braking ---------------------------------------------
    p_brake = np.clip(-p_wheel, 0, None)  # positive = power that must be dissipated
    regen_force_cap = m * veh["regen_max_decel"]           # N
    regen_power_cap = veh["regen_max_kw"] * 1000           # W
    fade = np.clip(v_ms / veh["regen_fade_speed_ms"], 0, 1)  # regen fades at crawl speed
    if temp_c < 5:  # cold battery accepts less charge
        fade = fade * 0.5
    p_regen_avail = np.minimum(p_brake, regen_force_cap * v_ms)
    p_regen_avail = np.minimum(p_regen_avail, regen_power_cap) * fade
    p_friction = p_brake - p_regen_avail                    # lost as heat
    p_batt_regen = p_regen_avail * motor_efficiency(p_regen_avail) * veh["eta_battery"]

    # --- auxiliaries --------------------------------------------------------
    p_aux = (veh["aux_base_kw"] + hvac_kw) * 1000.0 * np.ones_like(v_ms)

    p_batt = p_batt_trac - p_batt_regen + p_aux

    e_wh = float(np.sum(p_batt) * dt / 3600.0)
    dist_km = float(np.sum(v_ms) * dt / 1000.0)
    return {
        "p_batt_w": p_batt,
        "p_trac_batt_w": p_batt_trac,
        "p_regen_batt_w": p_batt_regen,
        "p_friction_w": p_friction,
        "p_aux_w": p_aux,
        "energy_wh": e_wh,
        "traction_wh": float(np.sum(p_batt_trac) * dt / 3600.0),
        "regen_wh": float(np.sum(p_batt_regen) * dt / 3600.0),
        "friction_loss_wh": float(np.sum(p_friction) * dt / 3600.0),
        "aux_wh": float(np.sum(p_aux) * dt / 3600.0),
        "distance_km": dist_km,
        "wh_per_km": e_wh / max(dist_km, 1e-6),
    }


def steady_state_wh_per_km(speeds_kmh: np.ndarray, grade: float = 0.0, **kw) -> np.ndarray:
    """Energy intensity at constant speed on a constant grade (for the energy-vs-speed curve)."""
    out = []
    for s in speeds_kmh:
        v = np.full(600, s * KMH)
        g = np.full(600, grade)
        out.append(energy_model(v, g, **kw)["wh_per_km"])
    return np.array(out)


# ----------------------------------------------------------------------------
# Route + driver simulation
# ----------------------------------------------------------------------------
@dataclass
class TripMeta:
    trip_id: int
    driver_style: str
    road_type: str
    duration_s: int
    ambient_temp_c: float
    rain: bool
    hvac_on: bool
    hvac_kw: float
    payload_kg: float
    extra: dict = field(default_factory=dict)


def _gradient_profile(n: int, road: dict, rng: np.random.Generator) -> np.ndarray:
    """Terrain gradient as a sum of 3 random sinusoids plus slow drift."""
    t = np.arange(n)
    grade = np.zeros(n)
    for k in range(3):
        wl = rng.uniform(*road["grade_wavelength_s"])
        amp = road["grade_amp"] * rng.uniform(0.3, 1.0) / (k + 1)
        grade += amp * np.sin(2 * np.pi * t / wl + rng.uniform(0, 2 * np.pi))
    grade += road["grade_amp"] * 0.08 * rng.normal()  # net uphill / downhill bias
    return np.clip(grade, -0.12, 0.12)


def _target_speed_profile(n: int, road: dict, style: dict, rng: np.random.Generator) -> np.ndarray:
    """Posted-limit segments with the driver's speed preference, stops and slowdowns."""
    target = np.zeros(n)
    t = 0
    while t < n:
        seg = int(rng.integers(60, 300))
        limit = rng.choice(road["limits_kmh"])
        pref = limit * style["speed_factor"] * rng.normal(1.0, 0.04)
        target[t:t + seg] = pref
        t += seg

    # traffic stops (signals, junctions)
    n_stops = rng.poisson(road["stop_rate"] * n)
    for s in rng.integers(30, max(31, n - 30), size=n_stops):
        dwell = int(rng.integers(5, 60))
        target[s:s + dwell] = 0.0
    # slow-moving traffic
    n_slow = rng.poisson(road["slowdown_rate"] * n)
    for s in rng.integers(0, n, size=n_slow):
        dur = int(rng.integers(20, 120))
        target[s:s + dur] = np.minimum(target[s:s + dur], rng.uniform(10, 30))
    target[:5] = 0.0     # trip starts from rest
    target[-8:] = 0.0    # and ends at rest
    return target * KMH  # m/s


def _drive(target_ms: np.ndarray, style: dict, rng: np.random.Generator) -> np.ndarray:
    """Turn a target-speed profile into a realised 1 Hz speed trace.

    A proportional controller with archetype-specific gain and comfort limits.
    Eco drivers 'see' stops further ahead (min-filter look-ahead) and hence
    coast instead of braking hard.
    """
    n = len(target_ms)
    la = int(style["lookahead_s"])
    # look-ahead: the driver aims for the lowest target in the next `la` seconds
    if la > 1:
        padded = np.concatenate([target_ms, np.full(la, target_ms[-1])])
        windows = np.lib.stride_tricks.sliding_window_view(padded, la + 1)
        anticipated = windows.min(axis=1)[:n]
    else:
        anticipated = target_ms
    jitter = rng.normal(0.0, style["jitter"], size=n)
    gain, a_max, d_max = style["gain"], style["accel_max"], style["decel_max"]

    v = np.zeros(n)
    for i in range(1, n):
        a_cmd = gain * (anticipated[i] - v[i - 1]) + jitter[i]
        a_cmd = min(a_max, max(-d_max, a_cmd))
        v[i] = max(0.0, v[i - 1] + a_cmd * C.DT)
    return v


def _personalise(style: dict, rng: np.random.Generator) -> dict:
    """Every driver is an individual: perturb the archetype parameters per trip.

    Without this, the three archetypes would be perfectly separable and the
    driver-style classifier would be trivially 100 % accurate.
    """
    s = dict(style)
    for k in ("gain", "accel_max", "decel_max", "jitter"):
        s[k] = style[k] * float(rng.lognormal(0.0, C.DRIVER_VARIABILITY))
    s["speed_factor"] = style["speed_factor"] * float(rng.normal(1.0, 0.04))
    s["lookahead_s"] = max(1, int(round(style["lookahead_s"] * rng.lognormal(0.0, C.DRIVER_VARIABILITY))))
    return s


def simulate_trip(trip_id: int, rng: np.random.Generator) -> tuple[TripMeta, pd.DataFrame, dict]:
    """Simulate one trip. Returns (metadata, 1 Hz dataframe, energy summary)."""
    style_name = rng.choice(list(C.DRIVER_STYLE_PROBS), p=list(C.DRIVER_STYLE_PROBS.values()))
    road_name = rng.choice(list(C.ROAD_TYPE_PROBS), p=list(C.ROAD_TYPE_PROBS.values()))
    style, road = _personalise(C.DRIVER_STYLES[style_name], rng), C.ROAD_TYPES[road_name]

    n = int(rng.integers(*road["duration_s"]))
    temp = float(rng.normal(C.AMBIENT_TEMP_MEAN_C, C.AMBIENT_TEMP_STD_C))
    rain = bool(rng.random() < C.RAIN_PROB)
    # HVAC is more likely the further ambient is from comfort
    p_hvac = min(0.95, 0.15 + 0.06 * abs(temp - C.HVAC_COMFORT_C)) * style["hvac_prob_scale"]
    hvac_on = bool(rng.random() < p_hvac)
    hvac_kw = hvac_power_kw(temp, hvac_on, rng)
    payload = float(rng.uniform(70, 320))

    grade = _gradient_profile(n, road, rng)
    target = _target_speed_profile(n, road, style, rng)
    v = _drive(target, style, rng)
    energy = energy_model(v, grade, payload_kg=payload, temp_c=temp, rain=rain, hvac_kw=hvac_kw)

    df = pd.DataFrame({
        "trip_id": trip_id,
        "t_s": np.arange(n),
        "speed_kmh": v / KMH,
        "accel_ms2": np.gradient(v, C.DT),
        "grade": grade,
        "target_speed_kmh": target / KMH,
        "battery_power_kw": energy["p_batt_w"] / 1000.0,
        "regen_power_kw": energy["p_regen_batt_w"] / 1000.0,
        "friction_brake_kw": energy["p_friction_w"] / 1000.0,
    })
    meta = TripMeta(
        trip_id=trip_id, driver_style=style_name, road_type=road_name, duration_s=n,
        ambient_temp_c=temp, rain=rain, hvac_on=hvac_on, hvac_kw=hvac_kw, payload_kg=payload,
    )
    return meta, df, energy


def generate_dataset(n_trips: int = C.N_TRIPS, seed: int = C.RANDOM_SEED, verbose: bool = True):
    """Generate ``n_trips`` synthetic trips.

    Returns
    -------
    metas : list[TripMeta]
    raw   : dict[trip_id -> 1 Hz DataFrame]
    energies : dict[trip_id -> energy summary dict]
    """
    rng = np.random.default_rng(seed)
    metas, raw, energies = [], {}, {}
    for i in range(n_trips):
        meta, df, en = simulate_trip(i, rng)
        metas.append(meta)
        raw[i] = df
        energies[i] = en
        if verbose and (i + 1) % 500 == 0:
            print(f"  simulated {i + 1}/{n_trips} trips")
    return metas, raw, energies


if __name__ == "__main__":  # quick smoke run
    metas, raw, en = generate_dataset(20, verbose=False)
    for m in metas[:5]:
        print(m.driver_style, m.road_type, f"{en[m.trip_id]['wh_per_km']:.1f} Wh/km")
