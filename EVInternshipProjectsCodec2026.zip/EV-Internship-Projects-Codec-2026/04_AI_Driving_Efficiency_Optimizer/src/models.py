"""Scikit-learn models: Wh/km regression, driver-style classification, importances."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.inspection import permutation_importance
from sklearn.linear_model import Ridge
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    mean_absolute_percentage_error,
    r2_score,
    root_mean_squared_error,
)
from sklearn.model_selection import KFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import config as C
from .features import BEHAVIOUR_FEATURES, ENVIRONMENT_FEATURES, FEATURE_COLUMNS, TARGET


def make_regressors(seed: int = C.RANDOM_SEED) -> dict[str, object]:
    """The three regression candidates compared in this project."""
    return {
        "Ridge (baseline)": Pipeline([
            ("scale", StandardScaler()),
            ("model", Ridge(alpha=1.0)),
        ]),
        "RandomForest": RandomForestRegressor(
            n_estimators=300, min_samples_leaf=2, n_jobs=-1, random_state=seed
        ),
        "GradientBoosting": GradientBoostingRegressor(
            n_estimators=400, learning_rate=0.05, max_depth=3, subsample=0.8,
            random_state=seed,
        ),
    }


def split_data(df: pd.DataFrame, seed: int = C.RANDOM_SEED):
    """Stratified (by driver style) train/test split of the trip table."""
    train_df, test_df = train_test_split(
        df, test_size=C.TEST_SIZE, random_state=seed, stratify=df["driver_style"]
    )
    return train_df.reset_index(drop=True), test_df.reset_index(drop=True)


def regression_metrics(y_true, y_pred) -> dict:
    return {
        "r2": float(r2_score(y_true, y_pred)),
        "mae_wh_per_km": float(mean_absolute_error(y_true, y_pred)),
        "rmse_wh_per_km": float(root_mean_squared_error(y_true, y_pred)),
        "mape_pct": float(mean_absolute_percentage_error(y_true, y_pred) * 100),
    }


def compare_regressors(train_df: pd.DataFrame, test_df: pd.DataFrame, seed: int = C.RANDOM_SEED):
    """K-fold CV on the training set + evaluation on the held-out test set.

    Returns (comparison DataFrame, dict of fitted models, name of best model).
    """
    X_tr, y_tr = train_df[FEATURE_COLUMNS], train_df[TARGET]
    X_te, y_te = test_df[FEATURE_COLUMNS], test_df[TARGET]
    cv = KFold(n_splits=C.CV_FOLDS, shuffle=True, random_state=seed)

    rows, fitted = [], {}
    for name, model in make_regressors(seed).items():
        cvres = cross_validate(
            model, X_tr, y_tr, cv=cv,
            scoring={"r2": "r2", "mae": "neg_mean_absolute_error"},
            n_jobs=1,
        )
        model.fit(X_tr, y_tr)
        fitted[name] = model
        test = regression_metrics(y_te, model.predict(X_te))
        rows.append({
            "model": name,
            "cv_r2_mean": cvres["test_r2"].mean(),
            "cv_r2_std": cvres["test_r2"].std(),
            "cv_mae_mean": -cvres["test_mae"].mean(),
            "test_r2": test["r2"],
            "test_mae_wh_per_km": test["mae_wh_per_km"],
            "test_rmse_wh_per_km": test["rmse_wh_per_km"],
            "test_mape_pct": test["mape_pct"],
        })
    comparison = pd.DataFrame(rows).sort_values("test_r2", ascending=False).reset_index(drop=True)
    best_name = comparison.iloc[0]["model"]
    return comparison, fitted, best_name


def feature_importance(model, test_df: pd.DataFrame, seed: int = C.RANDOM_SEED, n_repeats: int = 10) -> pd.DataFrame:
    """Permutation importance (drop in R^2 when a feature is shuffled) on held-out data."""
    res = permutation_importance(
        model, test_df[FEATURE_COLUMNS], test_df[TARGET],
        n_repeats=n_repeats, random_state=seed, scoring="r2", n_jobs=1,
    )
    imp = pd.DataFrame({
        "feature": FEATURE_COLUMNS,
        "importance_mean": res.importances_mean,
        "importance_std": res.importances_std,
        "group": ["behaviour" if f in BEHAVIOUR_FEATURES else "environment" for f in FEATURE_COLUMNS],
    })
    return imp.sort_values("importance_mean", ascending=False).reset_index(drop=True)


# ----------------------------------------------------------------------------
# Driver-style classification
# ----------------------------------------------------------------------------
STYLE_ORDER = ["eco", "normal", "aggressive"]


def train_style_classifier(train_df: pd.DataFrame, test_df: pd.DataFrame, seed: int = C.RANDOM_SEED):
    """Classify eco / normal / aggressive from behaviour features only.

    The environment features (gradient, weather, road type) are deliberately
    excluded so the classifier learns *how* someone drives, not *where*.
    """
    feats = BEHAVIOUR_FEATURES
    clf = RandomForestClassifier(
        n_estimators=300, min_samples_leaf=2, class_weight="balanced",
        n_jobs=-1, random_state=seed,
    )
    clf.fit(train_df[feats], train_df["driver_style"])
    pred = clf.predict(test_df[feats])
    metrics = {
        "accuracy": float(accuracy_score(test_df["driver_style"], pred)),
        "macro_f1": float(f1_score(test_df["driver_style"], pred, average="macro")),
        "confusion_matrix": confusion_matrix(test_df["driver_style"], pred, labels=STYLE_ORDER).tolist(),
        "labels": STYLE_ORDER,
        "report": classification_report(test_df["driver_style"], pred, labels=STYLE_ORDER, output_dict=True),
        "features": feats,
    }
    return clf, metrics
