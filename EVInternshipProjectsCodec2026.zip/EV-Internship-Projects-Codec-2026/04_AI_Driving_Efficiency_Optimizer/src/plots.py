"""Matplotlib figures for the results folder. All functions save a PNG and return its path."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from . import config as C  # noqa: E402
from .data_generator import steady_state_wh_per_km  # noqa: E402
from .models import STYLE_ORDER  # noqa: E402

STYLE_COLORS = {"eco": "#2a9d8f", "normal": "#457b9d", "aggressive": "#e76f51"}
ROAD_ORDER = ["urban", "highway", "hilly"]
plt.rcParams.update({"figure.dpi": 110, "axes.grid": True, "grid.alpha": 0.3, "font.size": 10})
SYNTH_NOTE = "Synthetic (simulated) data - not real telemetry"


def _finish(fig, path: Path) -> Path:
    fig.text(0.99, 0.01, SYNTH_NOTE, ha="right", va="bottom", fontsize=7, color="grey")
    fig.tight_layout(rect=(0, 0.02, 1, 1))
    fig.savefig(path)
    plt.close(fig)
    return path


def plot_pred_vs_actual(test_df: pd.DataFrame, preds: dict[str, np.ndarray], out: Path) -> Path:
    n = len(preds)
    fig, axes = plt.subplots(1, n, figsize=(4.6 * n, 4.4), squeeze=False)
    y = test_df["wh_per_km"].to_numpy()
    lo, hi = y.min() * 0.95, y.max() * 1.05
    for ax, (name, p) in zip(axes[0], preds.items()):
        for s in STYLE_ORDER:
            m = (test_df["driver_style"] == s).to_numpy()
            ax.scatter(y[m], p[m], s=12, alpha=0.6, color=STYLE_COLORS[s], label=s)
        ax.plot([lo, hi], [lo, hi], "k--", lw=1)
        r2 = 1 - np.sum((y - p) ** 2) / np.sum((y - y.mean()) ** 2)
        mae = np.mean(np.abs(y - p))
        ax.set_title(f"{name}\nR² = {r2:.3f}, MAE = {mae:.1f} Wh/km")
        ax.set_xlabel("Actual Wh/km (simulator)")
        ax.set_ylabel("Predicted Wh/km")
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
    axes[0][0].legend(title="driver style", loc="upper left")
    fig.suptitle("Held-out test set: predicted vs actual energy consumption")
    return _finish(fig, out)


def plot_feature_importance(imp: pd.DataFrame, out: Path, top: int = 15) -> Path:
    d = imp.head(top).iloc[::-1]
    colors = ["#e76f51" if g == "behaviour" else "#457b9d" for g in d["group"]]
    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    ax.barh(d["feature"], d["importance_mean"], xerr=d["importance_std"], color=colors, alpha=0.9)
    ax.set_xlabel("Permutation importance (drop in test R² when shuffled)")
    ax.set_title("What drives Wh/km? (best regression model)")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color="#e76f51", label="driver behaviour"),
                       Patch(color="#457b9d", label="environment / vehicle")], loc="lower right")
    return _finish(fig, out)


def plot_energy_by_group(df: pd.DataFrame, out: Path) -> Path:
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    # by driver style
    data = [df.loc[df["driver_style"] == s, "wh_per_km"] for s in STYLE_ORDER]
    bp = axes[0].boxplot(data, tick_labels=STYLE_ORDER, patch_artist=True, showfliers=False)
    for patch, s in zip(bp["boxes"], STYLE_ORDER):
        patch.set_facecolor(STYLE_COLORS[s])
        patch.set_alpha(0.7)
    for i, d in enumerate(data, 1):
        axes[0].text(i, d.median(), f"{d.mean():.0f}", ha="center", va="bottom", fontsize=9, weight="bold")
    axes[0].set_ylabel("Wh/km")
    axes[0].set_title("Energy use by driver style (labels = mean)")
    # by road type x style
    width = 0.25
    x = np.arange(len(ROAD_ORDER))
    for i, s in enumerate(STYLE_ORDER):
        means = [df[(df.road_type == r) & (df.driver_style == s)]["wh_per_km"].mean() for r in ROAD_ORDER]
        stds = [df[(df.road_type == r) & (df.driver_style == s)]["wh_per_km"].std() for r in ROAD_ORDER]
        axes[1].bar(x + (i - 1) * width, means, width, yerr=stds, capsize=3,
                    color=STYLE_COLORS[s], alpha=0.85, label=s)
    axes[1].set_xticks(x, ROAD_ORDER)
    axes[1].set_ylabel("Mean Wh/km (± 1 SD)")
    axes[1].set_title("Energy use by road type and driver style")
    axes[1].legend()
    return _finish(fig, out)


def plot_energy_vs_speed(df: pd.DataFrame, out: Path) -> Path:
    speeds = np.arange(10, 131, 5)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    ax = axes[0]
    for grade, ls, lab in [(0.0, "-", "flat road"), (0.02, "--", "2 % uphill"), (-0.02, ":", "2 % downhill")]:
        ax.plot(speeds, steady_state_wh_per_km(speeds, grade=grade, hvac_kw=0.0), ls, color="#264653", label=lab)
    ax.plot(speeds, steady_state_wh_per_km(speeds, grade=0.0, hvac_kw=2.0), "-", color="#e76f51",
            label="flat road + 2 kW HVAC")
    ax.set_xlabel("Constant speed (km/h)")
    ax.set_ylabel("Wh/km")
    ax.set_title("Physics model: steady-state energy vs speed")
    ax.axhline(0, color="k", lw=0.6)
    ax.legend()
    ax = axes[1]
    for s in STYLE_ORDER:
        d = df[df.driver_style == s]
        ax.scatter(d["mean_speed_kmh"], d["wh_per_km"], s=9, alpha=0.5, color=STYLE_COLORS[s], label=s)
    ax.set_xlabel("Trip mean speed (km/h)")
    ax.set_ylabel("Trip Wh/km")
    ax.set_title("Simulated trips: mean speed vs energy use")
    ax.legend(title="driver style")
    return _finish(fig, out)


def plot_counterfactual_savings(savings: pd.DataFrame, out: Path) -> Path:
    """Mean predicted saving per tip across all trips where the tip applied."""
    agg = (savings.groupby("tip")
           .agg(mean_pct=("saving_pct", "mean"), n=("trip_id", "nunique"),
                mean_wh=("saving_wh_per_km", "mean"))
           .sort_values("mean_pct"))
    fig, ax = plt.subplots(figsize=(8, 4.8))
    bars = ax.barh(agg.index, agg["mean_pct"], color="#2a9d8f", alpha=0.9)
    for b, (_, row) in zip(bars, agg.iterrows()):
        ax.text(b.get_width() + 0.15, b.get_y() + b.get_height() / 2,
                f"{row.mean_pct:.1f} % ({row.mean_wh:.0f} Wh/km, n={int(row.n)})", va="center", fontsize=9)
    ax.set_xlabel("Mean predicted saving (%) on trips where the tip applies")
    ax.set_title("Counterfactual savings per driving tip (model re-prediction)")
    ax.set_xlim(0, agg["mean_pct"].max() * 1.45)
    return _finish(fig, out)


def plot_example_trip(raw: pd.DataFrame, meta, out: Path) -> Path:
    fig, axes = plt.subplots(3, 1, figsize=(10, 7), sharex=True)
    t = raw["t_s"] / 60
    axes[0].plot(t, raw["speed_kmh"], color="#264653", lw=1, label="speed")
    axes[0].plot(t, raw["target_speed_kmh"], color="grey", lw=0.8, ls="--", label="target speed")
    axes[0].set_ylabel("km/h")
    axes[0].legend(loc="upper right")
    axes[1].plot(t, raw["grade"] * 100, color="#8d6a9f", lw=1)
    axes[1].set_ylabel("gradient %")
    axes[2].plot(t, raw["battery_power_kw"], color="#e76f51", lw=0.8, label="battery power")
    axes[2].plot(t, -raw["regen_power_kw"], color="#2a9d8f", lw=0.8, label="regen")
    axes[2].plot(t, -raw["friction_brake_kw"], color="#6c757d", lw=0.8, label="friction brake (lost)")
    axes[2].axhline(0, color="k", lw=0.5)
    axes[2].set_ylabel("kW")
    axes[2].set_xlabel("time (min)")
    axes[2].legend(loc="upper right", ncol=3)
    fig.suptitle(f"Example simulated trip {meta.trip_id}: {meta.driver_style} driver, {meta.road_type} road, "
                 f"{meta.ambient_temp_c:.0f} C, HVAC {meta.hvac_kw:.1f} kW")
    return _finish(fig, out)


def plot_confusion(cm: list[list[int]], labels: list[str], out: Path) -> Path:
    cm = np.array(cm)
    fig, ax = plt.subplots(figsize=(4.8, 4.2))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(labels)), labels)
    ax.set_yticks(range(len(labels)), labels)
    ax.set_xlabel("Predicted style")
    ax.set_ylabel("True style")
    ax.set_title("Driver-style classifier (held-out)")
    ax.grid(False)
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im, ax=ax, fraction=0.046)
    return _finish(fig, out)
