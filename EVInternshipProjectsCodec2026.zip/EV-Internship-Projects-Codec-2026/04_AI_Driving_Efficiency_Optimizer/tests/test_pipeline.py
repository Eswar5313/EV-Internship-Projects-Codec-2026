"""Pytest suite for the AI Driving Efficiency Optimizer.

Uses a small synthetic dataset (400 trips) built once per session so the whole
suite runs in well under a minute.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import config as C  # noqa: E402
from src.data_generator import KMH, energy_model, generate_dataset, motor_efficiency, steady_state_wh_per_km  # noqa: E402
from src.features import FEATURE_COLUMNS, TARGET, build_feature_table  # noqa: E402
from src.models import compare_regressors, split_data, train_style_classifier  # noqa: E402
from src.recommender import Recommender, savings_table  # noqa: E402


@pytest.fixture(scope="session")
def dataset():
    metas, raw, energies = generate_dataset(400, seed=7, verbose=False)
    trips = build_feature_table(metas, raw, energies)
    return metas, raw, energies, trips


@pytest.fixture(scope="session")
def trained(dataset):
    _, _, _, trips = dataset
    train_df, test_df = split_data(trips, seed=7)
    comparison, fitted, best_name = compare_regressors(train_df, test_df, seed=7)
    clf, clf_metrics = train_style_classifier(train_df, test_df, seed=7)
    return train_df, test_df, comparison, fitted, best_name, clf, clf_metrics


# ----------------------------------------------------------------------------
# Physics / simulator
# ----------------------------------------------------------------------------
def test_motor_efficiency_range():
    eta = motor_efficiency(np.array([0.0, 2e3, 20e3, 60e3, 110e3]))
    assert np.all((eta >= 0.55) & (eta <= 0.96))
    assert eta[2] > eta[0]  # low load is less efficient than mid load


def test_steady_state_energy_rises_with_speed():
    wh = steady_state_wh_per_km(np.array([40, 80, 120]))
    assert wh[0] < wh[1] < wh[2]
    assert 50 < wh[0] < 150 and 120 < wh[2] < 260  # plausible mid-size EV numbers


def test_uphill_costs_more_than_flat():
    v = np.full(300, 60 * KMH)
    flat = energy_model(v, np.zeros(300))["wh_per_km"]
    up = energy_model(v, np.full(300, 0.03))["wh_per_km"]
    down = energy_model(v, np.full(300, -0.03))["wh_per_km"]
    assert up > flat > down


def test_regen_never_exceeds_braking_power():
    rng = np.random.default_rng(0)
    v = np.clip(np.cumsum(rng.normal(0, 0.8, 600)), 0, 35)
    res = energy_model(v, np.zeros(600))
    assert np.all(res["p_regen_batt_w"] >= 0)
    assert np.all(res["p_friction_w"] >= -1e-9)
    assert res["regen_wh"] <= res["traction_wh"]


def test_dataset_shape_and_energy_positive(dataset):
    metas, raw, energies, trips = dataset
    assert len(trips) == 400
    assert trips[TARGET].gt(0).all(), "every trip must consume net positive energy"
    assert trips["distance_km"].gt(0.5).all()
    assert trips["energy_wh"].gt(0).all()
    assert not trips[FEATURE_COLUMNS].isna().any().any()
    # 1 Hz traces: no negative speed, one row per second
    for m in metas[:20]:
        df = raw[m.trip_id]
        assert (df["speed_kmh"] >= 0).all()
        assert len(df) == m.duration_s


def test_aggressive_uses_more_energy_than_eco(dataset):
    *_, trips = dataset
    means = trips.groupby("driver_style")[TARGET].mean()
    assert means["aggressive"] > means["normal"] > means["eco"]
    assert means["aggressive"] > means["eco"] * 1.15
    harsh = trips.groupby("driver_style")["harsh_brake_per10km"].mean()
    assert harsh["aggressive"] > harsh["eco"]


def test_generation_is_reproducible():
    a = generate_dataset(5, seed=3, verbose=False)
    b = generate_dataset(5, seed=3, verbose=False)
    for i in range(5):
        pd.testing.assert_frame_equal(a[1][i], b[1][i])
        assert a[2][i]["wh_per_km"] == b[2][i]["wh_per_km"]


# ----------------------------------------------------------------------------
# Models
# ----------------------------------------------------------------------------
def test_best_model_r2_on_holdout(trained):
    _, _, comparison, _, best_name, _, _ = trained
    best = comparison.loc[comparison.model == best_name].iloc[0]
    assert best["test_r2"] > 0.8, comparison
    assert best["cv_r2_mean"] > 0.8


def test_tree_models_beat_linear_baseline(trained):
    _, _, comparison, _, _, _, _ = trained
    r2 = comparison.set_index("model")["test_r2"]
    assert max(r2["GradientBoosting"], r2["RandomForest"]) >= r2["Ridge (baseline)"] - 0.02


def test_style_classifier_accuracy(trained):
    *_, clf_metrics = trained
    assert clf_metrics["accuracy"] > 0.75
    cm = np.array(clf_metrics["confusion_matrix"])
    assert cm.sum() == 80  # 20 % of 400 trips


# ----------------------------------------------------------------------------
# Recommender
# ----------------------------------------------------------------------------
def test_recommender_savings_non_negative(trained):
    _, test_df, _, fitted, best_name, clf, _ = trained
    rec = Recommender(fitted[best_name], clf)
    recs = rec.recommend_many(test_df)
    tab = savings_table(recs)
    assert len(tab) > 0
    assert (tab["saving_pct"] >= 0).all()
    assert (tab["saving_wh_per_km"] >= 0).all()
    for r in recs:
        # tips are ranked by saving
        savings = [t.saving_pct for t in r.tips]
        assert savings == sorted(savings, reverse=True)
        if r.combined is not None:
            assert r.combined.saving_pct >= max(savings)
            assert r.combined.counterfactual_wh_per_km < r.predicted_wh_per_km


def test_recommender_targets_aggressive_drivers(trained):
    _, test_df, _, fitted, best_name, clf, _ = trained
    rec = Recommender(fitted[best_name], clf)
    recs = rec.recommend_many(test_df)
    comb = pd.Series(
        [r.combined.saving_pct if r.combined else 0.0 for r in recs], index=test_df.index
    )
    assert comb[test_df.driver_style == "aggressive"].mean() > comb[test_df.driver_style == "eco"].mean()


def test_recommendation_markdown(trained):
    _, test_df, _, fitted, best_name, clf, _ = trained
    rec = Recommender(fitted[best_name], clf)
    r = rec.recommend(test_df.iloc[0], test_df.iloc[0][TARGET])
    md = r.to_markdown()
    assert "Wh/km" in md and f"Trip {r.trip_id}" in md
