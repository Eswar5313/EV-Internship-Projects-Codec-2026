"""Generates notebook/analysis.ipynb (kept as a script so the notebook is reproducible).

    python notebook/build_notebook.py
    jupyter nbconvert --execute --to notebook --inplace notebook/analysis.ipynb
"""
from __future__ import annotations

from pathlib import Path

import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip()))


def code(s):
    cells.append(nbf.v4.new_code_cell(s.strip()))


md("""
# AI-Powered Driving Efficiency Optimizer - analysis notebook

**Eswar Mahalingam - Codec Technologies India EV internship, September 2026**

> **All data in this notebook is SYNTHETIC.** It is produced by the physics-based trip simulator in
> `src/data_generator.py`; no real vehicle telemetry was used. See the README for the model equations.

This notebook walks through the pipeline interactively:

1. simulate a handful of trips and look at the raw 1 Hz traces,
2. load the trip-level dataset written by `python main.py`,
3. explore how driving behaviour and environment affect Wh/km,
4. train the Wh/km regressor and the driver-style classifier,
5. generate counterfactual driving tips for an example trip.
""")

code("""
import sys, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd().resolve()
if not (ROOT / "src").exists():
    ROOT = ROOT.parent
sys.path.insert(0, str(ROOT))

from src import config as C
from src.data_generator import generate_dataset, steady_state_wh_per_km, motor_efficiency
from src.features import build_feature_table, FEATURE_COLUMNS, BEHAVIOUR_FEATURES, TARGET
from src.models import split_data, compare_regressors, feature_importance, train_style_classifier
from src.recommender import Recommender, savings_table

RESULTS = ROOT / "results"
plt.rcParams.update({"figure.dpi": 100, "axes.grid": True, "grid.alpha": 0.3})
print("project root:", ROOT)
""")

md("## 1. The simulator: what does a synthetic trip look like?")
code("""
metas, raw, energies = generate_dataset(6, seed=123, verbose=False)
for m in metas:
    e = energies[m.trip_id]
    print(f"trip {m.trip_id}: {m.driver_style:>10} | {m.road_type:>7} | {e['distance_km']:5.1f} km | "
          f"{m.ambient_temp_c:4.0f} C | HVAC {m.hvac_kw:.1f} kW | {e['wh_per_km']:6.1f} Wh/km")
""")
code("""
m = metas[0]; df = raw[m.trip_id]
fig, ax = plt.subplots(3, 1, figsize=(11, 7), sharex=True)
ax[0].plot(df.t_s / 60, df.speed_kmh, lw=1, label="speed"); ax[0].plot(df.t_s / 60, df.target_speed_kmh, lw=0.7, ls="--", c="grey", label="target")
ax[0].set_ylabel("km/h"); ax[0].legend()
ax[1].plot(df.t_s / 60, df.grade * 100, c="purple", lw=1); ax[1].set_ylabel("gradient %")
ax[2].plot(df.t_s / 60, df.battery_power_kw, c="C3", lw=0.8, label="battery power")
ax[2].plot(df.t_s / 60, -df.regen_power_kw, c="C2", lw=0.8, label="regen"); ax[2].plot(df.t_s / 60, -df.friction_brake_kw, c="k", lw=0.8, label="friction brake")
ax[2].set_ylabel("kW"); ax[2].set_xlabel("min"); ax[2].legend(ncol=3)
fig.suptitle(f"Synthetic trip {m.trip_id}: {m.driver_style} driver on a {m.road_type} road"); plt.show()
""")

md("""
### Physics sanity checks
The motor efficiency map and the steady-state Wh/km curve are the two building blocks of the energy model.
Constant-speed consumption should rise roughly with $v^2$ because of aerodynamic drag, with a penalty at
very low speed where the fixed auxiliary load is spread over few kilometres.
""")
code("""
p = np.linspace(0, 110e3, 200); v = np.arange(10, 131, 5)
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].plot(p / 1e3, motor_efficiency(p)); ax[0].set_xlabel("|motor power| (kW)"); ax[0].set_ylabel("efficiency"); ax[0].set_title("Motor + inverter efficiency approximation")
for g, lab in [(0, "flat"), (0.02, "2 % uphill"), (-0.02, "2 % downhill")]:
    ax[1].plot(v, steady_state_wh_per_km(v, grade=g), label=lab)
ax[1].plot(v, steady_state_wh_per_km(v, hvac_kw=2.0), label="flat + 2 kW HVAC")
ax[1].axhline(0, c="k", lw=0.5); ax[1].set_xlabel("km/h"); ax[1].set_ylabel("Wh/km"); ax[1].set_title("Steady-state energy vs speed"); ax[1].legend()
plt.show()
""")

md("""
## 2. Trip-level dataset
`python main.py` writes `results/trips_dataset.csv` (2,000 simulated trips). If it is missing we
simulate a smaller dataset here so the notebook still runs standalone.
""")
code("""
csv = RESULTS / "trips_dataset.csv"
if csv.exists():
    trips = pd.read_csv(csv)
    print("loaded", csv)
else:
    _m, _r, _e = generate_dataset(600, seed=C.RANDOM_SEED, verbose=False)
    trips = build_feature_table(_m, _r, _e)
    print("simulated a 600-trip dataset in-notebook")
print(trips.shape)
trips.head()
""")
code("""
trips.groupby(["road_type", "driver_style"])[TARGET].agg(["mean", "std", "count"]).round(1)
""")
code("""
fig, ax = plt.subplots(1, 3, figsize=(15, 4))
for s, c in zip(["eco", "normal", "aggressive"], ["C2", "C0", "C3"]):
    d = trips[trips.driver_style == s]
    ax[0].hist(d[TARGET], bins=40, alpha=0.5, color=c, label=s)
    ax[1].scatter(d.harsh_accel_per10km, d[TARGET], s=6, alpha=0.5, color=c, label=s)
    ax[2].scatter(d.hvac_kw, d[TARGET], s=6, alpha=0.5, color=c, label=s)
ax[0].set_xlabel("Wh/km"); ax[0].set_title("Distribution by driver style"); ax[0].legend()
ax[1].set_xlabel("harsh accelerations / 10 km"); ax[1].set_ylabel("Wh/km"); ax[1].set_title("Harsh acceleration vs energy")
ax[2].set_xlabel("HVAC power (kW)"); ax[2].set_title("HVAC vs energy")
plt.show()
""")
code("""
corr = trips[FEATURE_COLUMNS + [TARGET]].corr()[TARGET].drop(TARGET).sort_values()
corr.plot.barh(figsize=(7, 6), color=np.where(corr > 0, "C3", "C0")); plt.title("Pearson correlation with Wh/km"); plt.show()
""")

md("## 3. Models: Wh/km regression and driver-style classification")
code("""
train_df, test_df = split_data(trips)
comparison, fitted, best_name = compare_regressors(train_df, test_df)
print("best model:", best_name)
comparison.round(3)
""")
code("""
best = fitted[best_name]
pred = best.predict(test_df[FEATURE_COLUMNS])
plt.figure(figsize=(5, 5)); plt.scatter(test_df[TARGET], pred, s=10, alpha=0.6)
lim = [test_df[TARGET].min() * 0.95, test_df[TARGET].max() * 1.05]; plt.plot(lim, lim, "k--")
plt.xlabel("actual Wh/km"); plt.ylabel("predicted Wh/km"); plt.title(f"{best_name}: held-out test"); plt.show()
""")
code("""
imp = feature_importance(best, test_df, n_repeats=5)
imp.head(12).round(4)
""")
code("""
clf, clf_metrics = train_style_classifier(train_df, test_df)
print(f"driver-style accuracy = {clf_metrics['accuracy']:.3f}, macro-F1 = {clf_metrics['macro_f1']:.3f}")
pd.DataFrame(clf_metrics["confusion_matrix"], index=[f"true {l}" for l in clf_metrics["labels"]], columns=[f"pred {l}" for l in clf_metrics["labels"]])
""")

md("""
## 4. Driving tips via counterfactual re-prediction
For each applicable tip the recommender edits the trip's feature vector (e.g. sets harsh accelerations to
zero and damps the acceleration variance) and asks the model what Wh/km would have been. Tips are ranked
by predicted saving.
""")
code("""
rec = Recommender(best, clf)
worst = test_df.sort_values(TARGET, ascending=False).iloc[0]
r = rec.recommend(worst, worst[TARGET])
from IPython.display import Markdown, display
display(Markdown(r.to_markdown()))
""")
code("""
recs = rec.recommend_many(test_df)
tab = savings_table(recs)
summary = tab.groupby("tip").agg(n=("trip_id", "nunique"), mean_saving_pct=("saving_pct", "mean"), mean_saving_wh_per_km=("saving_wh_per_km", "mean")).sort_values("mean_saving_pct", ascending=False)
summary.round(2)
""")
code("""
comb = pd.Series([r.combined.saving_pct if r.combined else 0 for r in recs], index=test_df.index)
print("mean predicted saving if all tips are followed, by true driver style:")
print(comb.groupby(test_df.driver_style).mean().round(1))
""")

md("""
## 5. Take-aways

* On this **synthetic** fleet the physics model puts aggressive drivers ~30 % above eco drivers in Wh/km,
  and the gradient-boosting regressor recovers the simulator's energy with R² ~ 0.97 on held-out trips.
* HVAC load, net climb, 95th-percentile speed and acceleration variance carry most of the predictive power -
  two environmental and two behavioural factors.
* The counterfactual recommender predicts double-digit savings for aggressive drivers and single-digit
  savings for eco drivers, which is the direction one would hope for from a coaching tool.
* Everything here should be re-validated on real OBD-II / CAN logs before any claim is made about real vehicles.
""")

nb["cells"] = cells
nb["metadata"] = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python"},
}
out = Path(__file__).resolve().parent / "analysis.ipynb"
nbf.write(nb, out)
print("wrote", out)
