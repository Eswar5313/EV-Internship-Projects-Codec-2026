# Sample driving recommendations

> **Data provenance:** the trips below are SYNTHETIC - produced by the physics-based
> simulator in `src/data_generator.py`. Savings are model re-predictions (`GradientBoosting`), not measured results.

Each tip is triggered by a rule on the trip's features, then evaluated by editing the
feature vector (the *counterfactual*) and re-predicting Wh/km with the trained model.
Tips are ranked by predicted saving.

## Trip 119 - aggressive driver, highway road, 62.2 km, 24 C, HVAC 0.0 kW

Key stats: mean speed 101 km/h, 95th-pct speed 125 km/h, harsh accel 1.3/10 km, harsh brake 0.8/10 km, idle 1%, regen share 9%, mean |gradient| 1.0 %

### Trip 119
- Actual energy use: **182.2 Wh/km**
- Model prediction: **185.6 Wh/km**
- Detected driving style: **normal** (aggressive: 16%, eco: 0%, normal: 83%)

| # | Tip | Why it fired | Predicted Wh/km | Saving |
|---|-----|--------------|-----------------|--------|
| 1 | **Lower your cruising speed** - Aerodynamic drag grows with the square of speed - keep to the posted limit or slightly below. | 95th-pct speed 125 km/h vs 100 km/h cap (highway) | 152.3 | 17.9 % |
| 2 | **Accelerate smoothly** - Ease onto the accelerator; aim for < 1.5 m/s^2 and let the car build speed gradually. | 1.3 harsh accelerations / 10 km | 178.7 | 3.7 % |
| 3 | **Anticipate and brake gently** - Look further ahead, lift off early and let regenerative braking slow the car instead of the friction brakes. | 0.8 harsh braking events / 10 km | 181.3 | 2.3 % |
| 4 | **Remove unnecessary weight** - Every 60 kg of extra load costs energy on every acceleration and hill. | payload 313 kg | 183.9 | 0.9 % |

**All tips together:** 139.4 Wh/km (-24.9 %, 46.2 Wh/km saved)

Not applicable to this trip: Use climate control sparingly, Cut stationary time

## Trip 80 - normal driver, hilly road, 14.6 km, 28 C, HVAC 0.0 kW

Key stats: mean speed 41 km/h, 95th-pct speed 85 km/h, harsh accel 4.8/10 km, harsh brake 0.0/10 km, idle 5%, regen share 37%, mean |gradient| 2.7 %

### Trip 80
- Actual energy use: **108.3 Wh/km**
- Model prediction: **115.6 Wh/km**
- Detected driving style: **normal** (aggressive: 2%, eco: 0%, normal: 98%)

| # | Tip | Why it fired | Predicted Wh/km | Saving |
|---|-----|--------------|-----------------|--------|
| 1 | **Accelerate smoothly** - Ease onto the accelerator; aim for < 1.5 m/s^2 and let the car build speed gradually. | 4.8 harsh accelerations / 10 km | 103.3 | 10.6 % |
| 2 | **Lower your cruising speed** - Aerodynamic drag grows with the square of speed - keep to the posted limit or slightly below. | 95th-pct speed 85 km/h vs 70 km/h cap (hilly) | 103.7 | 10.3 % |
| 3 | **Remove unnecessary weight** - Every 60 kg of extra load costs energy on every acceleration and hill. | payload 243 kg | 114.1 | 1.3 % |

**All tips together:** 91.2 Wh/km (-21.2 %, 24.5 Wh/km saved)

Not applicable to this trip: Anticipate and brake gently, Use climate control sparingly, Cut stationary time

## Trip 1609 - eco driver, hilly road, 20.4 km, 44 C, HVAC 2.5 kW

Key stats: mean speed 42 km/h, 95th-pct speed 72 km/h, harsh accel 0.0/10 km, harsh brake 1.5/10 km, idle 7%, regen share 29%, mean |gradient| 3.0 %

### Trip 1609
- Actual energy use: **191.0 Wh/km**
- Model prediction: **184.4 Wh/km**
- Detected driving style: **eco** (aggressive: 0%, eco: 87%, normal: 13%)

| # | Tip | Why it fired | Predicted Wh/km | Saving |
|---|-----|--------------|-----------------|--------|
| 1 | **Use climate control sparingly** - Pre-condition the cabin while plugged in, use seat heating/ventilation and an eco climate mode. | HVAC drawing 2.5 kW at 44 C | 161.9 | 12.2 % |
| 2 | **Anticipate and brake gently** - Look further ahead, lift off early and let regenerative braking slow the car instead of the friction brakes. | 1.5 harsh braking events / 10 km | 182.1 | 1.3 % |
| 3 | **Remove unnecessary weight** - Every 60 kg of extra load costs energy on every acceleration and hill. | payload 318 kg | 182.5 | 1.0 % |

**All tips together:** 159.1 Wh/km (-13.7 %, 25.3 Wh/km saved)

Not applicable to this trip: Accelerate smoothly, Lower your cruising speed, Cut stationary time
