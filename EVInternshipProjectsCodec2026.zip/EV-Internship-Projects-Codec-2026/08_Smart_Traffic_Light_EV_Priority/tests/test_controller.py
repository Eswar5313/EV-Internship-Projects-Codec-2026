"""Verification suite for the EV-priority traffic controller (python -m pytest tests)."""
import random
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "simulation"))

import controller as C  # noqa: E402
from controller import EvPriorityController, GREEN, YELLOW, RED  # noqa: E402
from traffic_sim import SimConfig, run  # noqa: E402

HEADER = ROOT / "firmware/arduino_ev_priority/ev_priority_controller.h"
NON_GREEN_BOUND_MS = C.GREEN_NORMAL_MS + C.EV_EXT_MAX_MS + 2 * (C.YELLOW_MS + C.ALLRED_MS)  # 60 s


# ------------------------------------------------------------------ firmware <-> python parity
def test_timing_constants_match_firmware_header():
    txt = HEADER.read_text()
    for name in ["GREEN_MIN_MS", "GREEN_NORMAL_MS", "YELLOW_MS", "ALLRED_MS", "EV_HOLD_MS", "EV_EXT_MAX_MS",
                 "STARVE_RED_MS", "EV_REQ_TIMEOUT_MS", "EV_CLEAR_MS", "EV_LEAD_MS", "RFID_ETA_MS"]:
        m = re.search(rf"#define {name}\s+(\d+)UL", txt)
        assert m, f"{name} missing from header"
        assert int(m.group(1)) == getattr(C, name), name


def test_gps_variant_uses_identical_header():
    other = ROOT / "firmware/gps_variant/controller_gps_receiver/ev_priority_controller.h"
    assert other.read_text() == HEADER.read_text()


# ------------------------------------------------------------------ helpers
def drive(ctrl, t_ms, until_ms, events=None, step=100):
    """Tick the controller from t_ms to until_ms; events = {time_ms: (approach, eta_ms)}."""
    log = []
    events = events or {}
    t = t_ms
    while t <= until_ms:
        if t in events:
            a, eta = events[t]
            ctrl.ev_detected(a, t, eta)
        ctrl.tick(t)
        log.append((t, ctrl.phase, ctrl.lights()))
        t += step
    return log


def random_run(seed, hours=2, priority=True):
    rng = random.Random(seed)
    ctrl = EvPriorityController(priority_enabled=priority)
    ctrl.begin(0)
    log = []
    t = 0
    end = hours * 3600 * 1000
    while t <= end:
        if rng.random() < 0.02:                      # ~ one EV every 5 s, bursty
            ctrl.ev_detected(rng.randrange(4), t, rng.choice([8000, 12000, 20000]))
        ctrl.tick(t)
        log.append((t, ctrl.phase, ctrl.lights(), ctrl.preemptions))
        t += 100
    return ctrl, log


# ------------------------------------------------------------------ safety invariants
@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_never_conflicting_greens(seed):
    _, log = random_run(seed)
    for t, ph, (ns, ew), _ in log:
        assert not (ns == GREEN and ew == GREEN), f"double green at {t}"
        assert not (ns == GREEN and ew == YELLOW), f"green vs yellow at {t}"
        assert not (ns == YELLOW and ew == GREEN), f"yellow vs green at {t}"
        assert not (ns == YELLOW and ew == YELLOW), f"double yellow at {t}"


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_all_red_clearance_always_inserted(seed):
    _, log = random_run(seed)
    # compress to phase intervals
    intervals = []
    for t, ph, _, _ in log:
        if not intervals or intervals[-1][1] != ph:
            intervals.append([t, ph, t])
        intervals[-1][2] = t
    seq = [ph for _, ph, _ in intervals]
    allowed = {C.GREEN_NS: C.YELLOW_NS, C.YELLOW_NS: C.ALLRED_NS, C.ALLRED_NS: C.GREEN_EW,
               C.GREEN_EW: C.YELLOW_EW, C.YELLOW_EW: C.ALLRED_EW, C.ALLRED_EW: C.GREEN_NS}
    for a, b in zip(seq, seq[1:]):
        assert allowed[a] == b, f"illegal transition {C.PHASE_NAMES[a]} -> {C.PHASE_NAMES[b]}"
    for start, ph, last in intervals[1:-1]:
        dur = last - start + 100
        if ph in (C.YELLOW_NS, C.YELLOW_EW):
            assert dur == C.YELLOW_MS
        if ph in (C.ALLRED_NS, C.ALLRED_EW):
            assert dur == C.ALLRED_MS
        if ph in (C.GREEN_NS, C.GREEN_EW):
            assert C.GREEN_MIN_MS <= dur <= C.GREEN_NORMAL_MS + C.EV_EXT_MAX_MS


@pytest.mark.parametrize("seed", [1, 2, 3])
def test_non_green_time_bounded_by_guards(seed):
    ctrl, log = random_run(seed)
    for g in range(2):
        red_start = None
        for t, ph, lights, _ in log:
            if lights[g] != GREEN and red_start is None:
                red_start = t
            elif lights[g] == GREEN and red_start is not None:
                assert t - red_start <= NON_GREEN_BOUND_MS, f"group {g} not green for {(t - red_start) / 1000} s"
                red_start = None
    assert ctrl.preemptions > 50  # the run really exercised priority


@pytest.mark.parametrize("seed", [1, 2])
def test_no_two_consecutive_cuts_on_same_group(seed):
    ctrl, log = random_run(seed)
    greens = []   # [start, phase, last_t, was_cut]; a green was cut if the pre-emption counter rose during it
    prev_pre = 0
    for t, ph, _, pre in log:
        if ph in (C.GREEN_NS, C.GREEN_EW):
            if not greens or greens[-1][1] != ph or greens[-1][2] + 100 < t:
                greens.append([t, ph, t, False])
            greens[-1][2] = t
        if pre > prev_pre and greens:          # the cut tick is the first yellow tick -> belongs to the last green
            greens[-1][3] = True
        prev_pre = pre
    n_cut = 0
    for g in (C.GREEN_NS, C.GREEN_EW):
        cuts = [was_cut for _, ph, _, was_cut in greens if ph == g]
        n_cut += sum(cuts)
        for a, b in zip(cuts, cuts[1:]):
            assert not (a and b), "fairness guard violated: two consecutive cut greens on one group"
    assert n_cut == ctrl.preemptions > 50


def test_baseline_is_plain_fixed_time():
    ctrl, log = random_run(9, priority=False)
    assert ctrl.preemptions == 0 and ctrl.extensions == 0
    greens = [t for t, ph, _, _ in log if ph == C.GREEN_NS]
    # NS green starts every cycle = 2*(30+3+2) s
    starts = [t for i, t in enumerate(greens) if i == 0 or greens[i - 1] + 100 < t]
    assert all(b - a == 2 * (C.GREEN_NORMAL_MS + C.YELLOW_MS + C.ALLRED_MS) for a, b in zip(starts, starts[1:]))


# ------------------------------------------------------------------ priority behaviour (deterministic)
def test_cross_ev_cuts_green_after_min_green_and_clearance():
    ctrl = EvPriorityController()
    ctrl.begin(0)
    log = drive(ctrl, 0, 40000, events={2000: (1, C.RFID_ETA_MS)})   # EV on E at t=2 s
    ph = {t: p for t, p, _ in log}
    assert ph[9900] == C.GREEN_NS and ph[10000] == C.YELLOW_NS          # cut exactly at GREEN_MIN
    assert ph[13000] == C.ALLRED_NS and ph[15000] == C.GREEN_EW          # 3 s yellow + 2 s all-red
    assert ctrl.preemptions == 1
    # EV green covers arrival (10 s) + clear (5 s) or EV_HOLD, whichever later -> ends at 30 s
    assert ph[29900] == C.GREEN_EW and ph[30000] == C.YELLOW_EW


def test_gps_eta_cut_is_timed_so_green_shows_before_arrival():
    ctrl = EvPriorityController()
    ctrl.begin(0)
    # EV on W detected at t=12 s with 20 s ETA -> arrives at 32 s. Cut due at 32-5-3 = 24 s.
    log = drive(ctrl, 0, 60000, events={12000: (3, 20000)})
    ph = {t: p for t, p, _ in log}
    assert ph[23900] == C.GREEN_NS and ph[24000] == C.YELLOW_NS
    assert ph[29000] == C.GREEN_EW                       # green 3 s before arrival
    assert all(ph[t] == C.GREEN_EW for t in range(29000, 37000, 100))   # still green at arrival + 5 s


def test_same_direction_ev_extends_green_up_to_cap():
    ctrl = EvPriorityController()
    ctrl.begin(0)
    log = drive(ctrl, 0, 60000, events={28000: (0, C.RFID_ETA_MS)})   # EV on N just before green ends
    ph = {t: p for t, p, _ in log}
    assert ph[30000] == C.GREEN_NS and ph[42900] == C.GREEN_NS and ph[43000] == C.YELLOW_NS  # 28+15 = 43 s
    assert ctrl.extensions == 1
    ctrl.begin(0)
    ev = {t: (0, C.RFID_ETA_MS) for t in range(1000, 80000, 5000)}     # continuous EV stream on N
    log = drive(ctrl, 0, 80000, events=ev)
    ph = {t: p for t, p, _ in log}
    assert ph[49900] == C.GREEN_NS and ph[50000] == C.YELLOW_NS       # capped at 30 + 20 s


def test_request_expires():
    ctrl = EvPriorityController()
    ctrl.begin(0)
    ctrl.green_locked = True                    # nothing may be cut
    ctrl.ev_detected(1, 1000, 8000)
    ctrl.tick(1000)
    # the request is due at 1000+8000-5000-3000 = 1000 -> consumed as pending (denied). Now test a
    # request that is never due within the timeout: huge ETA
    ctrl.begin(0)
    ctrl.ev_detected(1, 1000, 200000)
    for t in range(1000, 40000, 100):
        ctrl.tick(t)
    assert ctrl.expired_requests == 1 and ctrl.preemptions == 0


def test_priority_disabled_ignores_detections():
    ctrl = EvPriorityController(priority_enabled=False)
    ctrl.begin(0)
    log = drive(ctrl, 0, 40000, events={2000: (1, 8000)})
    ph = {t: p for t, p, _ in log}
    assert ph[29900] == C.GREEN_NS and ctrl.preemptions == 0


# ------------------------------------------------------------------ traffic simulation
@pytest.mark.parametrize("seed", [1, 2, 3])
def test_ev_delay_lower_with_priority(seed):
    base = run(SimConfig(duration_s=1800, ev_share=0.10, priority=False, seed=seed)).metrics()
    prio = run(SimConfig(duration_s=1800, ev_share=0.10, priority=True, seed=seed)).metrics()
    assert prio["ev_mean_delay_s"] < base["ev_mean_delay_s"]
    assert prio["preemptions"] > 0
    assert prio["vehicles_served"] == prio["vehicles_arrived"]       # nobody left stranded


def test_nonev_max_wait_bounded():
    for seed in (1, 2):
        m = run(SimConfig(duration_s=3600, ev_share=0.40, priority=True, seed=seed)).metrics()
        assert m["max_red_s"] <= NON_GREEN_BOUND_MS / 1000 + 0.2
        assert m["nonev_max_delay_s"] <= 3 * NON_GREEN_BOUND_MS / 1000   # at most three signal cycles


def test_simulation_conserves_vehicles_and_is_deterministic():
    a = run(SimConfig(duration_s=900, seed=5)).metrics()
    b = run(SimConfig(duration_s=900, seed=5)).metrics()
    assert a == b
    assert a["vehicles_served"] == a["vehicles_arrived"] > 0
