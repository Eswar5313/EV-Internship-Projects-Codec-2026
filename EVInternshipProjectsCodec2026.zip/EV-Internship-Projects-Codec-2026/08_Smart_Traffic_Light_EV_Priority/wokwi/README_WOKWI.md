# Simulating the circuit in Wokwi (free, browser)

Wokwi (https://wokwi.com) has no MFRC522 part, so the demo build replaces the two RFID
readers with push buttons on the same pins (10 = EV on N, A5 = EV on E) and also accepts
`n / e / s / w` typed in the serial monitor. The state machine and LED wiring are unchanged.

## Option A - paste into wokwi.com (no install)
1. Go to https://wokwi.com -> *New project* -> *Arduino Uno*.
2. Replace the contents of `diagram.json` with the file in this folder.
3. Replace `sketch.ino` with `firmware/arduino_ev_priority/arduino_ev_priority.ino` **after
   changing** `#define USE_RFID 1` to `#define USE_RFID 0` (or add `#define USE_RFID 0` at the
   very top), and add a file `ev_priority_controller.h` with the header's contents.
4. Press *Start simulation*. Watch: NS green 30 s -> yellow 3 s -> all-red 2 s -> EW green ...
   Press the *EV on E* button during NS green: NS is cut at 10 s (or immediately if it has
   already run 10 s), 3 s yellow, 2 s all-red, then EW green for 15 s. Press *EV on N* during
   NS green near its end: the green is extended. The serial monitor logs every phase change
   and `?` prints the counters.

## Option B - VS Code Wokwi extension (uses the local build)
```
cd wokwi
arduino-cli compile --fqbn arduino:avr:uno --build-property "build.extra_flags=-DUSE_RFID=0" \
    --output-dir build ../firmware/arduino_ev_priority
```
then open this folder in VS Code with the *Wokwi Simulator* extension and press F1 -> *Wokwi: Start Simulator*
(`wokwi.toml` points at `build/arduino_ev_priority.ino.hex`).

## What to expect
* 12 LEDs: N and S always identical, E and W always identical.
* Never two greens at the same time; every green->green hand-over goes through yellow + all-red.
* Two consecutive presses on the same side do **not** cut the other side twice in a row
  (fairness guard) - the second EV is served at the natural end of the green instead.
