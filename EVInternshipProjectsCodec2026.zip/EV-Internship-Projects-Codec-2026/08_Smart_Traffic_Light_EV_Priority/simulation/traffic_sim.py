"""
traffic_sim.py - discrete-event simulation of a 4-approach intersection
controlled by the EV-priority state machine (controller.py, ported from the
Arduino header).

Model
  * SimPy environment; one Poisson arrival process per approach (N, E, S, W)
    with an EV fraction `ev_share`.
  * A vehicle is created at the *detection point* `detect_lead_s` seconds of
    free-flow travel upstream of the stop line (an RFID reader ~100 m upstream
    at 45 km/h = 8 s; the GPS variant triggers on a 20 s ETA).  An EV calls
    controller.ev_detected() the moment it passes that point.
  * Vertical (point) queue at the stop line. Discharge only on green: first
    vehicle after STARTUP_LOST_S, then one every SAT_HEADWAY_S (1800 veh/h).
    A vehicle reaching an empty queue on green passes without stopping.
  * Delay = departure time - (arrival at detection point + free-flow travel).
  * The controller is ticked every TICK_S (100 ms) exactly like loop() on the Uno.

Author: Eswar Mahalingam, Codec Technologies EV internship, Sept 2026
"""

from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field

import simpy

from controller import (EvPriorityController, GREEN, PHASE_NAMES, APPROACH_NAMES,
                        approach_to_group)

TICK_S = 0.1
SAT_HEADWAY_S = 2.0
STARTUP_LOST_S = 2.0


@dataclass
class Vehicle:
    vid: int
    approach: int
    is_ev: bool
    t_detect: float          # passes the detection point
    t_stopline: float        # would reach the stop line at free flow
    t_depart: float = -1.0

    @property
    def delay(self) -> float:
        return self.t_depart - self.t_stopline


@dataclass
class SimConfig:
    duration_s: float = 3600.0
    arrival_rate_veh_per_h: float = 360.0    # per approach
    ev_share: float = 0.10
    detect_lead_s: float = 8.0               # RFID reader ~100 m upstream
    priority: bool = True
    seed: int = 1
    record_timeline: bool = False


@dataclass
class SimResult:
    cfg: SimConfig
    vehicles: list = field(default_factory=list)
    phase_log: list = field(default_factory=list)       # (t, phase)
    ev_detect_log: list = field(default_factory=list)   # (t, approach)
    queue_log: list = field(default_factory=list)       # (t, [q0..q3]) every 1 s
    controller: EvPriorityController | None = None
    red_durations: list = field(default_factory=list)   # (group, seconds) per red interval

    # ---- metrics -------------------------------------------------------------
    def metrics(self) -> dict:
        done = [v for v in self.vehicles if v.t_depart >= 0]
        ev = [v for v in done if v.is_ev]
        nev = [v for v in done if not v.is_ev]
        mean = lambda xs: sum(xs) / len(xs) if xs else float("nan")  # noqa: E731
        c = self.controller
        hrs = self.cfg.duration_s / 3600.0
        return {
            "priority": self.cfg.priority,
            "ev_share": self.cfg.ev_share,
            "seed": self.cfg.seed,
            "detect_lead_s": self.cfg.detect_lead_s,
            "arrival_rate": self.cfg.arrival_rate_veh_per_h,
            "vehicles_arrived": len(self.vehicles),
            "vehicles_served": len(done),
            "throughput_veh_per_h": len(done) / hrs,
            "ev_count": len(ev),
            "ev_mean_delay_s": mean([v.delay for v in ev]),
            "ev_max_delay_s": max([v.delay for v in ev], default=float("nan")),
            "ev_stopped_frac": mean([1.0 if v.delay > 1.0 else 0.0 for v in ev]),
            "nonev_mean_delay_s": mean([v.delay for v in nev]),
            "nonev_max_delay_s": max([v.delay for v in nev], default=float("nan")),
            "nonev_p95_delay_s": (sorted(v.delay for v in nev)[int(0.95 * (len(nev) - 1))] if nev else float("nan")),
            "all_mean_delay_s": mean([v.delay for v in done]),
            "max_queue": max((max(q) for _, q in self.queue_log), default=0),
            "max_red_s": max((d for _, d in self.red_durations), default=0.0),
            "preemptions": c.preemptions,
            "extensions": c.extensions,
            "denied_requests": c.denied_requests,
            "expired_requests": c.expired_requests,
            "unserved_at_end": len(self.vehicles) - len(done),
        }


def run(cfg: SimConfig) -> SimResult:
    rng = random.Random(cfg.seed)
    env = simpy.Environment()
    ctrl = EvPriorityController(priority_enabled=cfg.priority)
    ctrl.begin(0)
    res = SimResult(cfg=cfg, controller=ctrl)
    queues = [deque() for _ in range(4)]
    pending = [deque() for _ in range(4)]     # vehicles travelling from detector to stop line
    next_depart = [0.0] * 4
    was_green = [False] * 4
    vid = 0

    def arrivals(approach: int):
        nonlocal vid
        lam = cfg.arrival_rate_veh_per_h / 3600.0
        while True:
            yield env.timeout(rng.expovariate(lam))
            if env.now > cfg.duration_s:
                return
            vid += 1
            v = Vehicle(vid, approach, rng.random() < cfg.ev_share, env.now, env.now + cfg.detect_lead_s)
            res.vehicles.append(v)
            pending[approach].append(v)
            if v.is_ev:
                ctrl.ev_detected(approach, int(env.now * 1000), int(cfg.detect_lead_s * 1000))
                if cfg.record_timeline:
                    res.ev_detect_log.append((env.now, approach))

    def controller_loop():
        last_phase = ctrl.phase
        last_q_log = -1.0
        red_start = [None, None]
        ns, ew = ctrl.lights()
        for g, l in enumerate((ns, ew)):
            if l != GREEN:
                red_start[g] = 0.0
        while env.now <= cfg.duration_s + 120:   # drain for 2 min after arrivals stop
            now = env.now
            ctrl.tick(int(round(now * 1000)))
            if ctrl.phase != last_phase:
                last_phase = ctrl.phase
                if cfg.record_timeline:
                    res.phase_log.append((now, ctrl.phase))
            lights = ctrl.lights()
            for g in range(2):
                if lights[g] == GREEN and red_start[g] is not None:
                    res.red_durations.append((g, now - red_start[g]))
                    red_start[g] = None
                elif lights[g] != GREEN and red_start[g] is None:
                    red_start[g] = now
            for a in range(4):
                # vehicles reaching the stop line
                while pending[a] and pending[a][0].t_stopline <= now + 1e-9:
                    queues[a].append(pending[a].popleft())
                green = ctrl.light_for_approach(a) == GREEN
                if green and not was_green[a]:
                    next_depart[a] = now + STARTUP_LOST_S
                was_green[a] = green
                if green and queues[a] and now + 1e-9 >= next_depart[a]:
                    v = queues[a].popleft()
                    v.t_depart = now          # a vehicle reaching an empty stop line on green leaves within one tick
                    next_depart[a] = now + SAT_HEADWAY_S
            if cfg.record_timeline and now - last_q_log >= 1.0 - 1e-9:
                last_q_log = now
                res.queue_log.append((now, [len(q) + len(p) for q, p in zip(queues, pending)]))
            elif not cfg.record_timeline and now - last_q_log >= 5.0 - 1e-9:
                last_q_log = now
                res.queue_log.append((now, [len(q) for q in queues]))
            yield env.timeout(TICK_S)

    for a in range(4):
        env.process(arrivals(a))
    env.process(controller_loop())
    env.run(until=cfg.duration_s + 121)
    return res


if __name__ == "__main__":
    import json
    for prio in (False, True):
        r = run(SimConfig(duration_s=1800, ev_share=0.1, priority=prio, seed=1))
        print(json.dumps(r.metrics(), indent=1))
