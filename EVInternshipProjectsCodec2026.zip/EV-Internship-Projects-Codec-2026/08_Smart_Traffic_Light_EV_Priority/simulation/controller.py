"""
controller.py - Python port of firmware/arduino_ev_priority/ev_priority_controller.h

The class below mirrors the C++ struct EvPriorityController *function by
function* with the same names, the same millisecond timing constants and the
same branch order, so that what the simulation measures is what the Arduino
will do. tests/test_controller.py parses the header and asserts the constants
are identical.

Author: Eswar Mahalingam, Codec Technologies EV internship, Sept 2026
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---------------- timing constants (ms) - must equal the #defines in the header ----------------
GREEN_MIN_MS = 10000
GREEN_NORMAL_MS = 30000
YELLOW_MS = 3000
ALLRED_MS = 2000
EV_HOLD_MS = 15000
EV_EXT_MAX_MS = 20000
STARVE_RED_MS = 60000
EV_REQ_TIMEOUT_MS = 30000
EV_CLEAR_MS = 5000
EV_LEAD_MS = 3000
RFID_ETA_MS = 8000

# phases
GREEN_NS, YELLOW_NS, ALLRED_NS, GREEN_EW, YELLOW_EW, ALLRED_EW = range(6)
PHASE_NAMES = ["GREEN_NS", "YELLOW_NS", "ALLRED_NS", "GREEN_EW", "YELLOW_EW", "ALLRED_EW"]
RED, YELLOW, GREEN = 0, 1, 2
GROUP_NS, GROUP_EW = 0, 1
APPROACH_NAMES = ["N", "E", "S", "W"]


def approach_to_group(approach: int) -> int:
    return GROUP_NS if approach in (0, 2) else GROUP_EW


@dataclass
class EvPriorityController:
    priority_enabled: bool = True

    phase: int = GREEN_NS
    phase_start: int = 0
    green_end: int = 0
    ev_request: list = field(default_factory=lambda: [False, False])
    ev_request_time: list = field(default_factory=lambda: [0, 0])
    ev_arrival: list = field(default_factory=lambda: [0, 0])
    preempt_pending: bool = False
    pending_arrival: int = 0
    green_locked: bool = False
    ev_protect_until: int = 0
    last_green_cut: list = field(default_factory=lambda: [False, False])
    current_green_cut: bool = False
    red_since: list = field(default_factory=lambda: [0, 0])

    preemptions: int = 0
    extensions: int = 0
    denied_requests: int = 0
    expired_requests: int = 0

    # ------------------------------------------------------------------ API
    def begin(self, now: int):
        self.phase = GREEN_NS
        self.phase_start = now
        self.green_end = now + GREEN_NORMAL_MS
        self.red_since = [now, now]
        self.ev_request = [False, False]
        self.preempt_pending = False
        self.pending_arrival = 0
        self.green_locked = False
        self.ev_protect_until = now
        self.last_green_cut = [False, False]
        self.current_green_cut = False
        self.preemptions = self.extensions = self.denied_requests = self.expired_requests = 0

    def ev_detected(self, approach: int, now: int, eta_ms: int = RFID_ETA_MS):
        if not self.priority_enabled:
            return
        g = approach_to_group(approach)
        arrival = now + eta_ms
        if not self.ev_request[g] or arrival < self.ev_arrival[g]:
            self.ev_arrival[g] = arrival
        self.ev_request[g] = True
        self.ev_request_time[g] = now

    @staticmethod
    def clamp_green(phase_start: int, want: int) -> int:
        return min(want, phase_start + GREEN_NORMAL_MS + EV_EXT_MAX_MS)

    def green_group(self) -> int:
        return GROUP_NS if self.phase <= ALLRED_NS else GROUP_EW

    def is_green(self) -> bool:
        return self.phase in (GREEN_NS, GREEN_EW)

    def lights(self) -> tuple[int, int]:
        ns, ew = RED, RED
        if self.phase == GREEN_NS:
            ns = GREEN
        elif self.phase == YELLOW_NS:
            ns = YELLOW
        elif self.phase == GREEN_EW:
            ew = GREEN
        elif self.phase == YELLOW_EW:
            ew = YELLOW
        return ns, ew

    def light_for_approach(self, approach: int) -> int:
        ns, ew = self.lights()
        return ns if approach_to_group(approach) == GROUP_NS else ew

    def tick(self, now: int):
        for g in range(2):
            if self.ev_request[g] and now - self.ev_request_time[g] >= EV_REQ_TIMEOUT_MS:
                self.ev_request[g] = False
                self.expired_requests += 1
        elapsed = now - self.phase_start

        if self.phase in (GREEN_NS, GREEN_EW):
            g = self.green_group()
            other = 1 - g
            # (a) same-direction EV: extend so the green covers the arrival
            if self.ev_request[g]:
                want = max(now + EV_HOLD_MS, self.ev_arrival[g] + EV_CLEAR_MS)
                want = self.clamp_green(self.phase_start, want)
                if want > self.green_end:
                    self.green_end = want
                    self.extensions += 1
                self.ev_protect_until = max(self.ev_protect_until, self.ev_arrival[g])
                self.ev_request[g] = False
            # (b) cross-direction EV: cut when it is due and allowed
            if self.ev_request[other]:
                due_at = self.ev_arrival[other] - (YELLOW_MS + ALLRED_MS) - EV_LEAD_MS
                due = now >= due_at
                if due and elapsed >= GREEN_MIN_MS:
                    allowed = (not self.green_locked) and (not self.last_green_cut[g]) and now >= self.ev_protect_until
                    if allowed:
                        if self.green_end > now:
                            self.green_end = now
                            self.current_green_cut = True
                            self.preemptions += 1
                    else:
                        self.denied_requests += 1
                    self.preempt_pending = True
                    self.pending_arrival = self.ev_arrival[other]
                    self.ev_request[other] = False
            if now >= self.green_end:
                self.last_green_cut[g] = self.current_green_cut
                self.current_green_cut = False
                self.phase = YELLOW_NS if self.phase == GREEN_NS else YELLOW_EW
                self.phase_start = now

        elif self.phase in (YELLOW_NS, YELLOW_EW):
            if elapsed >= YELLOW_MS:
                self.phase = ALLRED_NS if self.phase == YELLOW_NS else ALLRED_EW
                self.phase_start = now

        else:  # ALLRED
            if elapsed >= ALLRED_MS:
                leaving = self.green_group()
                entering = 1 - leaving
                red_wait = now - self.red_since[entering]
                self.green_locked = self.priority_enabled and red_wait >= STARVE_RED_MS
                duration = GREEN_NORMAL_MS
                preempt_was_pending = self.preempt_pending
                if self.preempt_pending:
                    duration = EV_HOLD_MS
                    need = self.pending_arrival + EV_CLEAR_MS
                    if need > now + duration:
                        duration = need - now
                    duration = min(duration, GREEN_NORMAL_MS + EV_EXT_MAX_MS)
                if self.green_locked and duration < GREEN_NORMAL_MS:
                    duration = GREEN_NORMAL_MS
                self.preempt_pending = False
                self.phase = GREEN_NS if entering == GROUP_NS else GREEN_EW
                self.phase_start = now
                self.green_end = now + duration
                self.ev_protect_until = self.pending_arrival if preempt_was_pending else now
                self.red_since[leaving] = now
