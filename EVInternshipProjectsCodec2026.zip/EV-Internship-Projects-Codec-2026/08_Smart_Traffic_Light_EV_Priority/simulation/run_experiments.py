#!/usr/bin/env python3
"""
run_experiments.py - baseline fixed-time vs EV-priority controller sweep.

  1 h of traffic x 10 seeds x EV share {5, 10, 20, 40} %  x
  {baseline, priority (RFID, 8 s lead), priority (GPS, 20 s lead)}

Writes to results/:
  metrics.csv            one row per run
  summary.json           mean / std per (controller, ev_share)
  delay_vs_ev_share.png  EV vs non-EV mean delay, max non-EV wait, pre-emptions
  timeline.png           10 min of signal states + EV detections + queue lengths
  queue_lengths.png      queue length per approach, baseline vs priority (same seed)

    python simulation/run_experiments.py           # ~1 min
    python simulation/run_experiments.py --quick   # 3 seeds, 20 min runs

All numbers are from the simulation model - no real traffic data.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from controller import (APPROACH_NAMES, GREEN_MIN_MS, GREEN_NORMAL_MS, EV_EXT_MAX_MS,  # noqa: E402
                        YELLOW_MS, ALLRED_MS, PHASE_NAMES, GREEN, YELLOW, RED)
from traffic_sim import SimConfig, run  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results"

CONTROLLERS = {
    "baseline": dict(priority=False, detect_lead_s=8.0),
    "priority_rfid": dict(priority=True, detect_lead_s=8.0),
    "priority_gps": dict(priority=True, detect_lead_s=20.0),
}
COLORS = {"baseline": "#64748b", "priority_rfid": "#0284c7", "priority_gps": "#16a34a"}
LABELS = {"baseline": "fixed-time baseline", "priority_rfid": "EV priority, RFID (8 s lead)",
          "priority_gps": "EV priority, GPS (20 s lead)"}


def sweep(seeds, shares, duration, rate):
    rows = []
    for name, kw in CONTROLLERS.items():
        for share in shares:
            for seed in seeds:
                cfg = SimConfig(duration_s=duration, arrival_rate_veh_per_h=rate, ev_share=share, seed=seed, **kw)
                m = run(cfg).metrics()
                m["controller"] = name
                rows.append(m)
                print(f"{name:14s} share={share:.2f} seed={seed:2d} EV delay={m['ev_mean_delay_s']:5.1f}s "
                      f"non-EV={m['nonev_mean_delay_s']:5.1f}s maxwait={m['nonev_max_delay_s']:5.1f}s "
                      f"preempt={m['preemptions']:3d}", flush=True)
    return rows


def summarise(rows):
    keys = ["ev_mean_delay_s", "nonev_mean_delay_s", "all_mean_delay_s", "nonev_max_delay_s", "nonev_p95_delay_s",
            "ev_stopped_frac", "throughput_veh_per_h", "preemptions", "extensions", "denied_requests", "max_red_s", "max_queue"]
    out = {}
    for name in CONTROLLERS:
        for share in sorted({r["ev_share"] for r in rows}):
            sel = [r for r in rows if r["controller"] == name and r["ev_share"] == share]
            if not sel:
                continue
            entry = {"n_runs": len(sel)}
            for k in keys:
                vals = [r[k] for r in sel]
                entry[k + "_mean"] = statistics.fmean(vals)
                entry[k + "_std"] = statistics.pstdev(vals) if len(vals) > 1 else 0.0
            entry["nonev_max_delay_s_max"] = max(r["nonev_max_delay_s"] for r in sel)
            entry["max_red_s_max"] = max(r["max_red_s"] for r in sel)
            out[f"{name}@{share:.2f}"] = entry
    return out


def plot_delay(summary, shares, path):
    fig, ax = plt.subplots(1, 3, figsize=(15, 5.6))
    for name in CONTROLLERS:
        ev = [summary[f"{name}@{s:.2f}"]["ev_mean_delay_s_mean"] for s in shares]
        ev_sd = [summary[f"{name}@{s:.2f}"]["ev_mean_delay_s_std"] for s in shares]
        nev = [summary[f"{name}@{s:.2f}"]["nonev_mean_delay_s_mean"] for s in shares]
        nev_sd = [summary[f"{name}@{s:.2f}"]["nonev_mean_delay_s_std"] for s in shares]
        mx = [summary[f"{name}@{s:.2f}"]["nonev_max_delay_s_max"] for s in shares]
        pre = [summary[f"{name}@{s:.2f}"]["preemptions_mean"] for s in shares]
        x = [100 * s for s in shares]
        ax[0].errorbar(x, ev, yerr=ev_sd, marker="o", color=COLORS[name], label=LABELS[name] + " - EV", capsize=3)
        ax[0].errorbar(x, nev, yerr=nev_sd, marker="s", ls="--", color=COLORS[name], label=LABELS[name] + " - non-EV", capsize=3)
        ax[1].plot(x, mx, marker="o", color=COLORS[name], label=LABELS[name])
        ax[2].plot(x, pre, marker="o", color=COLORS[name], label=LABELS[name])
    bound = (GREEN_NORMAL_MS + EV_EXT_MAX_MS + 2 * (YELLOW_MS + ALLRED_MS)) / 1000
    ax[1].axhline(bound, color="r", ls=":", label=f"max non-green time per group {bound:.0f} s")
    ax[0].set_title("Mean control delay (mean +- sd over seeds)"); ax[0].set_ylabel("delay (s)")
    ax[0].legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=2)
    ax[1].set_title("Worst non-EV wait over all runs"); ax[1].set_ylabel("max delay (s)"); ax[1].legend(fontsize=7)
    ax[2].set_title("Green pre-emptions per hour"); ax[2].set_ylabel("count"); ax[2].legend(fontsize=7)
    for a in ax:
        a.set_xlabel("EV share of traffic (%)"); a.grid(alpha=.3); a.set_xticks([100 * s for s in shares])
    fig.suptitle("Simulated 4-approach intersection, 360 veh/h/approach - SIMULATION OUTPUT, no field data", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def plot_timeline(seed, share, duration, rate, path, path_q, window=(600, 1200)):
    runs = {}
    for name in ("baseline", "priority_rfid"):
        kw = CONTROLLERS[name]
        runs[name] = run(SimConfig(duration_s=duration, arrival_rate_veh_per_h=rate, ev_share=share, seed=seed,
                                   record_timeline=True, **kw))
    t0, t1 = window
    light_color = {RED: "#ef4444", YELLOW: "#f59e0b", GREEN: "#22c55e"}

    def phase_lights(phase):
        ns = GREEN if phase == 0 else YELLOW if phase == 1 else RED
        ew = GREEN if phase == 3 else YELLOW if phase == 4 else RED
        return ns, ew

    fig, axes = plt.subplots(4, 1, figsize=(14, 9), sharex=True,
                             gridspec_kw={"height_ratios": [1, 1, 1.6, 1.6]})
    for row, name in enumerate(("baseline", "priority_rfid")):
        r = runs[name]
        log = [(0.0, 0)] + r.phase_log
        for i, (t, ph) in enumerate(log):
            t_end = log[i + 1][0] if i + 1 < len(log) else duration + 120
            if t_end < t0 or t > t1:
                continue
            ns, ew = phase_lights(ph)
            axes[row].barh(1, min(t_end, t1) - max(t, t0), left=max(t, t0), color=light_color[ns], height=0.8)
            axes[row].barh(0, min(t_end, t1) - max(t, t0), left=max(t, t0), color=light_color[ew], height=0.8)
        for t, a in r.ev_detect_log:
            if t0 <= t <= t1:
                y = 1 if a in (0, 2) else 0
                axes[row].plot(t, y + 0.55, marker="v", color="k", ms=6)
        axes[row].set_yticks([0, 1]); axes[row].set_yticklabels(["E-W", "N-S"]); axes[row].set_ylim(-0.6, 1.9)
        axes[row].set_title(f"{LABELS[name]}: signal groups (black triangles = EV detected on that group)", fontsize=9, loc="left")
    for row, name in enumerate(("baseline", "priority_rfid")):
        r = runs[name]
        ts = [t for t, _ in r.queue_log if t0 <= t <= t1]
        for a in range(4):
            axes[2 + row].plot(ts, [q[a] for t, q in r.queue_log if t0 <= t <= t1], label=f"approach {APPROACH_NAMES[a]}", lw=1)
        axes[2 + row].set_ylabel("vehicles on approach"); axes[2 + row].legend(fontsize=7, ncol=4, loc="upper right"); axes[2 + row].grid(alpha=.3)
        axes[2 + row].set_title(f"{LABELS[name]}: queue lengths", fontsize=9, loc="left")
    axes[-1].set_xlabel("simulation time (s)")
    fig.suptitle(f"10-minute window, seed {seed}, EV share {share:.0%}, {rate:.0f} veh/h/approach - SIMULATION OUTPUT", fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)

    # whole-hour queue comparison
    fig, ax = plt.subplots(2, 1, figsize=(14, 6), sharex=True)
    for row, name in enumerate(("baseline", "priority_rfid")):
        r = runs[name]
        ts = [t for t, _ in r.queue_log]
        for a in range(4):
            ax[row].plot(ts, [q[a] for _, q in r.queue_log], lw=.8, label=f"approach {APPROACH_NAMES[a]}")
        ax[row].set_title(LABELS[name], fontsize=9, loc="left"); ax[row].set_ylabel("vehicles"); ax[row].grid(alpha=.3)
        ax[row].legend(fontsize=7, ncol=4)
    ax[-1].set_xlabel("simulation time (s)")
    fig.suptitle("Queue length per approach over the full hour - SIMULATION OUTPUT", fontsize=10)
    fig.tight_layout()
    fig.savefig(path_q, dpi=130)
    plt.close(fig)
    return {name: runs[name].metrics() for name in runs}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--rate", type=float, default=360.0, help="veh/h per approach")
    args = ap.parse_args()
    seeds = list(range(1, 4 if args.quick else 11))
    duration = 1200 if args.quick else 3600
    shares = [0.05, 0.10, 0.20, 0.40]
    RES.mkdir(exist_ok=True)

    rows = sweep(seeds, shares, duration, args.rate)
    with open(RES / "metrics.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    summary = summarise(rows)
    plot_delay(summary, shares, RES / "delay_vs_ev_share.png")
    tl = plot_timeline(seed=3, share=0.10, duration=duration, rate=args.rate,
                       path=RES / "timeline.png", path_q=RES / "queue_lengths.png")
    summary["_meta"] = {
        "note": "SIMULATION OUTPUT (simulation/traffic_sim.py); controller logic ported from ev_priority_controller.h",
        "seeds": seeds, "duration_s": duration, "arrival_rate_veh_per_h_per_approach": args.rate,
        "timings_ms": {"GREEN_MIN": GREEN_MIN_MS, "GREEN_NORMAL": GREEN_NORMAL_MS, "YELLOW": YELLOW_MS,
                       "ALLRED": ALLRED_MS, "EV_EXT_MAX": EV_EXT_MAX_MS},
        "timeline_runs": tl,
    }
    (RES / "summary.json").write_text(json.dumps(summary, indent=1))
    print("\n=== summary (mean over seeds) ===")
    for k, v in summary.items():
        if k.startswith("_"):
            continue
        print(f"{k:22s} EV {v['ev_mean_delay_s_mean']:5.1f}s  non-EV {v['nonev_mean_delay_s_mean']:5.1f}s  "
              f"all {v['all_mean_delay_s_mean']:5.1f}s  worst non-EV {v['nonev_max_delay_s_max']:5.1f}s  "
              f"max red {v['max_red_s_max']:5.1f}s  preempt {v['preemptions_mean']:5.1f}  thr {v['throughput_veh_per_h_mean']:6.0f}/h")


if __name__ == "__main__":
    main()
