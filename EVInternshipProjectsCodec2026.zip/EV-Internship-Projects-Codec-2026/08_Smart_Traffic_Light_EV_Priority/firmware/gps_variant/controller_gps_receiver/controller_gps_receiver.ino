/*
 * controller_gps_receiver.ino - intersection controller, GPS/radio variant.
 *
 * EV Internship Project 08 - Codec Technologies India - Eswar Mahalingam, Sept 2026
 *
 * Receives $EV beacons from vehicle_gps_beacon over an HC-12 (SoftwareSerial
 * D2 rx / D3 tx... see below), works out which approach the EV is on from its
 * bearing to the intersection, and raises an EV request when it is inside the
 * geofence AND heading towards the junction AND predicted to arrive within
 * ETA_TRIGGER_S. Same state machine (ev_priority_controller.h) and the same
 * 12-LED layout as the RFID build, so the two are interchangeable.
 *
 * Pins: LEDs as in arduino_ev_priority; HC-12 TX -> D10, RX -> D9 (SoftwareSerial 9600).
 * Library: TinyGPSPlus (only for distanceBetween / courseTo). Compile-checked, not run on hardware.
 */
#include <Arduino.h>
#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>
#include "ev_priority_controller.h"

// ---- intersection location (example: Anna Salai / Mount Road junction, Chennai - replace) ----
static const double JUNCTION_LAT = 13.0604;
static const double JUNCTION_LON = 80.2496;
static const double GEOFENCE_M = 250.0;      // consider vehicles within this radius
static const double ETA_TRIGGER_S = 20.0;    // request priority when ETA <= this
static const double MIN_SPEED_KMH = 5.0;     // stationary vehicles do not request
static const double HEADING_TOL_DEG = 45.0;  // must be heading towards the junction
static const uint32_t REPEAT_REQUEST_MS = 5000;  // re-assert request at most this often per vehicle

static const uint8_t LED_PINS[4][3] = { {2, 3, 4}, {8, A0, A1}, {5, 6, 7}, {A2, A3, A4} };
static const char* APPROACH_NAME[4] = {"N", "E", "S", "W"};

SoftwareSerial radio(10, 9);   // RX, TX
EvPriorityController ctrl;
char line[100];
uint8_t lineLen = 0;
uint32_t beacons = 0, requests = 0;
char lastVehicle[12] = "";
uint32_t lastRequestMs = 0;

uint8_t xorChecksum(const char* s, uint8_t n) { uint8_t c = 0; for (uint8_t i = 0; i < n; i++) c ^= (uint8_t)s[i]; return c; }

// Approach = the side the vehicle is coming FROM: bearing from junction to vehicle.
uint8_t approachFromBearing(double bearingFromJunction) {
  // 0 N (315..45), 1 E (45..135), 2 S (135..225), 3 W (225..315)
  double b = fmod(bearingFromJunction + 45.0 + 360.0, 360.0);
  return (uint8_t)(b / 90.0) & 3;
}

void handleBeacon(char* body) {
  // body: EV,<id>,<lat>,<lon>,<kmh>,<course>,<age>
  char* tok[7]; uint8_t n = 0;
  for (char* p = strtok(body, ","); p && n < 7; p = strtok(NULL, ",")) tok[n++] = p;
  if (n < 6 || strcmp(tok[0], "EV") != 0) return;
  beacons++;
  const double lat = atof(tok[2]), lon = atof(tok[3]), kmh = atof(tok[4]), course = atof(tok[5]);
  const double dist = TinyGPSPlus::distanceBetween(lat, lon, JUNCTION_LAT, JUNCTION_LON);
  const double toJunction = TinyGPSPlus::courseTo(lat, lon, JUNCTION_LAT, JUNCTION_LON);
  const double fromJunction = TinyGPSPlus::courseTo(JUNCTION_LAT, JUNCTION_LON, lat, lon);
  double headErr = fabs(course - toJunction); if (headErr > 180) headErr = 360 - headErr;
  const double eta = (kmh > MIN_SPEED_KMH) ? dist / (kmh / 3.6) : 1e9;
  const uint8_t approach = approachFromBearing(fromJunction);
  Serial.print(F("[gps] ")); Serial.print(tok[1]); Serial.print(F(" d=")); Serial.print(dist, 0);
  Serial.print(F(" m v=")); Serial.print(kmh, 0); Serial.print(F(" km/h eta=")); Serial.print(eta, 0);
  Serial.print(F(" s approach=")); Serial.print(APPROACH_NAME[approach]); Serial.print(F(" headErr=")); Serial.println(headErr, 0);
  const uint32_t now = millis();
  if (dist <= GEOFENCE_M && headErr <= HEADING_TOL_DEG && eta <= ETA_TRIGGER_S) {
    if (strcmp(tok[1], lastVehicle) != 0 || now - lastRequestMs >= REPEAT_REQUEST_MS) {
      strncpy(lastVehicle, tok[1], sizeof(lastVehicle) - 1);
      lastRequestMs = now;
      requests++;
      Serial.print(F("[EV] priority request for approach ")); Serial.println(APPROACH_NAME[approach]);
      ctrl.evDetected(approach, now, (uint32_t)(eta * 1000.0));
    }
  }
}

void pollRadio() {
  while (radio.available()) {
    char c = radio.read();
    if (c == '\n' || c == '\r') {
      line[lineLen] = 0;
      if (lineLen > 4 && line[0] == '$') {
        char* star = strchr(line, '*');
        if (star) {
          *star = 0;
          uint8_t want = (uint8_t)strtol(star + 1, NULL, 16);
          if (xorChecksum(line + 1, strlen(line + 1)) == want) handleBeacon(line + 1);
          else Serial.println(F("[radio] checksum error"));
        }
      }
      lineLen = 0;
    } else if (lineLen < sizeof(line) - 1) {
      line[lineLen++] = c;
    }
  }
}

void applyLights() {
  Light ns, ew; ctrl.lights(ns, ew);
  for (uint8_t a = 0; a < 4; a++) {
    Light l = (approachToGroup(a) == GROUP_NS) ? ns : ew;
    digitalWrite(LED_PINS[a][0], l == RED); digitalWrite(LED_PINS[a][1], l == YELLOW); digitalWrite(LED_PINS[a][2], l == GREEN);
  }
}

void setup() {
  Serial.begin(115200);
  radio.begin(9600);
  for (uint8_t a = 0; a < 4; a++) for (uint8_t c = 0; c < 3; c++) pinMode(LED_PINS[a][c], OUTPUT);
  ctrl.begin(millis());
  Serial.println(F("\n=== EV-priority controller, GPS/HC-12 variant ==="));
}

void loop() {
  static Phase last = GREEN_NS;
  pollRadio();
  ctrl.tick(millis());
  applyLights();
  if (ctrl.phase != last) {
    last = ctrl.phase;
    Serial.print('['); Serial.print(millis() / 1000); Serial.print(F(" s] phase ")); Serial.print((int)ctrl.phase);
    Serial.print(F(" beacons=")); Serial.print(beacons); Serial.print(F(" requests=")); Serial.print(requests);
    Serial.print(F(" preemptions=")); Serial.println(ctrl.preemptions);
  }
  delay(5);
}
