/*
 * vehicle_gps_beacon.ino - EV-side beacon: NEO-6M GPS + HC-12 433 MHz radio.
 *
 * EV Internship Project 08 - Codec Technologies India - Eswar Mahalingam, Sept 2026
 *
 * Every BEACON_MS the vehicle broadcasts
 *   $EV,<vehicle id>,<lat>,<lon>,<speed km/h>,<course deg>,<age ms>*<xor checksum>\n
 * The intersection controller (controller_gps_receiver) geofences the message
 * and predicts the arrival time. HC-12 defaults: 9600 baud, channel 1, 100 mW.
 *
 * Wiring (Arduino Uno / Nano):
 *   NEO-6M TX -> D4, RX -> D3 (SoftwareSerial, 9600)     VCC 5 V (module has LDO), GND
 *   HC-12  RX -> D1 (TX), TX -> D0 (RX): hardware Serial, 9600   VCC 5 V (add 100 uF), GND
 *   (unplug HC-12 from D0/D1 while flashing over USB)
 * Library: TinyGPSPlus (Mikal Hart). Compile-checked, not run on hardware.
 */
#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>

static const char* VEHICLE_ID = "EV042";
static const uint32_t BEACON_MS = 1000;
static const uint8_t GPS_RX_PIN = 4, GPS_TX_PIN = 3;

SoftwareSerial gpsSerial(GPS_RX_PIN, GPS_TX_PIN);
TinyGPSPlus gps;
uint32_t lastBeacon = 0;

uint8_t xorChecksum(const char* s) { uint8_t c = 0; while (*s) c ^= (uint8_t)*s++; return c; }

void setup() {
  Serial.begin(9600);      // HC-12
  gpsSerial.begin(9600);   // NEO-6M default
}

void loop() {
  while (gpsSerial.available()) gps.encode(gpsSerial.read());
  const uint32_t now = millis();
  if (now - lastBeacon < BEACON_MS) return;
  lastBeacon = now;
  if (!gps.location.isValid()) {
    Serial.println(F("$EV,NOFIX*00"));   // keeps the link alive; receiver ignores it
    return;
  }
  char body[96];
  char lat[16], lon[16], spd[10], crs[10];
  dtostrf(gps.location.lat(), 1, 6, lat);
  dtostrf(gps.location.lng(), 1, 6, lon);
  dtostrf(gps.speed.kmph(), 1, 1, spd);
  dtostrf(gps.course.deg(), 1, 0, crs);
  snprintf(body, sizeof(body), "EV,%s,%s,%s,%s,%s,%lu", VEHICLE_ID, lat, lon, spd, crs, (unsigned long)gps.location.age());
  Serial.print('$'); Serial.print(body); Serial.print('*');
  uint8_t ck = xorChecksum(body);
  if (ck < 0x10) Serial.print('0');
  Serial.println(ck, HEX);
}
