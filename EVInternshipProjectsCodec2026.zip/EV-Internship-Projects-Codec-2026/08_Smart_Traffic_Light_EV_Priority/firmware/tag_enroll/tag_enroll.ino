/*
 * tag_enroll.ino - write EV RFID tag UIDs into the Uno's EEPROM whitelist.
 *
 * EV Internship Project 08 - Codec Technologies India - Eswar Mahalingam, Sept 2026
 *
 * Wiring: one MFRC522 on SPI (SS 10, RST 9, MOSI 11, MISO 12, SCK 13, 3.3 V!).
 * Serial monitor at 115200:
 *   present a tag  -> its UID is appended to the list (max 16)
 *   'l'            -> list stored tags
 *   'c'            -> clear the list
 *   'w'            -> write list to EEPROM (layout: 'E','V',count, count x 7 bytes)
 * The main sketch (arduino_ev_priority) reads this layout at boot.
 * Compile-checked, not run on hardware.
 */
#include <SPI.h>
#include <EEPROM.h>
#include <MFRC522.h>

static const uint8_t UID_LEN = 7, MAX_TAGS = 16;
MFRC522 rfid(10, 9);
uint8_t tags[MAX_TAGS][UID_LEN];
uint8_t count = 0;

void printUid(const uint8_t* u) {
  for (uint8_t i = 0; i < UID_LEN; i++) { if (u[i] < 0x10) Serial.print('0'); Serial.print(u[i], HEX); if (i < UID_LEN - 1) Serial.print(':'); }
}

void loadFromEeprom() {
  if (EEPROM.read(0) == 'E' && EEPROM.read(1) == 'V' && EEPROM.read(2) <= MAX_TAGS) {
    count = EEPROM.read(2);
    for (uint8_t i = 0; i < count; i++)
      for (uint8_t b = 0; b < UID_LEN; b++) tags[i][b] = EEPROM.read(3 + i * UID_LEN + b);
  }
}

void writeToEeprom() {
  EEPROM.update(0, 'E'); EEPROM.update(1, 'V'); EEPROM.update(2, count);
  for (uint8_t i = 0; i < count; i++)
    for (uint8_t b = 0; b < UID_LEN; b++) EEPROM.update(3 + i * UID_LEN + b, tags[i][b]);
  Serial.print(F("[eeprom] wrote ")); Serial.print(count); Serial.println(F(" tag(s)"));
}

void listTags() {
  Serial.print(F("[list] ")); Serial.print(count); Serial.println(F(" tag(s):"));
  for (uint8_t i = 0; i < count; i++) { Serial.print("  "); Serial.print(i); Serial.print(": "); printUid(tags[i]); Serial.println(); }
}

void setup() {
  Serial.begin(115200);
  SPI.begin();
  rfid.PCD_Init();
  Serial.println(F("\n=== EV tag enrolment ===  present tag | l list | c clear | w write"));
  Serial.print(F("[rfid] version 0x")); Serial.println(rfid.PCD_ReadRegister(MFRC522::VersionReg), HEX);
  loadFromEeprom();
  listTags();
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'l') listTags();
    else if (c == 'c') { count = 0; Serial.println(F("[list] cleared (not yet written)")); }
    else if (c == 'w') writeToEeprom();
  }
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  uint8_t uid[UID_LEN] = {0};
  memcpy(uid, rfid.uid.uidByte, rfid.uid.size > UID_LEN ? UID_LEN : rfid.uid.size);
  rfid.PICC_HaltA();
  for (uint8_t i = 0; i < count; i++)
    if (memcmp(uid, tags[i], UID_LEN) == 0) { Serial.print(F("[tag] already enrolled: ")); printUid(uid); Serial.println(); delay(1000); return; }
  if (count >= MAX_TAGS) { Serial.println(F("[tag] list full")); return; }
  memcpy(tags[count++], uid, UID_LEN);
  Serial.print(F("[tag] enrolled #")); Serial.print(count - 1); Serial.print(' '); printUid(uid); Serial.println(F("  (press w to save)"));
  delay(1000);
}
