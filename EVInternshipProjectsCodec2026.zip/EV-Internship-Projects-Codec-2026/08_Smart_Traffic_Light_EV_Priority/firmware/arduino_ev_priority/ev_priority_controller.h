// ev_priority_controller.h - signal-controller state machine with EV priority.
//
// EV Internship Project 08 - Codec Technologies India - Eswar Mahalingam, Sept 2026
//
// Pure logic, no hardware calls, so the exact same behaviour can be ported to
// simulation/ev_priority/controller.py (the Python file mirrors this one
// function by function and the tests check that the timing constants match).
//
// Intersection model: 4 approaches N(0) E(1) S(2) W(3) grouped into two signal
// groups: NS = group 0 (approaches N and S), EW = group 1 (E and W).
//
// Phases:  GREEN_NS -> YELLOW_NS -> ALLRED_NS -> GREEN_EW -> YELLOW_EW -> ALLRED_EW -> GREEN_NS ...
//
// Priority rules:
//  * Every detection carries an ETA (ms until the EV reaches the stop line):
//    a fixed RFID_ETA_MS for a reader at a known distance, or the GPS estimate.
//  * EV detected on the group that is currently green  -> extend that green so
//    it lasts until max(now + EV_HOLD_MS, arrival + EV_CLEAR_MS), but never
//    beyond GREEN_NORMAL_MS + EV_EXT_MAX_MS.
//  * EV detected on the other group -> cut the current green once it has run
//    GREEN_MIN_MS *and* the cut is due (arrival - clearance - EV_LEAD_MS), go
//    through the normal yellow + all-red clearance, then give the EV group a
//    green long enough to cover the arrival (at least EV_HOLD_MS, extendable).
//  * Fairness guard: a group whose previous green was cut short cannot be cut
//    again on its next green (no two consecutive cuts).
//  * Starvation guard: a group that has been red for STARVE_RED_MS or longer
//    gets an uncuttable green of at least GREEN_NORMAL_MS.
//  * A request that is not served within EV_REQ_TIMEOUT_MS is dropped (the EV
//    turned off or was mis-read).
#pragma once
#include <stdint.h>

// ---------------- timing constants (ms) - mirrored in controller.py ----------------
#define GREEN_MIN_MS        10000UL   // minimum green before it may be cut
#define GREEN_NORMAL_MS     30000UL   // fixed-time green
#define YELLOW_MS            3000UL
#define ALLRED_MS            2000UL   // all-red clearance after every yellow
#define EV_HOLD_MS          15000UL   // green granted / extended for an EV
#define EV_EXT_MAX_MS       20000UL   // max extension beyond GREEN_NORMAL_MS
#define STARVE_RED_MS       60000UL   // red this long -> next green locked
#define EV_REQ_TIMEOUT_MS   30000UL   // unserved request expires
#define EV_CLEAR_MS          5000UL   // keep green this long after the predicted arrival
#define EV_LEAD_MS           3000UL   // green should be showing this long before arrival
#define RFID_ETA_MS          8000UL   // reader ~100 m upstream at ~45 km/h

enum Phase : uint8_t { GREEN_NS = 0, YELLOW_NS, ALLRED_NS, GREEN_EW, YELLOW_EW, ALLRED_EW };
enum Light : uint8_t { RED = 0, YELLOW = 1, GREEN = 2 };
enum Group : uint8_t { GROUP_NS = 0, GROUP_EW = 1 };

static inline uint8_t approachToGroup(uint8_t approach) { return (approach == 0 || approach == 2) ? GROUP_NS : GROUP_EW; }

struct EvPriorityController {
  // --- configuration
  bool priorityEnabled = true;      // false -> plain fixed-time controller (baseline)

  // --- state
  Phase phase = GREEN_NS;
  uint32_t phaseStart = 0;
  uint32_t greenEnd = 0;            // planned end of the current green
  bool evRequest[2] = {false, false};
  uint32_t evRequestTime[2] = {0, 0};
  uint32_t evArrival[2] = {0, 0};   // predicted stop-line arrival of the requesting EV
  bool preemptPending = false;      // next green is an EV green
  uint32_t pendingArrival = 0;
  bool greenLocked = false;         // starvation guard active for current green
  uint32_t evProtectUntil = 0;      // current green may not be cut before this (an EV is due)
  bool lastGreenCut[2] = {false, false};
  bool currentGreenCut = false;
  uint32_t redSince[2] = {0, 0};

  // --- statistics
  uint32_t preemptions = 0;         // greens cut short for an EV
  uint32_t extensions = 0;          // greens extended for an EV
  uint32_t deniedRequests = 0;      // requests refused by fairness/starvation guard (served later or expired)
  uint32_t expiredRequests = 0;

  void begin(uint32_t now) {
    phase = GREEN_NS; phaseStart = now; greenEnd = now + GREEN_NORMAL_MS;
    redSince[GROUP_NS] = now; redSince[GROUP_EW] = now;
    evRequest[0] = evRequest[1] = false; preemptPending = false; pendingArrival = 0; greenLocked = false; evProtectUntil = now;
    lastGreenCut[0] = lastGreenCut[1] = false; currentGreenCut = false;
    preemptions = extensions = deniedRequests = expiredRequests = 0;
  }

  // Called by the detector layer (RFID read or GPS geofence) for an approach 0..3.
  // etaMs = predicted time until the EV reaches the stop line.
  void evDetected(uint8_t approach, uint32_t now, uint32_t etaMs = RFID_ETA_MS) {
    if (!priorityEnabled) return;
    uint8_t g = approachToGroup(approach);
    uint32_t arrival = now + etaMs;
    // keep the earliest arrival if a request is already pending for this group
    if (!evRequest[g] || (int32_t)(arrival - evArrival[g]) < 0) evArrival[g] = arrival;
    evRequest[g] = true;
    evRequestTime[g] = now;
  }

  static uint32_t clampGreen(uint32_t phaseStart_, uint32_t want) {
    const uint32_t cap = phaseStart_ + GREEN_NORMAL_MS + EV_EXT_MAX_MS;
    return (int32_t)(want - cap) > 0 ? cap : want;
  }

  uint8_t greenGroup() const { return (phase <= ALLRED_NS) ? GROUP_NS : GROUP_EW; }
  bool isGreen() const { return phase == GREEN_NS || phase == GREEN_EW; }

  // Lights for the two groups.
  void lights(Light& ns, Light& ew) const {
    ns = RED; ew = RED;
    switch (phase) {
      case GREEN_NS:  ns = GREEN;  break;
      case YELLOW_NS: ns = YELLOW; break;
      case GREEN_EW:  ew = GREEN;  break;
      case YELLOW_EW: ew = YELLOW; break;
      default: break;              // all-red
    }
  }

  void tick(uint32_t now) {
    // expire stale requests
    for (uint8_t g = 0; g < 2; g++) {
      if (evRequest[g] && (uint32_t)(now - evRequestTime[g]) >= EV_REQ_TIMEOUT_MS) {
        evRequest[g] = false; expiredRequests++;
      }
    }
    const uint32_t elapsed = now - phaseStart;
    switch (phase) {
      case GREEN_NS:
      case GREEN_EW: {
        const uint8_t g = greenGroup();
        const uint8_t other = 1 - g;
        // (a) same-direction EV: extend so the green covers the arrival
        if (evRequest[g]) {
          uint32_t want = now + EV_HOLD_MS;
          const uint32_t cover = evArrival[g] + EV_CLEAR_MS;
          if ((int32_t)(cover - want) > 0) want = cover;
          want = clampGreen(phaseStart, want);
          if ((int32_t)(want - greenEnd) > 0) { greenEnd = want; extensions++; }
          if ((int32_t)(evArrival[g] - evProtectUntil) > 0) evProtectUntil = evArrival[g];
          evRequest[g] = false;
        }
        // (b) cross-direction EV: cut when it is due and allowed
        if (evRequest[other]) {
          const uint32_t dueAt = evArrival[other] - (YELLOW_MS + ALLRED_MS) - EV_LEAD_MS;
          const bool due = (int32_t)(now - dueAt) >= 0;
          if (due && elapsed >= GREEN_MIN_MS) {
            const bool allowed = !greenLocked && !lastGreenCut[g] && (int32_t)(now - evProtectUntil) >= 0;
            if (allowed) {
              if ((int32_t)(greenEnd - now) > 0) { greenEnd = now; currentGreenCut = true; preemptions++; }
            } else {
              deniedRequests++;               // guard refused the cut; served at the natural end instead
            }
            preemptPending = true;
            pendingArrival = evArrival[other];
            evRequest[other] = false;
          }
          // not yet due: the request stays pending; if the green ends naturally first the
          // EV group gets its normal green and the request is handled as a same-direction extension
        }
        if ((int32_t)(now - greenEnd) >= 0) {
          lastGreenCut[g] = currentGreenCut;
          currentGreenCut = false;
          phase = (phase == GREEN_NS) ? YELLOW_NS : YELLOW_EW;
          phaseStart = now;
        }
        break;
      }
      case YELLOW_NS:
      case YELLOW_EW:
        if (elapsed >= YELLOW_MS) {
          phase = (phase == YELLOW_NS) ? ALLRED_NS : ALLRED_EW;
          phaseStart = now;
        }
        break;
      case ALLRED_NS:
      case ALLRED_EW:
        if (elapsed >= ALLRED_MS) {
          const uint8_t leaving = greenGroup();
          const uint8_t entering = 1 - leaving;
          const uint32_t redWait = now - redSince[entering];
          greenLocked = priorityEnabled && redWait >= STARVE_RED_MS;
          uint32_t duration = GREEN_NORMAL_MS;
          const bool preemptWasPending = preemptPending;
          if (preemptPending) {                           // EV green: cover the predicted arrival
            duration = EV_HOLD_MS;
            const uint32_t need = pendingArrival + EV_CLEAR_MS;
            if ((int32_t)(need - (now + duration)) > 0) duration = need - now;
            if (duration > GREEN_NORMAL_MS + EV_EXT_MAX_MS) duration = GREEN_NORMAL_MS + EV_EXT_MAX_MS;
          }
          if (greenLocked && duration < GREEN_NORMAL_MS) duration = GREEN_NORMAL_MS;
          preemptPending = false;
          phase = (entering == GROUP_NS) ? GREEN_NS : GREEN_EW;
          phaseStart = now;
          greenEnd = now + duration;
          evProtectUntil = preemptWasPending ? pendingArrival : now;
          redSince[leaving] = now;
        }
        break;
    }
  }
};
