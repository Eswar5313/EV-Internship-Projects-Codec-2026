/*
 * arduino_ev_priority.ino - smart traffic light with EV priority (Arduino Uno)
 *
 * EV Internship Project 08 - Codec Technologies India
 * Author: Eswar Mahalingam, September 2026
 *
 * Hardware
 *   4 approaches x (R,Y,G) LEDs = 12 LEDs with 220 ohm resistors
 *   MFRC522 RFID readers on the shared SPI bus (MOSI 11, MISO 12, SCK 13),
 *   one per priority approach - 2 fitted in this build (N and E), see README
 *   for the 74HC595 option that frees pins for all four.
 *   EV tag whitelist in EEPROM (written by firmware/tag_enroll) with a
 *   PROGMEM fallback list.
 *
 * Logic lives in ev_priority_controller.h (shared with the Python simulation).
 *
 * Build flags
 *   USE_RFID 1  - real MFRC522 readers (default)
 *   USE_RFID 0  - Wokwi / bench demo: push buttons on the reader SS pins and
 *                 serial commands n/e/s/w inject EV detections
 *
 * Compile-checked with arduino-cli (arduino:avr 1.8.8, MFRC522 1.4.x) but NOT
 * run on a physical board during the internship - see README.
 */

#include <Arduino.h>
#include <EEPROM.h>
#include <SPI.h>
#include "ev_priority_controller.h"

#ifndef USE_RFID
#define USE_RFID 1
#endif
#if USE_RFID
#include <MFRC522.h>
#endif

// ---------------------------------------------------------------------------
// Pin map (Uno). Analog pins are used as digital outputs for the E/W LEDs.
// ---------------------------------------------------------------------------
static const uint8_t LED_PINS[4][3] = {   // [approach][R,Y,G]
  {2, 3, 4},        // N
  {8, A0, A1},      // E
  {5, 6, 7},        // S
  {A2, A3, A4},     // W
};
static const char* APPROACH_NAME[4] = {"N", "E", "S", "W"};

// RFID readers: {SS pin, approach served}. RST shared on pin 9.
static const uint8_t NUM_READERS = 2;
static const uint8_t READER_SS[NUM_READERS] = {10, A5};
static const uint8_t READER_APPROACH[NUM_READERS] = {0, 1};   // N, E
static const uint8_t RFID_RST_PIN = 9;

// ---------------------------------------------------------------------------
// EV tag whitelist: EEPROM layout  [0]='E' [1]='V' [2]=count [3..] count x 7 bytes (UID padded)
// ---------------------------------------------------------------------------
static const uint8_t UID_LEN = 7;
static const uint8_t MAX_TAGS = 16;
static const uint8_t DEFAULT_TAGS[][UID_LEN] PROGMEM = {   // replaced by EEPROM list if present
  {0xDE, 0xAD, 0xBE, 0xEF, 0x00, 0x00, 0x00},   // example 4-byte UID, padded
  {0x04, 0x52, 0x1A, 0x7B, 0x2C, 0x5E, 0x80},   // example 7-byte UID
};
uint8_t tags[MAX_TAGS][UID_LEN];
uint8_t tagCount = 0;

void loadWhitelist() {
  if (EEPROM.read(0) == 'E' && EEPROM.read(1) == 'V' && EEPROM.read(2) <= MAX_TAGS) {
    tagCount = EEPROM.read(2);
    for (uint8_t i = 0; i < tagCount; i++)
      for (uint8_t b = 0; b < UID_LEN; b++) tags[i][b] = EEPROM.read(3 + i * UID_LEN + b);
    Serial.print(F("[whitelist] ")); Serial.print(tagCount); Serial.println(F(" tag(s) from EEPROM"));
  } else {
    tagCount = sizeof(DEFAULT_TAGS) / UID_LEN;
    for (uint8_t i = 0; i < tagCount; i++)
      memcpy_P(tags[i], DEFAULT_TAGS[i], UID_LEN);
    Serial.print(F("[whitelist] ")); Serial.print(tagCount); Serial.println(F(" default tag(s) from PROGMEM (run tag_enroll to change)"));
  }
}

bool isWhitelisted(const uint8_t* uid, uint8_t len) {
  uint8_t padded[UID_LEN] = {0};
  memcpy(padded, uid, len > UID_LEN ? UID_LEN : len);
  for (uint8_t i = 0; i < tagCount; i++)
    if (memcmp(padded, tags[i], UID_LEN) == 0) return true;
  return false;
}

// ---------------------------------------------------------------------------
// Detection layer
// ---------------------------------------------------------------------------
#if USE_RFID
MFRC522 readers[NUM_READERS] = { MFRC522(READER_SS[0], RFID_RST_PIN), MFRC522(READER_SS[1], RFID_RST_PIN) };
#endif
static const uint32_t TAG_DEBOUNCE_MS = 5000;   // same tag on same reader ignored for 5 s
uint8_t lastUid[NUM_READERS][UID_LEN];
uint32_t lastUidTime[NUM_READERS];

EvPriorityController ctrl;
uint32_t evDetections = 0, rejectedTags = 0;

void reportDetection(uint8_t approach, const char* how) {
  evDetections++;
  Serial.print(F("[EV] detected on ")); Serial.print(APPROACH_NAME[approach]);
  Serial.print(F(" via ")); Serial.println(how);
  ctrl.evDetected(approach, millis(), RFID_ETA_MS);
}

void pollDetectors() {
  const uint32_t now = millis();
#if USE_RFID
  for (uint8_t r = 0; r < NUM_READERS; r++) {
    // one reader at a time on the shared bus: the library asserts/deasserts SS itself
    if (!readers[r].PICC_IsNewCardPresent() || !readers[r].PICC_ReadCardSerial()) continue;
    const uint8_t* uid = readers[r].uid.uidByte;
    const uint8_t len = readers[r].uid.size;
    readers[r].PICC_HaltA();
    bool same = memcmp(uid, lastUid[r], len) == 0 && (now - lastUidTime[r]) < TAG_DEBOUNCE_MS;
    memcpy(lastUid[r], uid, len); lastUidTime[r] = now;
    if (same) continue;
    Serial.print(F("[rfid] reader ")); Serial.print(r); Serial.print(F(" UID "));
    for (uint8_t i = 0; i < len; i++) { if (uid[i] < 0x10) Serial.print('0'); Serial.print(uid[i], HEX); }
    if (isWhitelisted(uid, len)) reportDetection(READER_APPROACH[r], "RFID");
    else { rejectedTags++; Serial.println(F(" - not an EV tag")); }
  }
#else
  // demo inputs: active-low buttons on the reader SS pins
  static uint32_t lastPress[NUM_READERS] = {0, 0};
  for (uint8_t r = 0; r < NUM_READERS; r++) {
    if (digitalRead(READER_SS[r]) == LOW && now - lastPress[r] > 500) {
      lastPress[r] = now;
      reportDetection(READER_APPROACH[r], "button");
    }
  }
#endif
  // serial commands work in both builds (useful for bench tests and the GPS receiver bridge)
  while (Serial.available()) {
    char c = Serial.read();
    switch (c) {
      case 'n': case 'N': reportDetection(0, "serial"); break;
      case 'e': case 'E': reportDetection(1, "serial"); break;
      case 's': case 'S': reportDetection(2, "serial"); break;
      case 'w': case 'W': reportDetection(3, "serial"); break;
      case 'p': ctrl.priorityEnabled = !ctrl.priorityEnabled;
                Serial.print(F("[ctrl] priority ")); Serial.println(ctrl.priorityEnabled ? F("ON") : F("OFF (baseline)")); break;
      case '?': printStats(); break;
      default: break;
    }
  }
}

// ---------------------------------------------------------------------------
// Output layer
// ---------------------------------------------------------------------------
void applyLights() {
  Light ns, ew;
  ctrl.lights(ns, ew);
  for (uint8_t a = 0; a < 4; a++) {
    Light l = (approachToGroup(a) == GROUP_NS) ? ns : ew;
    digitalWrite(LED_PINS[a][0], l == RED    ? HIGH : LOW);
    digitalWrite(LED_PINS[a][1], l == YELLOW ? HIGH : LOW);
    digitalWrite(LED_PINS[a][2], l == GREEN  ? HIGH : LOW);
  }
}

const char* phaseName(Phase p) {
  switch (p) {
    case GREEN_NS: return "GREEN_NS"; case YELLOW_NS: return "YELLOW_NS"; case ALLRED_NS: return "ALLRED_NS";
    case GREEN_EW: return "GREEN_EW"; case YELLOW_EW: return "YELLOW_EW"; case ALLRED_EW: return "ALLRED_EW";
  }
  return "?";
}

void printStats() {
  Serial.print(F("[stats] detections=")); Serial.print(evDetections);
  Serial.print(F(" rejected=")); Serial.print(rejectedTags);
  Serial.print(F(" preemptions=")); Serial.print(ctrl.preemptions);
  Serial.print(F(" extensions=")); Serial.print(ctrl.extensions);
  Serial.print(F(" denied=")); Serial.print(ctrl.deniedRequests);
  Serial.print(F(" expired=")); Serial.println(ctrl.expiredRequests);
}

// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  Serial.println(F("\n=== EV-priority traffic controller (Codec EV internship, E. Mahalingam) ==="));
  for (uint8_t a = 0; a < 4; a++)
    for (uint8_t c = 0; c < 3; c++) { pinMode(LED_PINS[a][c], OUTPUT); digitalWrite(LED_PINS[a][c], LOW); }
  loadWhitelist();
#if USE_RFID
  SPI.begin();
  for (uint8_t r = 0; r < NUM_READERS; r++) {
    readers[r].PCD_Init();
    Serial.print(F("[rfid] reader ")); Serial.print(r); Serial.print(F(" (approach "));
    Serial.print(APPROACH_NAME[READER_APPROACH[r]]); Serial.print(F(") version 0x"));
    Serial.println(readers[r].PCD_ReadRegister(MFRC522::VersionReg), HEX);   // 0x91/0x92 = OK, 0x00/0xFF = wiring fault
  }
#else
  for (uint8_t r = 0; r < NUM_READERS; r++) pinMode(READER_SS[r], INPUT_PULLUP);
  Serial.println(F("[demo] USE_RFID=0: buttons on pins 10 / A5, serial n/e/s/w inject EVs, p toggles priority, ? stats"));
#endif
  ctrl.begin(millis());
  applyLights();
  Serial.println(F("[ctrl] GREEN_NS"));
}

void loop() {
  static Phase lastPhase = GREEN_NS;
  static uint32_t lastLog = 0;
  pollDetectors();
  const uint32_t now = millis();
  ctrl.tick(now);
  applyLights();
  if (ctrl.phase != lastPhase) {
    lastPhase = ctrl.phase;
    Serial.print('['); Serial.print(now / 1000); Serial.print(F(" s] "));
    Serial.print(phaseName(ctrl.phase));
    if (ctrl.isGreen()) {
      Serial.print(F(" for ")); Serial.print((ctrl.greenEnd - now) / 1000); Serial.print(F(" s"));
      if (ctrl.greenLocked) Serial.print(F(" [starvation lock]"));
    }
    Serial.println();
  }
  if (now - lastLog >= 60000UL) { lastLog = now; printStats(); }
  delay(5);
}
