# Wiring - EV-priority traffic controller (Arduino Uno)

Not assembled during the internship (no hardware available); this is what the firmware expects.

## LEDs (12, each through 220 ohm to GND)

| Approach | Red | Yellow | Green |
|---|---|---|---|
| N | D2 | D3 | D4 |
| S | D5 | D6 | D7 |
| E | D8 | A0 | A1 |
| W | A2 | A3 | A4 |

N and S share a signal group (always identical), E and W share the other.

## MFRC522 RFID readers (3.3 V logic and supply)

| MFRC522 pin | Reader 0 (approach N) | Reader 1 (approach E) |
|---|---|---|
| SDA / SS | D10 | A5 |
| SCK | D13 | D13 |
| MOSI | D11 | D11 |
| MISO | D12 | D12 |
| RST | D9 | D9 (shared) |
| 3.3V | 3.3V | 3.3V |
| GND | GND | GND |

The Uno's 3.3 V pin can supply ~50 mA; each MFRC522 draws 13-26 mA, so two readers are fine.
The readers share MOSI/MISO/SCK; the library asserts each SS in turn. Mount a reader 80-120 m
upstream of the stop line (RFID_ETA_MS = 8 s assumes ~45 km/h) in the EV lane; range of the
MFRC522 is only a few cm, so in practice the tag is read from a reader mounted at windscreen
height on a gantry/pole with the tag on the dash, or replaced by a UHF (860-960 MHz) reader for
several metres of range - same serial interface idea, different library.

## All four approaches with readers
The Uno runs out of pins with 12 LEDs + 4 SS lines. Drive the 12 LEDs from two daisy-chained
74HC595 shift registers (3 pins: data, clock, latch) which frees D2-D8 and A0-A4 for four SS
lines and the buttons. `applyLights()` is the only function that changes.

## GPS variant
Vehicle (Nano): NEO-6M TX -> D4, RX -> D3 (SoftwareSerial 9600); HC-12 on D0/D1 (hardware
serial, 9600). Controller: HC-12 TX -> D10, RX -> D9 (SoftwareSerial), LEDs as above.
Both HC-12 must be on the same channel (AT+C001 default) and baud (9600).

```
   [tag on EV] ~~~ MFRC522 (N) --SPI--+                +-- 12 x LED/220R (N,S,E,W)
   [tag on EV] ~~~ MFRC522 (E) --SPI--+--> Arduino Uno +-- Serial 115200 log
                                                       +-- EEPROM whitelist (tag_enroll)
   NEO-6M --> Nano --> HC-12 ))) 433 MHz ((( HC-12 --> Uno (GPS variant)
```
