# Smart Traffic Light with EV Priority

**EV Internship Project 08 - Codec Technologies India**
**Author:** Eswar Mahalingam | **Date:** September 2026

> **Honesty note.** No Arduino, RFID reader or GPS module was available to me during the
> internship, so **nothing in this folder has run on physical hardware**. The firmware is
> compile-checked with `arduino-cli` against the official `arduino:avr` core, and the
> controller logic was ported line-for-line to Python and exercised in a discrete-event traffic
> simulation (SimPy). The controller can also be run in the free browser simulator Wokwi
> (`wokwi/`). **Every number in `results/` comes from the simulation model, not from traffic
> measurements.**

---

## 1. Overview

Task brief: *"Develop a smart traffic system that gives priority to EVs. Use Arduino with RFID
tags or GPS modules. Identify EVs approaching intersections. Change traffic light logic
dynamically."*

| Part | What I built | Where |
|---|---|---|
| Controller firmware | Arduino Uno, 4-approach intersection (N/E/S/W) with 12 LEDs, two MFRC522 RFID readers on shared SPI (N and E approaches; 74HC595 note for four), EV tag whitelist in EEPROM with PROGMEM fallback, tag debounce, serial logging, `p` toggles priority for A/B tests. | `firmware/arduino_ev_priority/` |
| Shared state machine | `ev_priority_controller.h` - pure logic (no hardware calls): fixed-time cycle -> EV request -> safe transition (yellow + all-red) -> ETA-timed green for the EV approach with a max-extension cap, a fairness guard and a starvation guard. | `firmware/arduino_ev_priority/ev_priority_controller.h` |
| Tag enrolment | Reads tag UIDs and writes the whitelist to EEPROM. | `firmware/tag_enroll/` |
| GPS variant | Vehicle beacon (Nano + NEO-6M + HC-12 radio, `$EV,...*ck` messages) and a receiver-side controller that geofences the vehicle, derives its approach from the bearing and its ETA from speed/distance, and calls the same state machine. | `firmware/gps_variant/` |
| Simulation | `controller.py` = Python port of the header (constants asserted equal by a test); `traffic_sim.py` = SimPy intersection with Poisson arrivals, queues and saturation-flow discharge; `run_experiments.py` = 1 h x 10 seeds x EV share {5, 10, 20, 40} % x {baseline, RFID priority, GPS priority}. | `simulation/` |
| Wokwi | `diagram.json` (Uno + 12 LEDs + 2 buttons standing in for the readers) + instructions. | `wokwi/` |
| Tests | 26 pytest cases: safety invariants, guards, ETA timing, firmware/Python parity, delay improvement. | `tests/` |

## 2. Architecture

```
  EV tag ~~~ MFRC522 reader (N)  --SPI--+
  EV tag ~~~ MFRC522 reader (E)  --SPI--+        +----------------------------------+      12 x LED
  [GPS variant]                          +------> |  Arduino Uno                     | ---> N  R Y G
  NEO-6M -> Nano -> HC-12 )))  ((( HC-12 -SoftSer-|  detection layer -> evDetected() |      E  R Y G
                                                  |  EvPriorityController::tick()    |      S  R Y G
  serial monitor: n/e/s/w inject EVs, p, ? -----> |  applyLights(), serial log       |      W  R Y G
                                                  +----------------------------------+
                                                             ^  same header, ported to Python
                                                  +----------------------------------+
                                                  |  simulation/controller.py        |
                                                  |  simulation/traffic_sim.py (SimPy)|
                                                  +----------------------------------+
```

### State machine (`ev_priority_controller.h`)

```
 GREEN_NS (30 s) -> YELLOW_NS (3 s) -> ALLRED_NS (2 s) -> GREEN_EW (30 s) -> YELLOW_EW -> ALLRED_EW -> GREEN_NS ...
```

* Every detection carries an **ETA** to the stop line: `RFID_ETA_MS` = 8 s for a reader ~100 m
  upstream at 45 km/h, or the GPS estimate `distance / speed`.
* **Same-direction EV** (its group is green): extend the green to
  `max(now + 15 s, arrival + 5 s)`, never beyond `30 s + 20 s` after the green started.
* **Cross-direction EV**: once the green has run `GREEN_MIN` = 10 s *and* the cut is due
  (`arrival - 5 s clearance - 3 s lead`), end the green now; yellow 3 s, all-red 2 s, then the EV
  group gets a green long enough to cover the arrival (at least 15 s, extendable, capped at 50 s).
  A green that is protecting an EV that has not arrived yet cannot be cut.
* **Fairness guard**: a group whose previous green was cut cannot be cut again on its next green
  (no two consecutive cuts) - the EV is served at the natural end instead (`deniedRequests`).
* **Starvation guard**: a group that has been red >= 60 s gets an uncuttable green >= 30 s.
* Requests unserved after 30 s expire. Result: a group is never without green for longer than
  `30 + 20 + 2 x (3 + 2)` = **60 s** (tested).
* `priorityEnabled = false` turns the same code into the fixed-time baseline.

### Firmware flow (`arduino_ev_priority.ino`)

`setup()` loads the whitelist (EEPROM `'E','V',count, 7-byte UIDs`, else PROGMEM defaults),
initialises SPI and both readers and prints each reader's version register (0x91/0x92 = wired
correctly). `loop()` polls the readers (5 s per-tag debounce, non-whitelisted tags are logged and
ignored), processes serial commands, calls `ctrl.tick(millis())`, writes the 12 LEDs and logs
every phase change plus a stats line every minute. Build with `-DUSE_RFID=0` to replace the
readers with push buttons on the same pins (Wokwi / bench).

## 3. Hardware: wiring and BOM

Full tables in [`hardware/wiring.md`](hardware/wiring.md); prices in [`hardware/bom.csv`](hardware/bom.csv).

| Approach | R / Y / G pins | | RFID | SS | shared |
|---|---|---|---|---|---|
| N | D2 / D3 / D4 | | reader 0 (N) | D10 | SCK 13, MOSI 11, MISO 12, RST 9, 3.3 V |
| S | D5 / D6 / D7 | | reader 1 (E) | A5 | |
| E | D8 / A0 / A1 | | GPS variant HC-12 | D10 rx / D9 tx | SoftwareSerial 9600 |
| W | A2 / A3 / A4 | | | | |

BOM (**all prices are Sept-2026 estimates**, +/-30 %): Uno ~650, 2 x MFRC522 ~300, tags ~60,
12 LEDs + resistors ~50, buttons/breadboard/wires/cable ~330 -> **~1,460 INR** for the RFID
build; GPS add-on (Nano, NEO-6M, 2 x HC-12) **~1,500 INR**.

Practical note: an MFRC522 reads at a few centimetres, so the "reader per approach" needs either a
gantry-mounted reader with the tag on the dashboard or a UHF reader (several metres) - the
firmware's detection layer is the only part that changes.

## 4. Compile status (arduino-cli, 2 Sept 2026)

```
arduino-cli core install arduino:avr
arduino-cli lib install MFRC522 TinyGPSPlus
arduino-cli compile --fqbn arduino:avr:uno firmware/arduino_ev_priority
```

| Sketch | Core / libs | Flash | RAM | Result |
|---|---|---|---|---|
| `arduino_ev_priority` (RFID) | arduino:avr 1.8.8, MFRC522 1.4.12 | 9,130 B (28 %) | 549 B (26 %) | **compiles** |
| `arduino_ev_priority` (`-DUSE_RFID=0`, Wokwi) | arduino:avr 1.8.8 | 6,198 B | 496 B | **compiles** (hex in `wokwi/build/`) |
| `tag_enroll` | MFRC522 | 6,100 B | 334 B | **compiles** |
| `gps_variant/vehicle_gps_beacon` | TinyGPSPlus 1.0.3, SoftwareSerial | 10,578 B | 534 B | **compiles** |
| `gps_variant/controller_gps_receiver` | TinyGPSPlus, SoftwareSerial | 11,956 B | 541 B | **compiles** |

`--warnings all` reports nothing from my code (only unused-parameter warnings inside the AVR core's
`new.cpp`). Compiled is not tested: reader timing on the shared SPI bus, LED polarity, HC-12
range and GPS heading noise all still need a bench check.

### How to flash
1. Arduino IDE 2.x -> Library Manager -> *MFRC522* (GithubCommunity) and *TinyGPSPlus* (Mikal Hart).
2. Open `firmware/arduino_ev_priority/arduino_ev_priority.ino` (the header in the same folder is picked up automatically), board *Arduino Uno*, Upload.
3. Serial monitor 115200: `[whitelist] 2 default tag(s)`, `[rfid] reader 0 ... version 0x92`, then phase changes every few seconds. Type `e` to inject an EV on the east approach.
4. To enrol real tags: flash `firmware/tag_enroll`, present each tag, press `w`; re-flash the controller.
5. GPS variant: flash `vehicle_gps_beacon` on the Nano (unplug the HC-12 from D0/D1 while flashing) and `controller_gps_receiver` on the Uno; set `JUNCTION_LAT/LON`.

## 5. Running the simulation

```bash
pip install -r requirements.txt
python simulation/run_experiments.py        # ~30 s: results/metrics.csv, summary.json, 3 PNGs
python simulation/traffic_sim.py            # single 30-min baseline vs priority run, JSON to stdout
python -m pytest tests -q                   # 26 tests, ~3 s
```

Wokwi: see [`wokwi/README_WOKWI.md`](wokwi/README_WOKWI.md) - paste `diagram.json` and the sketch
(with `USE_RFID 0`) into wokwi.com; the two buttons inject EV detections on N and E.

### Simulation model (`simulation/traffic_sim.py`)
* 4 approaches, Poisson arrivals at 360 veh/h each (v/c ~ 0.5 with a 70 s cycle), EV share
  `p`; each EV calls `ev_detected()` when it passes the detection point (8 s upstream for
  RFID, 20 s ETA for GPS).
* Point queue at the stop line; discharge on green after a 2 s start-up loss at 2 s headways
  (1800 veh/h); a vehicle reaching an empty stop line on green is not delayed.
* Delay = departure - free-flow arrival. The controller is ticked every 100 ms like `loop()`.
* Metrics per run: mean/max/p95 delay for EVs and non-EVs, fraction of EVs stopped, throughput,
  max queue, max non-green time per group, pre-emptions, extensions, denied and expired requests.

## 6. Results (simulation, 1 h x 10 seeds, 360 veh/h/approach)

| Controller | EV share | EV mean delay | non-EV mean delay | all vehicles | non-EV p95 | worst non-EV wait (any run) | EVs stopped | pre-emptions /h | max non-green |
|---|---|---|---|---|---|---|---|---|---|
| fixed-time baseline | any | 16.3-16.8 s | 16.3 s | 16.3 s | 39.6 s | 58.7 s | 76 % | 0 | 40 s |
| EV priority, RFID (8 s lead) | 5 % | **8.1 s (-52 %)** | 17.0 s (+4 %) | 16.6 s | 43.1 s | 94.3 s | 63 % | 24.9 | 60 s |
| | 10 % | **10.7 s (-35 %)** | 17.7 s (+9 %) | 17.0 s | 45.2 s | 94.5 s | 66 % | 35.0 | 60 s |
| | 20 % | 12.2 s (-25 %) | 18.1 s (+11 %) | 16.9 s | 51.1 s | 127.3 s | 67 % | 48.3 | 60 s |
| | 40 % | 14.3 s (-12 %) | 19.1 s (+17 %) | 17.2 s | 54.3 s | 107.0 s | 68 % | 50.8 | 60 s |
| EV priority, GPS (20 s lead) | 5 % | **8.4 s (-50 %)** | 17.5 s | 17.0 s | 46.0 s | 94.7 s | **53 %** | 14.6 | 60 s |
| | 10 % | **10.3 s (-37 %)** | 19.3 s | 18.4 s | 54.1 s | 144.3 s | 55 % | 17.8 | 60 s |
| | 20 % | 13.1 s (-20 %) | 20.3 s | 18.8 s | 56.6 s | 144.2 s | 59 % | 20.3 | 60 s |
| | 40 % | 18.1 s (+11 %) | 22.5 s | 20.7 s | 59.9 s | 142.5 s | 66 % | 14.9 | 60 s |

Throughput is 1,459 veh/h in every configuration (nobody is left in the queue at the end), so
priority redistributes delay rather than destroying capacity at this load.

![delay](results/delay_vs_ev_share.png)
![timeline](results/timeline.png)

What I take from this:

1. **Priority works where it is meant to** - at the EV shares that exist on Indian roads
   today (5-10 %), EV delay halves (16.8 -> 8.1 s) for a 4-9 % increase in everyone else's
   mean delay. The timeline plot shows the mechanism: cross-direction greens are cut at 10 s,
   the all-red is always inserted, and same-direction greens are stretched.
2. **The benefit shrinks as EVs become common.** At 40 % share the fairness guard denies
   most cuts (175 denied vs 51 granted per hour) and EV delay is only 12 % better - which is the
   right behaviour: when every third vehicle is "priority", priority stops meaning anything.
3. **Earlier detection (GPS, 20 s) is not automatically better.** It stops fewer EVs (53 % vs
   63 % at 5 %) but holds greens longer, so non-EVs wait more and the worst single wait rises to
   144 s; at 40 % share it is worse than the baseline for EVs. My first GPS implementation was
   actually *worse* than baseline at every share because the EV green expired just as the EV
   arrived - that is why the controller became ETA-aware (`EV_LEAD_MS`, `EV_CLEAR_MS`,
   `evProtectUntil`); the unit test `test_gps_eta_cut_is_timed_so_green_shows_before_arrival`
   pins this behaviour.
4. **Fairness has a price.** The guards bound the non-green time at 60 s (never exceeded in
   any run), but a non-EV can still sit through up to three cycles (worst 144 s) because a
   10 s green clears only ~4 vehicles. Compensating a cut group with a longer next green is the
   obvious next improvement.

`results/metrics.csv` holds all 120 runs; `results/summary.json` the aggregates and the two
timeline runs; `results/queue_lengths.png` the full-hour queues for seed 3.

## 7. Tests (`python -m pytest tests` - 26 passed)

* **Parity**: the 11 timing constants parsed from the `.h` equal `controller.py`; the GPS
  variant's header copy is byte-identical.
* **Safety** (2 h random EV storms, 5 seeds): never two greens, never green vs yellow; the only
  transitions are green->yellow->all-red->green; every yellow is exactly 3 s and every all-red
  exactly 2 s; every green is between 10 s and 50 s.
* **Guards**: no group is non-green for more than 60 s; no two consecutive cut greens on a group
  (checked against the pre-emption counter); baseline mode cycles at exactly 70 s with zero
  pre-emptions.
* **Behaviour** (deterministic): cross EV cuts at exactly `GREEN_MIN`, 3 s yellow, 2 s all-red,
  EV green covers arrival + 5 s; GPS 20 s ETA cuts at 24 s so green shows 3 s before arrival;
  same-direction extension to 43 s and cap at 50 s; stale request expires; priority off ignores
  detections.
* **Simulation**: EV delay with priority < baseline on 3 seeds; all vehicles served; max
  non-green <= 60 s and non-EV max delay <= 3 cycles at 40 % EV share; deterministic per seed.

## 8. Limitations

* **No hardware testing at all** - see the honesty note. Specific unknowns: MFRC522 read
  reliability at speed (it is a proximity reader; a UHF reader is the realistic choice), SPI bus
  sharing between two readers, HC-12 packet loss, GPS heading noise at low speed (the
  `MIN_SPEED_KMH` and `HEADING_TOL_DEG` filters are untested guesses).
* Two signal groups only (N+S, E+W); no protected right turns, pedestrian phases or
  coordination with neighbouring junctions.
* The traffic model is a point queue with fixed headways; no lane changing, no queue spill-back
  past the RFID reader (which would make the 8 s ETA wrong), no driver reaction to yellow.
* Arrival rates are a single mid-load case (360 veh/h/approach). At higher loads the
  redistribution of delay would be harsher; at lower loads the benefit larger.
* "EV priority" as specified in the brief privileges private vehicles; in practice a city would
  apply this to electric buses / ambulances. The controller does not care what the tag is on.

## 9. References

* Arduino MFRC522 library (miguelbalboa / GithubCommunity), https://github.com/miguelbalboa/rfid
* TinyGPSPlus, Mikal Hart, https://github.com/mikalhart/TinyGPSPlus
* NXP MFRC522 datasheet; u-blox NEO-6 datasheet; HC-12 user manual (SI4463 433 MHz module)
* SimPy documentation, https://simpy.readthedocs.io
* Wokwi Arduino simulator, https://docs.wokwi.com
* IRC:93 *Guidelines on Design and Installation of Road Traffic Signals* (Indian Roads Congress) - yellow / all-red intervals
* Transit Signal Priority Handbook (US FTA, 2005) - green extension / early green concepts adapted here
