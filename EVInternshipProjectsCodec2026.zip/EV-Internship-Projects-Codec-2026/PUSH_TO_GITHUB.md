# Publishing this repo and submitting

## 1. Push to GitHub (one time)
1. On github.com click **New repository**, name it `EV-Internship-Projects-Codec-2026`, keep it **Public**, do NOT tick "Add a README" (this folder already has one). Create it.
2. In a terminal inside this unzipped folder:
   ```bash
   git remote add origin https://github.com/<your-username>/EV-Internship-Projects-Codec-2026.git
   git branch -M main
   git push -u origin main
   ```
   (Git history with one commit per project is already included. If `git` says "not a git repository", run `git init && git add . && git commit -m "EV internship projects"` first.)
3. Open the repo page and check the three project READMEs render with their images (they use relative paths, so they show automatically).

## 2. LinkedIn post (optional but helps)
Post the repo link with a line per project, tag Codec Technologies India, and add a screenshot from `10_EV_Market_Forecast_Dashboard/results/screenshots/dash_overview.png` or `01_BMS_Simulation/results/soc_estimation.png`.

## 3. Submission email
To: vaishali@codectechnologies.in
Subject: EV Internship – Part 01 Project Submission – Eswar Mahalingam

Dear Vaishali,

Please find my Part 01 project submission for the Electric Vehicle internship. I completed all ten projects from the list — BMS simulation, EV charging-station locator app, solar-powered charging station design, AI driving-efficiency optimizer, drivetrain modelling, IoT EV health monitoring, EV lifecycle analysis, smart traffic light with EV priority, wireless charging design and EV market forecast dashboard — each in its own folder with a README, runnable code, automated tests (226 in total, all passing) and generated results.

GitHub: https://github.com/<your-username>/EV-Internship-Projects-Codec-2026
LinkedIn post: <link if posted>

My offer letter is attached.

Regards,
Eswar Mahalingam
+91-9360548243
